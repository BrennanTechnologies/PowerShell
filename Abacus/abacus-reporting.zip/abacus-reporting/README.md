# Abacus-Reporting #

### Overview ###
This module contains reporting functions for use with PowerShell.

### Requirements ###
Requires the Abacus-Reporting module.

```powershell
Import-Abacus-Reporting
or
RequiredModules = @('Abacus-Reporting')
```

### Commands ###

##### Send-EmailReport ####

This function accepts a PowerShell object as input and generates an HTML Email report for output.

#### Examples

Example 1:   
` Send-EmailReport -ReportObject $ReportObject `

Example 2:   
` Send-EmailReport -ReportObject $ReportObject `

Example 3:   
` Send-EmailReport -ReportObject $ReportObject `

Example 4:   
` Send-EmailReport -ReportObject $ReportObject `


### Support for Module ###

Author: cbrennan

Date: 4-12-2020

Contact: devops.all@abacusgroupllc.com
