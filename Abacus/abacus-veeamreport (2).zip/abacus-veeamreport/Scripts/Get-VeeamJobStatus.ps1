<#
.SYNOPSIS
Find the status of all Veeam Jobs and report on jobs that have not run in $JobAgeDays days .

.DESCRIPTION
Find the status of all Veeam Jobs and report on jobs that have not run in $JobAgeDays days .

.PARAMETER VBRServer
Veeam Backup & Restore Server to connect to.

.PARAMETER ServiceAccount
The Active Directory service account used to connect to Veeam VBR

.PARAMETER JobAgeDays
How many days a job has not run.

.EXAMPLE
Get-VeeamJobStatus

#>

function Get-VeeamJobStatus {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false)]
        [string]$VBRServer = "nymgmt-vem01.management.corp"
        ,
        [Parameter(Mandatory = $false)]
        [string]$ServiceAccount = "srv-devopsveeam"
    )
    Begin{
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VeeamReportLog -ForegroundColor DarkGray
        Add-PSSnapin -Name VeeamPSSnapin
        [PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -Domain Management -prefix
        Connect-ABAVBRServer -VBRServer $VBRServer -ServiceAccount $ServiceAccount -Credentials $Credentials
    }
    Process{
        try{
            ### Returns jobs stored in Veeam Backup & Replication d atabase.
            $VBRJobs = Get-VBRJob | Where-Object { $_.JobType -eq "Backup" }
        }
        catch{
            ### Send Alert
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -LogObject $VeeamReportLog -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Exit
        }
        $VeeamJobStatus = @()
        $EnabledJobs    = @()
        $DisabledJobs   = @()
        foreach($VBRJob in $VBRJobs){
            if( ($VBRJob.ScheduleOptions.OptionsDaily.DaysSrv).Count -eq 1 ){
                $JobSchedule     = "Weekly"
                $JobIntervalDays = 7
            }
            elseif( ($VBRJob.ScheduleOptions.OptionsDaily.DaysSrv).Count -eq 7 ){
                $JobSchedule     = "Daily"
                $JobIntervalDays = 1
            }
            else{
                $JobSchedule     = "Other"
            }

            [datetime]$LastSession = $VBRJob.FindLastSession().CreationTime
            [datetime]$JobWindow   = $(Get-Date).AddDays( - $JobIntervalDays )
            [int]$DaysOverDue      = $(($JobWindow - $LastSession).TotalDays)

            $JobStatus = [PSCustomObject]@{
                Name                 = $VBRJob.Name
                JobType              = $VBRJob.JobType
                IsScheduleEnabled    = $VBRJob.IsScheduleEnabled
                JobSchedule          = $JobSchedule
                LastSession          = $VBRJob.FindLastSession().CreationTime
                DaysOverDue          = $DaysOverDue 
            }
            if($DaysOverDue -gt $JobAgeDays){
                if($VBRJob.IsScheduleEnabled -eq $True){
                    $EnabledJobs += $JobStatus
                }
                elseif($VBRJob.IsScheduleEnabled -eq $False){
                    $DisabledJobs += $JobStatus
                }
            }
        }
        [PSCustomObject[]]$VeeamJobStatus = @(
            ($EnabledJobs  | Sort-Object -Property LastSession -Descending),
            ($DisabledJobs | Sort-Object -Property LastSession -Descending)
        )
        if($VeeamJobStatus.Count -lt 1){
            [PSCustomObject]$VeeamJobStatus = New-Object PSObject -Property @{ Results = "No Jobs missing thier scheduled dates.";}
        }
        Return $VeeamJobStatus
    }
    End{
        Disconnect-VBRServer
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VeeamReportLog -ForegroundColor DarkGray
    }
}

Import-Module Abacus-VeeamReport -Force 
Import-Module Abacus-Logging -Force

[PSCustomObject[]]$VeeamJobStatus = Get-VeeamJobStatus 

$ReportSummary = [Ordered]@{
    Description = "Veeam `"Backup`" Jobs Missing Scheduled Run Dates"
    JobType = "Backup"
}

$ReportNotes = @(
    "* This report shows Veeam jobs that have not run within their scheduled dates.",
    "** Disabled jobs are shown on purpose, in case a job was accidentally disabled.",
    "*** These are backup jobs only, not replication or backup copy jobs."
)

Abacus-Logging\Send-EmailReport `
    -ReportData $VeeamJobStatus `
    -ReportSummary $ReportSummary `
    -Subject "Veeam Job Status Report" `
    -ReportNotes $ReportNotes `
    -To "cbrennan@abacusgroupllc.com" `
    -Quiet

