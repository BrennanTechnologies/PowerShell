
[string]$VBRServer = "nymgmt-vem01.management.corp"
[string]$ServiceAccount = "srv-devopsveeam"
[PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix

Add-PSSnapin -Name VeeamPSSnapin
Connect-VBRServer -Server $VBRServer -Credential $Credentials

$VBRJob = Get-VBRJob | Where-Object {$_.Name -eq "NY - Internal Servers"}
$VBRJob.ScheduleOptions.OptionsDaily

$DaysSrv = $VBRJob.ScheduleOptions.OptionsDaily.DaysSrv.Count
$DaysSrv