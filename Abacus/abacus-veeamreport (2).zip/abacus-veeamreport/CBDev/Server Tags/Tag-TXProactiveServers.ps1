$TxServers = @(
    "TXDC-AALDC01",
    "TXDC-AISDC01",
    "TXDC-AMCDC01",
    "TXDC-AULDC01",
    "TXDC-BIPDC01",
    "TXDC-CILDC01",
    "TXDC-COEDC01",
    "TXDC-DLTDC01",
    "TXDC-HNEDC01",
    "TXDC-HPPDC01",
    "TXDC-IISDC01",
    "TXDC-JMCDC01",
    "TXDC-LCNDC01",
    "TXDC-LNSDC01",
    "TXDC-LRPDC01",
    "TXDC-MATDC01",
    "TXDC-NRSDC01",
    "TXDC-OOCDC01",
    "TXDC-PATDC01",
    "TXDC-PFMDC01",
    "TXDC-PFMDDC01",
    "TXDC-RATDC01",
    "TXDC-SIPDC01",
    "TXDC-SISDC01",
    "TXDC-TUCDC01"
)
foreach ($Server in $TXServers){
    #Write-Host "Server: " $Server
    $VM  = VMware.VimAutomation.Core\Get-VM -Name $Server | Select-Object -Property Name, Folder 
    $VMName = $VM.Name
    $VMFolder = $VM.Folder
    $ParentFolder = Get-Folder $VM.Folder | Select Parent #| Select -ExcludeProperty Parent
    if($ParentFolder -like "*Proactive*" ){
        #Write-Host "VM: " $VMName $VMFolder -ForegroundColor Green
        #$ParentFolder #| Select -ExcludeProperty Parent
        
        
        #Get-VM $Server | Get-TagAssignment
        
        #Get-VM "TXDC-AALDC01"
        #Get-TagAssignment -Entity $Server

        
        #####################################
        $TagAssignment = Get-TagAssignment $VMName
        Remove-TagAssignment $TagAssignment -Confirm:$false
        #####################################
        $TagName = "BK_EXEMPT_PBA"
        $Tag = Get-Tag -Name $TagName -Server "txmgmtvc01.management.corp" #| Where{$_.Description -eq "Proactive MSP"}
        Get-VM $Server | New-TagAssignment -Tag $Tag.Name
        #####################################
        $Server

    }
    else {
        Write-Host "VM: " $VMName $VMFolder -ForegroundColor DarkYellow
        #$ParentFolder #| Select -ExcludeProperty Parent
    }
}

#abacus-veeamreport\Connect-ABAvCenters 
#connect-viserver "txmgmtvc01.management.corp"
#Get-VM "TXDC-TUCDC01" | Select-Object -Property *

#Get-Tag -Name "BK_EXEMPT"
#$Category = Get-TagCategory -Name "BackupType" #| Where {$_.Description -eq "Used by vCommander & Veeam"}
#New-Tag -Name "BK_EXEMPT_PBA" -Category $Category  -Description "Proactive MSP" -Server "txmgmtvc01.management.corp"
$global:defaultviservers
$global:DefaultVIServers | ForEach-Object { Disconnect-VIServer -Server $_.Name -Confirm:$false }