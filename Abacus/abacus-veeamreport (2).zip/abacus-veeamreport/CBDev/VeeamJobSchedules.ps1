
Connect-ABAVIServer -All

[string]$VBRServer = "nymgmt-vem01.management.corp"
[string]$ServiceAccount = "srv-devopsveeam"
[PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix

Add-PSSnapin -Name VeeamPSSnapin
Connect-VBRServer -Server $VBRServer -Credential $Credentials


$VBRJobs = Get-VBRJob | Where-Object {$_.TypeToString -eq "VMware Backup" }
$VBRJobs

foreach($VBRJob in $VBRJobs){
    $VBRJob.ScheduleOptions #.OptionsDaily.DaysSrv
    exit
}


foreach($VBRJob in $VBRJobs){
    Write-Host $VBRJob.Name -ForegroundColor Yellow
    if( (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True) -eq $True ){
        $DaysSrv = ($VBRJob.ScheduleOptions.OptionsDaily.DaysSrv).Count
        $DaysSrv #.Count
    }
    elseif( (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True) -eq $False ){
        Write-Host "Other" -ForegroundColor Magenta
        Write-Host "OptionsDaily        : " (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True)
        Write-Host "OptionsMonthly      : " (($VBRJob.ScheduleOptions.OptionsMonthly).Enabled -eq $True)
        Write-Host "OptionsPeriodically : " (($VBRJob.ScheduleOptions.OptionsPeriodically).Enabled -eq $True)
        Write-Host "OptionsContinuous   : " (($VBRJob.ScheduleOptions.OptionsContinuous).Enabled -eq $True)
    }
}


foreach($VBRJob in $VBRJobs){
    Write-Host $VBRJob.Name -ForegroundColor Yellow
    #Write-Host "OptionsDaily        : " (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True)
    #Write-Host "OptionsMonthly      : " (($VBRJob.ScheduleOptions.OptionsMonthly).Enabled -eq $True)
    #Write-Host "OptionsPeriodically : " (($VBRJob.ScheduleOptions.OptionsPeriodically).Enabled -eq $True)
    #Write-Host "OptionsContinuous   : " (($VBRJob.ScheduleOptions.OptionsContinuous).Enabled -eq $True)

    if( (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True) -eq $True ){
        $DaysSrv = $VBRJob.ScheduleOptions.OptionsDaily.DaysSrv
        $DaysSrv.Count
    }
    elseif( (($VBRJob.ScheduleOptions.OptionsDaily).Enabled -eq $True) -eq $False ){
        Write-Host "Other" -ForegroundColor Magenta
    }

}

foreach($VBRJob in $VBRJobs){
    $VBRJob
    exit
    # This cmdlet returns job scheduling options for a selected job.
    $VBRJobScheduleOptions = $VBRJobs | Get-VBRJobScheduleOptions
    if(
        (($VBRJobScheduleOptions.OptionsDaily).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsMonthly).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsPeriodically).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsContinuous).Enabled -eq $True)  `
    )
}

$JobOptions = @(
    "OptionsDaily",
    "OptionsMonthly",
    "OptionsPeriodically",
    "OptionsContinuous"
)


