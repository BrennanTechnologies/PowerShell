$Services = Get-Service -Name Ap* | Select Name,StartType,Status
$Object = [PSCustomObject]@{
    Name       = $Services.Name
    StartType  = $Services.StartType
    Status     = $Services.Status
}
$myServices += $Object

$myProcesses = @()
$Processes = Get-Process  -Name F* | Select ProcessName,Id,Handles
$Object = [PSCustomObject]@{
    ProcessName  = $Processes.ProcessName
    Id           = $Processes.Id
    Handles      = $Processes.Handles
}
$myProcesses += $Object

$myServices
$myProcesses

[array]$Report = @(
    $myServices,
    $myProcesses
)


[PSCustomObject[]]$Report = @(
    $myProcesses
)
$Report | Select -Property Array

$myProcesses.Count
$Report.Count
$Report -is [array]

$myProcesses.GetType()
$Report.GetType()
$Services.GetType()

($Report.GetType() | Select-Object -Property BaseType).BaseType 
$Report.Count

if( ($Report.GetType() | Select-Object -Property BaseType).BaseType -eq "System.Array" )

($Report.GetType()).BaseType

(($Report.GetType()).BaseType).Name

(($myProcesses.GetType()).BaseType).Name
