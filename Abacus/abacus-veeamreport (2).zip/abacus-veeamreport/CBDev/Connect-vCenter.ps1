﻿<#
.SYNOPSIS
Connect to VMWare vCenters.

.DESCRIPTION
Connect to VMWare vCenters.

.PARAMETER Credentials
PSCredentials object to connect to Veeam Backup & Restore Server.

.PARAMETER ABAvCenters
[array] of vCenters to connect.

.PARAMETER ServiceAccount
Service Account to connect to vCenter.

.EXAMPLE
Connect-ABAVCenters @vCenters -SerivceAccount $svcAccount

#>
function Connect-vCenter {
    [CmdletBinding()]
    param( 
        [Parameter(Mandatory = $False)]
        [array]$ABAvCenters =  @(
            "nymgmtvc01.management.corp",
            "sfmgmtvc01.management.corp",
            "l1mgmtvc01.management.corp",
            "txmgmtvc01.management.corp",
            "l2mgmtvc01.management.corp"
        )
        ,
        [Parameter(Mandatory = $False)]
        [string]$ServiceAccount
        ,
        [Parameter(Mandatory = $False)]
        [string]$Site
        ,
        [Parameter(Mandatory = $False)]
        [switch]$PassThru
        ,
        [Parameter(Mandatory = $False)]
        [switch]$Prompt
        ,
        [Parameter(Mandatory = $False)]
        [switch]$Reconnect
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
        $vCenter = $null
        if($Reconnect) {
            <#  IMPORTANT:   
                ----------
                - This setting is important to be aware of because vCenter can allow multiple sessions to be created simultaneously under different Credentials. 
                - This means you can be connected to the same vCenter with two differnt user ID's.
                - Use this Reconnect switch to close previos vCenter sessions.
                Example:
                    PS > $global:defaultviservers
                    Name                           Port  User
                    ----                           ----  ----
                    txmgmtvc01.management.corp     443   MANAGEMENT\srv-devopsvmdeploy
                    txmgmtvc01.management.corp     443   MANAGEMENT\adm-cbrennan        
            #>
            while ($global:DefaultVIServers) {
                if($DeveloperMode) {
                    Write-Host "Closing Previous vCenter Sessions: " $global:DefaultVIServers -ForegroundColor DarkCyan
                }
                $global:DefaultVIServers | ForEach-Object { Disconnect-VIServer -Server $_.name -Confirm:$false }
                $global:DefaultVIServers = $null
                Start-Sleep -Seconds 3
            }
        }
        try{
            ### Get vCenter Credentials
            ###---------------------------------------------
            <#http://duffney.io/AddCredentialsToPowerShellFunctions#>

            $Credentials = $null
            if($PassThru) {
                Write-Host "Connecting to vCenter with Pass through Credentials: " $env:USERNAME -ForegroundColor DarkCyan
                $Credentials = $env:USERNAME
            }
            elseif($Prompt) {
                $Credentials = Get-Credential -Message "Enter Credentials to Connect to vCenter: "
            }
            elseif($ServiceAccount) {
                ### Get Credentials from Secret Server
                ###---------------------------------------------
                Write-Host "Connecting to vCenter with Service Account: " $ServiceAccount -ForegroundColor DarkCyan
                try {
                    [PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix
                }
                catch {
                    $ErrMsg = "ERROR: Invalid Credentials" + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                }
            }
            elseif($DeveloperMode -eq "Authentication") {
                $UserName = "Management\adm-cbrennan"
                #$UserName = Read-Host -Prompt "Enter UserName: "
                $SecPassword = Read-Host -Prompt "Enter Password: " -AsSecureString
                $SecPassword = ConvertTo-SecureString $SecPassword -AsPlainText -Force
                [PSCredential]$Credentials = New-Object System.Management.Automation.PSCredential ($UserName, $SecPassword)
            }
        }
        catch {
            $ErrMsg = "ERROR: Invalid Credentials" + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
        ### Get vCenter Sites
        ###---------------------------------------------
        if($Site) {
            switch ($Site) {
                "NY" { $vCenters = "nymgmtvc01.management.corp" }
                "SF" { $vCenters = "sfmgmtvc01.management.corp" }
                "TX" { $vCenters = "txmgmtvc01.management.corp" }
                "L1" { $vCenters = "l1mgmtvc01.management.corp" }
                "L2" { $vCenters = "l2mgmtvc01.management.corp" }
            }
        }
        else {
            $vCenters = $ABAvCenters
        }
        ### Set WebOperationTimeoutSeconds value.
        ###---------------------------------------------
        Set-PowerCLIConfiguration -WebOperationTimeoutSeconds 180 -DefaultVIServerMode Multiple -Scope Session -InvalidCertificateAction Ignore -DisplayDeprecationWarnings $false -Confirm:$false | Out-Null
    }

    Process {
        ### Connect to VIServers w/ Retry Attemps
        ###---------------------------------------------
        $Retries      = 3
        $RetryCounter = 0
        $t            = 5
        
        foreach ($vCenter in $vCenters) {
            $Connected = $False
            while ( $Connected -ne $True ) {
                try {
                        if($PassThru) {
                            Connect-VIServer -Server $vCenter -ErrorAction Stop
                            $Connected = $True
                        }
                        else {
                            Connect-VIServer -Server $vCenter -Credential $Credentials -ErrorAction Stop
                            $Connected = $True
                        }
                        Write-Log -LogString ("Connected to vCenter: " + $vCenter) -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor Cyan
                    }
                catch {
                    if($RetryCounter -eq $Retries)
                    {
                            ### Send Alert
                            ###---------------------------------------------
                            $ErrMsg = "ERROR: Re-Try Limit Reached: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                            Write-Host $ErrMsg  -ForegroundColor Red
                            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
                            Throw $ErrorMsg
                    }
                    else {
                        $RetryCounter++
                        Write-Host "Re-Attempting to Connect to vCenter: " -ForegroundColor DarkYellow
                        Start-Sleep -Seconds ($t * $RetryCounter )
                    }
                }
            }
        }

        if($DeveloperMode) {
            Write-Host `r`n"vCenters Connected: " -ForegroundColor Cyan
            #$global:DefaultVIServers
        }

        if($DeveloperMode) {
            ### Verify vCenter Connections
            ###---------------------------------------------
            foreach ($vCenter in $vCenters){
                if (($global:defaultviservers).Name -contains $vCenter) {
                    Write-Log -LogString ("Verified vCenter Connection: " + $vCenter) -LogLevel Output -LogObject $VMDeployLogObject  -ForegroundColor DarkGreen
                }
                else{
                    ### Send Alert
                    ###---------------------------------------------
                    $ErrMsg = "ERROR: Failed Verification: " + $((Get-PSCallStack)[0].Command) + "`n`r" 
                    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[0].Command) -Function $((Get-PSCallStack)[0].Command)
                    Throw $ErrorMsg
                }
            }
        }
        if($Site){
            Return $vCenter
        }
        else {
            Return $vCenters
        }
    }
    End {
        ### Reset Switches
        ###---------------------
        $ServiceAccount = $null
        $PassThru       = $null
        $Prompt         = $null

        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}
