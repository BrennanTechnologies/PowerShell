
Connect-ABAVIServer -All

[string]$VBRServer = "nymgmt-vem01.management.corp"
[string]$ServiceAccount = "srv-devopsveeam"
[PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix

Add-PSSnapin -Name VeeamPSSnapin
Connect-VBRServer -Server $VBRServer -Credential $Credentials


<#
Server Group: *FS0*

vCenter	ServerName	TagCategory	TagName	VeeamRestorePoint	FirstSeen
L1	L1DC-CESFS01	BackupType ServerType	BK_GlobalSync_30D_0 FileServer	None	03-01-2020
SF	SFDC-CAVFS01	Not Found	Not Found	None	03-01-2020
NY	NYDC-ICMFS01	BackupType	BK_GlobalSync_30D_0	None	03-01-2020
NY	NYDC-MTSFS01	BackupType	BK_GlobalSync_30D_0	None	04-07-2020
NY	NYDC-PWSFS02	BackupType	BK_GlobalSync_30D_0	None	03-01-2020
#>

#$Server = Get-VM "NYDC-MTSFS01"
#$RestorePoint = Get-VBRRestorePoint -Name $server.Name



$JobOptions = @(
    "OptionsDaily",
    "OptionsMonthly",
    "OptionsPeriodically",
    "OptionsContinuous"
)

# This cmdlet returns jobs stored in Veeam Backup & Replication database.
$VBRJobs = Get-VBRJob | Where-Object {$_.TypeToString -eq "VMware Backup" -AND $_.IsScheduleEnabled -eq $True}

$VBRJobs = Get-VBRJob | Where-Object { `
        $_.FindLastSession().CreationTime -lt (Get-Date).adddays(-2)  `
            -AND  `
        $_.JobType -eq "Backup"  `
    }  `
    #| Select-Object Name, JobType, IsBackupJob, IsScheduleEnabled  | FT #,TypeToString, $($_.FindLastSession().CreationTime)

foreach($VBRJob in $VBRJobs){
    $LastSession = $VBRJob.FindLastSession().CreationTime  #| Where-Object {$_.Result -ne "Success"}
    $LastJob = [Ordered]@{
        Name = $VBRJob.Name
        JobType = $VBRJob.JobType
        IsBackupJob = $VBRJob.IsBackupJob
        IsScheduleEnabled = $VBRJob.IsScheduleEnabled
        LastSession = $LastSession
    }
    $LastJob | FT
    #Write-Host "Job Name    : " $VBRJob.Name -ForegroundColor Cyan
    #Write-Host "Last Result : " $LastSession.Result -ForegroundColor Gray
    #Get-VBRBackup -Name $VBRJob.Name
}


$JobName = "NY - File Server_1"
$VBRJob = Get-VBRJob -Name $JobName
$VBRJob.Name
Get-VBRBackup -Name $VBRJob.Name

$(Get-VBRBackup).name | sort



# This cmdlet returns backups stored in the Veeam Backup & Replication database.
Get-VBRBackup -Name $VBRJobs.Name


#$VBRJobs = Get-VBRJob | Where-Object {$_.JobType -eq "Backup" }
#$VBRJobs = Get-VBRJob | Where-Object {$_.IsBackup -eq $True }
#IsBackupJob
#SheduleEnabledTime

foreach($VBRJob in $VBRJobs){
    $VBRJob
    exit
    # This cmdlet returns job scheduling options for a selected job.
    $VBRJobScheduleOptions = $VBRJob | Get-VBRJobScheduleOptions
    if(
        (($VBRJobScheduleOptions.OptionsDaily).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsMonthly).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsPeriodically).Enabled -eq $True) -OR  `
        (($VBRJobScheduleOptions.OptionsContinuous).Enabled -eq $True)  `
    )
    {
        Write-Host "VBRJobName: " $VBRJob.Name -ForegroundColor Cyan
        #rite-Host "VBRJobName: " $VBRJob.Name -ForegroundColor Cyan
        #$VBRJobScheduleOptions.OptionsDaily
        
        # This cmdlet returns backups stored in the Veeam Backup & Replication database.
        Get-VBRBackup -Name $VBRJob.Name
        CreationTime
        LastPointCreationTime
        MetaUpdateTime
    }
   # $VBRJobScheduleOptions
}

    if($VBRJobScheduleOptions -eq "Everyday"){
        #Write-Host "VBRJob : " $VBRJob.Name -ForegroundColor Yellow
        Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Yellow
    }
    elseif($JobPropertiesKind -eq "SelectedDays"){
        #Write-Host "VBRJob : " $VBRJob.Name -ForegroundColor Magenta
        Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Magenta
    }
    else{
        #Write-Host "VBRJob : " $VBRJob.Name -ForegroundColor Gray
        Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Gray
    }
}

$JobName = "NY - File Server_1"
$JobName = "NY - File Servers 1 Year - Backup Copy"

Get-VBRJob -Name $JobName


Get-VBRJobScheduleOptions -Job $JobName

# This cmdlet returns backups stored in the Veeam Backup & Replication database.
Get-VBRBackup -Name $JobName