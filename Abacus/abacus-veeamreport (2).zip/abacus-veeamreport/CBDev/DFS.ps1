cls



<#
Get DFS NameSpace
-----------------

PS > Get-DfsnRoot

Path                   Type      Properties                      TimeToLiveSec State  Description
----                   ----      ----------                      ------------- -----  -----------
\\Mosaic.local\Private Domain V2 {Target Failback, Site Costing} 300           Online            
\\Mosaic.local\Public  Domain V2 {Target Failback, Site Costing} 300           Online            
\\Mosaic.local\Shares  Domain V2 Site Costing    
#>

$DFSRoots = Get-DfsnRoot

foreach($DFSRoot in $DFSRoots){
    <#
    Get DFS Path
    ------------

    #$DFSPath = "\\Mosaic.local\Shares\*"
    #$DFSPath = "\\Mosaic.local\Private\*"
    #>

    $DFSPath = $DFSRoot.Path + "\*"
    Write-Host "DFSPath        : " $DFSPath -ForegroundColor Yellow
    
    $DfsnFolders = Get-DfsnFolder $DFSPath
    Write-Host "DfsnFolders    : " $DfsnFolders -ForegroundColor Magenta

    foreach($DfsnFolder in $DfsnFolders){
        $DFSTargets = Get-DfsnFolderTarget $DfsnFolder.Path | Select Path,TargetPath
        Write-Host "DFSTargets     : " $DFSTargets -ForegroundColor Cyan    
        foreach($DFSTarget in $DFSTargets){
            Write-Host "DFSPath        : " $DFSTarget.Path -ForegroundColor Gray
            Write-Host "DFSTargetPath  : " $DFSTarget.TargetPath -ForegroundColor Gray
        }
    }
}


Mosaic.local
NYDC-MTSFS01.Mosaic.local
MOSAIC-CA-DC01


### Create Credentials Object
###-----------------------------
#$ServiceAccount = "srv-devopsvmdeploy"
#[PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix
$UserName = "management\adm-cbrennan"
$SecPassword = "Tolkien4374!!"
$SecPassword = ConvertTo-SecureString $SecPassword -AsPlainText -Force
[PSCredential]$Credentials = New-Object System.Management.Automation.PSCredential ($UserName, $SecPassword)


### Create PSSession
###-----------------------------
$NodeName = "NYDC-MTSFS01.Mosaic.local"
$NodeName = "Mosaic\NYDC-MTSFS01"
ping $NodeName
$PSSession = New-PSSession -ComputerName $NodeName -Credential $Credentials


$PSSession = New-PSSession -ComputerName $NodeName -Credential $Credentials

### Create CIMSession
###-----------------------------
$NodeName = "NYDC-TSTDC03.ezevonage.corp"
$CimSession = New-CimSession -ComputerName $NodeName -Credential $Credentials
