$JobPropertiesKind = "Everyday"

if($JobPropertiesKind -eq "Everyday"){
    Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Yellow
}
elseif($JobPropertiesKind -eq "SelectedDays"){
    Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Magenta
}
else{
    Write-Host "Kind   : " $JobPropertiesKind -ForegroundColor Gray
}