Import-Module Abacus-VeeamReport -Force
Import-Module Abacus-Logging -Force

[PSCustomObject]$VeeamJobStatus = Get-VeeamJobStatus

$ReportData1  = [PSCustomObject]@{
    Test = "This is a test."
    Report = "This is a test Report."
    Date = "Today"
}
$ReportData2  = [PSCustomObject]@{
    FName = "Chris"
    MName = "John"
    LName = "Brennan"
}
$ReportData2 | Measure-Object 
$ReportData2.GetType()

$Services = Get-Service -Name Ap* | Select Name,StartType,Status

[array]$ReportData = @(
    $ReportData1,
    $ReportData2,
    $Services,
    $VeeamJobStatus
)
$ReportData | Measure-Object 

$ReportData
$ReportData -is [array]
$ReportData.Count
$ReportData[0]
$ReportData[1]

[PSCustomObject]$Services = Get-Service -Name Ap* | Select Name,StartType,Status

$Services.GetType()

[array]$ReportDataTest = @(
    $Services 
)
[array]$ReportDataTest.Count
$ReportDataTest -is [array]


<#
for ($i=0;$i -lt $ReportData.Count; $i++) {
    $Data= $ReportData[$i]
    Write-Host $Data
    ($ReportData[$i] | Measure-Object).Count
}
#>

$ReportSummary = [Ordered]@{
    Description = "Veeam Job Status"
    JobAgeDays = 2
    JobType = "Backup"
}

$ReportParameters = [Ordered]@{
    Description = "Veeam Job Status"
    JobAgeDays = 2
    JobType = "Backup"
}

$ReportSummary = [Ordered]@{
    Author = "Chris Brennan"
    Company = "Abacus"
    Dept = "DevOps"
}

$ReportNotes = @(
    "* This report shows Veeam jobs that have not run in the last 2 days.",
    "** Disabled jobs are shown on purpose.",
    "*** These are backup jobs only."
)

$ReportFooter = @(
    "* This is a footnote.",
    "** This is a footnote, but a longer footnote.",
    "*** This is a footnote, but a much, much longer longer footnote than usual."
)

Abacus-logging\Send-EmailReport `
    -ReportData $ReportData `
    -ReportParameters $ReportParameters `
    -ReportSummary $ReportSummary `
    -Subject "Veeam Job Status Report" `
    -ReportNotes $ReportNotes `
    -ReportFooter $ReportFooter `
    "Chris" LName "Brennan"


#$VeeamJobStatus | Abacus-VeeamReport\Send-EmailReport -ReportSummary $ReportSummary -Subject "Veeam Job Status"

