function Invoke-localADODataInsert {
    <#
    .SYNOPSIS
    Invoke a .NET ADO Database Connection & Runs a SQL Query to Insert a record.
    
    .DESCRIPTION
    Invoke a .NET ADO Database Connection & Runs a SQL Query to Insert a record.
    
    .PARAMETER ServerInstance
    Invoke a .NET ADO Database Connection & Runs a SQL Query to return a data table object.
    
    .PARAMETER Database
    Specifies the name of a database. This cmdlet connects to this database in the instance that is specified in the ServerInstance parameter.
    
    .PARAMETER Query
    Specifies the SQL query that this function will run. 
    
    .EXAMPLE
    Invoke-ADODataInsert -ServerInstance $ServerInstance -Database $Database -Query $Query

    .OUTPUTS
    ExitCode: Success
    ExitCode: Error
    
    .NOTES
    General notes
    #>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [string]$ServerInstance = "nymgmtdodb01.management.corp\MSSQLSERVER,1433"
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Database
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Query
        )
    Begin {
        ### Create Database Connection String
        ###----------------------------------
        $ConnectionString = "Data Source=$ServerInstance;Initial Catalog=$Database;Integrated Security=true;"
        ### Open DB Connection
        ###----------------------------------
        $Connection = New-Object System.Data.SqlClient.SqlConnection
        $Connection.ConnectionString = $ConnectionString
        $Connection.Open()
        ### SQL Command
        ###----------------------------------
        $SQLCommand = New-Object System.Data.SqlClient.SqlCommand
        $SQLCommand.Connection = $Connection
        $SQLCommand.CommandText = $Query
    }
    Process {
        ### Execute the SQL Query
        ###----------------------------------
        try {
            $SQLCommand.ExecuteNonQuery() | Out-Null
        } catch {
            Write-Warning -Message ("ERROR EXECUTING SQL: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message) 
        }
    }
    End {
        ### Close DB Connection
        ###----------------------------------
        $Connection.Close()
    }
}
function New-SignedScript {
<#
.SYNOPSIS
Code Sign the specified script.

.DESCRIPTION
Code Sign the specified script.

.PARAMETER FilePath
A string that specifies the full path of the script to sign.

.PARAMETER CertFilePath
A string that specifies the full path of certificate to use for signing. It defaults to the Abacus Code Signing Certificate.

.PARAMETER TimeStampServer
Using the TimeStampServer parameter will allow the signed script to execute even after the Cert expires, because the Cert was valid at the time of the signing.

.EXAMPLE
New-SignedScript -FilePath $FilePath

.EXAMPLE
Optional Parameters:
New-SignedScript -FilePath $FilePath -CertFilePath $CertFilePath -TimeStampServer $TimeStampServer

.NOTES

#>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$FilePath
        ,
        [Parameter(Mandatory = $False)]
        [string]$CertFilePath = "\\management.corp\shares\Kits\Certificates\CodeSigning\CodeSigningCert.pfx"
        ,
        [Parameter(Mandatory = $False)]
        [string]$TimeStampServer = 'http://timestamp.digicert.com'
    )
    Begin{
        $UserName = $env:USERNAME
        $ComputerName = $env:COMPUTERNAME
    }
    Process{
        ### Create File for the New Signed Script from the Original
        if(Test-Path -Path $FilePath){
            $SignedScript = (Split-Path -Path $FilePath -Parent) + "\" + (Split-Path -Path $FilePath -Leaf).Split(".")[0] + "-Signed." + (Split-Path -Path $FilePath -Leaf).Split(".")[1] 
            Get-Content -Path $FilePath | Set-Content -Path $SignedScript
        } 
        else {
            Write-Error -Message "File not found. $FilePath" -ErrorAction Stop
        }
        try {
            ### Sign the Script with the Code Signing Signature
            Set-AuthenticodeSignature -FilePath $SignedScript -Certificate @(Get-ChildItem -recurse Cert:\LocalMachine\TrustedPublisher -codesigning | Where-Object {$_.Subject -match "CN=Abacus Group LLC"})[0] -TimeStampServer $TimeStampServer
            ### Verify Signed Script Code Signature
            if( (Get-AuthenticodeSignature -FilePath $SignedScript).Status -eq 'Valid'){
                Write-Host "The script was successfully signed." -ForegroundColor Green
                Write-Host "Signed Script: " $SignedScript -ForegroundColor White
            } 
            else {
                Write-Warning -Message ("Error Verifying Authenticode Signature." ) -ErrorAction Stop
            }
        } 
        catch {
            Write-Warning -Message ("Error Setting Authenticode Signature. `r`n" + $global:Error[0].Exception.Message) -ErrorAction Stop
        }
    }
    End {
        ### Create a Database Record
        $Query = [string] "INSERT INTO [dbo].[ScriptSigning] `
                            ([UserName],[ComputerName],[FilePath],[SignedScript],[CertFilePath]) `
                            VALUES ('$UserName','$ComputerName','$FilePath','$SignedScript','$CertFilePath')"
        Invoke-localADODataInsert -Database "DevOps" -Query $Query
    }
}
