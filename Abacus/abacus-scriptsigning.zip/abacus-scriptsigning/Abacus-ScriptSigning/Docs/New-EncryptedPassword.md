# New-EncryptedPassword #

### Description ###
Create an encrypted a password for use in PowerShell scripts. 

* This cmdlet generates a 256-bit AES Encrypted Key Pair.

### Requirements ###
Requires the Abacus-ScriptSigning module.

```powershell
Import-Abacus-ScriptSigning
or
RequiredModules = @('Abacus-ScriptSigning')
```

### Syntax ###
```powershell
New-EncryptedPassword
    [-KeyFolder <String>]
    [-PasswordFile <String>]
    [-AESKey <String>]
```
 [ ] = Optional Parameter
 
**Example 1:**

* You do not need to enter any parameters.
* You will be prompted to enter the password to be encrypted.

```powershell
New-EncryptedPassword
```
**Example 2:** 

Optional Parameters:

* Optionally, you can specify the output folder for the key pair, and the name of the key files.

```powershell
New-EncryptedPassword -KeyFolder $myFolder -PasswordFile $myPassswordFile -AESKey $myAESKey
```

#### New Encrypted Password Key Pair:  
  
This cmdlet will create a signed copy of the original script in the same directory.

```html
PS > New-EncryptedPassword

The Encrypted Password Key Pair was created in the folder:
\\management.corp\shares\Kits\AESKeys\04-07-2020.07-57-24 

PasswordFile :  \\management.corp\shares\Kits\AESKeys\04-07-2020.07-57-24\Password.txt
AESKey       :  \\management.corp\shares\Kits\AESKeys\04-07-2020.07-57-24\AES.key
```

### Parameters 

##### -KeyFolder

The output folder for the new key pair.

Example:  
`$KeyFolder = "\\management.corp\shares\Kits\AESKeys"`
  
  
##### -PasswordFile  

File name for the encrypted password file.

Example:  
` $PasswordFile = "Password.txt"`
   
   
##### -AESKey  

File name for the AES Key file.

Example:   
` $AESKey = "AES.key" `


### Author ###
Author: Chris Brennan

Date: 4-4-2020

### Support ###
**Known Bugs**

None

**Report Bugs**

bugs.devops@abacusgroupllc.com
