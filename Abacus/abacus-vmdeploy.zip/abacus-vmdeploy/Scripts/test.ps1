cls
Import-Module abacus-vmdeploy -force

$Script = "$PSScriptRoot\Invoke-VMDeploy.ps1"
$JobParams  = $null
$JobParams = @{
    Site        = "NY"
    ClientCode  = "TST"
    ServerType  = "DC"
    FourthOctet = "123"
    #####VMTemplate  = "TEMPLATE_WIN2016" #<--- Use Manual Template?
}
. $Script -JobParams $JobParams

