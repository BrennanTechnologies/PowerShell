Import-Module abacus-vmdeploy -force  ### <--- Here for Development Testing
<#
Param(
    [Parameter(Mandatory = $True,
    HelpMessage = "You must enter a 2 character Site ID ('NY','SF','TX','L1','L2')")]
    [ValidateNotNullOrEmpty()]
    [ValidateLength([int]2, [int]2)]
    [ValidateSet('NY','SF','TX','L1','L2')]
    [string]$Site
    ,
    [Parameter(Mandatory = $True,
    HelpMessage = "You must enter a 3 character Client Code: i.e. ('ABA','CTX','TST')")]
    [ValidateNotNullOrEmpty()]
    [ValidateLength(3,3)]
    #[ValidatePattern('/(.*[a-z]){3}/i')] 
    [string]$ClientCode
    ,
    [Parameter(Mandatory = $True,
    HelpMessage = "You must enter a ServerType: ('FS','DC','CTX','SQL')")]
    [ValidateNotNullOrEmpty()]
    [ValidateSet('FS','DC','CTX','SQL')]
    [string]$ServerType
    ,
    [Parameter(Mandatory = $True,
    HelpMessage = "You must enter a 3 digit 4th Octect of the IP Address: i.e. '123'")]
    [ValidateNotNullOrEmpty()]
    #[ValidateLength(3,3)]
    [ValidatePattern('[0-255]')] 
    [int]$FourthOctet
    ,
    [Parameter(Mandatory = $False)]
    [ValidateNotNullOrEmpty()]
    [string]$VMTemplate = "TEMPLATE_WIN2016"
    ,
    [Parameter(Mandatory = $False)]
    [string]$ServiceAccount = "srv-devopsveeam"
    #[string]$ServiceAccount = "srv-devops"
    ,
    [Parameter(Mandatory = $False)]
    [array]$RequiredModules = 
    @(
        "Abacus-vmDeploy"
        #"VMware.VimAutomation.Core"
    )
)
#>
function Invoke-ADO.SQL
{
    <#
    .SYNOPSIS
    Invoke a .NET ADO Database Connection & Run a SQL Query.
    
    .DESCRIPTION
    Invoke a .NET ADO Database Connection & Run a SQL Query.
    
    .PARAMETER Database
    Database Name
    
    .PARAMETER Query
    SQL Query String
    
    .EXAMPLE
    Invoke-ADO.SQL -Database $Database -Query $Query
    
    .NOTES
    General notes
    #>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Database
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Query
        )

    Begin {
        ### Database Variables
        ###--------------------------
        $DBServer = "nymgmtdodb01.management.corp"
        $ConnectionString = "Server=$DBServer;Initial Catalog=$Database;Integrated Security=True;"

        ### Open DB Connection
        ###--------------------------
        $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
        $Connection.Open()
        $Cmd = New-Object System.Data.SqlClient.SqlCommand
        $Cmd.Connection = $Connection
    }
    Process {
        ### Execute SQL Query
        ###--------------------------
        $cmd.CommandText = $Query
        try {
            $Cmd.ExecuteNonQuery() #| Out-Null
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Error -Message $ErrMsg -ErrorAction Stop ### Using Write-Error because No modules are loaded at this time.
        }
    }
    End {
        ### Close DB Connection
        ###--------------------------
        $Connection.Close()
    }
}
function Add-ServerRequest.ADO.SQL
{
    <#
    .SYNOPSIS
    Insert a New Server Request into the ServerRquest table of the VMDeploy database
    
    .DESCRIPTION
    Insert a New Server Request into the ServerRquest table of the VMDeploy database
    
    .PARAMETER Site
    2 character Site ID. ('NY','SF','TX','L1','L2')

    .PARAMETER ClientCode
    3 character Client Code. ('ABA','CTX')

    .PARAMETER ServerType
    Server TypeCode. ('FS','DC','CTX')
    
    .PARAMETER FourthOctet
    Fourth octet of the IP Address (i.e. 123)
    
    .PARAMETER VMTemplate
    Optional: VM Template name (if specified)
    
    .PARAMETER UserName
    User Name from $env:USERNAME
    
    .PARAMETER Computername
    Computer Name from $env:COMPUTERNAME
    
    .EXAMPLE
        ### Add Server Request to SQL
        ###-----------------------------------------
        $ServerRequest = @{
            Site          = $Site.ToUpper()
            ClientCode    = $ClientCode.ToUpper()
            ServerType    = $ServerType.ToUpper()
            FourthOctet   = $FourthOctet
            VMTemplate    = $VMTemplate
            UserName      = $env:USERNAME
            ComputerName  = $env:COMPUTERNAME
        }
        $RequestID = Add-ServerRequest.ADO.SQL @ServerRequest

    #>

    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$FourthOctet
        ,
        [Parameter(Mandatory = $False)]
        [string]$VMTemplate
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$UserName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Computername
        )

    Begin { }
    Process {
        ### Database Variables
        ###--------------------------
        $Database       = "VMDeploy"
        $Table          = "ServerRequest"

        ### Build SQL Query
        ###--------------------------
        $Query = [string]" 
        INSERT INTO [dbo].[$Table]
            (
                [Site],
                [ClientCode],
                [ServerType],
                [FourthOctet],
                [UserName],
                [ComputerName]
            ) 
            OUTPUT Inserted.RequestID
            VALUES 
            (
                '$Site',
                '$ClientCode',
                '$ServerType',
                '$FourthOctet',
                '$UserName',
                '$ComputerName'
            )
        "
         ### Invoke SQL Query
        ###--------------------------
        $RequestID =  Invoke-ADO.SQL -Database $Database -Query $Query
        #$RequestID =  $RequestID.Item(0)
        Write-Host "RequestID    :" $RequestID -ForegroundColor DarkGray
        Return $RequestID
    }
    End { }
}
function Add-DevOpsJob.ADO.SQL
{
    <#
    .SYNOPSIS
    Insert DevOpsJob record to the DevOpsJobs table in the DevOps database.
    
    .DESCRIPTION
    Insert DevOpsJob record to the DevOpsJobs table in the DevOps database.
    
    .PARAMETER RequestID
    Primary Key of the ServerRequest record.
    
    .PARAMETER JobName
    Name of the job. 
        example:
        $JobName = Split-Path $MyInvocation.PSCommandPath -Leaf
    
    .PARAMETER JobParameters
    Job Parameters
        example:
        $JobParameters  = "Site=$Site, ClientCode=$ClientCode, ServerType=$ServerType"
    
    .PARAMETER JobStatus
        Status of the Job.
            example:
            $JobStatus      = "New Job"
    
    .PARAMETER UserName
    User Name from $env:USERNAME
    
    .PARAMETER Computername
    Computer Name from $env:COMPUTERNAME
    
    .EXAMPLE
        ### Add DevOps Job to SQL
        ###-----------------------------------------
        $DevOpsJob = @{
            RequestID      = $RequestID
            JobName        = $JobName
            JobParameters  = $JobParameters
            JobStatus      = $JobStatus
            UserName       = $env:USERNAME
            ComputerName   = $env:COMPUTERNAME
        }
        $JobID = Add-DevOpsJob.ADO.SQL @DevOpsJob

    #>

    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$RequestID
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$JobName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$JobParameters
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$JobStatus
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$UserName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName
        )

    Begin { }

    Process {
        ### Database Variables
        ###--------------------------
        $Database       = "DevOps"
        $Table          = "DevOpsJobs"

        ### Build SQL Query
        ###--------------------------
        $Query = [string]" 
        INSERT INTO [dbo].[$Table]
            (
                [RequestID],
                [JobName],
                [JobParameters],
                [JobStatus],
                [UserName],
                [ComputerName]
            ) 
            OUTPUT Inserted.JobID
            VALUES 
            (
                '$RequestID',
                '$JobName',
                '$JobParameters',
                '$JobStatus',
                '$UserName',
                '$ComputerName'
            );
        "
<#
        #OUTPUT Inserted.JobID
        #SELECT TOP 1 JobID FROM DevOpsJobs ORDER BY JobID DESC;
        #SELECT SCOPE_IDENTITY() AS [JobID];
        #SELECT SCOPE_IDENTITY() AS [SCOPE_IDENTITY];  
        #SELECT @@IDENTITY AS [@@IDENTITY];  
        #SET @Identity = SCOPE_IDENTITY(); 
#>
        ### Invoke SQL Query
        ###--------------------------
        $JobID =  Invoke-ADO.SQL -Database $Database -Query $Query
        #$JobID =  $JobID.Item(0)
        Write-Host "JobID        :" $JobID -ForegroundColor DarkGray
        Return $JobID
    }
    End { }
}

& {
    Begin{ }
    Process {
        ### New VM Request Input Parameters
        ###-----------------------------------------
        Clear-Host
        Write-Host "Input New VM Parameters: "`r`n -ForegroundColor Cyan
        $Site           = ( Read-Host -Prompt "Input 2-Chararcter Site Code: i.e. (NY, TX, SF, L1, L2) " ).ToUpper()
        $ClientCode     = ( Read-Host -Prompt "Input Client Site Code: i.e. (ABA, TST, FAS) " ).ToUpper()
        $ServerType     = ( Read-Host -Prompt "Input Server Type: i.e. (FS, DC, CTX) " ).ToUpper()
        $FourthOctet    =   Read-Host -Prompt "Input Fourth Octet of IP Address: i.e. (123) "

        ### OPTIONAL: Speciafy VM Template or pull from ServerSpec database table.
        ###-----------------------------------------
        #$VMTemplate    =   Read-Host -Prompt "Input VM Template: i.e. (TEMPLATE_WIN2016) "
        #$VMTemplate     = "TEMPLATE_WIN2016"
        
        ### OPTIONAL: Use PassThru Creds, Service Acct, or Prompt for Creds
        ###-----------------------------------------
        #$Credentials    = Get-Credential -Message "Enter Credentials to Connect to vCenter: "

        $UserName       = $env:USERNAME
        $ComputerName   = $env:COMPUTERNAME
        $JobName        = Split-Path $MyInvocation.PSCommandPath -Leaf
        $JobParameters  = "Site=$Site, ClientCode=$ClientCode, ServerType=$ServerType"
        $JobStatus      = "New Job"
        $script:DeveloperMode  = $True

        ### Add Server Request to SQL
        ###-----------------------------------------
        $ServerRequest = @{
            Site          = $Site.ToUpper()
            ClientCode    = $ClientCode.ToUpper()
            ServerType    = $ServerType.ToUpper()
            FourthOctet   = $FourthOctet
            VMTemplate    = $VMTemplate
            UserName      = $env:USERNAME
            ComputerName  = $env:COMPUTERNAME
        }
        try {
            $RequestID = Add-ServerRequest.ADO.SQL @ServerRequest
        }
        catch {
            Write-Error -Message ("ERROR: " + "`n`r" + $global:Error[0].Exception.Message) -ErrorVariable +ABAError -ErrorAction Continue
        }

        ### Add DevOps Job to SQL
        ###-----------------------------------------
        $DevOpsJob = @{
            RequestID      = $RequestID
            JobName        = $JobName
            JobParameters  = $JobParameters
            JobStatus      = $JobStatus
            UserName       = $env:USERNAME
            ComputerName   = $env:COMPUTERNAME
        }
        try {
            $JobID = Add-DevOpsJob.ADO.SQL @DevOpsJob
        }
        catch {
            Write-Error -Message ("ERROR: " + "`n`r" + $global:Error[0].Exception.Message) -ErrorVariable +ABAError -ErrorAction Continue
        }

        ### Display Job
        ###-----------------------------------------
        Clear-Host
        Write-Host "`r`nQueueing VM for Deployment: `r`n"      -ForegroundColor Cyan
        if($DeveloperMode){
            Write-Host "`tRequestID    : " $RequestID          -ForegroundColor DarkCyan
            Write-Host "`tJobID        : " $JobID              -ForegroundColor DarkCyan
        }
        Write-Host "`r`nJob Details:`r`n "                     -ForegroundColor Cyan
        Write-Host "`tSite         : " $Site                   -ForegroundColor DarkCyan
        Write-Host "`tClientCode   : " $ClientCode             -ForegroundColor DarkCyan
        Write-Host "`tServerType   : " $ServerType             -ForegroundColor DarkCyan
        Write-Host "`tFourthOctet  : " $FourthOctet            -ForegroundColor DarkCyan
        if($VMTemplate){
            Write-Host "`tVMTemplate   : " $VMTemplate         -ForegroundColor DarkCyan
        }
        Write-Host "`tUserName     : " $UserName               -ForegroundColor DarkCyan
        Write-Host "`tComputerName : " $ComputerName           -ForegroundColor DarkCyan
        Write-Host "`tJobStatus    : " $JobStatus  `r`n`r`n    -ForegroundColor DarkCyan

        ### Pause
        Read-Host -prompt  'Press any key to start VM Deployment'
        
        ### Return any Errors
        if($ABAError -eq $True){
            Write-Host "`r`n`r`nABAError: " $ABAError -ForegroundColor DarkGray
        }

        ### Invoke VM Deployment Job
        ###-----------------------------------------
        $InvokeScript = "$PSScriptRoot\Invoke-VMDeploy.ps1"

        $JobParams = @{
            Site        = $Site 
            ClientCode  = $ClientCode 
            ServerType  = $ServerType 
            FourthOctet = $FourthOctet 
            VMTemplate  = $VMTemplate
        }
        . $InvokeScript -JobParams $JobParams
    }
    End {}
}
