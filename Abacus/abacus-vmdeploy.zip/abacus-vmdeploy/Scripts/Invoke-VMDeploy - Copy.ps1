<#
.SYNOPSIS
#

.DESCRIPTION
Long description

.PARAMETER requiredModule
Required Modules.

.PARAMETER ServiceAccount
AD Service Account to authenticate to vCenter

.PARAMETER Site
2 character Site ID. ('NY','SF','TX','L1','L2')

.PARAMETER ClientCode
3 character Client Code. ('ABA','CTX')

.PARAMETER ServerType
Server TypeCode. ('FS','DC','CTX')

.EXAMPLE
An example

.NOTES
General notes
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [PSCustomObject]$JobParams
    ,
    [Parameter(Mandatory = $False)]
    [string]$VMTemplate #= "Get_from_ServerBuildSpecs"
    ,
    [Parameter(Mandatory = $False)]
    [string]$ServiceAccount # = "srv-devopsvmdeploy" vs PassThru Creds
    ,
    [Parameter(Mandatory = $False)]
    [switch]$PassThruCreds
    ,
    [Parameter(Mandatory = $False)]
    [switch]$Prompt
    ,
    [Parameter(Mandatory = $False)]
    [string]$DeveloperMode = $True
    ,
    [Parameter(Mandatory = $False)]
    [array]$RequiredModules = @("Abacus-vmDeploy")
)


& {
    Begin {
        ### Set Script Variables
        ###-----------------------------------------
        $script:ScriptStartTime  = Get-Date
        $global:ConnectionString = "Server=nymgmtdodb01.management.corp;Initial Catalog=VMDeploy;Integrated Security=True;"
        $global:ServerInstance   = 'nymgmtdodb01.management.corp\MSSQLSERVER,1433'

        ### Set DeveloperMode
        ###-----------------------------------------
        if($DeveloperMode){
            $script:DeveloperMode = $True
            Write-Host "DeveloperMode : " $DeveloperMode -ForegroundColor Yellow
            try { Stop-transcript -ErrorAction SilentlyContinue } catch { } 
            Start-Transcript -Path ( $PSScriptRoot + "\logs\Transcript_" + (Split-Path $MyInvocation.PSCommandPath -Leaf) + ".txt" ) -Force 
        } else {
            $script:DeveloperMode = $False
            Write-Host "DeveloperMode : " $DeveloperMode -ForegroundColor Yellow
        }

        ### Import Required Modules
        ###-----------------------------------------
        #Import-Module -Name $RequiredModules -Force

        $modules = @("abacus-portal","abacus-secret")
        foreach($Module in $RequiredModules){
            Get-Module -Name $Module -ListAvailable | Import-Module
        }

########################################################################
<#        
            #  $global:DefaultVIServers | ForEach-Object { Disconnect-VIServer -Server $_.name -Confirm:$false }
            $vCenter = $null
            $DeveloperMode = $True
            #$DeveloperMode = $False
            $ServiceAccount = "srv-devopsvmdeploy"
            $ServiceAccount
            $Site = "NY"
            $Site
            import-module abacus-vmdeploy -force
            #Connect-vCenter -ServiceAccount $ServiceAccount -Reconnect -Site $Site 
            #Connect-vCenter -PassThruCreds -Reconnect #-Site $Site  
            Connect-vCenter -Prompt -Site $Site -ReConnect
            #$DeveloperMode -eq "Authentication"
#>
########################################################################


        ### Connect vCenter
        ###-----------------------------------------
        switch ($Site) {
            "NY" { $vCenter = "nymgmtvc01.management.corp" }
            "SF" { $vCenter = "sfmgmtvc01.management.corp" }
            "TX" { $vCenter = "txmgmtvc01.management.corp" }
            "L1" { $vCenter = "l1mgmtvc01.management.corp" }
            "L2" { $vCenter = "l2mgmtvc01.management.corp" }
        }
        #if($PassThruCreds) {
            #$vCenter = abacus-vmdeploy\Connect-vCenter -PassThruCreds -Site $Site -Reconnect
        #}
        #elseif($Prompt) {
        #    $vCenter = abacus-vmdeploy\Connect-vCenter -Prompt -Site $Site -Reconnect
        #}
        #else {
            $ServiceAccount = "srv-devopsvmdeploy"
            #$VCenter = "nymgmtvc01.management.corp"
            #$vCenter = abacus-vmdeploy\Connect-vCenter -ServiceAccount $ServiceAccount -Site $Site -Reconnect
            #$global:DefaultVIServers = $null
        #}

#&&&&&&&&&&&&&&   WORKING ON THIS !!!! &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        $vCenter = Connect-VIServer -Server $Vcenter        
        $VCENTER = $VCENTER[0].name
        Write-Host "VCENTER: " $VCENTER -ForegroundColor Yellow
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        
    }

    Process {
        ### Add DevOps Job in SQL
        ###-----------------------------------------
        $DevOpsJobParams = @{
            Site       = $Site
            ClientCode = $ClientCode
            ServerType = $ServerType
            JobStatus  = "New Job"
        }
        $JobID = abacus-vmdeploy\Add-DevOpsJob.SQL @DevOpsJobParams

        ### Add New Server Request to SQL
        ###-----------------------------------------
        $NewRequestParams = @{
            Site        = $Site
            ClientCode  = $ClientCode
            ServerType  = $ServerType
            FourthOctet = $FourthOctet
            VMTemplate  = $VMTemplate
        }
        $RequestID = Add-ServerRequest.SQL @NewRequestParams

        ### Get Build ID from SQL
        ###-----------------------------------------
        $BuildID = Get-ServerBuildID.SQL -ServerType $ServerType

        ### Add New Server Record to SQL
        ###-----------------------------------------
        $NewServerParams = @{
            Site        = $Site
            ClientCode  = $ClientCode
            ServerType  = $ServerType
            FourthOctet = $FourthOctet
            VMTemplate  = $VMTemplate
            JobID       = $JobID
            RequestID   = $RequestID
            BuildID     = $BuildID
        }
        $ServerID = Add-Server.SQL @NewServerParams

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "Job Started"

        ### Get Server Build Specifications from SQL
        ###-----------------------------------------
        $BuildSpecs = Get-ServerBuildSpecs.SQL -BuildID $BuildID

        ### Get Client Data from Portal
        ###-----------------------------------------
        $PortalData = Get-PortalData -Site $Site -ClientCode $ClientCode

        ### Get Target Cluster from vCenter
        ###-----------------------------------------
        $Cluster = Get-TargetCluster -vCenter $vCenter
        #$Cluster = Get-TargetCluster -vCenter "nymgmtvc01.management.corp"

        ### Get Target DataStore from vCenter
        ###-----------------------------------------
        $Datastore = Get-TargetDatastore -vCenter $vCenter

        ### Get Next VM Name from vCenter
        ###-----------------------------------------
        $VMName = Get-NextVMName -Site $Site -ClientCode $ClientCode -ServerType $ServerType

        ### Get VM Template from vCenter
        ###-----------------------------------------
        if(!$VMTemplate){
            $VMTemplate = $BuildSpecs.VMTemplate
        }
        $VMTemplate = Get-TargetVMTemplate -VMTemplate $VMTemplate -vCenter $vCenter

        ### Get OSCustomizationSpec from vCenter
        ###-----------------------------------------
        $OSCustomizationSpec = abacus-vmdeploy\Get-OSCustomizationSpec.SQL -BuildID $BuildID

        ### Get IP Address
        ###-----------------------------------------
        $IPObject = Get-IPAddress -Site $Site -VLAN $PortalData.VLAN -FourthOctet $FourthOctet

        ### Update Server Record /w IP Address
        ###-----------------------------------------
        $ConfigParams = @{
            IPAddress      = $IPObject.IPAddress
            SubnetMask     = $IPObject.SubnetMask
            DefaultGateway = $IPObject.DefaultGateway
            PrimaryDNS     = $IPObject.DNS[0]
            SecondaryDNS   = $IPObject.DNS[1]
        }
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### Get VM Location from vCenter
        ###-----------------------------------------
        $Folder = Get-VMFolder -vCenter $vCenter -ClientName $PortalData.ClientName

        ### Get VM Tags
        ###-----------------------------------------
        $Tags = Get-VMTags.SQL -BuildID $BuildID

        ###---------------------------------------
        ### Update Server Record in SQL
        ###---------------------------------------
        $ConfigParams = [ordered]@{

            ### Server Request Data
            ###---------------------------------------
            VMName              = $VMName
            ClientCode          = $ClientCode
            Folder              = $Folder
            Cluster             = $Cluster
            Datastore           = $Datastore
            VMTemplate          = $VMTemplate
            OSCustomizationSpec = $OSCustomizationSpec.Name

            ### Portal Data
            ###---------------------------------------
            VLan                = $PortalData.VLan
            PortGroup           = $PortalData.PortGroup
            ClientID            = $PortalData.ClientID
            ClientName          = $PortalData.ClientName
            ClientDomain        = $PortalData.ClientDomain

            ### Server Build Specifications
            ###---------------------------------------
            ServerType          = $BuildSpecs.ServerType
            Description         = $BuildSpecs.Description
            OSType              = $BuildSpecs.OSType
            NumCPU              = $BuildSpecs.NumCPU
            MemoryGB            = $BuildSpecs.MemoryGB
            Disk0Label          = $BuildSpecs.Disk0Label
            Disk0SizeGB         = $BuildSpecs.Disk0SizeGB
            Disk1Label          = $BuildSpecs.Disk1Label
            Disk1SizeGB         = $BuildSpecs.Disk1SizeGB
        }          
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### New OSCustomizationSpec
        ###---------------------------------------
        #$NewOSCustomizationSpec = abacus-vmdeploy\New-OSCustomizationSpec -vCenter $vCenter -Domain $PortalData.ClientDomain -DomainCredentials $Credentials -OSCustomizationSpec $OSCustomizationSpec
        $NewOSCustomizationSpec = abacus-vmdeploy\New-OSCustomizationSpec -vCenter $vCenter -Domain $PortalData.ClientDomain -OSCustomizationSpec $OSCustomizationSpec

        ### Set OSCustomizationNicMapping
        ###-----------------------------------------
        abacus-vmdeploy\Set-OSCustomizationNICMapping -vCenter $vCenter -OSCustomizationSpec $NewOSCustomizationSpec -IPObject $IPObject

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "Deploying New VM"

        ###---------------------------------------
        ### Deploy New VM
        ###---------------------------------------
        $ConfigParams = @{
            vCenter             = $vCenter
            VMName              = $VMName
            VMTemplate          = $VMTemplate
            OSCustomizationSpec = $OSCustomizationSpec.Name
            ResourcePool        = $Cluster
            Folder              = $Folder
            Datastore           = $Datastore
            DiskStorageFormat   = 'Thin'
        }

        abacus-vmdeploy\New-VM -ConfigParams $ConfigParams
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### Set VM Configuration
        ###-----------------------------------------
        $ConfigParams = @{
            VMName   = $VMName
            NumCPU   = $BuildSpecs.NumCPU 
            MemoryGB = $BuildSpecs.MemoryGB
        }
        abacus-vmdeploy\Set-VMConfiguration -ConfigParams $ConfigParams
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### Set VM Tag Assignment
        ###-----------------------------------------
        $ConfigParams = @{
            VMName  = $VMName
            TagName = "Deployed_by_DevOps"
            #Tags    = $Tags <--- Object from SQL
        }
        Set-VMTagAssignment -vCenter $vCenter -ConfigParams $ConfigParams
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "Starting VM"

        ### Start VM
        ###-----------------------------------------
        Set-VMPowerState -vCenter $vCenter -VMName $VMName -PowerState PowerOn

        ### Wait OSCustomizationSpec
        ###-----------------------------------------
        Write-Host "Waiting for VM to Start." -ForegroundColor Cyan
        $t = 15
        Start-Sleep -Seconds $t
        while (-NOT ($VMTools = Wait-Tools -VM $VMName)) {
            Start-Sleep -Seconds $t
        }
        Write-Host "VM Restarted: " $VMTools -ForegroundColor Cyan

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------`
        Update-ServerRequest.SQL -RequestID $RequestID -Status "VM Started"

        ### Set VM Network Adapter
        ###-----------------------------------------
        $ConfigParams = @{
            VMName    = $VMName
            PortGroup = $PortalData.PortGroup
        }
        abacus-vmdeploy\Set-VMNetworkAdapter -vCenter $vCenter -ConfigParams $ConfigParams
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "VM Started"

        ### Get Guest State
        ###-----------------------------------------
        $GuestStateReady = Get-VMGuestState -VMName $VMName
        if($GuestStateReady -ne $True){
            #Wait-OSCustomization
        }

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "Guest State Ready"

<#
        ### Set Puppet Role
        ###-----------------------------------------
        switch ($ServerType) {
            "FS"  { $PuppetRole = "win_fs" }
            "DC"  { $PuppetRole = "win_dc" }
            "CTX" { $PuppetRole = "win_app_ctx" }
        }
        Read-Host -prompt  'Press any key to start VM Role Config'
        Write-Host "Installing Puppet Agent: " -ForegroundColor Yellow
        Install-PuppetAgent -VMName $VMName
        Write-Host "Installing Puppet Role: " -ForegroundColor Yellow
        Set-PuppetRole -VMame $VMName -PuppetRole $PuppetRole -ClientCode $ClientCode -Site $Site

        $ConfigParams = @{
            ServerType  = $ServerType
            ClientCode  = $ClientCode 
            Site        = $Site
        }
        Set-ServerRole -VMName $VMName -ConfigParams $ConfigParams
        Update-ServerRecord.SQL -ServerID $ServerID -ConfigParams $ConfigParams
#>

        ### Update DevOpsJob/ServerReuest in SQL
        ###-----------------------------------------
        Update-ServerRequest.SQL -RequestID $RequestID -Status "VM Deployed"

        ### Get Deployed Server from SQL
        ###-----------------------------------------
        $ServerConfig = Get-ServerConfig.SQL -ServerID $ServerID

        ### Email Report
        ###-----------------------------------------
        Send-EmailReport -ServerConfig $ServerConfig -JobID $JobID

        ###-----------------------------------------
        ### Write Logs to SQL
        ###-----------------------------------------
        #Add-Logs.SQL -Quite
    }
    End {
        if(!$DeveloperMode) {
            $global:DefaultVIServers | ForEach-Object { Disconnect-VIServer -Server $_.name -Confirm:$false }
        }
        Write-Log -LogString "End Script." -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor Cyan
        Write-Host "Script Run Time:" ($(Get-Date) - $ScriptStartTime)
        if($DeveloperMode){
            try { Stop-transcript -ErrorAction SilentlyContinue | Out-Null } catch { }
        }
    }
}