USE [VMDeploy]
GO

/****** Object:  Table [dbo].[ServerRequest]    Script Date: 2/15/2020 7:12:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ServerRequest](
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[Site] [varchar](2) NULL,
	[ClientCode] [varchar](3) NULL,
	[ServerType] [varchar](5) NULL,
	[FourthOctet] [int] NULL,
	[UserName] [varchar](50) NULL,
	[ComputerName] [varchar](50) NULL,
	[VMTemplate] [varchar](50) NULL,
	[RequestDate] [datetime] NULL,
 CONSTRAINT [PK_ServerRequest] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ServerRequest] ADD  CONSTRAINT [DF_ServerRequest_RequestDate]  DEFAULT (getdate()) FOR [RequestDate]
GO

