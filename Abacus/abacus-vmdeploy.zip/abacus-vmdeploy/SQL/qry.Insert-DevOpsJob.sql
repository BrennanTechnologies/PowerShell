INSERT INTO [dbo].[$Table]
    (
        [RequestID],
        [JobName],
        [JobParameters],
        [JobStatus],
        [UserName],
        [ComputerName]
    ) 
    OUTPUT Inserted.JobID
    VALUES 
    (
        '$RequestID',
        '$JobName',
        '$JobParameters',
        '$JobStatus',
        '$UserName',
        '$ComputerName'
    );
