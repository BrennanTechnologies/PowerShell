USE [VMDeploy]
GO

/****** Object:  Table [dbo].[ServerBuildSpecs]    Script Date: 2/16/2020 7:11:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ServerBuildSpecs](
	[BuildID] [int] IDENTITY(1,1) NOT NULL,
	[ServerType] [char](3) NULL,
	[Description] [varchar](50) NULL,
	[OSType] [varchar](50) NULL,
	[VMTemplate-NOTUSED] [varchar](50) NULL,
	[OSCustomizationSpec] [varchar](100) NULL,
	[NumCPU] [int] NULL,
	[MemoryGB] [int] NULL,
	[Disk0Label] [varchar](25) NULL,
	[Disk0SizeGB] [int] NULL,
	[Disk1Label] [varchar](25) NULL,
	[Disk1SizeGB] [int] NULL,
	[Disk2Label] [varchar](25) NULL,
	[Disk2SizeGB] [int] NULL,
	[Disk3Label] [varchar](25) NULL,
	[Disk3SizeGB] [int] NULL,
	[Disk4Label] [varchar](25) NULL,
	[Disk4SizeGB] [int] NULL,
 CONSTRAINT [PK_ServerBuild] PRIMARY KEY CLUSTERED 
(
	[BuildID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

