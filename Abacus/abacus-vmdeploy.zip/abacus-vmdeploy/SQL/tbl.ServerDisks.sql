USE [VMDeploy]
GO

/****** Object:  Table [dbo].[ServerDisks]    Script Date: 2/16/2020 7:12:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ServerDisks](
	[DiskID] [int] IDENTITY(1,1) NOT NULL,
	[ServerID] [int] NULL,
	[DiskLabel] [nchar](10) NULL,
	[DiskSizeGB] [int] NULL,
 CONSTRAINT [PK_ServerDisks] PRIMARY KEY CLUSTERED 
(
	[DiskID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

