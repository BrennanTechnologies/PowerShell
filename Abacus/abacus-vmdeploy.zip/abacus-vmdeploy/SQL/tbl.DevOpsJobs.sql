USE [DevOps]
GO

/****** Object:  Table [dbo].[DevOpsJobs]    Script Date: 2/15/2020 7:10:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DevOpsJobs](
	[JobID] [int] IDENTITY(1,1) NOT NULL,
	[RequestID] [int] NULL,
	[JobName] [varchar](50) NULL,
	[JobParameters] [varchar](100) NULL,
	[JobStatus] [varchar](50) NULL,
	[UserName] [varchar](50) NULL,
	[ComputerName] [varchar](50) NULL,
	[VMColor] [varchar](50) NULL,
	[JobDate] [date] NULL,
 CONSTRAINT [PK_Jobs] PRIMARY KEY CLUSTERED 
(
	[JobID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DevOpsJobs] ADD  CONSTRAINT [DF_Jobs_Date]  DEFAULT (getdate()) FOR [JobDate]
GO

