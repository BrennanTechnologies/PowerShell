USE [VMDeploy]
GO

/****** Object:  View [dbo].[View_1]    Script Date: 2/16/2020 7:13:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[View_1]
AS
SELECT     dbo.Servers.ServerID, dbo.Servers.RequestID, dbo.Servers.BuildID, dbo.Servers.JobID, dbo.Servers.SiteID, dbo.Servers.ClientCode, dbo.Servers.Client, dbo.Servers.ServerType, dbo.Servers.ServerName, dbo.Servers.Description, dbo.Servers.OSType, 
                  dbo.Servers.VMTemplate, dbo.Servers.OSCustomizationSpec, dbo.Servers.NumCPU, dbo.Servers.MemoryGB, dbo.Servers.Disk0Label, dbo.Servers.Disk0SizeGB, dbo.Servers.Disk1Label, dbo.Servers.Disk1SizeGB, dbo.Servers.Disk2Label, dbo.Servers.Disk2SizeGB, 
                  dbo.Servers.Disk3Label, dbo.Servers.Disk3SizeGB, dbo.Servers.FourthOctet, dbo.Servers.VLAN, dbo.Servers.Cluster, dbo.Servers.Datastore, dbo.Servers.PortGroup, dbo.Servers.ResourcePool, dbo.Servers.Folder
FROM        dbo.VMTemplates INNER JOIN
                  dbo.OSCustomizationSpec INNER JOIN
                  dbo.ServerBuildSpecs ON dbo.OSCustomizationSpec.BuildID = dbo.ServerBuildSpecs.BuildID ON dbo.VMTemplates.BuildID = dbo.ServerBuildSpecs.BuildID INNER JOIN
                  dbo.Servers INNER JOIN
                  dbo.ServerRequest ON dbo.Servers.RequestID = dbo.ServerRequest.RequestID ON dbo.ServerBuildSpecs.BuildID = dbo.Servers.BuildID INNER JOIN
                  dbo.ServerDisks ON dbo.Servers.ServerID = dbo.ServerDisks.ServerID INNER JOIN
                  dbo.DevOpsJobs ON dbo.Servers.JobID = dbo.DevOpsJobs.JobID
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[58] 4[3] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "VMTemplates"
            Begin Extent = 
               Top = 17
               Left = 1320
               Bottom = 229
               Right = 1554
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "OSCustomizationSpec"
            Begin Extent = 
               Top = 296
               Left = 1363
               Bottom = 680
               Right = 1615
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ServerRequest"
            Begin Extent = 
               Top = 34
               Left = 160
               Bottom = 353
               Right = 361
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ServerDisks"
            Begin Extent = 
               Top = 36
               Left = 937
               Bottom = 209
               Right = 1156
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Servers"
            Begin Extent = 
               Top = 21
               Left = 483
               Bottom = 823
               Right = 814
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ServerBuildSpecs"
            Begin Extent = 
               Top = 275
               Left = 917
               Bottom = 776
               Right = 1158
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "DevOpsJobs"
            Begin Extent = 
               Top = 440
               Left = 131
               Bottom = 694
               Right = 325
  ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_1'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'          End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1176
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 1356
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_1'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'View_1'
GO

