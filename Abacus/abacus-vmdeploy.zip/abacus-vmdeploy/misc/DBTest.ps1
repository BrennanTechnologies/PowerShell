

### Database Variables
###--------------------------
$DBServer = "nymgmtdodb01.management.corp"
$Database = "VMDeploy"
$ConnectionString = "Server=$DBServer;Initial Catalog=$Database;Integrated Security=True;"

### Open DB Connection
###--------------------------
$Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
$Connection.Open()
$Cmd = New-Object System.Data.SqlClient.SqlCommand
$Cmd.Connection = $Connection

### Execute SQL Query
###--------------------------
$Site = "NY"
$ClientCode = "TST"
$ServerType = "FS"
$FourthOctet = "222"
$UserName = "CBrennan"
$ComputerName = "CB-1234"


$Query = [string]" 
INSERT INTO [dbo].[ServerRequest]
    (
        [Site],
        [ClientCode],
        [ServerType],
        [FourthOctet],
        [UserName],
        [ComputerName]
    ) 
    VALUES 
    (
        '$Site',
        '$ClientCode',
        '$ServerType',
        '$FourthOctet',
        '$UserName',
        '$ComputerName'
    )
"
#>


$Cmd.CommandText = $Query
$Cmd.ExecuteNonQuery() #| Out-Null

### Close DB Connection
###--------------------------
$Connection.Close()