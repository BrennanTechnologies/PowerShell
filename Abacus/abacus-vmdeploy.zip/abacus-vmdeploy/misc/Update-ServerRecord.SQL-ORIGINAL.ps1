function Update-ServerRecord.SQL {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$ServerID
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VMName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Cluster
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Datastore
        ,
        [Parameter(Mandatory = $False)]
        [string]$VMTemplate
        ,
        [Parameter(Mandatory = $False)]
        [string]$OSCustomizationSpec
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VLAN
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Folder
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$PortGroup
        ,
        [Parameter(Mandatory = $False)]
        [string]$ClientName
        ,
        [Parameter(Mandatory = $False)]
        [string]$ClientDomain
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
        ,
        [Parameter(Mandatory = $False)]
        [string]$Description
        ,
        [Parameter(Mandatory = $False)]
        [string]$OSType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$NumCPU
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$MemoryGB
        ,
        [Parameter(Mandatory = $False)]
        [AllowEmptyString()]
        [string]$Disk0Label
        ,
        [Parameter(Mandatory = $False)]
        [AllowNull()]
        $Disk0SizeGB
        ,
        [Parameter(Mandatory = $False)]
        [AllowEmptyString()]
        [string]$Disk1Label
        ,
        [Parameter(Mandatory = $False)]
        [AllowNull()]
        $Disk1SizeGB
        ,
        [Parameter(Mandatory = $False)]
        [AllowEmptyString()]
        [string]$Disk2Label
        ,
        [Parameter(Mandatory = $False)]
        [AllowNull()]
        $Disk2SizeGB
        ,
        [Parameter(Mandatory = $False)]
        [AllowEmptyString()]
        [string]$Disk3Label
        ,
        [Parameter(Mandatory = $False)]
        [AllowNull()]
        $Disk3SizeGB
        ,
        [Parameter(Mandatory = $False)]
        [AllowEmptyString()]
        [string]$Disk4Label
        ,
        [Parameter(Mandatory = $False)]
        [AllowNull()]
        $Disk4SizeGB

        )

    ###--------------------------------
    ### Write Server Request to SQL
    ###--------------------------------
    Begin {
        if($DeveloperMode){Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkBlue}
    }
    Process {
        ### Database Variables
        ###--------------------------
        $Database = "VMDeploy"
        $Table    = "Servers"

        ### Build SQL Query
        ###--------------------------
        $UpdateQuery = "
            UPDATE [dbo].[$Table] 
                SET 
                    VMName               = '$VMName',
                    ClientCode           = '$ClientCode',
                    Cluster              = '$Cluster',
                    Datastore            = '$Datastore',
                    VMTemplate           = '$VMTemplate',
                    OSCustomizationSpec  = '$OSCustomizationSpec',
                    VLAN                 = '$VLAN',
                    Folder               = '$Folder',
                    PortGroup            = '$PortGroup',
                    ServerType           = '$ServerType',
                    Description          = '$Description',
                    OSType               = '$OSType',
                    NumCPU                  = '$NumCPU',
                    MemoryGB               = '$MemoryGB',
                    Disk0Label           = '$Disk0Label',
                    Disk0SizeGB          = '$Disk0SizeGB',
                    Disk1Label           = '$Disk1Label',
                    Disk1SizeGB          = '$Disk1SizeGB',
                    Disk2Label           = '$Disk2Label',
                    Disk2SizeGB          = '$Disk2SizeGB',
                    Disk3Label           = '$Disk3Label',
                    Disk3SizeGB          = '$Disk3SizeGB',
                    Disk4Label           = '$Disk4Label',
                    Disk4SizeGB          = '$Disk4SizeGB'
            WHERE ServerID               ='$ServerID' 
        GO    
        "
        if($DeveloperMode) {
            Write-Host "dbo.Database             : " $Database            -ForegroundColor Cyan
            Write-Host "dbo.Table                : " $Table               -ForegroundColor Cyan
            Write-Host "dbo.VMName               : " $VMName              -ForegroundColor Cyan
            Write-Host "dbo.ClientCode           : " $ClientCode          -ForegroundColor Cyan
            Write-Host "dbo.Cluster              : " $Cluster             -ForegroundColor Cyan
            Write-Host "dbo.Datastore            : " $Datastore           -ForegroundColor Cyan
            Write-Host "dbo.VMTemplate           : " $VMTemplate          -ForegroundColor Cyan
            Write-Host "dbo.OSCustomizationSpec  : " $OSCustomizationSpec -ForegroundColor Cyan
            Write-Host "dbo.VLAN                 : " $VLAN                -ForegroundColor Cyan
            Write-Host "dbo.Folder               : " $Folder              -ForegroundColor Cyan
            Write-Host "dbo.PortGroup            : " $PortGroup           -ForegroundColor Cyan
            Write-Host "dbo.ServerType           : " $ServerType          -ForegroundColor Cyan
            Write-Host "dbo.Description          : " $Description         -ForegroundColor Cyan
            Write-Host "dbo.OSType               : " $OSType              -ForegroundColor Cyan
            Write-Host "dbo.NumCPU                  : " $NumCPU                 -ForegroundColor Cyan
            Write-Host "dbo.MemoryGB               : " $MemoryGB              -ForegroundColor Cyan
            Write-Host "dbo.Disk0Label           : " $Disk0Label          -ForegroundColor Cyan
            Write-Host "dbo.Disk0SizeGB          : " $Disk0SizeGB         -ForegroundColor Cyan
            Write-Host "dbo.Disk1Label           : " $Disk1Label          -ForegroundColor Cyan
            Write-Host "dbo.Disk1SizeGB          : " $Disk1SizeGB         -ForegroundColor Cyan
            #Write-Host "dbo.Disk2Label           : " $Disk2Label          -ForegroundColor Cyan
            #Write-Host "dbo.Disk2SizeGB          : " $Disk2SizeGB         -ForegroundColor Cyan
            #Write-Host "dbo.Disk3Label           : " $Disk3Label          -ForegroundColor Cyan
            #Write-Host "dbo.Disk3SizeGB          : " $Disk3SizeGB         -ForegroundColor Cyan
            #Write-Host "dbo.Disk4Label           : " $Disk4Label          -ForegroundColor Cyan
            #Write-Host "dbo.Disk4SizeGB          : " $Disk4SizeGB         -ForegroundColor Cyan
        }

        ### Exececute SQL Command
        ###--------------------------
        try {
            Invoke-SQLCmd -ServerInstance $ServerInstance -Database $Database -query $UpdateQuery
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkBlue}  
    }
}