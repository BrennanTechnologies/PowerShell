param(
    $test1,
    $test2
)

Write-Host "Test1: " $test1
Write-Host "Test2: " $test2