function Invoke-InsertSQL
{
    Param( 
        [Parameter(Mandatory = $true)]
        [string]$DataTable
        ,
        [Parameter(Mandatory = $false)]
        [string]$ServerInstance = "nymgmtdodb01.management.corp\MSSQLSERVER,1433"
        ,
        [Parameter(Mandatory = $false)]
        [string]$Database = "DevOps"
        ,
        [Parameter(Mandatory = $false)]
        [string]$Table = "VeeamReport"
    )

    Begin {
        Write-Log -LogString "Start: $((Get-PSCallStack)[0].Command) ... " -LogLevel Output -LogObject $AbacusVeeamReport_global_logobject -ForegroundColor DarkMagenta
<#
        if($null -eq $Credentials){
            ### Get Credentials from Secret Server
            ###---------------------------------------------
            [PSCredential]$Credentials = Get-Secret -SecretName $ServiceAccount | Convert-secretToKerb -domain Management -prefix
        }
#>
    }
    Process {
        ### Get Data
        Write-Host "DataTable: " -ForegroundColor Cyan
        $DataTable | FT

        foreach($record in $DataTable){
            Write-Host "Record: "
            $record
            
            foreach($Column in $Record.PsObject.Properties){
                $Name  = $Column.Name
                $Value = $Column.Value
                Write-Host "Name/Value: " $Name ":" $Value
            }

            $TagGroup          = $record.TagGroup
            $vCenter           = $record.vCenter
            $ServerName        = $record.ServerName
            $TagCategory       = $record.TagCategory
            $TagName           = $record.TagName
            $VeeamRestorePoint = $record.VeeamRestorePoint
            $InitDate          = Get-Date
            
            Write-Host "TagGroup          : " $TagGroup -ForegroundColor DarkCyan
            Write-Host "vCenter           : " $vCenter -ForegroundColor DarkCyan
            Write-Host "ServerName        : " $ServerName -ForegroundColor DarkCyan
            Write-Host "TagCategory       : " $TagCategory -ForegroundColor DarkCyan
            Write-Host "TagName           : " $TagName -ForegroundColor DarkCyan
            Write-Host "VeeamRestorePoint : " $VeeamRestorePoint -ForegroundColor DarkCyan
            Write-Host "InitDate          : " $InitDate -ForegroundColor DarkCyan

            $insertQuery=" 
            INSERT INTO [dbo].[VeeamReport] 
                    (
                        [TagGroup],    
                        [vCenter],
                        [ServerName],
                        [TagCategory],
                        [TagName],
                        [VeeamRestorePoint],
                        [InitDate]
                        ) 
                VALUES 
                    (
                        '$TagGroup',
                        '$vCenter',
                        '$ServerName',
                        '$TagCategory',
                        '$TagName',
                        '$VeeamRestorePoint',
                        '$InitDate'
                        )
            GO 
            " 
            try{
                Invoke-SQLcmd -ServerInstance $serverInstance -Database $database -Query $insertQuery
            }
            catch {
                ### Send Alert
                ###---------------------------------------------
                $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
                Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
                Exit
            }
        }
    }
    End {   
        Write-Log -LogString "End: $((Get-PSCallStack)[0].Command) ... " -LogLevel Output -LogObject $AbacusVeeamReport_global_logobject -ForegroundColor DarkMagenta
    }
}
