### Database Variables
###-----------------------------------------
$Database       = "DevOps"
$Table          = "ServerRequest"
$Site           = $Site
$ClientCode     = $ClientCode
$ServerType     = $ServerType

$ServerRequest = [PSCustomObject]@{
    Table = $Table
    Site = $Site
    ClientCode = $ClientCode
    ServerType = $ServerType
}

### Build SQL Query
###-----------------------------------------
$InsertQuery = [string]" 
INSERT INTO [dbo].[$Table]
    (
        [Site],
        [ClientCode],
        [ServerType]
    ) 
    VALUES 
    (
        '$Site',
        '$ClientCode',
        '$ServerType'
    );"

### Exececute SQL Command
###-----------------------------------------
try {
    #Invoke-SQLcmd -ServerInstance $ServerInstance -Database $Database -query $InsertQuery
    Invoke-SQLcmd -ConnectionString $ConnectionString -Query $InsertQuery
    Write-Host "InsertQuery: `r`n" -ForegroundColor DarkCyan
    $ServerRequest | Format-Table
    
}
catch {
    $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $vmDeploy_global_logobject
}
