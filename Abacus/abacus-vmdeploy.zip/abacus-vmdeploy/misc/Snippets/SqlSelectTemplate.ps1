### Database Variables
###-----------------------------------------
$Database       = "DevOps"
$Table          = "ServerRequest"
$Site           = $Site
$ClientCode     = $ClientCode
$ServerType     = $ServerType

### Build SQL Query
###-----------------------------------------
$SelectQuery = " SELECT * FROM [dbo].[$Table] WHERE ConfigType = '$ServerType' "

### Exececute SQL Command
###-----------------------------------------
try {
    Invoke-SQLcmd -ServerInstance $ServerInstance -Database $Database -query $InsertQuery
}
catch {
    $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $vmDeploy_global_logobject
}
Write-Host "Select Query: " $SelectQuery -ForegroundColor DarkCyan
Return $SelectQuery
