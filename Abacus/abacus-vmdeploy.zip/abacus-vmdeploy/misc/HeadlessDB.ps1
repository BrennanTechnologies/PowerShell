function Invoke-ABASQL
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Query
        )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
        
        ### Database Variables
        ###--------------------------
        $DBServer = "nymgmtdodb01.management.corp"
        $Table = "DevOpsJobs"
        #$ConnectionString = "Server=nymgmtdodb01.management.corp;Initial Catalog=VMDeploy;Integrated Security=True;"
        $ConnectionString = "Server=$DBServer;Initial Catalog=$Table;Integrated Security=True;"

        ### Open DB Connection
        ###--------------------------
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = $ConnectionString 
        $Connection.Open()   
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $cmd.Connection = $Connection
    }
    Process {
        ### Execute SQL Query
        ###--------------------------
        $cmd.CommandText = $Query
        try {
             $cmd.ExecuteNonQuery() | Out-Null
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
    }
    End {
        ### Close DB Connection
        ###--------------------------
        $connection.Close()

        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
}

function Add-DevOpsJob.SQL
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateLength([int]3, [int]3)]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$JobStatus
        )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ### Database Variables
        ###--------------------------
        $Table          = "DevOpsJobs"
        $JobName        = split-path $MyInvocation.PSCommandPath -Leaf
        $JobDescription = "Site=$Site, ClientCode=$ClientCode, ServerType=$ServerType"
        $JobStatus      = "New Job"
        $UserName       = $env:USERNAME
        $ComputerName   = $env:COMPUTERNAME

        ### Build SQL Query
        ###--------------------------
        $Query = [string]" 
        INSERT INTO [dbo].[$Table]
            (
                [JobName],
                [JobDescription],
                [JobStatus],
                [UserName],
                [ComputerName]
            ) 
            OUTPUT Inserted.JobID
            VALUES 
            (
                '$JobName',
                '$JobDescription',
                '$JobStatus',
                '$UserName',
                '$ComputerName'
            )
        GO
        "
 
        ### Invoke SQL Query
        ###--------------------------
        $JobID =  Invoke-ABASQL -Query $Query
        $JobID =  $JobID.Item(0)
        Write-Host "JobID:" $JobID -ForegroundColor Cyan
        Return $JobID
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
}

function Add-ServerRequest.SQL
{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateLength([int]3, [int]3)]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$FourthOctet
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$UserName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Computername
        )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ### Database Variables
        ###--------------------------
        $Table          = "ServerRequest"
        $JobName        = split-path $MyInvocation.PSCommandPath -Leaf
        $JobDescription = "Site=$Site, ClientCode=$ClientCode, ServerType=$ServerType"
        $JobStatus      = "New Job"
        $UserName       = $env:USERNAME
        $ComputerName   = $env:COMPUTERNAME

        ### Build SQL Query
        ###--------------------------
        $Query = [string]" 
        INSERT INTO [dbo].[$Table]
            (
                [Site],
                [ClientCode],
                [ServerType],
                [ServerType],
                [FourthOctet],
                [UserName],
                [ComputerName]
            ) 
            OUTPUT Inserted.JobID
            VALUES 
            (
                '$Site',
                '$ClientCode',
                '$ServerType',
                '$FourthOctet',
                '$UserName',
                '$ComputerName'
            )
        GO
        "
 
        ### Invoke SQL Query
        ###--------------------------
        $JobID =  Invoke-ABASQL -Query $Query
        $JobID =  $JobID.Item(0)
        Write-Host "JobID:" $JobID -ForegroundColor Cyan
        Return $JobID
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
}

& {
    Begin{
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {

        ### Prompt for User Input
        ###-----------------------------------------
        $Site        = Read-Host -Prompt 'Input 2-Chararcter Site Code i.e. (NY, TX, SF, L1, L2, CF): '
        $ClientCode  = Read-Host -Prompt 'Input Client Site Code i.e. (ABA, TST, FAS, LI, L2, CF): '
        $ServerType  = Read-Host -Prompt 'Input Server Type i.e. (FS, DC, CTX, SQL)'
        $FourthOctet = Read-Host -Prompt 'Input Fourth Octet of IP Address i.e. (220)'

        ### Add DevOps Job to SQL
        ###-----------------------------------------
        $DevOpsJob = @{
            JobName        = $JobName
            JobDescription = $JobDescription
            JobStatus      = $JobStatus
            FourthOctet    = $FourthOctet
            UserName       = $UserName
            ComputerName   = $ComputerName
        }
        Add-DevOpsJob.SQL @DevOpsJob

        ### Add Server Request to SQL
        ###-----------------------------------------
        $ServerRequest = @{
            Site           = $Site
            ClientCode     = $ClientCode
            ServerType     = $ServerType
            FourthOctet    = $FourthOctet
            UserName       = $UserName
            ComputerName   = $ComputerName
        }
        Add-ServerRequest.SQL @ServerRequest

        ### Display Job
        ###-----------------------------------------
        Write-Host "The VM has been queued for deployment." -ForegroundColor Cyan
        Write-Host "RequestID  : " $RequestID -ForegroundColor Cyan
        Write-Host "JobID      : " $JobID     -ForegroundColor Cyan

        ### Invoke Deployment Job
        ###-----------------------------------------
        #Invoke-VMDeployJob -Site 'NY' -ClientCode 'TST' -ServerType 'FS' -FourthOctet: '123' -VMTemplate "TEMPLATE_WIN2016"
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }

}
