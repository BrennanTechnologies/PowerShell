﻿Class ABANet {
    [Site]$Site
    [int32]$VLANID
    [String]$IPAddress
    [String]$SubnetMask
    [String]$DefaultGateway
    [String[]]$DNS

    ABANet(
        [Site]$s,
        [string]$vlan,
        [string]$fourth_oct

    ){

        $first_oct = "10"
        $second_oct = -1
        $third_oct = -1
        $d =- 1

        switch -Regex ($s) {
            "ny" {
                
                if($($VLAN -ge 3000)-and $($VLAN -le 3255)){
                    $second_oct = "121"
                    $third_oct = $vlan-3000
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.221.$third_oct.220"
                    )
                }elseif($($VLAN -ge 3600)-and $($VLAN -le 3855)){
                    $second_oct = "122"
                    $third_oct = $vlan-3600
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.223.$third_oct.220"
                    )
                }else{
                    throw "ny site requires a vlan between 3600-3855"
                }
            }
            "sf" {
                if($($VLAN -ge 3300)-and $($VLAN -le 3555)){
                    $second_oct = "11"
                    $third_oct = $vlan-3300
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.222.$third_oct.220"
                    )
                }else{
                    throw "sf site requires a vlan between 3300-3555"
                }
            }
            "ph|tx" {
                if($($VLAN -ge 3000)-and $($VLAN -le 3255)){
                    $second_oct = "221"
                    $third_oct = $vlan-3000
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.121.$third_oct.220"
                    )
                }elseif($($VLAN -ge 3600)-and $($VLAN -le 3855)){
                    $second_oct = "223"
                    $third_oct = $vlan-3600
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.122.$third_oct.220"
                    )
                }elseif($($VLAN -ge 3300)-and $($VLAN -le 3555)){
                    $second_oct = "221"
                    $third_oct = $vlan-3300
                    $d = @(
                        "$first_oct.$second_oct.$third_oct.220",
                        "$first_oct.11.$third_oct.220"
                    )
                }
            }
            "l1" {
                if($($VLAN -ge 0)-and $($VLAN -le 255)){
                    $second_oct = "4"
                    $third_oct = $vlan
                    $d = @(
                            "$first_oct.$second_oct.$third_oct.220",
                            "$first_oct.8.$third_oct.220"
                    )
                }else{
                    throw "l1 site requires a vlan between 0-255"
                }

            }
            "l2" {
                if($($VLAN -ge 0)-and $($VLAN -le 255)){
                    $second_oct = "6"
                    $third_oct = $vlan
                    $d = @(
                            "$first_oct.$second_oct.$third_oct.220",
                            "$first_oct.4.$third_oct.220"
                    )
                }else{
                    throw "l2 site requires a vlan between 0-255"
                }

            }
        }

        $Ip = "$first_oct.$second_oct.$third_oct.$fourth_oct"
        $dg = "$first_oct.$second_oct.$third_oct.254"

        $this.site = $s
        $this.VLANID = $vlan
        $this.IPAddress = $([IPAddress]$Ip).IPAddressToString
        $this.SubnetMask = $([IPAddress]"255.255.255.0").IPAddressToString
        $this.DefaultGateway = $([IPAddress]$dg).IPAddressToString
        $this.DNS = $d
    }
}