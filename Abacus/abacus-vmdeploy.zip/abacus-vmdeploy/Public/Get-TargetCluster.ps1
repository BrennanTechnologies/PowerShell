function Get-TargetCluster {
    [CmdletBinding()]
    param( 
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
    )

$Clusters = Get-Cluster -Server $vCenter

$ClusterResources = @()
foreach($Cluster in $Clusters) {
    $VMHosts = $Cluster | Get-VMhost
    $HostCount = ($VMHosts | Measure-Object).Count
    if(($HostCount -gt 0)) {
        ### Get Cluster View
        ###--------------------------------
        #$ClusterUid                  = $Cluster.Uid
        #$ClustervCenter              = $ClusterUid.Substring($Uid.IndexOf('@')+1).split(':')[0]
        #$ClusterView                 = Get-View -Server $ClustervCenter -Id $Cluster.Id
        $ClusterView                 = Get-View -Server $vCenter -Id $Cluster.Id
        $VMHostsView                 = Get-View $ClusterView.Host -Property Name,Hardware,Config -Server $ClustervCenter
        $HostCount                   = ($VMHostsView | Measure-Object).Count

        ### Get Cluster CPU
        ###--------------------------------
        $pCPUSocket                  = ($VMHostsView | % { $_.Hardware.CPUInfo.NumCpuPackages } | Measure-Object -sum).Sum
        $TpCPUSocket                 = $pCPUSocket
        $pCPUCore                    = ($VMHostsView | % { $_.Hardware.CPUInfo.NumCpuCores } | Measure-Object -sum).Sum
        $CPUSpeed                    = ($VMHostsView |% {[math]::round($_.Hardware.CpuInfo.Hz / 1000000, 2)}| Measure-Object -sum).Sum
        $OverallCPUSpeed             = ($CPUSpeed / $HostCount)
        $TotalCPU                    = (($VMHostsView |% {[math]::round($_.Hardware.CpuInfo.Hz / 1000000, 2)}| Measure-Object -sum).Sum * $pCPUCore)

        ### Get Cluster Memory
        ###--------------------------------
        $TotalClusterRAMGB           = [math]::round($($vmhosts | measure-object -property memorytotalGB -sum).sum)
        $TotalClusterRAMusageGB      = [math]::round($($vmhosts | measure-object -property memoryusageGB -sum).sum)
        $TotalClusterRAMUsagePercent = [math]::round(($TotalClusterRAMusageGB/$TotalClusterRAMGB)*100)
        $TotalClusterRAMFreeGB       = [math]::round(($TotalClusterRAMGB-$TotalClusterRAMUsageGB))
        $TotalClusterRAMReservedGB   = [math]::round(($TotalClusterRAMGB/100)*20)
        $TotalClusterRAMAvailable    = [math]::round(($TotalClusterRAMFreeGB-$TotalClusterRAMReservedGB))

        ### Cluster Resources
        ###--------------------------------
        $Object = [PSCustomObject]@{
            Name            =  $Cluster.Name
            HostCount       =  $HostCount
            CPUSpeedMHz     =  $OverallCPUSpeed
            pCPUSocket      =  $TpCPUSocket
            pCPUCore        =  $pCPUCore
            RAMTotalGB      =  $TotalClusterRAMGB
            RAMUSAGEPercent =  $TotalClusterRAMUsagePercent
            RAMUsageGB      =  $TotalClusterRAMusageGB
            RAMFreeGB       =  $TotalClusterRAMfreeGB
            RAMReservedGB   =  $TotalClusterRAMReservedGB
            AvailableRAMGB  =  $TotalClusterRAMAvailable
            vcenter         = $vcenter
        }
        $ClusterResources += $Object
    }
}

#$ClusterResources | Select-Object Name, AvailableRAMGB | Sort AvailableRAMGB

### Select Cluster with Max AvailableRAMGB
###---------------------------------------------
$MaxAvailableRAMGB = ($ClusterResources | Measure-Object -Property AvailableRAMGB -Maximum).Maximum
Write-Host "MaxAvailableRAMGB: " $MaxAvailableRAMGB -ForegroundColor DarkCyan
$TargetCluster = $ClusterResources | Where-Object { $_.AvailableRAMGB -eq $MaxAvailableRAMGB } 
$Cluster = $TargetCluster.Name

Write-Host "Target Cluster: " $Cluster -ForegroundColor Cyan
Return $Cluster
}

#Get-TargetCluster -vCenter "nymgmtvc01.management.corp"