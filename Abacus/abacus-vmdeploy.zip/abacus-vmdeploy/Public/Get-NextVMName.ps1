Function Get-NextVMName{
    [Cmdletbinding()]
    param( 
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }

    Process {
        $RootVMName = "$($Site)DC-$($ClientCode)$($ServerType)"
        try {
            $VMs = vmware.vimautomation.core\Get-VM -Name $RootVMName*
        }
        catch {
            $ErrMsg = "ERROR: Getting VM -" + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }

        $NumberRange = 1..99
        $VMNumbers = @()
        
        foreach($VM in $VMs){
            $VMNumber = ($VM.Name).Replace($RootVMName,"")
            #$StringNumber = ($VM.Name).Replace($RootVMName,"")
            [string[]]$VMNumbers += $VMNumber
        }

        $FirstNumber = ($VMNumbers | Measure-Object -Maximum -Minimum).Minimum
        $LastNumber  = ($VMNumbers | Measure-Object -Maximum -Minimum).Maximum

#        foreach($Number in $NumberRange) {
#            $array.Contains($Number)
#        }

        $NextNumber  = $LastNumber + 1
        $NextNumber  = $NextNumber.ToString("00")
        $NextVMName  = $RootVMName + $NextNumber
        $NextVMName  = $NextVMName.ToUpper()
        $VMName      = $NextVMName

        if( Get-VM -Name $NextVMName -ErrorAction SilentlyContinue | Out-Null ) {
                ### Send Alert
                ###---------------------------------------------
                $ErrMsg = "ERROR: A VM with this name alreay exists."
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
                Throw $ErrMsg
        }
        if($DeveloperMode){
            Write-Host "Next Number  : " $NextNumber -ForegroundColor Cyan
            Write-Host "Next VM Name : " $NextVMName -ForegroundColor Cyan
        }
        Return $VMName
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}
