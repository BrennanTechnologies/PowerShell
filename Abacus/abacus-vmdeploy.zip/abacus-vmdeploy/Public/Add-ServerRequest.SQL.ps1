<#
.SYNOPSIS
Add Server Reuest to ServerRequest table in VMDeploy database.

.DESCRIPTION
Add Server Reuest to ServerRequest table in VMDeploy database.

.PARAMETER Site
vCenter Site. (i.e. NY, TX, SF, L1, L2)

.PARAMETER ClientCode
3 character Client Code (i.e ABA, CTX, TST)

.PARAMETER ServerType
Server Type (FS, DC, CTX)

.PARAMETER FourthOctet
Fourth Octect of the IP Address (i.e. 222)

.PARAMETER VMTemplate
Optional: VMTemplate Name (if specified)

.EXAMPLE
    ### Add New Server Request to SQL
    ###-----------------------------------------
    $NewRequestParams = @{
        Site        = $Site
        ClientCode  = $ClientCode
        ServerType  = $ServerType
        FourthOctet = $FourthOctet
        VMTemplate  = $VMTemplate
    }
    $RequestID = Add-ServerRequest.SQL @NewRequestParams

.NOTES
Returns the RequestID from SQL.

#>
function Add-ServerRequest.SQL {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientCode
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ServerType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$FourthOctet
        ,
        [Parameter(Mandatory = $False)]
        [string]$VMTemplate
    )

    ###--------------------------------
    ### Write Server Request to SQL
    ###--------------------------------
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ### Database Variables
        ###--------------------------
        $Database       = "VMDeploy"
        $Table          = "ServerRequest"
        $Site           = $Site
        $ClientCode     = $ClientCode
        $ServerType     = $ServerType
        $FourthOctet    = $FourthOctet
        $VMTemplate     = $VMTemplate
        $UserName       = $env:USERNAME
        $ComputerName   = $env:COMPUTERNAME

        if($DeveloperMode){
            Write-Host "Database     : " $Database     -ForegroundColor Cyan
            Write-Host "Table        : " $Table        -ForegroundColor Cyan
            Write-Host "Site         : " $Site         -ForegroundColor Cyan
            Write-Host "ClientCode   : " $ClientCode   -ForegroundColor Cyan
            Write-Host "ServerType   : " $ServerType   -ForegroundColor Cyan
            Write-Host "FourthOctet  : " $FourthOctet  -ForegroundColor Cyan
            Write-Host "VMTemplate   : " $VMTemplate   -ForegroundColor Cyan
            Write-Host "UserName     : " $UserName     -ForegroundColor Cyan
            Write-Host "ComputerName : " $ComputerName -ForegroundColor Cyan
        }

        ### Build SQL Query
        ###--------------------------
        $InsertQuery = [string]" 
        INSERT INTO [dbo].[$Table]
            (
                [Site],
                [ClientCode],
                [ServerType],
                [FourthOctet],
                [VMTemplate],
                [UserName],
                [ComputerName]
            ) 
            OUTPUT Inserted.RequestID
            VALUES 
            (
                '$Site',
                '$ClientCode',
                '$ServerType',
                '$FourthOctet',
                '$VMTemplate',
                '$UserName',
                '$ComputerName'
            )"

        ### Exececute SQL Command
        ###--------------------------
        try {
            $RequestID =  Invoke-SQLcmd -ServerInstance $DatabaseInstance -Database $Database -query $InsertQuery
            $RequestID =  $RequestID.Item(0)
            if($DeveloperMode){
                Write-Host "RequestID:" $RequestID -ForegroundColor DarkCyan
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
        Return $RequestID
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}