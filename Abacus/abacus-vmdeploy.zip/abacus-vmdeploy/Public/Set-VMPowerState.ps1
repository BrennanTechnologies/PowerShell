function Set-VMPowerState {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VMName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('PowerOn','PowerOff','Restart','KILL')]
        [string]$PowerState
        
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ### Get Current PowerState
        ###------------------------------------------------
        $CurrentPowerState = (Get-VM -Name $VMName).PowerState
        if($DeveloperMode){
            Write-Host "Current Power State : " $CurrentPowerState -ForegroundColor Cyan
        }
        ### Set VM Power State
        ###------------------------------------------------
        Write-Host "Setting PowerState  : "  $PowerState -ForegroundColor Cyan
        Switch ($PowerState) {
            PowerOn {
                if($CurrentPowerState -ne "PoweredOn") {
                    try {
                        VMware.VimAutomation.Core\Start-VM -VM $VMName -Server $vCenter -Confirm:$false | Out-Null
                        Start-Sleep -Seconds 30
                    }
                    catch {
                        $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                        Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    }
                }
                else {
                    $ErrMsg = "VM $VMName is already $CurrentPowerState"
                    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                }
            }
            PowerOff {
                if($CurrentPowerState -ne "PoweredOff") {
                    try {
                        VMware.VimAutomation.Core\Stop-VM -VM $VMName -Server $vCenter -Confirm:$false | Out-Null
                        Start-Sleep -Seconds 30
                    }
                    catch {
                        $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                        Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    }
                }
                else {
                    $ErrMsg = "VM $VMName is already $CurrentPowerState"
                    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                }
            }
            Restart {
                if($CurrentPowerState -ne "PoweredOff") {
                    try {
                        VMware.VimAutomation.Core\Restart-VM -VM $VMName -Server $vCenter -Confirm:$false | Out-Null
                        Start-Sleep -Seconds 60
                    }
                    catch {
                        $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                        Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    }
                }
                else {
                    $ErrMsg = "VM $VMName is already $CurrentPowerState"
                    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                }
            }
            KILL {
                if($CurrentPowerState -ne "PoweredOff") {
                    try {
                        VMware.VimAutomation.Core\Stop-VM -VM $VMName -Server $vCenter -Confirm:$false -KILL | Out-Null
                        Start-Sleep -Seconds 30
                    }
                    catch {
                        $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                        Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    }
                    else {
                        $ErrMsg = "VM $VMName is already $CurrentPowerState"
                        Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                    }
                }
            }
        }
        ### Get New PowerState
        ###------------------------------------------------
        $NewPowerState = (Get-VM -Name $VMName).PowerState
        if($DeveloperMode){
            Write-Host "New Power State     : " $NewPowerState -ForegroundColor Cyan
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}