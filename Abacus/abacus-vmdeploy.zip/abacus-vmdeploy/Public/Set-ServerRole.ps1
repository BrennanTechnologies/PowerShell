function Set-ServerRole {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VMName
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ConfigParams
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkCyan
    }
    Process {
        ###--------------------------------
        ### Set Puppet Role
        ###--------------------------------
        switch ($ServerType) {
            "FS"  { $PuppetRole = "win_fs" }
            "DC"  { $PuppetRole = "win_dc" }
            "CTX" { $PuppetRole = "win_app_ctx" }
        }
        try {
            if($PuppetRole){
                Install-PuppetAgent -VMName $VMName
                Set-PuppetRole -VMame $VMName -PuppetRole $PuppetRole -ClientCode $ClientCode -site $Site
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
        }
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkCyan
    }
}