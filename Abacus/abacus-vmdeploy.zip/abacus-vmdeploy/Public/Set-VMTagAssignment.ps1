function Set-VMTagAssignment {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $ConfigParams
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Set VM Tag Assignment
        ###--------------------------------
        $VMName  = $ConfigParams.VMName
        $TagName = $ConfigParams.TagName
        #try {
            ### Create VM Tag
            ###--------------------------------
            if($DeveloperMode){
                Write-Host "VMName    : " $VMName  -ForegroundColor DarkCyan
                Write-Host "TagName   : " $TagName -ForegroundColor DarkCyan
            }
            $Tag     = Get-Tag -Name $TagName
            if(!$Tag) {
                $Tag  = New-Tag -Name $TagName -Description $TagName -Category 'ServerType' -Server $vCenter -Confirm:$False
                Write-Host "Created Tag     : " $Tag -ForegroundColor Cyan
            }
            else {
                Write-Host "Tag Found : " $Tag -ForegroundColor Cyan
            }
            ### Set Tag Assignment
            ###--------------------------------
            $Tag = Get-Tag $TagName
            Get-VM -Name $VMName | New-TagAssignment -Tag $Tag.Name | Out-Null
        #}
        #catch {
        #    $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
        #    Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
       #}
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}