function Set-VMConfiguration {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$ConfigParams
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Set VM Configuration
        ###--------------------------------
        $Params = @{
            NumCPU   = $ConfigParams.NumCPU 
            MemoryGB = $ConfigParams.MemoryGB
        }
        if($DeveloperMode){
            Write-Host "VMName   : " $ConfigParams.VMName   -ForegroundColor DarkCyan
            Write-Host "NumCPU   : " $ConfigParams.NumCPU   -ForegroundColor DarkCyan
            Write-Host "MemoryGB : " $ConfigParams.MemoryGB -ForegroundColor DarkCyan
        }
        try {
            Set-VM -VM $ConfigParams.VMName @Params -Confirm:$False | Out-Null
            if($DeveloperMode){
                Write-Host "Set VM Configuration: $VMName -- NumCPU: " $Params.NumCPU "MemoryGB: " $Params.MemoryGB -ForegroundColor Cyan
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}