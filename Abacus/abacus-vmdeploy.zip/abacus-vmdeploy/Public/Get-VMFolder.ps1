function Get-VMFolder {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientName
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Get VM Folder
        ###--------------------------------
        try {
            $Folder = Get-Folder -Server $vCenter -Name $ClientName -ErrorAction SilentlyContinue
            if(!$Folder) {
                $Datacenter = (Get-Datacenter -Name "*DataCenter*" -Server $vCenter)[0]
                $Location = "Client VMs"
                $Folder = $Datacenter | Get-Folder | Where-Object {$_.Name -eq $Location} | New-Folder -Name $ClientName
                if($DeveloperMode){
                    Write-Host "Created New Folder:  " $Folder -ForegroundColor DarkCyan
                }
            }
            else {
                Write-Host "Folder Found:  " $Folder -ForegroundColor DarkCyan
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
        }
        Return $Folder
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}