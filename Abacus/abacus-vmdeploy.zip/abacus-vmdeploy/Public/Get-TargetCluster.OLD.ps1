Function Get-ABAClusterResources  {
    Param(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)]
        $Cluster_Names
    )

    Begin{
        $cluster_results = @()
    }
    Process{
        foreach($Cluster_Name in $Cluster_Names){

            if($Cluster_Name.GetType().name -ne "ClusterImpl"){
                $Cluster = Get-Cluster $Cluster_Name
            }
            else {
                $Cluster = $Cluster_Name
            }
            $uid = $Cluster.uid
            $vcenter= $uid.Substring($uid.IndexOf('@')+1).Split(':')[0]
            $Cluster_view = Get-View -Server $vcenter -Id $Cluster.Id
            $vmhosts = $Cluster | Get-VMhost
            if (!$($vmhosts | measure).count -gt 0) {
                Write-warning "Zero VMHosts found in cluster:$Cluster_Name"
            }
            else {

                $VMHostsView = $null
                $VMHostsView = Get-View $Cluster_view.Host -Property Name,Hardware,Config -Server $vcenter
                $HostCount   = ($VMHostsView | Measure-Object).Count


                $pNumCPUSocket       = ($VMHostsView | % { $_.Hardware.NumCPUInfo.NumCPUPackages } | Measure-Object -sum).Sum
                $TpNumCPUSocket      = $pNumCPUSocket
                $pNumCPUCore         = ($VMHostsView | % { $_.Hardware.NumCPUInfo.NumCPUCores } | Measure-Object -sum).Sum
                $NumCPUSpeed         = ($VMHostsView |% {[math]::round($_.Hardware.NumCPUInfo.Hz / 1000000, 2)}| Measure-Object -sum).Sum
                $OverallNumCPUSpeed  = ($NumCPUSpeed / $HostCount)
                $TotalNumCPU         = (($VMHostsView |% {[math]::round($_.Hardware.NumCPUInfo.Hz / 1000000, 2)}| Measure-Object -sum).Sum * $pNumCPUCore)


                $TotalClusterRAMGB             = [math]::round($($vmhosts | measure-object -property MemorytotalGB -sum).sum)
                $TotalClusterRAMusageGB        = [math]::round($($vmhosts | measure-object -property MemoryusageGB -sum).sum)
                $TotalClusterRAMUsagePercent   = [math]::round(($TotalClusterRAMusageGB/$TotalClusterRAMGB)*100)
                $TotalClusterRAMFreeGB         = [math]::round(($TotalClusterRAMGB-$TotalClusterRAMUsageGB))
                $TotalClusterRAMReservedGB     = [math]::round(($TotalClusterRAMGB/100)*20)
                $TotalClusterRAMAvailable      = [math]::round(($TotalClusterRAMFreeGB-$TotalClusterRAMReservedGB))


                $vcenter = $Cluster_view.Client.serviceurl.replace("https://","").replace("/sdk","")
                $object = New-Object PSObject
                $object | Add-Member NoteProperty "Name"                  $Cluster_Name
                $object | Add-Member NoteProperty "HostCount"             $HostCount
                $object | Add-Member NoteProperty "NumCPUSpeedMHz"           $OverallNumCPUSpeed
                $object | Add-Member NoteProperty "pNumCPUSocket"            $TpNumCPUSocket
                $object | Add-Member NoteProperty "pNumCPUCore"              $pNumCPUCore
                $object | Add-Member NoteProperty "RAMTotalGB"            $TotalClusterRAMGB
                $object | Add-Member NoteProperty "RAMUSAGE%"             $TotalClusterRAMUsagePercent
                $object | Add-Member NoteProperty "RAMUsageGB"            $TotalClusterRAMusageGB
                $object | Add-Member NoteProperty "RAMFreeGB"             $TotalClusterRAMfreeGB
                $object | Add-Member NoteProperty "RAMReservedGB(20%)"    $TotalClusterRAMReservedGB
                $object | Add-Member NoteProperty "AvailableRAMGB"        $TotalClusterRAMAvailable
                $object | Add-Member NoteProperty "vcenter"        $vcenter
                $cluster_results += $object
            }
        }
    }
    End{
        return $cluster_results
    }


}

function Get-TargetCluster {
    [CmdletBinding()]
    param( 
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $False)]
        [string]$VMDeploymentTargetTag =  "vm_deployment_target"
    )

    Begin {
        if($DeveloperMode){Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
    Process {
        ###--------------------------------
        ### Get Target Cluster
        ###--------------------------------
        try {
            $Clusters = Get-Cluster -Tag $VMDeploymentTargetTag -Server $vCenter
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }

        if($null -ne [bool]$Clusters) {
            try {
                $ClusterResources = $Clusters | Get-ABAClusterResources | Sort-Object -Descending -Property AvailableRAMGB
                $Cluster = ($ClusterResources | Select-Object -First 1).Name.name
            }
            catch {
                $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            }
        }
        elseif($null -eq [bool]$Clusters) {
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "No Clusters Found: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrMsg
        }
        if($null -eq [bool]$Cluster){
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "No Cluster Target Found: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrMsg
        }
        if($DeveloperMode){
            Write-Host "Target Cluster: " $Cluster -ForegroundColor Cyan
        }
        Return $Cluster
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}