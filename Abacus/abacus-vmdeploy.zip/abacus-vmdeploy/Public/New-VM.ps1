function New-VM {
    [CmdletBinding()]
    Param(
#        [Parameter(Mandatory = $True)]
#        [ValidateNotNullOrEmpty()]
#        [string]$vCenter
#        ,    
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$ConfigParams
    )    
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
        $ProgressPreference = "Continue" ### Show/Hide VMWare Cmdlet's Progress Bar - Continue/SilentlyContinue(default)
    }
    Process {
        ###--------------------------------
        ### Deploy New VM
        ###--------------------------------
        $NewVMParams = @{
            Name                = $ConfigParams.VMName 
            Template            = $ConfigParams.VMTemplate
            OSCustomizationSpec = $ConfigParams.OSCustomizationSpec
            Server              = $ConfigParams.vCenter
            ResourcePool        = $ConfigParams.ResourcePool
            Location            = $ConfigParams.Folder
            Datastore           = $ConfigParams.Datastore
            DiskStorageFormat   = $ConfigParams.DiskStorageFormat
        }
        
        if($DeveloperMode){
            Write-Host "New-VM.Params.Name                : " $NewVMParams.Name                -ForegroundColor Cyan
            Write-Host "New-VM.Params.Template            : " $NewVMParams.Template            -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.OSCustomizationSpec : " $NewVMParams.OSCustomizationSpec -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.Server              : " $NewVMParams.Server              -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.ResourcePool        : " $NewVMParams.ResourcePool        -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.Folder              : " $NewVMParams.Location            -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.Datastore           : " $NewVMParams.Datastore           -ForegroundColor DarkCyan
            Write-Host "New-VM.Params.DiskStorageFormat   : " $NewVMParams.DiskStorageFormat   -ForegroundColor DarkCyan
        }

        $CheckVMExists = VMware.VimAutomation.Core\Get-VM -Server $vCenter -Name $NewVMParams.Name -ErrorAction SilentlyContinue
        if( -NOT($CheckVMExists) ) {
            try {
                    Write-Host "Deploying New VM : " $NewVMParams.Name "(Please wait... this may take a while.)" -ForegroundColor Magenta
                    vmware.vimautomation.core\New-VM @NewVMParams -ErrorAction Stop  #-Confirm:$false | Out-Null
                    if(Get-VM -Name $NewVMParams.Name){
                        Write-Host "VM Deployed      : " $NewVMParams.Name -ForegroundColor Yellow
                    }
            }
            catch {
                $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            }
        }
        else {
                ### Send Alert
                ###---------------------------------------------
                $ErrMsg = "ERROR: A VM with this name already exists."
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
                Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
                Throw $ErrMsg
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}