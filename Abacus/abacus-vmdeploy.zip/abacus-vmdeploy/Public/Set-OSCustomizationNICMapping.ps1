function Set-OSCustomizationNICMapping {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$OSCustomizationSpec
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$IPObject
        )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }

    Process {
        ###--------------------------------
        ### Set OSCustomizationNICMapping
        ###--------------------------------
        $IPMode                    = "UseStaticIp "
        [IPAddress]$IPAddress      = $IPObject.IPAddress
        [IPAddress]$SubnetMask     = $IPObject.SubnetMask
        [IPAddress]$DefaultGateway = $IPObject.DefaultGateway
        [IPAddress]$PrimaryDNS     = $IPObject.DNS[0]
        [IPAddress]$SecondaryDNS   = $IPObject.DNS[1]

        if($DeveloperMode) {
            Write-Host "Set OSCustomizationSpecNICMapping : " $OSCustomizationSpec -ForegroundColor Cyan
            Write-Host "NICMapping.OSCustomizationSpec    : " $OSCustomizationSpec -ForegroundColor DarkCyan
            Write-Host "NICMapping.IPMode                 : " $IPMode              -ForegroundColor DarkCyan
            Write-Host "NICMapping.IPAddress              : " $IPAddress           -ForegroundColor DarkCyan
            Write-Host "NICMapping.SubnetMask             : " $SubnetMask          -ForegroundColor DarkCyan
            Write-Host "NICMapping.DefaultGateway         : " $DefaultGateway      -ForegroundColor DarkCyan
            Write-Host "NICMapping.PrimaryDNS             : " $PrimaryDNS          -ForegroundColor DarkCyan
            Write-Host "NICMapping.SecondaryDNS           : " $SecondaryDNS        -ForegroundColor DarkCyan
        }

#        try {

            VMware.VimAutomation.Core\Get-OSCustomizationSpec $OSCustomizationSpec | VMware.VimAutomation.Core\Get-OSCustomizationNicMapping | VMware.VimAutomation.Core\Set-OSCustomizationNicMapping `
                -IPMode 'UseStaticIp' `
                -IpAddress $IPAddress `
                -SubnetMask $SubnetMask `
                -DefaultGateway $DefaultGateway `
                -Dns $PrimaryDNS,$SecondaryDNS `
                 | Out-Null
#        }
#        catch {
#            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
#            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
#        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}