function Send-EmailReport {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$ServerConfig
        ,
        [Parameter(Mandatory = $False)]
        [string]$JobID
        ,
        [Parameter(Mandatory = $False)]
        [string]$To = "" #"cbrennan@abacusgroupllc.com"
        ,
#        [Parameter(Mandatory = $False)]
#        [string]$CC = "" # "cbrennan@abacusgroupllc.com,brennanc@hotmail.com"
#        ,
        [Parameter(Mandatory = $False)]
        [string]$From = "no-reply@accessabacus.com"
        ,
        [Parameter(Mandatory = $False)]
        [string]$Subject = "New Server Provisioning"
        ,
        [Parameter(Mandatory = $False)]
        [string]$smtpServer = "relay-ny.accessabacus.com"
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray

        ### Get DevOps Job Status
        ###---------------------------------------------
        Write-Host "Emailing Report: "  -ForegroundColor Cyan
        $JobStatus = Get-JobStatus.SQL -JobID $JobID
        Write-Host "Job Status   : " $JobStatus -foregroundcolor Yellow
        Write-Host "ABAErrors    : " $ABAError.Count -foregroundcolor Yellow
        Write-Host "VMName       : " $ServerConfig.VMName -foregroundcolor Yellow

        #### Get User Email Address
        ###---------------------------------------------
        $UserName = $env:USERNAME
        if($UserName -like "adm-*" ) {
            $UserName = ($UserName.Split("-")[1] + "_ABA")
            if($DeveloperMode){
                Write-Host "UserName     : " "system02.corp\"$UserName -ForegroundColor Cyan
            }
        }
        $System02EmailAddress = (Get-ADUser -Server "NYSRV2-DC02.service02.corp" -Filter {sAMAccountName -eq $UserName} -SearchBase "DC=service02,DC=corp" -Properties EmailAddress | Select-Object EmailAddress).EmailAddress
        Write-Host "EmailAddress : " $System02EmailAddress -foregroundcolor Cyan
        $UserEmail = $System02EmailAddress

        if($ManagementDomain){
            $ManagementEmailAddress = (Get-ADUser -Server "NYMGMTDC01.management.corp" -Filter {sAMAccountName -eq $UserName} -SearchBase "DC=management,DC=corp" -Properties EmailAddress | Select-Object EmailAddress).EmailAddress
            Write-Host "management.EmailAddress : " $EmailAddress -foregroundcolor Yellow
        }

        ### HTML Head
        ###---------------------------------------------
        $Palette  = "https://www.color-hex.com/color-palette/88338" + "<font color='#05878a'> #003850"
        $htmlHead = ""
        $htmlHead += "<style>"
        $htmlHead += "body{font-family:Verdana,Arial,Sans-Serif; font-size:11px; }"
        $htmlHead += "table{border-width: 1px; border-style: solid; border-color: gray; border-collapse: collapse; }" #width:800px; 
        $htmlHead += "th{font-size:9px; border-width: 1px; padding: 3px; border-style: solid; border-color: gray; color:white; background-color:#00008B; text-align:center; }" #text-align:center background-color: darkblue;
        $htmlHead += "th{font-size:9px; border-width: 1px; padding: 3px; border-style: solid; border-color: gray; color:black; background-color:#C0C0C0; text-align:center; }" #text-align:center background-color: darkblue;
        #$htmlHead += "td{font-size:10px; border-width: 0px; padding: 3px; border-style: solid; border-color: white; }"
        $htmlHead += "td{border-width: 0px; padding: 3px; border-style: solid; border-color: white; }"
        $htmlHead += "</style>"
    }

    Process {
        ### Message Body - Add Header
        ###---------------------------------------------
        $body = ""
        $body += $htmlHead
        $body += "<body>"
        $body += "<i><font size='3';color='gray';>"      + "Abacus DevOps Report:" + "</font></i><br>"
        $body += "<b><font size='4';color='darkblue';>"  + $Subject + "</font></b>"
        $body += "<br>"                                  + "Report Date: "  + $(Get-Date) + "<br><br>"

        ### SERVER REQUEST STATUS :
        ###----------------------------------------------
        $Section = "SERVER REQUEST STATUS : "
        $body += "<br>"
        $body += "<b><font size='1';color='	#003850';>" + $Section + "`r`n" + "</font></b><br>"
        
        if(($ABAError | Measure-Object).Count -lt 1){
            $Status = "Success"
            $StatusColor = "Green"
        }
        else {
            $Status = "Error(s)"
            $StatusColor = "Red"
        }

        $ServerStatus  = [ordered]@{
            JobStatus  = $JobStatus
            Errors     = $ABAError.Count
        }
        $body += "<table>"
#####
#$body += "<tr>"
#$body += "<td width='150';align='right';><font color='gray'>"   + "ServerID"  + "&nbsp; : </td></font>"
#$body += "<td align='left';><font color='black'>"               + $ServerConfig.ServerID + "</td></font>"
#$body += "</tr>"
$body += "<tr>"
$body += "<td width='150';align='right';><font color='gray'>"   + "VMName"  + "&nbsp; : </td></font>"
$body += "<td align='left';><font size='2';color='#05878a'><b>" + $ServerConfig.VMName + "</b></td></font>"
$body += "</tr>"
#####
        $body += "<tr>"
        $body += "<td width='150';align='right';><font color='gray'>" + "Status"  + "&nbsp; : </td></font>"
        $body += "<td align='left';><font color=$StatusColor><b>"          + $Status + "</b></td></font>"
        $body += "</tr>"
        foreach($Param in $ServerStatus.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$ServerStatus
        
        ### SERVER INFORMATION :
        ###----------------------------------------------
        $Section = "SERVER INFORMATION : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
        $ServerInfo = [ordered]@{
            ServerID             = $ServerConfig.ServerID
            Site                 = $ServerConfig.Site
            ClientName           = $ServerConfig.ClientName
            ClientDomain         = $ServerConfig.ClientDomain
            ServerType           = $ServerConfig.ServerType
        }
        $body += "<table>"

#        $body += "<tr>"
#        $body += "<td width='150';align='right';><font color='gray'>"   + "ServerID"  + "&nbsp; : </td></font>"
#        $body += "<td align='left';><font color='black'>"               + $ServerConfig.ServerID + "</td></font>"
#        $body += "</tr>"
#        $body += "<tr>"
#        $body += "<td width='150';align='right';><font color='gray'>"   + "VMName"  + "&nbsp; : </td></font>"
#        $body += "<td align='left';><font size='2';color='#05878a'><b>" + $ServerConfig.VMName + "</b></td></font>"
#        $body += "</tr>"

        foreach($Param in $ServerInfo.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$ServerInfo

        ### REQUEST INFORMATION :
        ###----------------------------------------------
        $Section = "REQUEST INFORMATION : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
        $RequestInfo = [ordered]@{
            RequestedBy          = $ServerConfig.UserName
            ClientName           = $ServerConfig.ClientName
            ClientCode           = $ServerConfig.ClientCode
            RequestID            = $ServerConfig.RequestID
            BuildID              = $ServerConfig.BuildID
            JobID                = $ServerConfig.JobID
        }
        $body += "<table>"
        foreach($Param in $RequestInfo.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$RequestInfo

        ### SERVER SPECIFICATIONS :
        ###----------------------------------------------
        $Section = "SERVER SPECIFICATIONS : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
        $ServerSpecs = [ordered]@{
            NumCPU               = $ServerConfig.NumCPU
            MemoryGB             = $ServerConfig.MemoryGB
            Description          = $ServerConfig.Description
            OSType               = $ServerConfig.OSType
            vCenter              = $ServerConfig.vCenter
            VMTemplate           = $ServerConfig.VMTemplate
            OSCustomizationSpec  = $ServerConfig.OSCustomizationSpec
        }
        $body += "<table>"
        foreach($Param in $ServerSpecs.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$ServerSpecs

        ### IP ADDRESS :
        ###----------------------------------------------
        $Section = "IP ADDRESS INFORMATION : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
        $IPInfo = [ordered]@{
            IPAddress            = $ServerConfig.IPAddress
            SubnetMask           = $ServerConfig.SubnetMask
            DefaultGateway       = $ServerConfig.DefaultGateway
            PrimaryDNS           = $ServerConfig.PrimaryDNS
            SecondaryDNS         = $ServerConfig.SecondaryDNS
        }
        $body += "<table>"
        foreach($Param in $IPInfo.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$IPInfo
        
        ### VMWARE INFORMATION :
        ###----------------------------------------------
        $Section = "VMWARE INFORMATION : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
        $VMWareInfo = [ordered]@{
            Cluster              = $ServerConfig.Cluster
            Datastore            = $ServerConfig.Datastore
            VLAN                 = $ServerConfig.VLAN
            Folder               = $ServerConfig.Folder
            PortGroup            = $ServerConfig.PortGroup
            ResourcePool         = $ServerConfig.ResourcePool
            DiskStorageFormat    = $ServerConfig.DiskStorageFormat  
            TagName              = $ServerConfig.TagName
        }
        $body += "<table>"
        foreach($Param in $VMWareInfo.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$VMWareInfo

        ### DISK CONFIGURATION :
        ###----------------------------------------------
        $Section = "DISK INFORMATION : "
        $body += "<br>"
        $body += "<b><font size='1';color='#003850';>" + $Section + "`r`n" + "</font></b><br>"
<#
        if(!$ServerConfig.Disk0Label){$ServerConfig.Disk0Label = "<none>"}
        if(!$ServerConfig.Disk1Label){$ServerConfig.Disk1Label = "<none>"}
        if(!$ServerConfig.Disk2Label){$ServerConfig.Disk2Label = "<none>"}
        if(!$ServerConfig.Disk3Label){$ServerConfig.Disk3Label = "<none>"}
        if(!$ServerConfig.Disk4Label){$ServerConfig.Disk4Label = "<none>"}
#>
        $DiskInfo = [ordered]@{
            Disk0Label           = $ServerConfig.Disk0Label
            Disk0SizeGB          = $ServerConfig.Disk0SizeGB
            Disk1Label           = $ServerConfig.Disk1Label
            Disk1SizeGB          = $ServerConfig.Disk1SizeGB
            #Disk2Label           = $ServerConfig.Disk2Label
            #Disk2SizeGB          = $ServerConfig.Disk2SizeGB
            #Disk3Label           = $ServerConfig.Disk3Label
            #Disk3SizeGB          = $ServerConfig.Disk3SizeGB
            #Disk4Label           = $ServerConfig.Disk4Label
            #Disk4SizeGB          = $ServerConfig.Disk4SizeGB
        }
        if(!$DiskInfo.Disk0Label){$DiskInfo.Disk0Label = "<none>"}
        if(!$DiskInfo.Disk1Label){$DiskInfo.Disk1Label = "<none>"}
        #if(!$DiskInfo.Disk2Label){$DiskInfo.Disk2Label = "<none>"}
        #if(!$DiskInfo.Disk3Label){$DiskInfo.Disk3Label = "<none>"}
        #if(!$DiskInfo.Disk4Label){$DiskInfo.Disk4Label = "<none>"}

        #### $body += $DiskInfo.GetEnumerator() | Select-Object Name, Value | ConvertTo-Html -Fragment
        $body += "<table>"
        foreach($Param in $DiskInfo.GetEnumerator()){
            $body += "<tr>"
            $body += "<td width='150';align='right';><font color='gray'>" + $Param.Name  + "&nbsp; : </td></font>"
            $body += "<td align='left';><font color='black'>"             + $Param.Value + "</td></font>"
            $body += "</tr>"
        }
        $body += "</table>"
        #Write-Host `r`n$Section -ForegroundColor Cyan
        #$DiskInfo

        ### End Body
        ###-----------------
        $body += "<br><br><font color='gray'>Total Deployment Time:   " + ($(Get-Date) - $ScriptStartTime) + "<br><br>"

        $body += "</body>"

        ### Send Email Message
        ###---------------------------------------------
        try {
            #-To           (($To + "," + $UserEmail) -Split ",")  `
            #-CC           ($CC -Split ",")   `
            Send-MailMessage  `
                -SmtpServer   $smtpServer `
                -To           $UserEmail  `
                -From         $From `
                -Body         $body `
                -Subject      $Subject `
                -BodyAsHtml
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}