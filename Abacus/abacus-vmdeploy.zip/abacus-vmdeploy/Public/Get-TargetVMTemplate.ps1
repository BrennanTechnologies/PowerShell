function Get-TargetVMTemplate {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VMTemplate
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Get VM Template
        ###--------------------------------
        try {
            $VMTemplate = Get-Template -Name $VMTemplate -Server $vCenter
        }
        catch {
            $ErrMsg = "ERROR: Getting VM -" + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
        if($null -eq [bool]$VMTemplate) {
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "No Clusters Found: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrMsg
        }
        if($DeveloperMode){
            Write-Host "VMTemplate: " $VMTemplate -ForegroundColor Cyan
        }
        Return $VMTemplate
    }

    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}