
function Wait-OSCustomization {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkMagenta
    }

    Process {
        ###--------------------------------
        ### Wait OS Customization
        ###--------------------------------
        try {


            
            $t = 60
            Start-Sleep -Seconds $t
            while (-NOT ($VMTools = Wait-Tools -VM $VMName)) {
                Start-Sleep -Seconds $t
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
        }
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkMagenta
    }
}