function New-OSCustomizationSpec {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        , 
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Domain
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$OSCustomizationSpec
#        , 
#        [Parameter(Mandatory = $False)]
#        [PSCredential]$ServiceAccount = "srv-devopsvmdeploy"
#        , 
#        [Parameter(Mandatory = $True)]
#        [ValidateNotNullOrEmpty()]
#        [PSCredential]$DomainCredentials
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }

    Process {
        ###-------------------------------------------
        ### New OS Customization Spec
        ###-------------------------------------------

        ### Remove Existing OSCustimizationSpec
        ###-------------------------------------------
        $CheckOSSpecExists = Get-OSCustomizationSpec $OSCustomizationSpec.Name -ErrorAction SilentlyContinue
        if( $CheckOSSpecExists ) {
            try {
                Remove-OSCustomizationSpec -OSCustomizationSpec $CheckOSSpecExists -Confirm:$False
            }
            catch {
                $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
                Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            }
        }

        ### New OS Customization Spec
        ###-------------------------------------------
        Switch ($Site) {
            "NY" { $TimeZone = '035' }
            "SF" { $TimeZone = '004' }
            "TX" { $TimeZone = '015' }
            "L1" { $TimeZone = '000' }
            "L2" { $TimeZone = '000' }
            "CF" { $TimeZone = '000' }
          }

          $NewOSCustomizationSpecParams = @{
            Name                  = $OSCustomizationSpec.Name
            Description           = $OSCustomizationSpec.Description
            FullName              = $OSCustomizationSpec.FullName
            OrgName               = $OSCustomizationSpec.OrgName
            OSType                = $OSCustomizationSpec.OSType
            #ChangeSid             = $OSCustomizationSpec.ChangeSid
            ChangeSid             = $True
            Type                  = $OSCustomizationSpec.Type
            AutoLogonCount        = $OSCustomizationSpec.AutoLogonCount
            LicenseMode           = $OSCustomizationSpec.LicenseMode
            LicenseMaxConnections = $OSCustomizationSpec.LicenseMaxConnections
          }

          if($DeveloperMode) {
            Write-Host "New OSCustomizationSpec : " $OSCustomizationSpec.Name                            -ForegroundColor Cyan
            Write-Host "vCenter                 : " $NewOSCustomizationSpecParams.vCenter                -ForegroundColor DarkCyan
            Write-Host "Name                    : " $NewOSCustomizationSpecParams.Name                   -ForegroundColor DarkCyan
            Write-Host "Description             : " $NewOSCustomizationSpecParams.Description            -ForegroundColor DarkCyan
            Write-Host "FullName                : " $NewOSCustomizationSpecParams.FullName               -ForegroundColor DarkCyan
            Write-Host "OrgName                 : " $NewOSCustomizationSpecParams.OrgName                -ForegroundColor DarkCyan
            Write-Host "OSType                  : " $NewOSCustomizationSpecParams.OSType                 -ForegroundColor DarkCyan
            Write-Host "ChangeSid               : " $NewOSCustomizationSpecParams.ChangeSid              -ForegroundColor DarkCyan
            Write-Host "Type                    : " $NewOSCustomizationSpecParams.Type                   -ForegroundColor DarkCyan
            Write-Host "AutoLogonCount          : " $NewOSCustomizationSpecParams.AutoLogonCount         -ForegroundColor DarkCyan
            Write-Host "LicenseMode             : " $NewOSCustomizationSpecParams.LicenseMode            -ForegroundColor DarkCyan
            Write-Host "LicenseMaxConnections   : " $NewOSCustomizationSpecParams.LicenseMaxConnections  -ForegroundColor DarkCyan
            Write-Host "Domain                  : " $Domain                                              -ForegroundColor DarkCyan
        }
                  
        ### New OSCustimizationSpecs
        ###-------------------------------------------
        try {
            #if($Domain -ne "WorkGroup"){
                #[PSCredential]$DomainCredentials =  Get-Secret srv-vc_dom_join -SecretId 11821 | Convert-secretToKerb
                [PSCredential]$DomainCredentials = Get-Secret -SecretName $ServiceAccount -SecretId 28070 | Convert-secretToKerb -domain Management -prefix
                $NewOSCustomizationSpec = VMware.VimAutomation.Core\New-OSCustomizationSpec -Server $vCenter -Domain $Domain -DomainCredentials $DomainCredentials @NewOSCustomizationSpecParams
            #}
            #else {
                #$NewOSCustomizationSpec = VMware.VimAutomation.Core\New-OSCustomizationSpec -Server $vCenter @NewOSCustomizationSpecParams
            #}
            
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }
        if($DeveloperMode){        
            Write-Host "Created New OSCustomizationSpec : " $NewOSCustomizationSpec.Name -ForegroundColor Cyan
        }
        Return $NewOSCustomizationSpec
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}

