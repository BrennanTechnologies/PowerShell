function Get-IPAddress {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$VLAN
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [int]$FourthOctet
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Get IP Address
        ###--------------------------------
        try {
            [PSCustomObject]$IPObject = [ABANet]::New($Site,$VLAN,$FourthOctet)
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }

        [IPAddress]$IPAddress      = $IPObject.IPAddress
        [IPAddress]$SubnetMask     = $IPObject.SubnetMask
        [IPAddress]$DefaultGateway = $IPObject.DefaultGateway
        [IPAddress]$PrimaryDNS     = $IPObject.DNS[0]
        [IPAddress]$SecondaryDNS   = $IPObject.DNS[1]
        
        if($DeveloperMode) {
            Write-Host "Site           : " $Site           -ForegroundColor DarkGray
            Write-Host "VLAN           : " $VLAN           -ForegroundColor DarkGray
            Write-Host "FourthOctet    : " $FourthOctet    -ForegroundColor DarkGray
            Write-Host "IPAddress      : " $IPAddress      -ForegroundColor DarkCyan
            Write-Host "SubnetMask     : " $SubnetMask     -ForegroundColor DarkCyan
            Write-Host "DefaultGateway : " $DefaultGateway -ForegroundColor DarkCyan
            Write-Host "PrimaryDNS     : " $PrimaryDNS     -ForegroundColor DarkCyan
            Write-Host "SecondaryDNS   : " $SecondaryDNS   -ForegroundColor DarkCyan
        }
        Return $IPObject
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}