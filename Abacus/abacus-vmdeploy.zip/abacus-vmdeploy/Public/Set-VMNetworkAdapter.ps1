function Set-VMNetworkAdapter {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$ConfigParams
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Set VM Network Adapter
        ###--------------------------------
        try {
            $PortGroup = Get-VDPortgroup -Name $ConfigParams.PortGroup -Server $vCenter
            if($PortGroup) {
                Get-VM -Name $ConfigParams.VMName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $PortGroup -Confirm:$false -Connected:$true | Out-Null
                if($DeveloperMode){
                    Write-Host "PortGroup          : " $PortGroup -ForegroundColor DarkCyan
                }
            }
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
        }
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}

