function Get-TargetDatastore {
    [CmdletBinding()]
    param( 
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$vCenter
        ,
        [Parameter(Mandatory = $False)]
        [string]$VMDeploymentTargetTag =  "vm_deployment_target"
        ,
        [Parameter(Mandatory = $False)]
        [int]$ReserveValue =  .2
        )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###--------------------------------
        ### Get Target Datastore
        ###--------------------------------
        try {

            #$Datastores = $null
            #$Cluster = "NJ HA Cluster 8 - 512GB"
            #$ClusterName = Get-Cluster $Cluster
            #Get-Datastore -Server $vcenter -Tag "vm_deployment_target"
            #$Datastores =  

            $Datastores = Get-Datastore -Server $vCenter -Tag $VMDeploymentTargetTag | Where-Object {$_.Name -ne "NYNBL01-SRV03"}
        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
        }

        $DatastoreResults = @()
        foreach($Datastore in $Datastores){
            $CapacityReservedGB  = ($Datastore.CapacityGB * $ReserveValue)
            $AvailableCapacityGB = $Datastore.FreeSpaceGB - $CapcityReserved

            $Object = [PSCustomObject]@{
                vCenter             = $vCenter
                Name                = $Datastore.Name
                FreeSpaceGB         = $Datastore.FreeSpaceGB
                CapacityGB          = $Datastore.CapacityGB
                CapacityReservedGB  = $CapacityReservedGB
                AvailableCapacityGB = $AvailableCapacityGB
            }
            $DatastoreResults += $Object
        }
        $MaxAvailableCapacity = ($DatastoreResults | Measure-Object -Property AvailableCapacityGB -Maximum).Maximum 
        $Datastore   = ( $DatastoreResults | Where-Object { $_.AvailableCapacityGB -eq $MaxAvailableCapacity } )
        $Datastore   = $Datastore.Name
        if($DeveloperMode){
            Write-Host "Target Datastore   : " $Datastore -ForegroundColor Cyan
        }
        Return $Datastore

        if($null -eq [bool]$Datastores) {
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "No Clusters Found: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrMsg
        }
        
        if($null -eq [bool]$TargetDatastore) {
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "No Clusters Found: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrMsg
        }
    }
    End{
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}