function Get-VMGuestState {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$VMName
    )

    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkMagenta
    }

    Process {
        ###--------------------------------
        ### Get-VMGuestState
        ###--------------------------------
        try {
            $VM = (Get-VM -Name $VMName -ErrorAction SilentlyContinue)
            $GuestStates = [ordered]@{
                VMName                            = $VM
                State                             = $VM.Guest.State                                              ### <---- RETURN: Running/NotRunning
                ToolsRunningStatus                = $VM.ExtensionData.Guest.ToolsRunningStatus                   ### <---- RETURN: guestToolsRunning/guestToolsNotRunning
                ToolsVersionStatus                = $VM.ExtensionData.Summary.Guest.ToolsVersionStatus           ### <---- RETURN: guestToolsCurrent/???
                VirtualMachineToolsStatus         = $VM.ExtensionData.Guest.ToolsStatus                          ### <---- RETURN: toolsNotInstalled/toolsNotRunning/toolsOk/toolsOld
                ConfigToolsToolsVersion           = ($VM | Get-View).Config.Tools.ToolsVersion                   ### <---- RETURN: 10309
                Configversion                     = ($VM | Get-View).Config.version                              ### <---- RETURN: vmx-11
                guestState                        = $VM.ExtensionData.guest.guestState                           ### <---- RETURN: running/notRunning
                guestOperationsReady              = $VM.ExtensionData.guest.guestOperationsReady                 ### <---- RETURN: True/False
                interactiveGuestOperationsReady   = $VM.ExtensionData.guest.interactiveGuestOperationsReady      ### <---- RETURN: True/False
                guestStateChangeSupported         = $VM.ExtensionData.guest.guestStateChangeSupported            ### <---- RETURN: True/False
            }
            foreach($State in $GuestStates.GetEnumerator()){
                Write-Host "VMGuestState : " $State.Name " : " $State.Value -ForegroundColor DarkCyan
            }

            ###----------------------------
            ### Guest Ready State
            ###----------------------------
            $VM = (Get-VM -Name $VMName -ErrorAction SilentlyContinue)
            $GuestState = @{
                "PowerState"                 = $VM.PowerState                                         ### <---- RETRUN: PoweredOn/PoweredOff
                "GuestState"                 = $VM.ExtensionData.guest.guestState                     ### <---- RETRUN: running/notRunning
                "GuestOperationsReady"       = $VM.ExtensionData.guest.guestOperationsReady           ### <---- RETRUN: True/False                                                                            
                "GuestStateChangeSupported"  = $VM.ExtensionData.guest.guestStateChangeSupported      ### <---- RETRUN: True/False 
            }
            $GuestState = New-Object -TypeName PSObject -Property $GuestState

            if(($GuestState.PowerState -eq "PoweredOn") -AND ($GuestState.GuestState -eq "running") -AND ($GuestState.GuestOperationsReady -eq $True) -AND ($GuestState.GuestStateChangeSupported -eq $True))
            {
                Return $True
            }
            else
            {
                Return $False
            }


        }
        catch {
            $ErrMsg = "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $AbacusVeeamReport_global_logobject
        }
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkMagenta
    }
}
