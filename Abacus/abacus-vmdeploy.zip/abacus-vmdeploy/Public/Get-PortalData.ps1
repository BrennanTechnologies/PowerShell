<#
Get-PortalTenant -ClientCode TST
    ID          : e910b335-f7a9-4a5e-a79b-7083f710b01b
    Identifier  : abacustestclient
    Name        : Ezevonage
    Description : Ezevonage test
    IsActive    : True
    Territory   : Corporate
    ClientCode  : {TST, TSTVM}
    ADDomain    : ezevonage.corp
    CloudPortal : {@{Value=206; Value3=EzeVonage}, @{Value=650; Value3=VOICEMAIL - Ezevonage}}
    Status      : Inactive/Gone
    ServiceType : {FlexHybrid, Flex}

Get-PortalTenant -ClientCode ABA
    ID          : 5f6ddcba-34a5-4211-b6ad-8da6b2c189aa
    Identifier  : abacus
    Name        : Abacus Group
    Description : Abacus Group company tenant
    IsActive    : True
    Territory   : Abacus Group
    ClientCode  : {ABA, ABACUS, PRO, PROVM...}
    ADDomain    : abacus.corp
    CloudPortal : {@{Value=16; Value3=Abacus Group LLC}, @{Value=185; Value3=Ex2013Test}, @{Value=206; Value3=EzeVonage}, @{Value=726; Value3=Proactive Technologies}...}
    Status      : Active
    ServiceType : {Hosted Voice, Flex, Citrix Resources}
#>
function Get-PortalData {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Site
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$ClientCode
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray
    }
    Process {
        ###-----------------------------------------
        ### Get Client Data from Portal
        ###-----------------------------------------
        
        ### Get Site ID
        ###-----------------------------------------
        Switch ($Site) {
            "NY" {[int]$SiteID = 5}
            "TX" {[int]$SiteID = 2221}
            "SF" {[int]$SiteID = 7}
            "L1" {[int]$SiteID = 13}
            "L2" {[int]$SiteID = 2283}
            "CF" {[int]$SiteID = 2578}
        }

        ### Get Portal Data
        ###-----------------------------------------
        try {
            $ClientData  = Get-PortalTenant -ClientCode $ClientCode
            $NetworkData = $ClientData | Get-PortalNetworks | Where-Object SiteID -eq $SiteID
        }
        catch {
            ### Send Alert
            ###---------------------------------------------
            $ErrMsg = "ERROR: Re-Try Limit Reached: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message
            Write-Log -LogString $ErrMsg -LogLevel Warning -LogObject $VMDeployLogObject
            Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
            Throw $ErrorMsg
        }

        ### Return PortalData Object
        ###-----------------------------------------
        [int]$VLAN     = $NetworkData.VlanId
        $PortGroup     = "dvs-$ClientCode-$vlan"
        $ClientID      = $ClientData.ID
        $ClientName    = $ClientData.Name
        $ClientDomain  = $ClientData.ADDomain
        if(!$ClientDomain){
            $ClientDomain = "WorkGroup"
        }
        $PortalData = [PSCustomObject]@{
            VLAN          = $VLAN
            PortGroup     = $PortGroup
            ClientID      = $ClientID
            ClientName    = $ClientName
            ClientDomain  = $ClientDomain
        }
        if($DeveloperMode) {
            Write-Host "PortalData.VLan         : " $PortalData.VLAN         -ForegroundColor DarkCyan
            Write-Host "PortalData.PortGroup    : " $PortalData.PortGroup    -ForegroundColor DarkCyan
            Write-Host "PortalData.ClientID     : " $PortalData.ClientID     -ForegroundColor DarkCyan
            Write-Host "PortalData.ClientName   : " $PortalData.ClientName   -ForegroundColor DarkCyan
            Write-Host "PortalData.ClientDomain : " $PortalData.ClientDomain -ForegroundColor DarkCyan
        }
        Return $PortalData
    }
    End {
        if($DeveloperMode){Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VMDeployLogObject -ForegroundColor DarkGray}
    }
}