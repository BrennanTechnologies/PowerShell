
#using module abacus-portal 
#using module abacus-secret 

#Start-Transcript -Path "C:\Users\adm-cbrennan\Documents\WindowsPowerShell\Modules\abacus-vmdeploy\Public\Set-PortalScriptTrans.log"
#$LogFile = "C:\Users\adm-cbrennan\Documents\WindowsPowerShell\Modules\abacus-vmdeploy\Public\Set-PortalScript.log"
#New-Item -Path $LogFile -Force -ItemType "file"
#Set-Content -Path $LogFile -Value 'Creating Log File'

$modules = @("abacus-portal","abacus-secret")
foreach($Module in $Modules){
    Get-Module -Name $Module -ListAvailable | Import-Module
}

$computertargets = "localhost" 
$portalUserACL = "portalusers@management.corp" 
$settings = Get-Content $PSscriptroot\PortalCert.json | ConvertFrom-Json 
#$settings = Get-Content .\Public\PortalCert.json | ConvertFrom-Json

$src_certlocation = $settings.src_certlocation 

$certs = dir $src_certlocation -Recurse | ? name -like *.pfx | select -ExpandProperty fullname 

$PFXPassword = get-secret -SecretId $settings.password_secretID | Convert-secretToString 

Add-Content -Path $LogFile -Value 'Starting: Install-PortalCert' -app
try{
    Install-PortalCert -CertPath $certs -ComputerName $computertargets -PFXPassword $PFXPassword 
}
catch {
    $ErrMsg = $global:Error[0].Exception.Message
    Add-Content -Path $LogFile -Value $ErrMsg
}

Add-Content -Path $LogFile -Value 'Ending: Install-PortalCert'

Add-Content -Path $LogFile -Value 'Starting: Update-PortalCertACLs'
Update-PortalCertACLs -Username $portalUserACL -Permission FullControl -ComputerName $computertargets 
Add-Content -Path $LogFile -Value 'Ending: Update-PortalCertACLs'
