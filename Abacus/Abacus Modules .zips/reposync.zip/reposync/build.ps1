Param (
    $Settings = $( Get-Content .\settings.json  | ConvertFrom-Json).Settings
)
Begin {
    Import-Module Abacus-Logging -Force
    $BuildLog = $(Start-Log -LogPath "$($Settings.Artifacts)\Build.log" -ScriptName 'build.ps1' -AttachToExistingLog True -Audit False -Global False)
}
Process {
    task Clean {
        If( Test-Path -Path $($Settings.Artifacts) ) {
            Write-Log -LogString "Removing old artifacts from previous builds..." -LogLevel Output -LogObject $BuildLog
            Remove-Item "$($Settings.Artifacts)/*" -Recurse -Force
        }
    }

    task Build {
        Write-Log -LogString "Writing Environment Variables to Log..." -LogLevel Output -LogObject $BuildLog
        Write-Log -LogString $(Get-ChildItem Env: | Select Name,Value | ConvertTo-Json) -LogLevel Output -LogObject $BuildLog
        Write-Log -LogString "----------------------------------------------------" -LogLevel Output -LogObject $BuildLog

        Write-Log -LogString "Attempting to create Artifacts directory if not present." -LogLevel Output -LogObject $BuildLog
        New-Item -Type Directory -Path $($Settings.Artifacts) -Force

        Write-Log -LogString "Checking PSModule dependencies..." -LogLevel Output -LogObject $BuildLog
        ForEach ( $Dependency in $($Settings.Dependencies) ) {
            Write-Log -LogString "Action Copy: [Repo: '$($Dependency.Name)' | Branch: '$($Dependency.Branch)' | Server: '$($Settings.JenkinsServer)']" -LogLevel Output -LogObject $BuildLog
            Copy-Item -Path "\\$($Settings.JenkinsServer)\$($Settings.JenkinsRepoShare)\$($Dependency.Branch)\$($Dependency.Name)" -Destination '.\Artifacts' -Force -Verbose -Recurse
        }
        $BuildNumber = $(Get-ChildItem env:'Build_Number').Value
        New-Item -Type File -Path "$($Settings.Artifacts)\BuildNumber"
        Set-Content -Path "$($Settings.Artifacts)\BuildNumber" -Value $BuildNumber
    }

    task Execute {
        # Run Execute
            ForEach ( $Dependency in $($Settings.Dependencies.Name) ) {
                If ($Dependency -ne 'PSTestReport') {
                    Write-Log -LogString "Importing $Dependency from the Artifacts directory." -LogLevel Output -LogObject $BuildLog
                    Import-Module -Name ".\Artifacts\$Dependency" -Force
                }
            }

            Write-Log -LogString "Executing Script..." -LogLevel Output -LogObject $BuildLog
            & .\$($Settings.ScriptToExecute)
            $BuildNumber = Get-Content -Path "$($Settings.Artifacts)\BuildNumber"
    }

    task Publish {
        Write-Log -LogString "Publishing results:" -LogLevel Output -LogObject $BuildLog
    }

    task Notify {
        Write-Log -LogString "Running Notify Task..." -LogLevel Output -LogObject $BuildLog
    }
}

