﻿Param (
    [ValidateNotNullOrEmpty()]
    $Branches = @("master", "qa", "pe", "devpe")
    ,
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [Switch]$WhatIf
)
Begin {
    Try {
        Import-Module Abacus-Logging -ErrorAction Stop
        Start-Log -LogPath ".\Artifacts\build.log" `
            -ScriptName "RepoSyncScript.ps1" `
            -AttachToExistingLog True `
            -Audit True `
            -AuditLogPath "\\service02.corp\dfs\SHARES\PSAuditLogs\RepoSync\RepoSyncScript.log" `
            -Global True `
            -ErrorAction Stop
    }
    Catch {
        Throw "There was an issue initializing logging...`n{Exception: $($_.Exception)}"
    }

    $ObjectArray = @()
    Try {
        ForEach ($Branch in $Branches) {
            $ObjectArray += [PSCustomObject]@{'Branch' = $Branch; 'Data' = $(Get-Content ".\$Branch.json" | ConvertFrom-Json) }
        }
    }
    Catch {
        Write-Log -LogString "There was an error loading one or more JSON files.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError
    }
}
Process {
    ForEach ($Object in $ObjectArray) {
        Write-Log -LogString "Working on Syncing Repos in Branch `'$($Object.Branch)`'" -LogLevel Output -ForegroundColor Magenta
        ForEach ($Repo in $Object.Data) {
            If ($True -eq $Repo.Enabled) {
                ForEach ($HostName in $Repo.Hosts) {
                    $Source = $Repo.SourceLocation -replace '\$\(\$Host\)', "$($HostName)" -replace '\$\(\$Branch\)', "$($Repo.Branch)" -replace '\$\(\$Repo\)', "$($Repo.Repo)"
                    $Destination = $Repo.DestinationLocation -replace '\$\(\$Host\)', "$($HostName)" -replace '\$\(\$Branch\)', "$($Repo.Branch)" -replace '\$\(\$Repo\)', "$($Repo.Repo)"
                    If ($True -eq $WhatIf) {
                        Write-Log -LogString "Syncing Repo {$($Repo.Repo)} branch {$($Repo.Branch)} from {$Source} to {$Destination} - WHATIF FLAG" -LogLevel Output
                        Robocopy.exe /Z /E /L /PURGE $Source $Destination
                    }
                    Else {
                        Write-Log -LogString "Syncing Repo {$($Repo.Repo)} branch {$($Repo.Branch)} from {$Source} to {$Destination}" -LogLevel Output
                        Robocopy.exe /Z /E /PURGE /r:2 /w:5 $Source $Destination | Out-String -OutVariable RoboCopyOutput
                    }
                }
            }
            Else {
                Write-Log -LogString "Repo {$($Repo.Repo)} branch {$($Repo.Branch)} is not enabled {$($Repo.Enabled)}" -LogLevel Output
            }
        }
    }


    # Legacy
    Write-Log -LogString "Working on Legacy..." -LogLevel Output

    $LegacySyncTasks = Get-Content .\Legacy.Json | ConvertFrom-Json
    $WorkSpace = "\\jenkins\repositories"

    ForEach ($Task in $LegacySyncTasks) {
        $Repository = $Task.Repo
        If ($Null -eq $($Task.Location)) {
            $Location = "\C$\Program Files\WindowsPowerShell\Modules\$Repository"
        }
        Else {
            $Location = $Task.Location
        }

        ForEach ($HostName in $Task.Hosts) {
            If ($True -eq $WhatIf) {
                Write-Log -LogString "Syncing Repo {$($Repository)} from {$($WorkSpace)\$($Repository)} to {$HostName} - WHATIF FLAG" -LogLevel Output
                Robocopy.exe /Z /E /L /PURGE "$WorkSpace\$($Repository)" "\\$($HostName)$($Location)"
            }
            Else {
                Write-Log -LogString "Syncing Repo {$($Repository)} from {$($WorkSpace)\$($Repository)} to {$HostName}" -LogLevel Output
                Robocopy.exe /Z /E /PURGE /r:2 /w:5 "$WorkSpace\$($Repository)" "\\$($HostName)$($Location)" | Out-String -OutVariable RoboCopyOutput
                If (   $True -eq [Boolean]$([Regex]::Match($RoboCopyOutput, "Access is denied").Value)   ) {
                    Write-Log -LogString "Access Denied" -LogLevel Warning
                }
            }
        }
        $Repository = $Null
    }
}