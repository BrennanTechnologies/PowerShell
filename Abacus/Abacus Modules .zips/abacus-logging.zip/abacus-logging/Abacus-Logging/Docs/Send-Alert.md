# Send-Alert #

### Description ###
Send an Email Alert Notification with the Script Name, the Function Name, and the Error message.

### Requirements ###
Requires the Abacus-Logging module.



```powershell
Import-Abacus-Logging
or
RequiredModules = @('Abacus-Logging')
```

### Syntax ###
```powershell
Send-Alert
    -Message <String>
    -Script <String>
    -Function <String>
    [-To <String>]
    [-From <String>]
    [-Subject <String>]
    [-SMTPServer <String>]
```

### Example ###
```powershell
Send-Alert -Message $global:Error[0].Exception.Message -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)
```

### Parameters ###

##### -Message

Main body of the Alert Message.

Example:

` -Message "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message`


##### -Script

Name of the script triggering the alert.

Example:

` -Script $((Get-PSCallStack)[-1].Command) `


##### -Function

Name of the function triggering the alert.

Example:  
` -Function $((Get-PSCallStack)[0].Command) `


##### -To
Email To Address.

Example:  
` $To ="devopsalerts@abacusgroupllc.com" `

##### -From
Email From Address.

Example:  
` $From = "no-replay@relay-ny.accessabacus.com" `


##### -Subject
Email Subject.

Example:  
` $Subject = "Script Alert: $Script" `

##### -SMTPServer
SMTP Relay Server.

Example:  
` $SMTPServer = "relay-ny.accessabacus.com" `

### Author ###
Author: Chris Brennan

Date: 4-8-2020

### Support ###
**Known Bugs**

None

**Report Bugs**

bugs.devops@abacusgroupllc.com
