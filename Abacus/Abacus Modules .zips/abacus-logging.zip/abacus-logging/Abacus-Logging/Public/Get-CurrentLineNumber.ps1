﻿<#
.SYNOPSIS
A command to nab the current line number in a running script for debugging.

.DESCRIPTION
A command to nab the current line number in a running script for debugging.

.EXAMPLE
Get-CurrentLineNumber

.NOTES
N/A
#>

Function Get-CurrentLineNumber {
    [cmdletbinding()]
    Param()
    [Int]$LineNumber = $($MyInvocation.ScriptLineNumber)
    Return $LineNumber
}