Class AbacusLog {
    # Required Class Parameters
    [String]$LogPath = $LogPath
    [String]$ScriptName = $Scriptname
    [String]$AttachToExistingLog = $AttachToExistingLog.ToUpper()
    [String]$AuditLog = $AuditLog
    [String]$AuditLogPath = $AuditLogPath
    $VerbosePreference = 'SilentlyContinue'
    $DebugPreference = 'SilentlyContinue'
    # Default Class Parameters
    $UniqueLogID

    # Hidden Class Parameters
    Hidden $MaxLogCount = 20


    [ValidateSet('Output', 'Error', 'TerminatingError', 'Warning', 'Verbose', 'Debug')]
    Hidden [String]$LogLevel = 'Output'
    ###################################


    # Default Constructor
    AbacusLog([String]$LogPath, [String]$ScriptName, [String]$AttachToExistingLog, [String]$AuditLog, [String]$AuditLogPath) {
        # Variable Initilization
        $LogParentDir = $(Split-Path $LogPath)
        $LogFileName = $(Split-Path $LogPath -Leaf)
        #############################################

        # Check Boolean Parameter
        If (   ($AttachToExistingLog -ne $True) -and ($AttachToExistingLog -ne $False)    ) {
            Throw 'Parameter "AttachToExistingLog" must be a valid Boolean $True, $False,///"True", "False" Value.'
        }

        # Check Parent Path
        If (   (Test-Path $LogParentDir) -eq $False   ) {
            Try {
                $This.InitilizeLogDir($LogParentDir)
            }
            Catch {
                Throw "Could not initialize log directory.`n{Exception: $($_.Exception)}"
            }
        }

        # Check File
        If (   (Test-Path $LogPath) -eq $False   ) {
            $This.WriteToConsole('No existing log file present', $This.LogLevel)
            $This.InitilizeLogFile($LogPath)
        }
        Else {
            If ($AttachToExistingLog -eq $True) {
                $This.WriteToConsole('Existing log file present... Attaching to log...', $This.LogLevel)
            }
            Else {
                $This.WriteToConsole('Existing log file present... Performing Log rotation', $This.LogLevel)
                $This.RotateLog($LogParentDir, $LogFileName)
                $This.InitilizeLogFile($LogPath)
            }
        }

        # If Audit Logging is Enabled
        If ($AuditLog -eq $True) {
            $This.WriteToConsole('Initializing Audit Log.', $This.LogLevel)

            # Generate Unique Log ID
            [String]$RandomizerString = "$(Get-Random -Minimum 100)$($env:COMPUTERNAME)$($env:USERNAME)$(Get-Date)".ToUpper()
            $SHAKey = New-Object System.Security.Cryptography.HMACSHA1
            $SHAKey.key = [Text.Encoding]::ASCII.GetBytes($RandomizerString)
            $Hash = $SHAKey.ComputeHash([Text.Encoding]::UTF8.GetBytes($RandomizerString))
            $This.UniqueLogID = -join ($Hash | ForEach-Object ToString X2).tolower()

            # Ensure AuditLogPath is not a null value
            $This.WriteToConsole('Ensuring Audit LogPath is not a NULL value.', $This.LogLevel)
            If (   [String]::IsNullOrEmpty($AuditLogPath)   ) {
                $This.WriteTerminatingError("Parameter 'AuditLogPath' cannot be a null value if Auditing Mode in enabled.`n{Exception: $($_.Exception)}")
            }
            Else {
                New-Variable AuditLogParentDir
                New-Variable AuditLogFileName
                $AuditLogParentDir = $(Split-Path $AuditLogPath)
                $AuditLogFileName = $(Split-Path $AuditLogPath -Leaf)
            }

            # Check accessibility to Audit Log location
            $This.WriteToConsole("Verifying Audit Path's parent directory.", $This.LogLevel)
            If (   [Boolean](Test-Path -Path $AuditLogParentDir) -eq $False   ) {
                $This.WriteTerminatingError("There was an error Accessing the AuditLog location. Does the location exist and are you able to reach it?`n{Exception: $($_.Exception)}")
            }

            If (   $True -eq [Boolean]$(Test-Path -Path "$AuditLogParentDir\$AuditLogFileName")   ) {
                # Rotate the Log if is too large
                Try {
                    $This.WriteToConsole('Checking to see if Audit Log should be rotated...', $This.LogLevel)
                    If (   $True -eq $((Get-Item -Path "$AuditLogParentDir\$AuditLogFileName").Length / 1MB -ge 50)   ) {
                        $This.RotateAuditLog($AuditLogParentDir, $AuditLogFileName)
                    }
                }
                Catch {
                    $This.WriteTerminatingError("There was an issue rotating the audit log.`n{Exception: $($_.Exception)}")
                }
            }

            ElseIf (   $False -eq [Boolean]$(Test-Path -Path "$AuditLogParentDir\$AuditLogFileName")   ) {
                #Create the Log
                Try {
                    $This.InitilizeAuditLogFile($AuditLogPath)
                }
                Catch {
                    $This.WriteTerminatingError("There was an issue creating the AuditLog in the path specified. Do we have access to do so?`n{Exception: $($_.Exception)}")
                }
            }

            # Audit Log Initialization Finish
        }
        $This.WriteOutput("===== Logs initialized =====")
    }
    # End Constructor

    ######################################################################################################################################################################################

    # Default Methods
    Hidden InitilizeLogDir([String]$LogParentDir) {
        Try {
            New-Item -Type Directory -Force -Path $LogParentDir -ErrorAction Stop -ErrorVariable errNewLogDir
            $This.WriteToConsole('Log directory created', $This.LogLevel)
        }
        Catch {
            Throw "{Exception: $($_.Exception)}"
        }
    }

    Hidden InitilizeLogFile([String]$LogPath) {
        Try {
            New-Item -Type File -Force -Path $LogPath -ErrorAction Stop -ErrorVariable errNewLogFile
            $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Authenticated Users", "FullControl", "Allow")
            $Acl = Get-Acl -Path $LogPath
            $Acl.SetAccessRule($AccessRule)
            Set-Acl -Path $LogPath -AclObject $Acl
            $This.WriteToConsole('Log file created', $This.LogLevel)
        }
        Catch {
            Throw "{Exception: $($_.Exception)}"
        }
    }

    Hidden RotateLog([String]$LogParentDir, [String]$LogFileName) {
        $BaseFileName = $LogFileName.Substring(0, $LogFileName.LastIndexOf('.'))
        $FileExtension = $LogFileName.Substring($BaseFileName.Length + 1)
        $MaxCount = $($This.MaxLogCount)

        $LogFiles = Get-ChildItem -LiteralPath $LogParentDir -Filter "$BaseFileName*" | ? { $_.Name -match "$BaseFileName\d+\.$FileExtension" }

        # If LogCount >= Max than remove the last log
        If (   $LogFiles.count -ge $MaxCount   ) {
            Remove-Item -Path "$($LogParentDir)\$($BaseFileName)$($MaxCount)`.$($FileExtension)" -Force -ErrorAction SilentlyContinue
            $LogFiles = Get-ChildItem -LiteralPath $LogParentDir -Filter "$BaseFileName*" | ? { $_.Name -match "$BaseFileName\d+\.$FileExtension" }
        }

        # Increment the LogFile count and rename the latest log
        For ($i = $MaxCount ; $i -ge 0 ; $i-- ) {
            If ($i -ne 0) {
                Rename-Item -Path "$($LogParentDir)\$($BaseFileName)$($i).$($FileExtension)" -NewName "$($BaseFileName)$($i+1).$($FileExtension)" -Force -ErrorAction SilentlyContinue
            }
            Else {
                Rename-Item -Path "$($LogParentDir)\$($BaseFileName).$($FileExtension)" -NewName "$($BaseFileName)$($i+1).$($FileExtension)" -Force -ErrorAction SilentlyContinue
            }
        }

        $This.WriteToConsole('Log files have been rotated', $This.LogLevel)
    }

    Hidden RotateAuditLog([String]$AuditLogParentDir, [String]$LogFileName) {
        $This.WriteToConsole('Attempting to rotate the audit log file...', $This.LogLevel)
        $BaseFileName = $LogFileName.Substring(0, $LogFileName.LastIndexOf('.'))
        $FileExtension = $LogFileName.Substring($BaseFileName.Length + 1)

        $LogFiles = Get-ChildItem -LiteralPath $AuditLogParentDir -Filter "$BaseFileName*" | ? { $_.Name -match "$BaseFileName\d+\.$FileExtension" }

        # Increment the LogFile count and rename the latest log
        For ($i = $($LogFiles.Count) ; $i -ge 0 ; $i-- ) {
            If ($i -ne 0) {
                Rename-Item -Path "$($AuditLogParentDir)\$($BaseFileName)$($i).$($FileExtension)" -NewName "$($BaseFileName)$($i+1).$($FileExtension)" -Force -ErrorAction SilentlyContinue
            }
            ElseIf ($i -eq 0) {
                $AttemptCounter = 0
                $MaxAttemptCount = 10
                While ($AttemptCounter -le $MaxAttemptCount) {
                    Try {
                        Rename-Item -Path "$($AuditLogParentDir)\$($BaseFileName).$($FileExtension)" -NewName "$($BaseFileName)$($i+1).$($FileExtension)" -ErrorAction Stop
                        Break
                    }
                    Catch {
                        $This.WriteToConsole("Failed to rotate Audit Log, Retrying... - {Attempt:$($AttemptCounter)/$($MaxAttemptCount)}", 'Warning')
                        $AttemptCounter++
                        Sleep 4
                    }
                }
                If ($AttemptCounter -eq 5) {
                    Throw "Failed to initialize Audit Log after 5 attempts."
                }
            }
        }
    }

    Hidden InitilizeAuditLogFile([String]$AuditLogPath) {
        Try {
            New-Item -Path $AuditLogPath -ItemType File -ErrorAction Stop -ErrorVariable errInitializeAuditLog
            $This.WriteToConsole('Audit Logfile created', $This.LogLevel)
        }
        Catch {
            Throw "{Exception: $($_.Exception)}"
        }
    }

    Hidden WriteToLog([String]$LogMessage, [String]$LogLevel) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }
        $Date = Get-Date -Format o

        $LogString = "[$Date] [$($this.ScriptName)] [$LogLevel] [$env:USERDOMAIN\$env:USERNAME] [$env:COMPUTERNAME] - $LogMessage"
        $LogString | Out-File -Append -LiteralPath $This.LogPath -Encoding utf8
    }

    Hidden WriteToAuditLog([String]$LogMessage, [String]$LogLevel) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }
        $Date = Get-Date -Format o

        $LogString = "[$Date] [$($this.ScriptName)] [$LogLevel] [$env:USERDOMAIN\$env:USERNAME] [$env:COMPUTERNAME] [$($This.UniqueLogID)] - $LogMessage"
        $LogString | Out-File -Append -LiteralPath $This.AuditLogPath -Encoding utf8
    }

    Hidden WriteToConsole([String]$LogMessage, [String]$LogLevel) {
        Switch ($LogLevel) {
            'Output' {
                Write-Host -ForegroundColor Green $LogMessage
            }
            'Error' {
                Write-Error $LogMessage
            }
            'TerminatingError' {
                Throw $LogMessage
            }
            'Warning' {
                Write-Warning $LogMessage
            }
            'Verbose' {
                If ($this.VerbosePreference -eq 'Continue') {
                    Write-Verbose $LogMessage -Verbose
                }
                Else {
                    Write-Verbose $LogMessage
                }
            }
            'Debug' {
            }
            Default {
                Write-Host -Foregroundcolor Green $LogMessage
            }
        }
    }

    WriteOutput([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Output')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Output')
        }

        #Write to Console
        $This.WriteToConsole($LogMessage, 'Output')
    }

    WriteError([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Error')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Error')
        }

        # Write to Console
        $This.WriteToConsole($LogMessage, 'Error')
    }

    WriteTerminatingError([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'TerminatingError')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'TerminatingError')
        }

        # Write to Console
        $This.WriteToConsole($LogMessage, 'TerminatingError')
    }

    WriteWarning([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Warning')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Warning')
        }

        #Write to Console
        $This.WriteToConsole($LogMessage, 'Warning')
    }

    WriteVerbose([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Verbose')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Verbose')
        }

        #Write to Console
        $This.WriteToConsole($LogMessage, 'Verbose')
    }

    WriteDebug([String]$LogMessage) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Debug')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Debug')
        }

        #Write to Console
        $This.WriteToConsole($LogMessage, 'Debug')
    }

    EmailLog([String]$SourceAddress, [String]$DestinationAddress, [String]$Subject, [String]$SmtpServer) {
        [Array]$LogToEmail = @()
        [String]$EmailBody = ""
        $LogToEmail += $($This.ReturnLog())
        $LogToEmail | % {
            [String]$EmailBody += "$_ `t`n"
        }
        Send-MailMessage -From $SourceAddress -To $DestinationAddress -Subject $Subject -SmtpServer $SmtpServer -Body $EmailBody
    }

    [Array]ReturnLog() {
        [Array]$LogContents = Get-Content $This.LogPath
        Return $LogContents
    }

    # Overload Methods
    Hidden WriteToLog([String]$LogMessage, [String]$LogLevel, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }
        $Date = Get-Date -Format o

        $LogString = "[$Date] [$($this.ScriptName)] [$LogLevel] [Line#:$LineNumber] [$env:USERDOMAIN\$env:USERNAME] [$env:COMPUTERNAME] - $LogMessage"
        $LogString | Out-File -Append -LiteralPath $This.LogPath -Encoding utf8
    }

    ###########################################################################

    Hidden WriteToAuditLog([String]$LogMessage, [String]$LogLevel, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }
        $Date = Get-Date -Format o

        $LogString = "[$Date] [$($this.ScriptName)] [$LogLevel] [Line#:$LineNumber] [$env:USERDOMAIN\$env:USERNAME] [$env:COMPUTERNAME] [$($This.UniqueLogID)] - $LogMessage"
        $LogString | Out-File -Append -LiteralPath $This.AuditLogPath -Encoding utf8
    }

    ###########################################################################

    Hidden WriteToConsole([String]$LogMessage, [String]$LogLevel, [String]$ForegroundColor) {
        Switch ($LogLevel) {
            'Output' {
                Try {
                    Write-Host -ForegroundColor $ForegroundColor $LogMessage
                }
                Catch {
                    $this.WriteTerminatingError("There was an error writing to the console.`n{Exception: $($_.Exception)}")
                }
            }
            'Error' {
                Write-Error $LogMessage
            }
            'TerminatingError' {
                Throw $LogMessage
            }
            'Warning' {
                Write-Warning $LogMessage
            }
            'Verbose' {
                If ($this.VerbosePreference -eq 'Continue') {
                    Write-Verbose $LogMessage -Verbose
                }
                Else {
                    Write-Verbose $LogMessage
                }
            }
            'Debug' {
            }
            Default {
                Write-Host -Foregroundcolor $ForegroundColor $LogMessage
            }
        }
    }

    ###########################################################################

    WriteOutput([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Output', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Output', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        #Write to Console
        $This.WriteToConsole($LogMessage, 'Output')
    }

    #

    WriteOutput([String]$LogMessage, [String]$ForegroundColor) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Output')

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Output')
        }

        #Write to Console
        $This.WriteToConsole($LogMessage, 'Output', $ForegroundColor)
    }

    #

    WriteOutput([String]$LogMessage, [String]$ForegroundColor, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Output', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Output', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        #Write to Console
        $This.WriteToConsole($LogMessage, 'Output', $ForegroundColor)
    }

    ###########################################################################

    WriteError([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Error', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Error', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        # Write to Console
        $This.WriteToConsole($LogMessage, 'Error')
    }

    ###########################################################################

    WriteTerminatingError([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'TerminatingError', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'TerminatingError', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        # Write to Console
        $This.WriteToConsole($LogMessage, 'TerminatingError')
    }

    ###########################################################################

    WriteWarning([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Warning', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Warning', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        #Write to Console
        $This.WriteToConsole($LogMessage, 'Warning')
    }

    ###########################################################################

    WriteVerbose([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Verbose', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Verbose', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        #Write to Console
        $This.WriteToConsole($LogMessage, 'Verbose')
    }

    ###########################################################################

    WriteDebug([String]$LogMessage, [Int]$LineNumber) {
        # Check String
        If (   [String]::IsNullOrWhiteSpace($LogMessage) -eq $True   ) {
            Throw 'The LogMessage String cannot be empty'
        }

        # Write to Log
        $This.WriteToLog($LogMessage, 'Debug', $LineNumber)

        If ($This.AuditLog -eq $True) {
            $This.WriteToAuditLog($LogMessage, 'Debug', $LineNumber)
        }

        $LogMessage = "$LogMessage ($($This.ScriptName):$LineNumber)"
        #Write to Console
        $This.WriteToConsole($LogMessage, 'Debug')
    }

    ###########################################################################

    #End Class
}