<#
.SYNOPSIS
Send an Email Alert Notification with the Script Name, the Function Name, and the Error message.

.DESCRIPTION
Send an Email Alert Notification with the Script Name, the Function Name, and the Error message.

.PARAMETER Message
Main body of the Alert Message.
Example:
-Message "ERROR: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message

.PARAMETER Script
Name of the script triggering the alert.
Example:
-Script $((Get-PSCallStack)[-1].Command)

.PARAMETER Function
Name of the function triggering the alert.
Example:
-Function $((Get-PSCallStack)[0].Command)

.PARAMETER To
Email account(s) to send the Alert to.

.PARAMETER From
Email account the Alert is sent from

.PARAMETER Subject
Custom the error message.

.PARAMETER SMTPServer
Mail relay server to send message.

.EXAMPLE
Send-Alert -Message $ErrMsg -Script $((Get-PSCallStack)[-1].Command) -Function $((Get-PSCallStack)[0].Command)

.INPUTS
Error Message

.OUTPUTS
Email Alert

#>

function Send-Alert {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Message
        ,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Script
        ,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Function
        ,
        [Parameter(Mandatory = $false)]
        [string]$To ="devopsalerts@abacusgroupllc.com"
        ,
        [Parameter(Mandatory = $false)]
        [string]$From = "no-replay@relay-ny.accessabacus.com"
        ,
        [Parameter(Mandatory = $false)]
        [string]$Subject = "Script Alert: $Script"
        ,
        [Parameter(Mandatory = $false)]
        [string]$SMTPServer = "relay-ny.accessabacus.com"
    )
    Begin {
        Write-Log -LogString "Start : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VeeamReportLog -ForegroundColor DarkGray

        ### HTML Head
        ###---------------------------------------------
        $htmlHead  = "<style>"
        $htmlHead += "body{font-family:Verdana,Arial,Sans-Serif; font-size:11px; font-color:black;}"
        $htmlHead += "table{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse; }" #width:800px;
        $htmlHead += "th{font-size:10px; border-width: 1px; padding: 3px; border-style: solid; border-color: gray; color:white; background-color:#00008B; text-align:center; }" #text-align:center background-color: darkblue;
        $htmlHead += "th{font-size:10px; border-width: 1px; padding: 3px; border-style: solid; border-color: gray; color:black; background-color:#C0C0C0; text-align:center; }" #text-align:center background-color: darkblue;
        $htmlHead += "td{font-size:10px; border-width: 1px; padding: 3px; border-style: solid; border-color: gray; color:black; background-color:White; text-align:center; }"
        $htmlHead += "</style>"
    }
    Process {
        ### Message Body
        ###---------------------------------------------
        $body  = $htmlHead
        $body += "<body>"
        $body += "<i><font size='3';color='gray';>"        + "Abacus DevOps Report:"                             + "</font></i><br>"
        $body += "<b><font size='5';color='darkblue';>"                                        + $Subject        + "</font></b>"
        $body += "<br><font size='2'>"                     + "Date: "                          + $(Get-Date)     + "</font><br><br>"
        $body += "<br><font size='3';color='red'>"         + "Script Name:  </font><br>"       + $Script         + "<br>"
        $body += "<br><font size='3';color='red'>"         + "Function Name:  </font><br>"     + $Function       + "<br>"
        $body += "<br><font size='3';color='red'>"         + "Message: </b></font><br>"
        $Body += $Message + "<br><br>"
        $Body += "</body>"
        try {
            Write-Host "Sending Alert: " $Subject -ForegroundColor Cyan

            ### Send Email Message
            ###---------------------------------------------
            Send-MailMessage `
                -SmtpServer $SMTPServer `
                -To ($To -split ",") `
                -From $From `
                -Body $Body  `
                -Subject $Subject `
                -BodyAsHtml
        }
        catch {
            Write-Log -LogString ("Error sending email report: " + ($global:Error[0].Exception.Message))  -LogLevel Warning -LogObject $VeeamReportLog
        }
    }
    End {
        Write-Log -LogString "End   : $((Get-PSCallStack)[0].Command)" -LogLevel Output -LogObject $VeeamReportLog -ForegroundColor DarkGray
    }
}