﻿<#
.SYNOPSIS
A wrapper around the AbacusLog class's WriteToLog method.

.DESCRIPTION
This command can be used to more easily write contents to the console and log file via the AbacusLog class without having to directly call the method.

.PARAMETER LogString
The desired string you wish to have outputted and captured in the log.

.PARAMETER LogLevel
The desired logging level for the particular string. This will appear in the log as such as well as the console in the respective level.

.PARAMETER ForegroundColor
If LogLevel is set to Output, text that is written to the console will be outputting in the following color.

.PARAMETER LineNumber
An optional parameter to include the LineNumber in the log file for debugging purposes. This can be used with the Get-CurrentLineNumber command.

.PARAMETER LogObject
If a dedicated LogObject was created rather than a global LogObject, you can specifiy the variable containing said LogObject here to direct all output to that log respectively.
This can be useful when you have more than one logObject within the same function or orchestration.

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Output

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Verbose

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Warning -LogObject $LogObject

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Output -ForegroundColor Magenta -LogObject $LogObject

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Output -LineNumber 1

.EXAMPLE
Write-Log -LogString "Test" -LogLevel Output -LineNumber $($Get-CurrentLineNumber)

.NOTES
N/A
#>
Function Write-Log {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        [String]$LogString
        ,
        [ValidateSet('Output', 'Error', 'TerminatingError', 'Warning', 'Verbose', 'Debug')]
        [String]$LogLevel = 'Output'
        ,
        [ValidateNotNullOrEmpty()]
        [ValidateSet('Black', 'DarkBlue', 'DarkGreen', 'DarkCyan', 'DarkRed', 'DarkMagenta', 'DarkYellow', 'Gray', 'DarkGray', 'Blue', 'Green', 'Cyan', 'Red', 'Magenta', 'Yellow', 'White')]
        [String]$ForegroundColor = "Green"
        ,
        [Int]$LineNumber = 0
        ,
        [System.Object]$LogObject = $Global:LogObject
    )
    Begin {
        Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState -Name 'VerbosePreference','DebugPreference'
        # CheckForLegacyLogging and/or active LogObject
        Try {
            If ($Null -eq $LogObject) {
                #Attempt to make a default log object
                $ScriptName = $($MyInvocation.ScriptName)
                If (   [String]::IsNullOrEmpty($ScriptName)   ) {
                    Start-Log -LogPath "C:\PSlogs\UnknownHeadlessScript.Log" -ScriptName 'UnknownHeadlessScript' -Global True -ErrorVariable errStartLogVar
                    # Reinitialize $LogObject
                    $LogObject = $Global:LogObject
                }
                Else {
                    $ScriptName = "$(Split-Path -Path $ScriptName -Leaf)"
                    Start-Log -LogPath "C:\PSlogs\$ScriptName.log" -ScriptName $ScriptName -Global True -ErrorVariable errStartLogVar
                    # Reinitialize $LogObject
                    $LogObject = $Global:LogObject
                }
            }
        }
        Catch {
            Write-Debug "Write-Log Function failed to create a default fallback Logging Object -- `n{Exception: $($errStartLogVar.message)}"
        }
    }
    Process {
        Switch ($LogLevel) {
            'Output' {
                Try {
                    If (  ($LineNumber -gt 0)   ) {
                        $LogObject.WriteOutput($LogString, $ForegroundColor, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteOutput($LogString, $ForegroundColor)
                    }
                }
                Catch {
                    Write-Host -ForegroundColor Magenta "Write-Log (Fallback/Output) : " -NoNewline
                    Write-Host -ForegroundColor $ForegroundColor $LogString
                }
            }
            'Error' {
                Try {
                    If (   $LineNumber -gt 0   ) {
                        $LogObject.WriteError($LogString, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteError($LogString)
                    }
                }
                Catch {
                    Write-Verbose "Write-Log (Fallback/Error) :"
                    Write-Error $LogString
                }
            }
            'TerminatingError' {
                Try {
                    If (   $LineNumber -gt 0   ) {
                        $LogObject.WriteTerminatingError($LogString, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteTerminatingError($LogString)
                    }
                }
                Catch {
                    Throw $LogString
                }
            }
            'Warning' {
                Try {
                    If (   $LineNumber -gt 0   ) {
                        $LogObject.WriteWarning($LogString, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteWarning($LogString)
                    }
                }
                Catch {
                    Write-Verbose "Write-Log (Fallback/Warning) :"
                    Write-Warning $LogString
                }
            }
            'Verbose' {
                Try {
                    If (   $Global:VerbosePreference -eq 'Continue' -or $VerbosePreference -eq 'Continue'   ) {
                        $LogObject.VerbosePreference = 'Continue'
                    }

                    If (   $LineNumber -gt 0   ) {
                        $LogObject.WriteVerbose($LogString, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteVerbose($LogString)
                    }

                    $LogObject.VerbosePreference = 'SilentlyContinue'
                }
                Catch {
                    If (   $Global:VerbosePreference -eq 'Continue' -or $VerbosePreference -eq 'Continue'   ) {
                        Write-Verbose "Write-Log (Fallback/Verbose) :"
                        $LogObject.VerbosePreference = 'Continue'
                        Write-Verbose $LogString -Verbose
                        $LogObject.VerbosePreference = 'SilentlyContinue'
                    }
                    Else {
                        Write-Verbose "Write-Log (Fallback/Verbose) :"
                        Write-Verbose $LogString
                    }
                }
            }
            'Debug' {
                Try {
                    If (   $LineNumber -gt 0   ) {
                        $LogObject.WriteDebug($LogString, $LineNumber)
                    }
                    Else {
                        $LogObject.WriteDebug($LogString)
                    }
                }
                Catch {
                    If (   $Global:DebugPreference -eq 'Continue' -or $DebugPreference -eq 'Continue'   ) {
                        Write-Verbose "Write-Log (Fallback/Debug) :"
                        $LogObject.DebugPreference = 'Continue'
                        Write-Debug $LogString
                        $LogObject.DebugPreference = 'SilentlyContinue'
                    }
                    Else {
                        Write-Debug "Write-Log (Fallback/Debug) :"
                        Write-Debug $LogString
                    }
                }
            }
            Default {
                Throw "Unhandled Exception"
            }
        }
    }
    End {

    }
}