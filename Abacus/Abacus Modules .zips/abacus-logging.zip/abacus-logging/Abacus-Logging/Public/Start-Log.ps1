﻿<#
.SYNOPSIS
A wrapper command that creates a new LogObject using the AbacusLog class.

.DESCRIPTION
This command can be used to more easily create and initialize log objects rather than directly calling the AbacusLog class method.

.PARAMETER LogPath
The full path of where the default log should be located. This path is usually local to the machine.

.PARAMETER ScriptName
The name of the script being called. This will be included in the log's output.

.PARAMETER AttachToExistingLog
If set to "True" the following will attempt to an existing log file assuming it is already present.

.PARAMETER Audit
If True, an additional log file will be created for audit purposes at the value specified from the AuditLogPath parameter.

.PARAMETER AuditLogPath
The full location (including file name) of where the audit log file should be created.

.PARAMETER Global
If True, the logObject created from this command will be stored as $global:LogObject otherwise the result can be outputting into a variable and specified to not be global.

.PARAMETER IgnoreLogging
If this flag is given, if logging fails to initiate, all output will go to console, but the script will not fail because logging failed.

.EXAMPLE
Start-Log -LogPath "C:\temp" -ScriptName Test.ps1 -AttachToExistingLog False -Global True

.EXAMPLE
Start-Log -LogPath "C:\temp" -ScriptName Test.ps1 -AttachToExistingLog True -Audit True -AuditLogPath "\\SOMEHOST.local\SHARES\Logs\TestLog.log" -Global True

.EXAMPLE
Start-Log -LogPath "C:\temp" -ScriptName Test.ps1 -AttachToExistingLog False -Audit False -AuditLogPath "C:\temp\test.log" -Global True -IgnoreLogging

.NOTES
General notes
#>

Function Start-Log {
    [cmdletbinding()]
    Param (
        [Parameter(Mandatory)]
        [String]$LogPath
        ,
        [Parameter(Mandatory)]
        [String]$ScriptName = $( Split-Path $MyInvocation.ScriptName -Leaf)
        ,
        [ValidateSet("True", "False")]
        [String]$AttachToExistingLog = "False"
        ,
        [ValidateSet("True", "False")]
        [String]$Audit = "False"
        ,
        [String]$AuditLogPath = $Null
        ,
        [ValidateSet("True", "False")]
        [String]$Global = "True"
        ,
        [ValidateNotNull()]
        [Switch]$IgnoreLogging = $False
    )
    $RetryAttempts = 5
    $LogStartStatus = $False

    While ($RetryAttempts -ge 0) {
        Try {
            $LogObject = New-Object AbacusLog($LogPath, $ScriptName, $AttachToExistingLog, $Audit, $AuditLogPath) -ErrorAction Stop -ErrorVariable errStartLog
            $LogStartStatus = $True
            Break
        }
        Catch {
            Write-Host -ForegroundColor Red "Failed to create a logging object, logging cannot start.`n Exception: {$($errStartLog.Message)}"
            $RetryAttempts--
            Sleep 2
        }
    }

    If ($False -eq $LogStartStatus) {
        If ($IgnoreLogging -eq $True) {
            Write-Verbose "Ignore logging has been selected"
            Write-Warning "Failed to create LogObject... Continuing without Logging as IgnoreLogging Flag is present."
        }
        Else {
            Throw "There was multiple issues trying to create our logging object. Logging could not start.`n Exception: {$($errStartLog.Message)}"
        }
    }
    Else {
        Write-Host -ForegroundColor Cyan "Log started sucessfully..."
        Switch ([Convert]::ToBoolean($Global)) {
            $True {
                $global:LogObject = $LogObject
            }
            $False {
                Return $LogObject
            }
            Default { Throw "Unhandled Exception" }
        }
    }
}