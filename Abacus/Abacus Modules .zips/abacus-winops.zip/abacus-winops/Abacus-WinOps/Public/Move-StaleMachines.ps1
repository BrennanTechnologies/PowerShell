Function Move-StaleMachines {
<#
    .SYNOPSIS
    Moves Active Directory computer objects into a stale workstations OU

    .DESCRIPTION
    Move-StaleMachines uses Active Directory module to move stale machines 

    .PARAMETER Machine
    Target machine to be moved in active directoy computer object format

    .EXAMPLE 
    Get-StaleMachines -domains $domains | Move-StaleMachines

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

    param(
        [Parameter(Mandatory=$true,ValueFromPipeline)]
        [Microsoft.ActiveDirectory.Management.ADComputer]$Machine,
        [String]$OU_Name = "Retired Objects"
    )

    Begin{
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Move-StaleMachines: Starting Job"
    }

    Process{
        
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Move-StaleMachines: Target: $($machine.DNSHostName)"
        [regex]$rx='(?:.*?)DC=(.*)'
        $DN=$machine.DistinguishedName
        #$rx.Replace($DN,'$1')
        $domain = $rx.Replace($DN,'$1') -replace ',DC=','.'
        $canonicalname_ou = "$domain/$OU_Name" 
        try{
            $retired_OU = Get-ADOrganizationalUnit -Server $domain -Filter {Name -eq "Retired Objects"} -Properties canonicalname | ? canonicalname -eq $canonicalname_ou
        }catch{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Move-StaleMachines: Failed query OU: $canonicalname_ou `n$($_.exception)" 
        }
    
        if(!$retired_OU){
            try{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Move-StaleMachines: $OU_Name does not exist"
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Move-StaleMachines: Attempting to create"

                Create-RetiredOU -domain $domain

                $retired_OU = Get-ADOrganizationalUnit -Server $domain -Filter {Name -eq "Retired Objects"} -Properties canonicalname | ? canonicalname -eq $canonicalname_ou

            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString  "Move-StaleMachines: Failed to create OU" 
            }
            
        }

        if($retired_OU){
            try{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Move-StaleMachines: Moving machine $dns_hostname to $($retired_OU.Name)"
                $machine | Move-ADObject -TargetPath $retired_OU
            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Move-StaleMachines: failed to move machines`n$($_.exception)"
            }
        }else{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString  "Move-StaleMachines: $OU_Name not found - unable to move" 
        }
    }
    End{
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Move-StaleMachines: End Job"
    }
}