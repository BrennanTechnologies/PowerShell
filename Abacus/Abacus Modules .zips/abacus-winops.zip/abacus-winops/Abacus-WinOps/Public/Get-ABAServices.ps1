﻿Function Get-ABAServices {
    Param(
        $computername,
        [switch]$return_bad_only
    )

    Begin{
        #$service_regex = "^(winrm$|dfs$|ServerAPI$|Workflow Server)"
    }

    Process{
        try{
            if([String]::IsNullOrEmpty($computername)){
                $all_services = Get-Service
            }else{
                $all_services = Get-Service -ComputerName $computername
            }

        }catch [System.InvalidOperationException]{    
            Write-Log -LogLevel TerminatingError -LogString "Test-ABAServices - $computername does not seem to be a valid machine"
        }catch {
            Write-Log -LogLevel TerminatingError -LogString "Test-ABAServices - Failed to query for services in $computername"
        }

        #$relevant_services = $all_services | ? name -Match $service_regex
        $relevant_services = $all_services | ? StartType -eq "Automatic" | ? Status -NE Running
            
        if($relevant_services){
            Write-Log -LogLevel verbose -LogString "Test-ABAServices - Found $($relevant_services.count) relevant services"
            $bad_services = $relevant_services | ? Status -ne "Running"
        }

        if($return_bad_only){
            if($bad_services){
                return $bad_services
            }
        }else{
            return $relevant_services
        
        }
        
    }
}