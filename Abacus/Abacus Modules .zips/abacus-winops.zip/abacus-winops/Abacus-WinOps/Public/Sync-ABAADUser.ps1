﻿<#
.SYNOPSIS
A PowerShell cmdlet that syncs the ABAAD User

.DESCRIPTION
This PowerShell command syncs the ABAAD User

.PARAMETER Domain
Domain entries to be targets

.PARAMETER username
The username to be targeted

.EXAMPLE
Sync-ABAADUser -Domain <domain> -username <username>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

function Sync-ABAADUser {
    [cmdletbinding()]
    Param(
        [string]$Domain,
        [string]$username
    )
    Begin{
        $SyncAdUserLog = Start-Log -LogPath "C:\releases\Logs\Sync-ABAADUser\Operations.log" -ScriptName Sync-ABAADUser -AttachToExistingLog True -Global False
    }

    Process{

        try{
            $allDCs = Get-ADDomainController -filter * -Server $Domain
            Write-Log -LogString "Sync-ABAADUser: Found DCs: $($allDCs.name)" -LogLevel Verbose -LogObject $SyncAdUserLog
        }catch{
            Write-Log -LogString "Sync-ABAADUser: Failed to query domain controllers in $Domain`n$($_.exception)" -LogLevel TerminatingError -LogObject $SyncAdUserLog
        }

        try{
            Write-Log -LogString "Sync-ABAADUser: Looking for user $Username" -LogLevel Verbose -LogObject $SyncAdUserLog
            $user_object  = Get-ADUser -Server $Domain -Identity $Username

        }catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException]{
            Write-Log -LogString "Sync-ABAADUser: Did not find user in original DC - looking in other DC locations" -LogLevel Verbose -LogObject $SyncAdUserLog

            foreach ($DC in $allDCs){
                Write-Log -LogString "Sync-ABAADUser: Looking for user $Username in $($DC.hostname)" -LogLevel Verbose -LogObject $SyncAdUserLog
                $tmp_user_object = Get-ADUser -Server $DC.hostname -Filter {SamAccountName -eq $Username}
                if($tmp_user_object -ne $null){
                    Write-Log -LogString "Sync-ABAADUser: Found User: $username" -LogLevel Verbose -LogObject $SyncAdUserLog
                    $user_object = $tmp_user_object
                    break
                }
            }
        }catch {
            Write-Log -LogLevel TerminatingError -LogString "Sync-ABAADUser: Failed to query user: $Username" -LogObject $SyncAdUserLog

        }finally{
            if($user_object -eq $null){
                Write-Log -LogLevel TerminatingError -LogString "Sync-ABAADUser: No users found: $Username" -LogObject $SyncAdUserLog
            }
            Write-Log -LogLevel Verbose -LogString "Sync-ABAADUser: $($user_object.name)" -LogObject $SyncAdUserLog
        }


        try{
            if($user_object -ne $null){
                $allDCs | %{
                    Write-Log -LogString "Sync-ABAADUser: Syncing $($user_object.name) to: $($_.hostname)" -LogLevel Verbose -LogObject $SyncAdUserLog
                    $user_object | Sync-ADObject  -Destination $_.hostname
                }
                Write-Log -LogString "Sync-ABAADUser: Syncing $($user_object.name) Complete" -LogLevel Verbose -LogObject $SyncAdUserLog
            }
        }catch{
            Write-Log -LogLevel TerminatingError -LogString "Sync-ABAADUser: Failed to sync object`n$($_.exception)" -LogObject $SyncAdUserLog
        }

    }
}