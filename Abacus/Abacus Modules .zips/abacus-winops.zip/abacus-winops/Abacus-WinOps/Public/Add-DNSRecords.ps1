Function Add-DNSRecords {
<#
.SYNOPSIS
A PowerShell cmdlet for adding DNS Records

.DESCRIPTION
A PowerShell cmdlet for adding DNS Records

.PARAMETER HostName
Specify Hostname

.PARAMETER RecordType
Specify Record type: 'A','CNAME'

.PARAMETER Ipv4Address
Specify the IPv4 address

.PARAMETER Alias
If creating a CNAME, specify the alias

.PARAMETER CreatePtr
Specify this switch if you want to inlcude a PTR with your A record

.PARAMETER ZoneName
Specify DNS zone if not "Service02"

.PARAMETER DNSServer
Specify DNSServer if not "Service02"

.EXAMPLE
Add-DNSRecords -HostName <Hostname> -RecordType A -Ipv4Address <IP Address> -DNSServer <FQDN DNS Server>

.NOTES
General notes
#>
    [Cmdletbinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory=$True)]
        [String]$HostName
        ,
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('A','CNAME')]
        [String]$RecordType
        ,
        [ValidateNotNullOrEmpty()]
        [String]$Ipv4Address
        ,
        [ValidateNotNullOrEmpty()]
        [String]$Alias
        ,
        [ValidateNotNullOrEmpty()]
        [Switch]$CreatePtr
        ,
        [ValidateNotNullOrEmpty()]
        [String]$ZoneName = "service02.corp"
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DNSServer = 'service02.corp'
    )
    Begin {
        $HostFQDN = "$HostName.$ZoneName"
    }
    Process {
        Switch ($RecordType) {
            'A' {
                If (   ($RecordType -eq 'A') -and ([String]::IsNullOrEmpty($Ipv4Address))   ) {
                    Write-Log -LogString "In order to create an A-Record an IPAddress needs to be provided" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
                }

                If ($CreatePtr -eq $True) {
                    Add-DnsServerResourceRecordA -CreatePtr -Name $HostName -IPv4Address $Ipv4Address -ComputerName $DNSServer -ZoneName $ZoneName
                }
                Else {
                    Add-DnsServerResourceRecordA -Name $HostName -IPv4Address $Ipv4Address -ComputerName $DNSServer -ZoneName $ZoneName
                }
            }
            'CNAME' {
                If (   ($RecordType -eq 'CNAME') -and ([String]::IsNullOrEmpty($Alias))   ) {
                    Write-Log -LogString "In order to create a CNAME Record an needs to be provided" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
                }

                Add-DnsServerResourceRecordCName -Name $Alias -HostNameAlias $HostFQDN -ComputerName $DNSServer -ZoneName $ZoneName
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
            }
        }
    }
    End {

    }
}