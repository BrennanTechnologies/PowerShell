Function Get-SANPolicy{
    Param(
        $ComputerName
    )

    if($null -eq $ComputerName){
        $ComputerName = $env:COMPUTERNAME
    }
    
    $results = Invoke-Command -ScriptBlock {"san" | diskpart} -ComputerName $computername
    
    $pol = ($results | ?{$_ -match "SAN Policy"}).split(":")[1].trim()

    return $pol
}
