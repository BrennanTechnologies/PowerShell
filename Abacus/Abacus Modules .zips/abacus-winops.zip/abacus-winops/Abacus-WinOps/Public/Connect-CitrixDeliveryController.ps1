
Function Connect-CitrixDeliveryController {
    <#
    .SYNOPSIS
    A PowerShell cmdlet to connect to a Citrix Delivery Controller

    .DESCRIPTION
    This PowerShell command connects to a Citrix Delivery Controller via WSMAN

    .PARAMETER CitrixDeliveryControllers
    Specify target citrix delivery controllers

    .PARAMETER CitrixSessionName
    Specify citrix session name

    .EXAMPLE
    Connect-CitrixDeliveryController -CitrixDeliveryControllers <ArrayOfServerNames>

    .NOTES

    #>

    [CmdletBinding()]
    Param(
        [ValidateNotNull()]
        [Array]$CitrixDeliveryControllers = @("NYSRV2-XD01.service02.corp", "NYSRV2-XD02.service02.corp")
        ,
        [String]$CitrixSessionName = 'CTXDCSession'
    )
    Begin {
        $ReturnObject = @()
        $AlreadyConnected = $False

        #Check to see if we are already connected
        If (   [Boolean](Get-PSSession -Name $CitrixSessionName -ErrorAction SilentlyContinue) -eq $True   ) {
            $AlreadyConnected = $True
        }

        If ($AlreadyConnected -eq $False) {
            #Check Delivery Controllers
            ForEach ($CitrixDeliveryController in $CitrixDeliveryControllers) {
                Clear-Variable PingTestResult -ErrorAction SilentlyContinue
                $PingTestResult = Start-PingTest -Servers $CitrixDeliveryController
                If ($True -ne $PingTestResult) {
                    Write-Log -LogString "Ping test did not return positive. Is the server online?" -LogLevel Error
                }
                Else {
                    Try {
                        Test-WSMan -ComputerName $CitrixDeliveryController -ErrorAction Stop -ErrorVariable err | Out-Null
                        Write-Log -LogString "Attempting to connect to Delivery Controller: $CitrixDeliveryController" -LogLevel Output -LogObject $WinOps_global_logobject

                        New-PSSession -ComputerName $CitrixDeliveryController -Name $CitrixSessionName -Verbose -ErrorAction Stop | Out-Null
                        $CTXDCSession = (Get-PSSession -Name $CitrixSessionName)
                        Write-Log -LogString "Session Established..." -LogLevel Output -LogObject $WinOps_global_logobject

                        Invoke-Command -Session $CTXDCSession -ScriptBlock {Add-PSSnapin Citrix*} -ErrorAction Stop
                        Write-Log -LogString "Importing Citrix Modules..." -LogLevel Output -LogObject $WinOps_global_logobject
                        Break
                    }
                    Catch {
                        Write-Log -LogString "There was an error establishing a connection with the Delivery Controller." -LogLevel Warning -LogObject $WinOps_global_logobject
                        Write-Log -LogString "Error: $err" -LogLevel Error -LogObject $WinOps_global_logobject
                        Get-PSSession -Name $CitrixSessionName | Disconnect-PSSession | Out-Null
                        Get-PSSession -Name $CitrixSessionName | Remove-PSSession | Out-Null
                    }
                }
            }
        }
    }
    Process {
        If ($AlreadyConnected -eq $False) {
            $ReturnMessage = "Connected to $CitrixDeliveryController"
            Return $ReturnMessage
        }
        Else {
            Write-Log -LogString "A Sesssion to a Citrix Delivery controller is already established." -LogLevel Verbose -LogObject $WinOps_global_logobject
        }
    }
}