﻿

Function Get-ABAHealthCheckResults {
    Param(
        [ValidateSet("PingTest","VMTools","Disk","File_Shares","Win_Services","CTX_Registration")]
        [String]$HealthCheckType,
        [ValidateSet("Pass","Fail","QueryError","toolsOld","toolsOk","toolsNotRunning","toolsNotInstalled")]
        [String]$Status
    )
 
    if($global:healthcheck_results){
        
        $results = $global:healthcheck_results

    }else{
    
        throw "No healthcheck data found run - Start-ABAHealthcheck first"
    }

    if($HealthCheckType){

        $results = $results | ? Name -eq $HealthCheckType 
        
    }

    if($Status){

        $results = $results | ? Status -eq $Status 
        
    }
    $results = $results | Out-GridView -PassThru -Title "Choose filter results"

    return $results
    
}
