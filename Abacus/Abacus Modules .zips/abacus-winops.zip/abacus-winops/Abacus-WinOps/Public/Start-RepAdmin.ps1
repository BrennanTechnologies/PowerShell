Function Start-RepAdmin {
    <#
    .SYNOPSIS
    A PowerShell wrapper around a full repadmin sync

    .DESCRIPTION
    This PowerShell command can be used to specify a Source DC to replicate to all of it's replication partners to speed up replication in the environment.

    .PARAMETER Source
    Specify Source domain controller

    .PARAMETER Destination
    Specify destination destination domain controller

    .EXAMPLE
    Start-RepAdmin -Source <HostNameOfDomainController>

    .NOTES
    General notes
    #>
    [Cmdletbinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Parameter(ValueFromPipeLineByPropertyName = $True)]
        [String[]]$Source = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
        ,
        [ValidateNotNullOrEmpty()]
        $Destination = $(   $(Get-ADDomainController -Filter * -Server 'service02.corp' | Select -ExpandProperty HostName) | ?{$_ -ne $Source}   )
    )
    Begin {
    }
    Process {
            Write-Log -LogString "Executing command: 'repadmin /syncall $Source /APedQ'" -LogLevel Output -LogObject $Zerto_global_logobject
            repadmin /syncall $Source /APedQ
        }
}