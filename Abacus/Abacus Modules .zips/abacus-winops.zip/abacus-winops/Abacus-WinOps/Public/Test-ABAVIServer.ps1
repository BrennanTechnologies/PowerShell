function Test-ABAVIServer{
    <#
    .SYNOPSIS
    A PowerShell cmdlet that tests the connection to an abacus vi server

    .DESCRIPTION
    This PowerShell command tests the ABAVI server if it is connected

    .PARAMETER site
    Specify specific site to check against

    .PARAMETER RootVcenter
    Root hostname of all vcenters

    .PARAMETER vcenter
    Check connection against a specific vcenter hostname

    .EXAMPLE
    Test-ABAVIServer

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log

    #>

    [CmdletBinding(DefaultParameterSetName='BySite')]
    Param(
        [Parameter(ParameterSetName='BySite')]
        [Site]$site
        ,
        [String]$RootVcenter = "mgmtvc01.management.corp"
        ,
        [Parameter(ParameterSetName='byVcenter')]
        [String]$vcenter
    )

    if(!$(get-module vmware.vimautomation.core)){
        try{
            Get-Module -ListAvailable vmware.vimautomation.core | Import-Module -MinimumVersion 10.0.0
        }catch{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Failed to import Powercli version 10 or above"
        }
    }

    $Blank = Set-PowerCLIConfiguration -DefaultVIServerMode multiple -Confirm:$false -Scope Session -InvalidCertificateAction Ignore -DisplayDeprecationWarnings $false


    if($($PsCmdlet.ParameterSetName -eq "BySite")){
        $vcenter = $site | %{"$_"+"$RootVcenter"}
    }

    if($PsCmdlet.ParameterSetName -eq "byVcenter"){

        if($vCenter -notlike "*.management.corp"){
            $vCenter = $vCenter+".management.corp"
        }
    }

    if($null-ne $global:DefaultVIServers){
        if($null -ne $vcenter){
            if([bool]$($global:DefaultVIServers -match $vcenter)){
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Already connected to $global:DefaultVIServers"
                return $true
            }else{
                return $false
            }
        }
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Already connected to $global:DefaultVIServers"
        return $true
    }else{
        return $false
    }
}