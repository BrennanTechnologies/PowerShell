Function Test-VDIRegistrationStatus {
    <#
    .SYNOPSIS
    A PowerShell cmdlet that test a Citrix Server's registration status

    .DESCRIPTION
    This PowerShell command tests to see if a Citrix server is registered through the Citrix Delivery Controller

    .PARAMETER VMNames
    Specify target VMNames

    .PARAMETER CTXDomain
    Specify CTX domain to check registration against

    .PARAMETER CitrixSessionName
    Check using specific CTX pssession

    .EXAMPLE
    Test-VDIRegistrationStatus -VMNames <VMName>

    .NOTES
    General notes
    #>
    [CmdletBinding()]
    Param(
        [ValidateNotNull()]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True)]
        [String[]]$VMNames
        ,
        [ValidateNotNull()]
        [String]$CTXDomain = ".service02.corp"
        ,
        [String]$CitrixSessionName = 'CTXDCSession'
    )
    Begin {
        $ReturnObject = @()
        #Check if We have an open connection
        $CTXDCSession = Get-PSSession -Name $CitrixSessionname
    }
    Process {
        ForEach ($VMName in $VMNames) {
            Remove-Variable CTXMachineObject -ErrorAction SilentlyContinue
            Remove-Variable RegistrationState -ErrorAction SilentlyContinue
            Remove-Variable CurrentVM -ErrorAction SilentlyContinue
            [String]$CurrentVM = $($VMName+$CTXDomain)

            Try {
                Write-Log -LogString "Performing query for VM $CurrentVM against endpoint `"$(Get-PSSession -Name $CitrixSessionname | Select -ExpandProperty ComputerName)`"" -LogLevel Output -LogObject $WinOps_global_logobject
                Invoke-Command -Session $CTXDCSession -ScriptBlock {Param ($CurrentVM) Get-BrokerMachine -DNSName $CurrentVM | Select DNSName, MachineName, IPAddress, RegistrationState, UUID } `
                    -ArgumentList $CurrentVM `
                    -OutVariable CTXMachineObject | Out-Null

                If ($Null -eq $CTXMachineObject.RegistrationState.Value) {
                    Write-Log -LogString "No machine object was returned for `"$CurrentVM`" by the Citrix Delivery Controller" -LogLevel Warning -LogObject $WinOps_global_logobject
                    $RegistrationState = "ERR"
                }
                Else {
                    #Object detected, check RegistrationState
                    If ($CTXMachineObject.RegistrationState.Value -eq 'Registered') {
                        [Boolean]$RegistrationState = $True
                    }
                    Else {
                        [Boolean]$RegistrationState = $False
                    }
                }
                $ReturnObject += [PSCustomObject]@{VMName = $($CurrentVM) ; RegistrationState = $RegistrationState}
            }
            Catch {
                Write-Log -LogString "An error was encountered when attempting to invoke command(s) to the Citrix Delivery Controller." -LogLevel Error -LogObject $WinOps_global_logobject
            }
        }

    }
    End {
        Return $ReturnObject
    }
}


