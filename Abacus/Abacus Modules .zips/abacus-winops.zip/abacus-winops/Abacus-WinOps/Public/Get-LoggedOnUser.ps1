﻿function Get-LoggedOnUser{
    <#
    .SYNOPSIS
    Querys machine for logged on user

    .DESCRIPTION
    Queries WMI or CIM for logged on users 

    .PARAMETER Computername 
    Target Computername


    .PARAMETER Method
    Choose method for query WMI or CIM

    .EXAMPLE 
    Get-LoggedOnUser -ComputerName nymgmtbatch03.management.corp -Method CIM

    .NOTES
    you need credentials to access panel to run this command.
    #>
     [CmdletBinding()]
     param
     (
         [Parameter(mandatory=$true)]
         [ValidateNotNullOrEmpty()]
         [string[]]$ComputerName = $env:COMPUTERNAME
         ,
         [ValidateSet('WMI','CIM')]
         [String]$Method = "WMI"
     )

     Begin{ }
     Process{

        $ping = Test-Connection $ComputerName -Quiet -Count 2

        if($ping -eq $true){
            
            switch ($Method)
            {
                'WMI' 
                {
                    $WMI = (Get-WmiObject Win32_LoggedOnUser).Antecedent
                    $ActiveUsers = @()
                    foreach($User in $WMI) {
                        $StartOfUsername = $User.LastIndexOf('=') + 2
                        $EndOfUsername = $User.Length - $User.LastIndexOf('=') -3
                        $ActiveUsers += $User.Substring($StartOfUsername,$EndOfUsername)
                    }
                }
                'CIM' 
                {
                    $ActiveUsers = (Get-CimInstance Win32_LoggedOnUser -ComputerName $ComputerName).antecedent.name | Select-Object -Unique
                }
            }
        }
        
        return $ActiveUsers
     }
}
