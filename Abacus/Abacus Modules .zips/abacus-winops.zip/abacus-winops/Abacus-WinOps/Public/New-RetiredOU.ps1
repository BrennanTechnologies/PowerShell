Function New-RetiredOU {
<#
    .SYNOPSIS
    Queries a Retired Objects OU and creates it if it does not exist

    .DESCRIPTION
    Create-RetiredOU uses Active Directory module Create a retired workstations OU in the domain Root level

    .PARAMETER Domain
    Domain entries to be targeted

    .PARAMETER OU_Name
    Default OU object name

    .EXAMPLE 
     Create-RetiredOU -domain "ezevonage.corp"

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

    Param(
        [Parameter(Mandatory=$true,ValueFromPipeline)]
        [String]$Domain,
        [String]$OU_Name = "Retired Objects"
    )
    
    $canonicalname_ou = "$Domain/$OU_Name" 
    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Create-RetiredOU: Checking for $canonicalname_ou OU" 
    try{
        $retired_OU = Get-ADOrganizationalUnit -Server $Domain -Filter {Name -eq "Retired Objects"} -Properties canonicalname | ? canonicalname -eq $canonicalname_ou
    }catch{
        Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Create-RetiredOU: Failed to query OU $canonicalname_ou`n$($_.exception)" 
    
    }

    $root_path  = 'DC=' + $Domain.Replace('.',',DC=')  

    if(!$retired_OU){
        try{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Create-RetiredOU: Creating OU $OU_Name in $root_path" 
            New-ADOrganizationalUnit -name $OU_Name -Path $root_path -Server $Domain
        }catch{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Create-RetiredOU: Failed creating OU $OU_Name in $root_path`n$($_.exception)" 
        }
    }else{
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Create-RetiredOU: OU already exists: $($retired_OU.name)" 
    }
}

Set-Alias -Name "Create-RetiredOU" -Value "New-RetiredOU"