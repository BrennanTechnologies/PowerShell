﻿<#
.SYNOPSIS
A PowerShell comdlet gets the VM Disk space

.DESCRIPTION
This Powershell command that gets the VM Disk spaces

.PARAMETER FQDN
Fully qualified domain name of computer

.EXAMPLE
Get-VMDiskSpace -VMname <VMname>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

Function Get-VMDiskSpace {
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true)]
        [Alias("Name")]
        [Alias("Computer")]
        [String]$FQDN = $([System.Net.DNS]::GetHostByName('').HostName)
    )
    begin{

    }
    process{
        Try {
            $os = Get-WmiObject win32_OperatingSystem -computername $FQDN -ErrorAction Stop
            #continue if there were no errors
            Get-WMIObject Win32_Logicaldisk -ComputerName $FQDN | Select PSComputername,DeviceID,
            @{Name="SizeGB";Expression={$_.Size/1GB -as [int]}},
            @{Name="FreeGB";Expression={[math]::Round($_.Freespace/1GB,2)}},
            @{Name="PercentFree";Expression={[math]::Round(($_.Freespace/$_.Size)*100,2)}} |? SizeGB -ne 0
            Sort PSComputerName
        }
        Catch {
            #$_ is the error object
            Write-Warning "Failed to get OperatingSystem information from $FQDN. $($_.Exception.Message)"
        }
    }
    end{
    
    }
    
}