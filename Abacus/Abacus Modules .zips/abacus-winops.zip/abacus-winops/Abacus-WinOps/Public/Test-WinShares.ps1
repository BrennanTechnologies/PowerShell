﻿<#
.SYNOPSIS
A PowerShell cmdlet that queries all shares on a target machine, runs a test path and touch test against them

.DESCRIPTION
This PowerShell command queries all shares on a target machine, runs a test path and touch test against them

.PARAMETER FQDN
Fully qualified domain name of the computer

.EXAMPLE
Test-WinShares -FQDN <FQDN>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

function Test-WinShares{
    Param(
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true)]
        [Alias("Machines")]
        $FQDN
    )
    begin{
        $results = @()
    }
    
    process{
        write-host "Testing $FQDN"
        if(Test-Connection -Count 2 -ComputerName $FQDN -ErrorAction SilentlyContinue){
            $shares = gwmi -class Win32_Share -ComputerName $FQDN
            $shares.name | %{
            $UNC_Path = "\\$FQDN\$_"
            
            $test_path = Test-Path $UNC_Path -ErrorAction SilentlyContinue -ErrorVariable $file_err
            
                
            
            if($null -ne $file_err){
                $test_path = $file_err.exception
            }
            
            $obj = New-Object -TypeName PSobject
            $obj | Add-Member -MemberType NoteProperty -Name Share -Value $_
            $obj | Add-Member -MemberType NoteProperty -Name UNC_Path -Value $UNC_Path
            $obj | Add-Member -MemberType NoteProperty -Name Reachable -Value $test_path
            $obj | Add-Member -MemberType NoteProperty -Name Touchtest -Value "NA"

            if($test_path -eq $true){
                $touch_file = "$UNC_Path\touch_test.txt"
                
                try{
                    Touch-File $touch_file    
                }catch{
                    $touch_err = "Failed to create test file"
                    $obj.Touchtest = $touch_err
                }

                if([string]::IsNullOrEmpty($touch_err)){
                    try{
                        unTouch-File $touch_file    
                    }catch{
                        $touch_err = "Failed to remove test file"
                        $obj.Touchtest = $touch_err
                    }
                }

                if([string]::IsNullOrEmpty($touch_err)){
                    $obj.Touchtest = "Success"
                }

            }

            $results += $obj
            Remove-Variable touch_err,touch_file -ErrorAction SilentlyContinue
        }
        }else{
            $result = "$FQDN unreachable"
        }
    }

    end{
        return $results
    }
}

Function Touch-File{
    Param(
        $file 
    )
    if([string]::IsNullOrEmpty($file)) {
        throw "No filename supplied"
    }

    if(Test-Path $file)
    {
        (Get-ChildItem $file).LastWriteTime = Get-Date
    }
    else
    {
        echo $null > $file
    }
}

Function unTouch-File{
    Param(
        $file 
    )
    if([string]::IsNullOrEmpty($file)) {
        throw "No filename supplied"
    }

    if(Test-Path $file)
    {
        Remove-Item $file
    }
    
}