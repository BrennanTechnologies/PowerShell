Function Sync-ABAADObject {
    <#
    .SYNOPSIS
    A PowerShell cmdlet for Syncing AD Objects

    .DESCRIPTION
    This PowerShell command can be used to Sync AD Objects across domain controllers

    .PARAMETER ADObject
    Specify the target AD object

    .PARAMETER Source
    Specify the Source DC

    .PARAMETER Destination
    Specify the Destnation DC

    .PARAMETER ZoneName
    Specify the zone name

    .EXAMPLE
    Sync-ABAADObject -ADObject <DistinguishedName> -Source <DomainController> -Destination <DomainController> -ZoneName <DomainName>

    .NOTES
    General notes
    #>


    [Cmdletbinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Alias("DistinguishedName")]
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [String[]]$ADObject
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [String[]]$Source = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
        ,
        [ValidateNotNullOrEmpty()]
        $Destination = $(   $(Get-ADDomainController -Filter * -Server 'service02.corp' | Select -ExpandProperty HostName) | ?{$_ -ne $Source}   )
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(ValueFromPipeLineByPropertyName = $True)]
        [String[]]$ZoneName = "service02.corp"
    )
    Begin {

    }
    Process {
            ForEach ($Server in $Destination ) {
                $StringSource = [String]$Source
                $StringADObject = [String]$ADObject
                $Object = $(Get-ADObject -Identity $StringADObject -Server $StringSource)
                $StringZoneName = [String]$ZoneName

                Write-Log -LogString "SyncADObject $StringADObject from $StringSource to $Server" -LogLevel Output -LogObject $WinOps_global_logobject
                Sync-ADObject -Object $Object -Source $StringSource -Destination $Server
            }
        }
}