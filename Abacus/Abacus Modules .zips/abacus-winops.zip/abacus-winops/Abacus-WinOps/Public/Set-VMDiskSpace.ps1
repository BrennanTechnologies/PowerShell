﻿Function Set-VMDiskSpace {
    Param(
        [Parameter(Mandatory=$true)]
        [Alias("Name")]
        [Alias("Computer")]
        [String]$FQDN = $([System.Net.DNS]::GetHostByName('').HostName)
        ,
        [Parameter(Mandatory=$true)]
        [Char]$Drive_letter
        ,
        [Parameter(Mandatory=$true)]
        [ValidateRange(5,50)] 
        [int32]$Percent_free
        ,
        $log_file
        ,
        $max_expand = 150
        ,
        $Data_store_percent_free_TH = 20
    )

    Begin{

        if($null -eq $log_file){
            $log_file = $WinOps_global_logobject 
        
        }

        Function Get-ExpandByValue {
            Param(
                    $Target_Percent_Free, #Make Disk to X percent free
                    $max_expand,
                    $target_disk_space,
                    $log_object
            )

            #calculate how much to expand by 
            [double]$total_capacity = $target_disk_space.SizeGB
            [double]$free_Space = $target_disk_space.FreeGB
            [double]$taken_Space = $total_capacity - $free_Space
                                
            $expand_value = ($taken_Space/($($(100-$Percent_free)/100))) - $total_capacity 

            Write-Log -LogObject $log_object "expected expand value: $expand_value"
                                    
            #validate expand property
            if($expand_value -lt 0){

                Write-Log -LogObject $log_object `
                          -LogLevel TerminatingError `
                          -LogString "Error: negetive number`n check to ensure that free space does not already exceed desired free space"

            }elseif($expand_value -gt $max_expand){
                Write-Log -LogObject $log_object -LogLevel TerminatingError "Execeeds the $max_expand GB limit set"
            }else{
                $expand_value = [math]::Ceiling($expand_value)
            }

            Write-Log -LogObject $log_object "Determined that Drive: $drive_letter needs to be expanded by $expand_value GB (Rounded up)"

            return $expand_value
        }

        Function Start-SmokeTest {
            Param (
                $target,
                $log_object
            )

            Write-Log -LogObject $log_object -Verbose -LogString "Starting Smoke test"
            $smoke_test = $true
            $testcon = test-connection -ComputerName $target -Count 2 -Quiet
            if($true -ne $testcon){
                Write-Log -LogObject $log_object -LogLevel Warning "Ping Test Failed - check host connection"
                $smoke_test = $false
            }

            $testKerb = Test-WSMan -ComputerName $target -Authentication Kerberos
            if([string]::IsNullOrEmpty($testKerb.wsmid)){
                Write-Log -LogObject $log_object -LogLevel Warning "Failed WSMan Test - check winrm connection"
                $smoke_test = $false
            }

            return $smoke_test

        }

        
        if([bool]$(Test-ABAVIServer) -eq $False){
            Write-Log -LogObject $log_file -LogLevel TerminatingError -LogString "Connect to VI server first"
        }
    }

    Process{

        $vm = Get-View -ViewType VirtualMachine -Filter @{'Guest.Hostname' = $FQDN}
            
        if($null -eq $vm){
            Write-Log -LogObject $log_file -LogLevel Warning "Failed to find VM $target_host"
            
        }else{
            if($null -ne $vm){
                Write-Log -LogObject $log_file "Drive in question: $Drive_letter"
                $target_disk = Get-VMDiskMapping -VMname $vm.Name | ? Drives -EQ "$($drive_letter):"
            }
        }
        
        

        if($null -eq $target_disk){

            Write-Log -LogObject $log_file -LogLevel Warning -LogString "Unable to find target disk $($Drive_letter)"
                    
        }else{

            Write-Log -LogObject $log_file "Target Disk detected: $($target_disk | Out-String)"
                        
            #Smoke Test 
            $smoke_test_results = Start-SmokeTest -target $FQDN -log_object $log_file

            #validate there has not already been a run of this script in the past month
                        
            if($smoke_test_results -eq $false){

                Write-Log -LogObject $log_file -LogLevel TerminatingError "Failed smoke test"

            }else{
                #calculate how much to expand disk
                #query disk info
                $target_disk_space = Get-VMDiskSpace -FQDN $FQDN | ? DeviceID -EQ "$($drive_letter):"

                if($null -eq $target_disk_space){
                                
                    Write-Log -LogObject $log_file -LogLevel Warning "Unable to query disk space of drive"

                }else{

                    if($target_disk_space.PercentFree -gt $Percent_free){

                        Write-Log -LogObject $log_file `
                                  -LogLevel Warning "Target free space is already $($target_disk_space.PercentFree) % free, passed the desired limit of $Percent_free"
                                    
                    }else{
 
                        #query for how much to expand disk by
                        $expand_by = Get-ExpandByValue -Target_Percent_free $Percent_free `
                                                       -max_expand $max_expand `
                                                       -target_disk_space $target_disk_space `
                                                       -log_object $log_file

                        if($expand_by -gt $max_expand){
                            Write-Log -LogObject $log_file `
                                      -LogLevel TerminatingError "$expand_by is beyond allow max expand value"
                            
                        }

                        #validate Datastore resources
                        Write-Log -LogObject $log_file "Validating Datastore: $($target_disk.vmHardDiskDatastore) has enough resources"

                        $data_store = Get-Datastore -Name $target_disk.vmHardDiskDatastore

                        $data_store_free =[Math]::Round((($data_store.FreeSpaceGB/$data_store.CapacityGB)*100),0)                    
                        
                        if($null -eq $data_store_free){
                            Write-Log -LogObject $log_file `
                                      -LogLevel TerminatingError "Unable to determine datastore freespace:$data_store"
                        }else{
                            if($data_store_free -lt $Data_store_percent_free_TH){
                                Write-Log -LogObject $log_file `
                                          -LogLevel TerminatingError `
                                          -LogString "The data store does not meet the required freespace threshhold of $Data_store_percent_free_TH percent"
                            }else{
                                if($expand_by -gt $($data_store.FreeSpaceGB)){
                                    Write-Log -LogObject $log_file -LogLevel TerminatingError -LogString "Not enough space on datastore"
                                }
                            }
                        }

                        #expand actual disk
                        try{
                            $vm_obj = vmware.vimautomation.core\get-vm -Id $vm.MoRef 
                            $vmware_harddisks = $vm_obj | vmware.vimautomation.core\Get-HardDisk
                            $target_vmware_harddisk = $vmware_harddisks | ? Filename -Match $($target_disk.vmHardDiskVmdk)

                        }catch{
                            Write-Log -LogObject $log_file -LogLevel TerminatingError "Failed to query vmdk object"
                        }

                        if($null -eq $target_vmware_harddisk){
                                    
                            Write-Log -LogObject $log_file -LogLevel TerminatingError "vmdk object not found"
                        }else{
                            try{
                                Write-Log -LogObject $log_file `
                                          -LogString "Executing expansion on disk on $($target_vmware_harddisk.Filename) to expand to $($target_disk_space.SizeGB + $expand_by)"
                                $results = $target_vmware_harddisk | Set-HardDisk -CapacityGB $($target_disk_space.SizeGB + $expand_by) -ResizeGuestPartition -Confirm:$false 
                            }catch{
                                Write-Log -LogObject $log_file -LogLevel TerminatingError "Failed to expand drive"
                            }
                        }
                    }
                }   
            }
        }           
    }
}