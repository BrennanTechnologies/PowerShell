﻿function Update-VMT {
    <#
    .SYNOPSIS
    A PowerShell cmdlet that updates the vmware tools on target vm

    .DESCRIPTION
    This PowerShell command can be used to update vmware tools

    .PARAMETER VMNames
    Name or names of Virtual Machines

    .PARAMETER VMs
    Pass powercli vmware VM object

    .EXAMPLE
    Update-VMT -VMname <VMname>

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
    #>
    [CmdletBinding(DefaultParameterSetName='ByName')]
    Param (
        [Parameter(ValueFromPipeline=$true,Mandatory=$true,ParameterSetName='ByName')]
        [ValidateNotNullOrEmpty()]
        [Alias("VMName")]
        [string]$VMNames
        ,
        [Parameter(ValueFromPipeline=$true,Mandatory=$true,ParameterSetName='ByVM')]
        [ValidateNotNullOrEmpty()]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl]$VMs
    )
    begin{
        if($global:DefaultVIServers.IsConnected -ne $true){
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Update-VMT: Connect to VIserver first: Connect-ABAVIServer -site <site>"
        }
    }

    process{



        if($PsCmdlet.ParameterSetName -eq "ByName"){

            if($VMNames | gm -MemberType NoteProperty -Name Data){
                $VMNames = $VMNames.data
            }

            try{
                $VMs = VMware.VimAutomation.Core\Get-VM -Name $VMname

            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Error trying to query vm $VMname"
            }
        }

        if(!$VMs){
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Update-VMT:VMs  not found"
        }else{
            foreach ($vm in $vms){
                try{
                    Write-Log -LogObject $WinOps_global_logobject -LogString "Update-VMT: Attempting to update $($vm.name)"
                    $vm | Update-Tools -NoReboot
                }catch{
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Update-VMT: Failed to update $($vm.name)`n$($_.exception)"
                }
            }

        }
    }

    end{
        Write-Log -LogObject $WinOps_global_logobject -LogString "Update-VMT: end"
    }
}