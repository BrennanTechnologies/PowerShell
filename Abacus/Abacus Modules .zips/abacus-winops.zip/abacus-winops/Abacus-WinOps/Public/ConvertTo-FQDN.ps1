<#
.SYNOPSIS
A PowerShell cmdlet takes a vm short name and returns the fully qualified domain name

.DESCRIPTION
This PowerShell command takes a vm short name and returns the fully qualified domain name

.PARAMETER VMname
Name or names of Virtual Machines

.EXAMPLE
ConvertTo-FQDN -VMname <VMname> 

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

Function ConvertTo-FQDN {
    Param(
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true)]
        [Alias("Name")]
        [String]$VMname
    )
    begin{
        If ( $(Test-ABAVIServer) -eq $False) {
            Write-Log -LogString "There is currently no connection to a VIServer" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        } 
    }
    process{
        $All_hostnames = @()
        $VMname | %{
            $hostname = VMware.VimAutomation.Core\Get-VM $_ | Get-VMGuest | Select-Object -ExpandProperty hostname
            $All_hostnames+= $hostname
        }
        return $All_hostnames
    }
    
}