Function Set-SANPolicy{
    Param(
        [String]$ComputerName,
        [ValidateSet("OnlineAll","OfflineAll","OfflineShared","OfflineInternal")]
        [String]$Policy
    )

    Invoke-Command -ScriptBlock {"san policy=$($args[0])" | diskpart} -ComputerName $ComputerName -ArgumentList $Policy
}