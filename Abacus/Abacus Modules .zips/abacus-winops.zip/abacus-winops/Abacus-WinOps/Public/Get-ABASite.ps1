﻿Function Get-ABASite {
    Param(
        $siteID
    )

    $allvalues = [System.enum]::GetValues('Site') | ForEach-Object -Process {
        [PSCustomObject]@{
        Name = $_
        Value = $_.value__
        }
    }

    if($siteID){
        return $allvalues | ? value -eq $siteID | select -ExpandProperty name | select -First 1
    }else{
        return $allvalues
    }

}

