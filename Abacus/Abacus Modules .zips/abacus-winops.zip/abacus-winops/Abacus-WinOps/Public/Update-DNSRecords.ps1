Function Update-DNSRecords {
    <#
    .SYNOPSIS
    A PowerShell cmdlet for updating DNS Records

    .DESCRIPTION
    This PowerShell command can be used to update DNS records' IP Addresses

    .PARAMETER HostName
    Specify Target Hostname

    .PARAMETER RecordType
    Specify Record type: A

    .PARAMETER Ipv4Address
    Specify IPv4 Address

    .PARAMETER ZoneName
    Specify DNS ZoneName if not "Service02.corp"

    .PARAMETER DNSServer
    Specify DNSServer: Default will use service02.corp srv record to evaluate

    .EXAMPLE
    Update-DNSRecords -HostName <Hostname> -RecordType A -Ipv4Address <IP Address> -DNSServer <FQDN DNS Server>

    .NOTES
    General notes
    #>
    [Cmdletbinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory=$True)]
        [String]$HostName
        ,
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('A')]
        [String]$RecordType
        ,
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [String]$Ipv4Address
        ,
        [ValidateNotNullOrEmpty()]
        [String]$ZoneName = "service02.corp"
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DNSServer = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
    )
    Begin {
        Write-Log -LogString "Perform 2 DNS queries for DNS objects (original + clone to modify)" -LogLevel Output -LogObject $WinOps_global_logobject
        $DNSServers = $(Get-ADDomainController -Filter * -Server $ZoneName | select -ExpandProperty HostName)
            $DNSServers = $DNSServers | ?{$_ -ne $DNSServer}
        $DNSRecord = $(Get-DNSRecords -HostNames $HostName -ZoneName $ZoneName -DNSServer $DNSServer -ErrorAction SilentlyContinue | ?{$_.RecordType -eq $RecordType})
        $UpdatedDNSRecord = $(Get-DNSRecords -HostNames $HostName -ZoneName $ZoneName -DNSServer $DNSServer -ErrorAction SilentlyContinue | ?{$_.RecordType -eq $RecordType})
    }
    Process {
        If ($Null -eq $DNSRecord) {
            Write-Log -LogString "No DNSRecords were detected for $HostName" -LogLevel Warning -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
        }
        Else {
            Write-Log -LogString "DNSRecord(s) detected for $HostName" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
            $UpdatedDNSRecord.RecordData.Ipv4Address = $Ipv4Address
        }
    }
    End {
        If ($Null -ne $DNSRecord) {
            Write-Log -LogString "Updating `"$HostName`" `"$($RecordType)-Record`" to `"$($UpdatedDNSRecord.RecordData.IPv4Address)`" on server `"$DNSServer`"" -LogLevel Output -LogObject $WinOps_global_logobject
            $DNSObject = $(Get-ADObject -Server $DNSServer -Identity $($DNSRecord | Select -ExpandProperty DistinguishedName))
            Set-DnsServerResourceRecord -OldInputObject $DNSRecord -NewInputObject $UpdatedDNSRecord -ZoneName $ZoneName -ComputerName $DNSServer
            $ReturnObject = [PSCustomObject]@{HostName=$HostName;Source=$DNSServer;ZoneName=$ZoneName;DistinguishedName=$DNSObject.DistinguishedName}
            Return $ReturnObject
        }
    }
}