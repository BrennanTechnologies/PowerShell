﻿<#
.SYNOPSIS
A PowerShell cmdlet for connecting to a VI Server (vCenter)

.DESCRIPTION
This PowerShell command connects to a VI Server (vCenter)

.PARAMETER site
Site you would like to connect to

.PARAMETER all
Connects to all sites

.PARAMETER vcenter
Connects to specific vcenter host. must end in management.corp or it will be appended

.PARAMETER RootVcenter
Root zvm string the site is appended to
    Default Value: mgmtvc01.management.corp

.EXAMPLE
Connect_ABAVIServer -site <SiteCode>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

function Connect-ABAVIServer{

    [CmdletBinding(DefaultParameterSetName='BySite')]
    Param(
        [Parameter(Mandatory=$true,ParameterSetName='BySite')]
        [Site]$site
        ,
        [Parameter(Mandatory=$true,ParameterSetName='byAll')]
        [Switch]$all
        ,
        [String]$RootVcenter = "mgmtvc01.management.corp"
        ,
        [Parameter(Mandatory=$true,ParameterSetName='byVcenter')]
        [String]$vcenter
        ,
        [PSCredential]$Credentials
    )

    if(!$(get-module vmware.vimautomation.core)){
        try{
            Get-Module -ListAvailable vmware.vimautomation.core | Import-Module -MinimumVersion 10.0.0
        }catch{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Failed to import Powercli version 10 or above"
        }
    }

    $Blank = Set-PowerCLIConfiguration -DefaultVIServerMode multiple -Confirm:$false -Scope Session -InvalidCertificateAction Ignore -DisplayDeprecationWarnings $false
    if($all -eq $true){
        [String[]]$site = $(Get-ABASite).Name
    }

    if($($PsCmdlet.ParameterSetName -eq "BySite") -or $($PsCmdlet.ParameterSetName -eq "byAll")){
        $vcenterList = $site | %{"$_"+"$RootVcenter"}
    }

    if($PsCmdlet.ParameterSetName -eq "byVcenter"){

        if($vCenter -notlike "*.management.corp"){
            $vCenter = $vCenter+".management.corp"
        }

        $vcenterlist = $vcenter
    }

    $vcenterList | %{
        $dns = Resolve-DnsName -Name $_ -ErrorAction SilentlyContinue
        if($dns){
            $vI_connection_test = $global:DefaultVIServers.Name -match $_
            if($($vI_connection_test -eq $false) -or $([String]::IsNullOrEmpty($vI_connection_test))){
                If ($Null -ne $Credentials) {
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Connecting to {$($_)} with specified Credentials."
                    Connect-VIServer -Server $_ -Credential $Credentials
                }
                Else {
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Connecting to {$($_)}."
                    Connect-VIServer -Server $_
                }
            }else{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Already connected to $_"
            }
        }else{
            Write-Warning "Skipping connection: $_ does not resolve DNS"
        }

    }
}