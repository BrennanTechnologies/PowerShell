﻿<#
.SYNOPSIS
Starts an array of healthchecks for servers and generates a report

.DESCRIPTION
Starts an array of healthchecks for servers and generates a report

.PARAMETER VMnames
Virtual machine name to target

.PARAMETER VMs
Virtual machine object to target

.PARAMETER File_path
Path to a txt file that contains list of virtual machine names to target

.EXAMPLE
Start-ABAHealthCheck -VMNames @("server01","Server2","Server3")
or
$vms = get-vm -name @("server01","Server2","Server3")
Start-ABAHealthCheck -VMs $vms

.NOTES
Value by pipeline will not work with this function!
#>

Function Start-ABAHealthCheck {
[CmdletBinding(DefaultParameterSetName='ByName')]
    Param (
        [Parameter(Mandatory=$true,ParameterSetName='ByName')]
        [ValidateNotNullOrEmpty()]
        [string[]]$VMNames
        ,
        [Parameter(Mandatory=$true,ParameterSetName='ByVM')]
        [ValidateNotNullOrEmpty()]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl[]]$VMs
        ,
        [Parameter(Mandatory=$true,ParameterSetName='ByFile')]
        [ValidateNotNullOrEmpty()]
        $File_Path
    )


    ######
    #connections
    ######
    if(!$(Test-ABAVIServer)){
        Write-Log -LogLevel TerminatingError -LogString "Start-ABAHealthCheck - No connections to VIServers"
    }
    $results = @()
    $FQDN_Mapping = @()
    ##citrix connection to delivery controller
    [String]$CitrixSessionName = 'CTXDCSession'
    If ([Boolean](Get-PSSession -Name $CitrixSessionName -ErrorAction SilentlyContinue) -eq $False) {
        Try {
            $blank = Connect-CitrixDeliveryController -ErrorAction Stop
            $CTXDCSession = Get-PSSession -Name $CitrixSessionname
        }
        Catch {
            Write-Log -LogString "There was an error trying to connect to a Citrix Delivery Controller" -LogLevel Error -LogObject $WinOps_global_logobject
        }
    }
    Else {
        $CTXDCSession = Get-PSSession -Name $CitrixSessionname
    }


    ########
    #determine input methods
    ########

    if($PsCmdlet.ParameterSetName -eq "ByName"){
        Write-Host -ForegroundColor Yellow "VMname input type detected"
        try{
            $VM_Objects = VMware.VimAutomation.Core\Get-VM -Name $VMnames
            Write-Host "VMObjects: `n$VM_Objects"
        }catch{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Error trying to query vm $VMnames"
        }
    }

    if($PsCmdlet.ParameterSetName -eq "ByVM"){

        Write-Host -ForegroundColor Yellow "VM input type detected"
        $VM_Objects = $VMs
        $VMnames = $VMs.name

    }

    if($PsCmdlet.ParameterSetName -eq "ByFile"){

        if(Test-Path -Path $File_Path){
            $VMnames = Get-Content $File_Path
            try{
                $VM_Objects = VMware.VimAutomation.Core\Get-VM -Name $VMnames

            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Error trying to query vm $VMnames"
            }
        }else{
            throw "Error attempting to query $File_Path"
        }

    }


    ######
    #Calculate FQDN from VM object
    ######
    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Querying VM for FQDN information"
    foreach($vm in $VM_Objects){

        $object = New-Object -TypeName PSObject
        $object | Add-Member -MemberType NoteProperty -Name "VMName" -Value $vm.name

        if($vm){
            $FQDN = $vm | Get-VMGuest | select -ExpandProperty hostname
            $object | Add-Member -MemberType NoteProperty -Name "FQDN" -Value $FQDN
            $object | Add-Member -MemberType NoteProperty -Name "Powerstate" -Value $vm.powerstate
            $object | Add-Member -MemberType NoteProperty -Name "VM_object" -Value $vm
        }else{
            $object | Add-Member -MemberType NoteProperty -Name "FQDN" -Value $null

        }

        $FQDN_Mapping += $object
    }

    $legit_machines = $FQDN_Mapping | where-object {$($_.FQDN -ne $null) -and $($_.Powerstate -eq "PoweredOn")}

    #####
    #Multi threaded operations
    #####

    #ping test
    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Pinging all Powered on machines"
    $ping_results = Start-PingTest -servers $legit_machines.FQDN -maxCurrentJobsRunning 100


    #VDIRegistration data gathering
    $target_ctx_vmnames = $VMNames | ? {$_ -like "*CTX*"}

    if($null -ne $target_ctx_vmnames){
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "checking all CTX registration status"
        $vdi_reg_results =  Test-VDIRegistrationStatus -VMNames $target_ctx_vmnames
    }


    #####
    #single threaded operations + data collection
    ######

    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Querying live machines"
    foreach($machine in $legit_machines){

        $FQDN = $machine.FQDN
        $vmname = $machine.VMName
        $vm_object = $machine.VM_object

        #ping collected results here

        $ping_data = $ping_results | ? Name -match $FQDN

        if($ping_data.status -eq $False){
            $ping_status = "Fail"
        }elseif($ping_data.status -eq $True){
            $ping_status = "Pass"
        }else{
            $ping_status = "QueryError"
        }

        $ping_object = New-Object -TypeName PSObject
        $ping_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
        $ping_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "PingTest"
        $ping_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $ping_status
        $ping_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $ping_data
        $results += $ping_object


        #check vmware tools
        try{
            $vmt_data = Get-VMTStatus -VMs $vm_object

            if(!$vmt_data.ToolsStatus){
                $vmt_status = "null"
            }

        }catch{
            $vmt_status = "QueryError"
        }

        $vmt_object = New-Object -TypeName PSObject
        $vmt_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
        $vmt_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "VMTools"
        $vmt_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $vmt_data.ToolsStatus
        $vmt_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $vmt_data
        $results += $vmt_object


        #CTX registration data collected here

        $vdi_reg_status_data = $vdi_reg_results | ? VMName -match $FQDN

        if($vdi_reg_status_data){
            if($vdi_reg_status_data.RegistrationState -eq $False){
                $vdi_reg_status_status = "Fail"
            }elseif($vdi_reg_status_data.RegistrationState -eq $True){
                $vdi_reg_status_status = "Pass"
            }elseif($vdi_reg_status_data.RegistrationState -eq "ERR"){
                $vdi_reg_status_status = "QueryError"
            }

            $vdi_reg_status_object = New-Object -TypeName PSObject
            $vdi_reg_status_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
            $vdi_reg_status_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "VDI_Registration_status"
            $vdi_reg_status_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $vdi_reg_status_status
            $vdi_reg_status_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $vdi_reg_status_data
            $results += $vdi_reg_status_object

        }

        #######
        #Additional checks only if machine is pingable
        ########

        if($ping_status -eq "Pass"){

            #check disk
            try{
                $disk_data = Get-VMDiskSpace -FQDN $FQDN

                if($($disk_data | ? percentfree -LT 10 |measure).count -gt 0){
                    $disk_status = "Fail"
                }else{
                    $disk_status = "Pass"
                }


            }catch{
                $disk_status = "QueryError"
            }
            if($disk_data){
                $disk_object = New-Object -TypeName PSObject
                $disk_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
                $disk_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "Disk"
                $disk_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $disk_status
                $disk_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $disk_data
                $results += $disk_object
            }

            #check file shares
            try{
                $file_share_data = Test-WinShares -FQDN $FQDN | ? Share -Match "^(Shared|Shares|Users)$"

                if($($($file_share_data | ? Touchtest -NE "Success" |measure).count -gt 0) -or $($($file_share_data | ? Reachable -NE "True" |measure).count -gt 0)){
                    $file_share_status = "Fail"
                }else{
                    $file_share_status = "Pass"
                }

            }catch{
                $file_share_status = "QueryError"
            }

            if($file_share_data){
                $file_share_object = New-Object -TypeName PSObject
                $file_share_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
                $file_share_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "File Shares"
                $file_share_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $file_share_status
                $file_share_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $file_share_data
                $results += $file_share_object

            }


            #check services
            try{
                $services_data = Get-ABAServices -computername $FQDN

                if($($services_data | ? Status -NE "Running" | measure).count -gt 0){
                    $services_status = "Fail"
                }else{
                    $services_status = "Pass"
                }

            }catch{
                $services_status = "QueryError"
            }

            $services_object = New-Object -TypeName PSObject
            $services_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
            $services_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "Win_Services"
            $services_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $services_status
            $services_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $services_data
            $results += $services_object

            #check SAN policy
            try{
                $SANPol_data = Get-SANPolicy -computername $FQDN

                if($($SANPol_data -notmatch "Online All" | measure).count -gt 0){
                    $SANPol_status = "Fail"
                }else{
                    $SANPol_status = "Pass"
                }

            }catch{
                $SANPol_status = "QueryError"
            }

            $SANPol_object = New-Object -TypeName PSObject
            $SANPol_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
            $SANPol_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "SAN_Policy"
            $SANPol_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $SANPol_status
            $SANPol_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $SANPol_data
            $results += $SANPol_object

            #$results
            <#

            #check for windows updates
            try{
                $windows_updates_data = Get-PendingUpdate -Computername $FQDN

                if($($windows_updates_data  | measure).count -gt 0){
                    $windows_updates_status = "Fail"
                }else{
                    $windows_updates_status = "Pass"
                }


            }catch{
                $windows_updates_status = "QueryError"
            }

            $windows_updates_object = New-Object -TypeName PSObject
            $windows_updates_object | Add-Member -MemberType NoteProperty -Name "Target" -Value $vmname
            $windows_updates_object | Add-Member -MemberType NoteProperty -Name "Name" -Value "PendingWinUpdates"
            $windows_updates_object | Add-Member -MemberType NoteProperty -Name "Status" -Value $windows_updates_status
            $windows_updates_object | Add-Member -MemberType NoteProperty -Name "Data" -Value $windows_updates_data
            $results += $windows_updates_object

            $results

            #>
        }
    }


    ######
    #Disconnect and return results
    ######

    Disconnect-CitrixDeliveryController

    $global:healthcheck_results = $results

    return $results


}
