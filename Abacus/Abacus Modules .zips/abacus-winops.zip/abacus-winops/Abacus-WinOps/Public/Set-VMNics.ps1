﻿<#
.SYNOPSIS
A PowerShell cmdlet for setting the VM Nics

.DESCRIPTION
This PowerShell command sets the VM Nics

.PARAMETER VMnames
Virtual machine name to target

.PARAMETER VMs
Virtual machine object to target

.PARAMETER connected
Determines NIC connection state
    True = Connect
    False = Disconnect

.EXAMPLE
Set-VMNics -VMnames <VMname> -Conneted:$True
Set-VMNics -VMs $vm_objects -Connected:$False

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

function Set-VMNics{
    Param(
        [Parameter(ValueFromPipeline=$true,Mandatory=$true,ParameterSetName='ByName')]
        [ValidateNotNullOrEmpty()]
        [Alias("VMName")]
        [string]$VMNames
        ,
        [Parameter(ValueFromPipeline=$true,Mandatory=$true,ParameterSetName='ByVM')]
        [ValidateNotNullOrEmpty()]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl]$VMs
        ,
        [Parameter(Mandatory=$true)]
        [bool]$Connected
    )

    Begin{
        if($global:DefaultVIServers.IsConnected -ne $true){
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Connect to VIserver first: Connect-ABAVIServer -site <site>"
        }
    }

    Process{

        if($PsCmdlet.ParameterSetName -eq "ByName"){

            try{
                $VMs = VMware.VimAutomation.Core\Get-VM -Name $VMnames -ErrorAction SilentlyContinue

            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Error trying to query vm $VMnames"
            }
        }


        if($null -eq $vms){
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "$VMnames not found"
        }else{

            foreach($vm in $vms){
                try{
                    if($connected -eq $true){

                        Write-Log -LogObject $WinOps_global_logobject -LogString "Set-VMNics: Setting $($vm.name) NIC to connected"
                    }elseif($Connected -eq $False){

                        Write-Log -LogObject $WinOps_global_logobject -LogString "Set-VMNics: Setting $($vm.name) NIC to disconnected"
                    }

                    $network_adapter = $vm | Get-NetworkAdapter
                    $network_adapter | Set-NetworkAdapter -StartConnected:$True `
                                                          -Connected:$Connected `
                                                          -WakeOnLan:$True `
                                                          -Confirm:$False | Out-Null
                }catch{
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "$VMname failed to modify nic"
                }
            }

        }
    }
    End{
        Write-Log -LogObject $WinOps_global_logobject -LogString "Set-VMNics: end"
    }
}

