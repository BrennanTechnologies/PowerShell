

Function Disconnect-CitrixDeliveryController {
    <#
    .SYNOPSIS
    A PowerShell cmdlet to disconnect from a Citrix Delivery Controller

    .DESCRIPTION
    This PowerShell command disconnects from a Citrix Delivery Controller

    .PARAMETER CitrixSessionName
    Specify citrix session name

    .EXAMPLE
    Disconnect-CitrixDeliveryController


    .NOTES

    #>
    [CmdletBinding()]
    Param(
        [String]$CitrixSessionName = 'CTXDCSession'
    )
    Begin {
    }
    Process {
        Write-Log -LogString "Performing clean up of PSSession" -LogLevel Verbose -LogObject $WinOps_global_logobject
        Get-PSSession -Name $CitrixSessionName -ErrorAction SilentlyContinue | Disconnect-PSSession | Out-Null
        Get-PSSession -Name $CitrixSessionName -ErrorAction SilentlyContinue | Remove-PSSession | Out-Null
    }
}