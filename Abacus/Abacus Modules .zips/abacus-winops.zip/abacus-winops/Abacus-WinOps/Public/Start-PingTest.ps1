<#
.SYNOPSIS
Runs ping test on specified servers

.DESCRIPTION
Runs ping test on specified servers

.PARAMETER servers
A list of fully qualified domain name/s

.PARAMETER maxCurrentJobsRunning
Number of jobs to run at a time

.EXAMPLE
Start-PingTest -Servers Server

.NOTES
General notes
#>

function Start-PingTest {
        [CmdletBinding()]
        param(
                [Parameter(Mandatory=$true)]
                [string[]]$Servers,
                
                [int]$maxCurrentJobsRunning = 20
        )

        $Result = @()
        $Jobs = @()

        #Start Jobs on each Server
        foreach($Server in $Servers){
                Write-Verbose "Working on Server $Server"
                $running = @(Get-Job -State Running)
                if($running.Count -ge $maxCurrentJobsRunning){
                        $null = $running | Wait-Job -Any
                }
                $Jobs += Start-Job -ScriptBlock {Test-Connection -ComputerName $args[0] -Quiet} -Name $Server -ArgumentList $Server
        }

        #Receive the result for each job
        foreach($Job in $Jobs){
                
                $Job_Result = (Receive-Job -Name $Job.Name -Wait -AutoRemoveJob)
                $ServerResult = New-Object -TypeName psobject
                $ServerResult | Add-Member -MemberType NoteProperty -Name "Name" -Value $Job.Name 
                $ServerResult | Add-Member -MemberType NoteProperty -Name "Status" -Value $Job_Result

                $Result += $ServerResult

        }

        $connected = ($Result | Where-Object -Property Status -EQ "True" | measure).Count
        $allservers = $Result.Count

        Write-Verbose "Servers Connected  $connected / $allservers"
    
        #return name of server and status
        return $Result 

        
        
} 
