Function Get-DNSRecords {
    <#
.SYNOPSIS
A PowerShell cmdlet for getting DNS Records

.DESCRIPTION
This PowerShell command can be used to fetch DNS record information

.PARAMETER HostNames
Specify Target Hostnames

.PARAMETER ZoneName
Specify DNS zone if not "Service02"

.PARAMETER DNSServer
Specify DNSServer if not "Service02"

.EXAMPLE
Get-DNSRecords -HostName <Hostname> -DNSServer <FQDN DNS Server>

.NOTES
General notes
#>
    Param (
        [ValidateNotNullOrEmpty()]
        [Alias("VMName")]
        [Parameter(Mandatory=$True,ValueFromPipeLineByPropertyName=$True,ValueFromPipeline=$True)]
        [String[]]$HostNames
        ,
        [ValidateNotNullOrEmpty()]
        [String]$ZoneName = 'service02.corp'
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DNSServer = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
    )
    Begin {
      $DNSRecords = @()
      # Clear jobs before proceeding just in case
      Get-Job | Remove-Job -Force | Out-Null
    }
    Process {
        ForEach ($HostName in $HostNames) {
            Write-Log -LogString "Performing DNS query on HostName $HostName in Zone $ZoneName against server $DNSServer" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
            Get-DnsServerResourceRecord -ComputerName $DNSServer -Name $HostName -ZoneName $ZoneName -ErrorAction SilentlyContinue -AsJob | Out-Null
        }
    }
    End {
        Get-Job | Wait-Job | Out-Null
        Write-Log -LogString "Retrieving DNS query results" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $WinOps_global_logobject
        $DNSRecords =  Get-Job | Receive-Job -Keep -ErrorAction SilentlyContinue
        Get-Job | Remove-Job -Force | Out-Null
        Return $DNSRecords
    }
}