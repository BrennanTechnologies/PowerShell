﻿<#
.SYNOPSIS
A PowerShell cmdlet gets the VM Disk mapping

.DESCRIPTION
This PowerShell command that gets the VM Disk mapping

.PARAMETER VMname
Name or names of Virtual Machines

.EXAMPLE
Get-VMDiskMapping -VMname <VMname>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

function Get-VMDiskMapping{
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true)]
        [Alias("Name")]
        [String]$VMname = $env:COMPUTERNAME
    )

    if($global:DefaultVIServers.IsConnected -ne $true){
        Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Connect to VIserver first: Connect-ABAVIServer -site <site>"
    }


    $vm  = VMware.VimAutomation.Core\Get-VM -Name $vmName
    $vm_guest = Get-VMGuest -VM $vm
    $fqdn = $vm_guest.hostname 
    $vcenter = $vm.Uid.Split(":")[0].Split("@")[1]

    $win32DiskDrive  = Get-WmiObject -Class Win32_DiskDrive -ComputerName $fqdn
    $vmHardDisks =  $vm | Get-HardDisk  
    $vmDatacenterView = $vm | Get-Datacenter | Get-View  
    $virtualDiskManager = Get-View -Server $vcenter -Id VirtualDiskManager-virtualDiskManager
    $diskToDriveVolume = Get-WmiObject Win32_DiskDrive -ComputerName $fqdn | % {
      $disk = $_
      $partitions = "ASSOCIATORS OF " +
                    "{Win32_DiskDrive.DeviceID='$($disk.DeviceID)'} " +
                    "WHERE AssocClass = Win32_DiskDriveToDiskPartition"
      Get-WmiObject -Query $partitions -ComputerName $fqdn | % {
        $partition = $_
        $drives = "ASSOCIATORS OF " +
                  "{Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} " +
                  "WHERE AssocClass = Win32_LogicalDiskToPartition"
        Get-WmiObject -Query $drives  -ComputerName $fqdn | % {
          New-Object -Type PSCustomObject -Property @{
            Disk        = $disk.DeviceID
            DriveLetter = $_.DeviceID
            VolumeName  = $_.VolumeName
 
          }
        }
      }
    }

    foreach ($disk in $win32DiskDrive){  
      $disk | Add-Member -MemberType NoteProperty -Name AltSerialNumber -Value $null  
      $diskSerialNumber = $disk.SerialNumber  
      if ($disk.Model -notmatch 'VMware Virtual disk SCSI Disk Device')  
      {  #identify vmware Virtual Disk by Serial if not by model attribute
        if ($diskSerialNumber -match '^\S{12}$'){ #search for serial with 12 non whitespaces
            $diskSerialNumber = ($diskSerialNumber | foreach {[byte[]]$bytes = $_.ToCharArray(); $bytes | foreach {$_.ToString('x2')} }  ) -join '' #formats the string as two uppercase hexadecimal characters
        }  
        $disk.AltSerialNumber = $diskSerialNumber  
      }
    }  

    $results = @()  
    foreach ($vmHardDisk in $vmHardDisks){  
 
      $vmHardDiskUuid = $virtualDiskManager[0].queryvirtualdiskuuid($vmHardDisk.Filename, $vmDatacenterView.MoRef) | foreach {$_.replace(' ','').replace('-','')}  

      $windowsDisk = $win32DiskDrive | where {$_.SerialNumber -eq $vmHardDiskUuid}  
      
      if (-not $windowsDisk){
        $windowsDisk = $win32DiskDrive | where {$_.AltSerialNumber -eq $vmHardDisk.ScsiCanonicalName.substring(12,24)}
      }  
      $result = "" | select vmName,vmHardDiskDatastore,vmHardDiskVmdk,vmHardDiskName,windowsDiskIndex,windowsDiskSerialNumber,vmHardDiskUuid,windowsDeviceID,drives,volumes  
      $result.vmName = $vmName.toupper()  
      $result.vmHardDiskDatastore = $vmHardDisk.filename.split(']')[0].split('[')[1]  
      $result.vmHardDiskVmdk = $vmHardDisk.filename.split(']')[1].trim()  
      $result.vmHardDiskName = $vmHardDisk.Name  
      $result.windowsDiskIndex = if ($windowsDisk){$windowsDisk.Index}else{"FAILED TO MATCH"}  

      $result.windowsDiskSerialNumber = if ($windowsDisk){$windowsDisk.SerialNumber}else{"FAILED TO MATCH"}  

      $result.vmHardDiskUuid = $vmHardDiskUuid  

      $result.windowsDeviceID = if ($windowsDisk){$windowsDisk.DeviceID}else{"FAILED TO MATCH"}  

      $driveVolumes = $diskToDriveVolume | where {$_.Disk -eq $windowsDisk.DeviceID}
      $result.drives = $driveVolumes.DriveLetter
      $result.volumes = $driveVolumes.VolumeName
      $results += $result
      
    }  
    $results = $results | sort {[int]$_.vmHardDiskName.split(' ')[2]}  
    $results
}