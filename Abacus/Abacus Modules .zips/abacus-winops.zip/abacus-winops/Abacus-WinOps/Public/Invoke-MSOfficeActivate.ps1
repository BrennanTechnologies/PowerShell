﻿

Function Invoke-MSOfficeActivate {
    <#
    .SYNOPSIS
    A PowerShell cmdlet for activating Microsoft Office

    .DESCRIPTION
    This PowerShell command can be used to activate Microsoft office

    .PARAMETER FQDN
    The fully qualified domain name of the computer

    .PARAMETER maxCurrentJobsRunning
    Specify the maximum number of running concurrent jobs

    .PARAMETER Credential
    Provide credentials to access the FQDN

    .EXAMPLE
    Activate-MSOffice -FQDN <FQDN> -Credential <Credential>

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
    #>
    [Cmdletbinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true)]
        [String]$FQDN
        ,
        [PSCredential]$Credential
        ,
        [int]$maxCurrentJobsRunning = 15
    )

    Begin{
        $End_Result = @()
    }
    Process{
        $scriptblock = {

            #check ps drive present
            try{
                $regdrive = Get-PSDrive HKLM

            }catch [System.Management.Automation.DriveNotFoundException]{

                New-PSDrive -Name HKLM -PSProvider Registry -Root HKEY_LOCAL_MACHINE
                $regdrive = Get-PSDrive HKLM
            }catch{
                return $(Write-Error "unable to mount drive HLKM")
            }

            #detection
            $results = @()
            if ($regdrive){
               $regsrcs = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
               foreach ($regsrc in $regsrcs) {
                    $reg = dir $regsrc
                    $results += $reg | ? {($_.name -like "*000000FF1CE*") -and ($_.name -like "*0011*")} # code ending in 000000FF1CE denotes office - 0011 denotes 2013
                }
            }

            $detection2013 = $results | %{Get-ItemProperty $_.pspath -ErrorAction SilentlyContinue} | ? {$_.displayname -eq "Microsoft Office Professional Plus 2013"}
            if ($detection2013){
                try{

                    Push-Location "c:\Program Files (x86)\Microsoft Office\Office15\"
                    Start-Process .\OSPPREARM.EXE
                    cscript ospp.vbs /act
                    Pop-Location

                }catch{
                    return $(Write-Error "failed to activate`n$($_.exception)")
                }
            }else{
                return "Office2013 not found"
            }
        }

        $running = @(Get-Job -State Running)
        if ($running.Count -ge $maxCurrentJobsRunning){
            $null = $running | Wait-Job -Any
        }

        Try{
            Write-Verbose "Activate-MSOffice: working on $FQDN"
            $invoke_params = @{
                ComputerName = $FQDN
                ScriptBlock  = $scriptblock
                ErrorAction  = 'Stop'
            }
            if ($null -ne $Credential){
                $invoke_params.Credential = $Credential
            }

            $jobs = Invoke-Command @invoke_params -AsJob
        }
        Catch{
            Write-Log -LogLevel Error -LogObject $WinOps_global_logobject -LogString "Activate-office: failed to invoke command against $FQDN`n$($_.exception)"
        }
    }
    End{
        $all_jobs = Get-Job
        foreach ($Job in $all_jobs){

            $Job_Result = $job | Receive-Job -Wait -AutoRemoveJob
            $ServerResult = New-Object -TypeName psobject
            $ServerResult | Add-Member -MemberType NoteProperty -Name "Name" -Value $Job.Location
            $ServerResult | Add-Member -MemberType NoteProperty -Name "Result" -Value $Job_Result
            $End_Result += $ServerResult
        }

        Return $End_Result

    }
}


Set-Alias -Name Activate-MSOffice -Value Invoke-MSOfficeActivate