﻿if(!("ToolsStatus" -as [Type])){
 Add-Type -TypeDefinition @'
    public enum ToolsStatus{
        toolsOk,
        toolsNotRunning,
        toolsNotInstalled,
        toolsOld
    }
'@
}

<#
.SYNOPSIS
A PowerShell cmdlet gets the VM tool Status

.DESCRIPTION
This PowerShell command that gets the VM tool Status

.PARAMETER VMname
Name or names of Virtual Machines

.PARAMETER toolsstatus
Status of the tools being checked

.EXAMPLE
Get-VMTStatus -VMname <VMname> -toolsstatus <toolstatus>

.NOTES
Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>

Function Get-VMTStatus{
[CmdletBinding(DefaultParameterSetName='ByName')]
    Param (
        [Parameter(Mandatory=$true,ParameterSetName='ByName')]
        [ValidateNotNullOrEmpty()]
        [Alias("VMs","VMNames")]
        [Array[]]$VMName
        ,
        [Parameter(Mandatory=$true,ParameterSetName='ByFile')]
        [ValidateNotNullOrEmpty()]
        $File_Path
    )
    Begin {
        $Results = @()
        If($global:DefaultVIServers.IsConnected -ne $true){
            Write-Log -LogObject $WinOps_global_logobject -LogLevel TerminatingError -LogString "Connect to VIserver first: Connect-ABAVIServer -site <site>"
        }
        If($PsCmdlet.ParameterSetName -eq "ByName"){
            If (   $($VMName | Get-Member | Select -expand typename -Unique) -ne 'VMware.VimAutomation.ViCore.Impl.V1.VM.UniversalVirtualMachineImpl'   ) {
                $VM_Objects = @()
                $VMName | %{
                    If ($Null -ne $VMName.Name ) {
                        $VM_Objects += $(VMware.VimAutomation.Core\Get-VM -Name $_.Name)
                    }
                    Else {
                        $VM_Objects += $(VMware.VimAutomation.Core\Get-VM -Name $_)
                    }
                }
                $VM_Objects = $VM_Objects | Sort -Property Name
            }
            Else {
                $VM_Objects = $VMName
            }
        }
        If($PsCmdlet.ParameterSetName -eq "ByFile"){
            If(Test-Path -Path $File_Path){
                $VM_Objects = @()
                $VMName = Get-Content $File_Path
                Try{
                    $VMName | %{
                        $VM_Objects += VMware.VimAutomation.Core\Get-VM -Name $_
                    }
                    $VM_Objects = $VM_Objects | Sort -Property Name
                }
                Catch{
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "Error trying to query VMs $VMname"
                }
            }
            Else{
                Throw "Error attempting to query $File_Path"
            }
        }
    }
    Process {        
        ForEach ($VM in $VM_Objects) {
            If ($Null -eq $VM) {
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Warning -LogString "$VMname not found"
            }
            Else {
                $results += $vm | select name, @{Name=“ToolsVersion”; Expression={$_.guest.ToolsVersion}}, @{ Name=“ToolsStatus”; Expression={$_.ExtensionData.Guest.ToolsStatus}}
            }
        }
    }
    End {
        If($ToolsStatus) {
             $Results | ? ToolsStatus -eq $toolsstatus.ToString()
        }
        Else {
            Return $Results
        }
    }
}