Function Get-StaleMachines {
    <#
    .SYNOPSIS
    Queries a for stale machines in specified domain(s)

    .DESCRIPTION
    Get-StaleMachines uses Active Directory module to query stale machines 

    .PARAMETER Domains
    One or more domain entries to be queried

    .PARAMETER DaysInactiveMax
    Number of days to determine a machine is Stale

    .PARAMETER Report
    Switch to specify output in report style or not. Do not specify to return active directory objects

    .PARAMETER OU_Name
    This parameter is used to exclude querying the retired objects OU

    .EXAMPLE 
    Get-StaleMachines -domains "ezevonage.corp","someotherdomain.com"

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline)]
        [String[]]$Domains,
        [Int]$DaysInactiveMax = 60,
        [Switch]$Report,
        [String]$OU_Name = "Retired Objects",
        [switch]$include_retired_OU
    )

    $time = (Get-Date).Adddays( - ($DaysInactiveMax))
    $all_stale_machines = @()
    $Report_results = @()

    if( $null -eq $DaysInactiveMax ){
        $DaysInactiveMax = 60 
    }

    foreach ($domain in $Domains) {
        $canonicalname_ou = "$domain/$OU_Name" 
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Get-StaleMachines: Working on domain: $domain" 
        if (Test-Connection -Count 2 -ComputerName $domain -ErrorAction SilentlyContinue) {
            
            try {
                $stale_machines = Get-ADComputer -Filter * -Server $domain -Properties Name, CanonicalName, OperatingSystem, SamAccountName, DistinguishedName, lastlogontimestamp, Description, ServicePrincipalName `
                                        | ? {$([datetime]::FromFileTime($_.lastlogontimestamp) -lt $time) -or $($_.Enabled -eq $false)} 

                if($include_retired_OU -eq $false){
                    $stale_machines = $stale_machines | ? CanonicalName -NotLike "$canonicalname_ou*"
                }

            
            }
            catch {
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Get-StaleMachines: Failed to query machines`n$($_.eception)"
            }


            if ($stale_machines.count -eq 0) {
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "No stale machines found"
            }
            else {
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "$($($stale_machines | measure).count) stale machines found"
                $all_stale_machines += $stale_machines

                if ($Report) {
            
                    $OSs = $stale_machines | select OperatingSystem -Unique

                    $object = New-Object -TypeName psobject
                    $object | Add-Member -MemberType NoteProperty -Name Domain -Value $domain
                    $object | Add-Member -MemberType NoteProperty -Name DaysInactive -Value $DaysInactiveMax
                    $object | Add-Member -MemberType NoteProperty -Name TotalObjects -Value $($stale_machines | measure ).count

                    foreach ($OS in $OSs) {
                        $OS_name = $OS.OperatingSystem
                        if (![string]::IsNullOrEmpty($OS_name) ) {
                            $stales = $stale_machines | ? OperatingSystem -eq $OS_name
                            
                            if ($Report_results) {
                                $property = $Report_results | Get-Member -MemberType NoteProperty -Name $OS_name

                                if (!$property) {
                                    $Report_results | Add-Member -MemberType NoteProperty -Name $OS_name -Value $null
                                }
                            }
                           
                            $object | Add-Member -MemberType NoteProperty -Name $OS_name -Value $($stales | measure ).count
                        }
                    }
                    $Report_results += $object
                }
            }
        }
        else {
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Unable to connect $domain"
        }
    }
    if ($Report) {
        $properties = $Report | gm | ? membertype -eq Noteproperty | select name
        $output = $Report_results | select $properties.name

        return $output
    }
    else {
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "End Query - returning $($($stale_machines | measure ).count) results"
        $all_stale_machines
        
        #| sort lastlogontimestamp | select name, OperatingSystem,@{N='lastlogontimestamp'; E={[DateTime]::FromFileTime($_.lastlogontimestamp)}} 
    }
}