﻿Function Get-ZombieMachines {
<#
    .SYNOPSIS
    Queries a for none stale machines in the retired objects OU

    .DESCRIPTION
    Get-StaleMachines uses Active Directory module to query stale machines 

    .PARAMETER Domains
    One or more domain entries to be queried

    .PARAMETER DaysInactiveMax
    Number of days to determine a machine is Stale

    .PARAMETER Report
    Switch to specify output in report style or not. Do not specify to return active directory objects

    .PARAMETER OU_Name
    This parameter is used to exclude querying the retired objects OU

    .EXAMPLE 
    Get-StaleMachines -domains "ezevonage.corp","someotherdomain.com"

    .NOTES
    Audit logs can be found \\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-WinOps\Operations.log
#>
    param(
        [Parameter(Mandatory=$true,ValueFromPipeline)]
        [String[]]$Domains,
        [Int]$DaysInactiveMax = 60,
        [Switch]$Report,
        [String]$OU_Name = "Retired Objects"
    )

    $time = (Get-Date).Adddays(-($DaysInactiveMax))
    $all_zombie_machines = @()
    $Report_results = @()


    foreach($domain in $Domains){
       
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Get-ZombieMachines: Working on domain:$domain" 
        if(Test-Connection -Count 2 -ComputerName $domain -ErrorAction SilentlyContinue){
            $canonicalname_ou = "$domain/$OU_Name" 
            try{
                $retired_OU = Get-ADOrganizationalUnit -Server $domain -Filter {Name -eq "Retired Objects"} -Properties canonicalname | ? canonicalname -eq $canonicalname_ou
            }catch{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Get-ZombieMachines: Failed query OU: $canonicalname_ou `n$($_.exception)" 
            }
            if($retired_OU){
                     Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Get-ZombieMachines: $($retired_OU.CanonicalName) OU found"
                try{
                    $zombie_machines = Get-ADComputer -Filter "Enabled -eq 'True'" -Server $domain -SearchBase $retired_OU -Properties Name, CanonicalName, OperatingSystem, SamAccountName, DistinguishedName, lastlogontimestamp | ? enabled -eq $true | ? {$([datetime]::FromFileTime($_.lastlogontimestamp) -gt $time)} 
                }catch{
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Error -LogString "Get-ZombieMachines: Failed to query machines`n$($_.eception)"
                }

                if($zombie_machines.count -eq 0){
                    Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString "Get-ZombieMachines: No zombie machines found"
                }else{
                    $all_zombie_machines +=$zombie_machines

                    if($Report){
            
                        $OSs =  $zombie_machines | select OperatingSystem -Unique

                        $object = New-Object -TypeName psobject
                        $object | Add-Member -MemberType NoteProperty -Name Domain -Value $domain
                        $object | Add-Member -MemberType NoteProperty -Name DaysInactive -Value $DaysInactiveMax
                        $object | Add-Member -MemberType NoteProperty -Name TotalObjects -Value $($zombie_machines | measure ).count

                        foreach($OS in $Oss){
                            $OS_name = $OS.OperatingSystem
                            if(![string]::IsNullOrEmpty($OS_name) ){
                                $zombies =  $zombie_machines | ? OperatingSystem -eq $OS_name
                            
                                if($Report_results){
                                     $property = $Report_results | Get-Member -MemberType NoteProperty -Name $OS_name

                                    if(!$property){
                                        $Report_results | Add-Member -MemberType NoteProperty -Name $OS_name -Value $null
                                    }
                                }
                           
                                $object | Add-Member -MemberType NoteProperty -Name $OS_name -Value $($zombies | measure ).count
                            }
                        }
                        $Report_results += $object
                     }
                }
            }else{
                Write-Log -LogObject $WinOps_global_logobject -LogLevel warning -LogString  "Get-ZombieMachines: $canonicalname_ou does not exist"
            }

         }else{
            Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Get-ZombieMachines: Unable to connect $domain"
        }
    }
    if($Report){
        $properties = $Report | gm | ? membertype -eq Noteproperty | select name
        $output  = $Report_results | select $properties.name

        return $output
    }else{
        Write-Log -LogObject $WinOps_global_logobject -LogLevel Verbose -LogString  "Get-ZombieMachines: End Query - returning results"
        $all_zombie_machines
        
        #| sort lastlogontimestamp | select name, OperatingSystem,@{N='lastlogontimestamp'; E={[DateTime]::FromFileTime($_.lastlogontimestamp)}} 
    }

}