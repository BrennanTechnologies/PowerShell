﻿#Get public and private function definition files.
$Public  = @( Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue )

#Dot source the files
ForEach($Import in @($Public + $Private))
{
    Try
    {
        . $Import.FullName | Out-Null
    }
    Catch
    {
        Write-Error -Message "Failed to import function $($Import.Fullname): $_"
    }
}

Export-ModuleMember -Function $Public.Basename

Try {
    $Script_Name = "Abacus-Jenkins"
    $LogName = "Jenkins.log"
    $Audit_Logroot = "\\service02.corp\DFS\SHARES\PSAuditLogs\"
    $Log_Logroot = "C:\ProgramData\PSlogs"

    $Audit_Logpath = Join-Path $(Join-Path $Audit_LogRoot $Script_Name) $LogName
    $Log_Logpath = Join-Path $(Join-Path $Log_LogRoot $Script_Name) $LogName

    Write-Host $Audit_Logpath
    Write-Host $Log_Logpath

    $Jenkins_LogObject = Start-Log -LogPath $Log_Logpath -ScriptName $Script_Name -Audit True -AuditLogPath $Audit_Logpath -Global False
}
Catch{
    Throw "Failed to initiate log $($Jenkins_LogObject | Out-String) `n($_.exception)"
}

Set-JenkinsSecurityByPass