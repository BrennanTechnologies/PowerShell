﻿<#
.SYNOPSIS
A command used to create the authorization headers needed to access Jenkin's API.

.DESCRIPTION
A command used to create the authorization headers needed to access Jenkin's API.

.EXAMPLE
Get-JenkinsAuthHeaders

.NOTES
General notes
#>

Function Get-JenkinsAuthHeaders {
    [cmdletbinding()]
    Param(
    )
    Begin {
        $Headers = @{}
        Write-Log -LogString "Fetching Jenkins API information from the secret server." -LogLevel Verbose -LogObject $Jenkins_LogObject
        $JenkinsAPISecret = $(Get-Secret -SecretId 14531 | Convert-secretToString)
    }
    Process {
        $UserName = $JenkinsAPISecret.username
        $Token    = $JenkinsAPISecret.password
        $AuthorizationString = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("$($UserName):$($($Token))"))
        $Headers.Add('Authorization',"Basic $($AuthorizationString)")
    }
    End {
        Write-Log -LogString "Returning Headers." -LogLevel Verbose -LogObject $Jenkins_LogObject
        Return $Headers
    }
}