﻿<#
.SYNOPSIS
A PowerShell command used to get the last build status for a particular Jenkins Job.

.DESCRIPTION
A PowerShell command used to get the last build status for a particular Jenkins Job.

.PARAMETER JobName
The name of the Jenkins job you are looking to execute a build for.

.PARAMETER JenkinsServer
The full Uri of the Jenkins server you are connecting to

.PARAMETER JenkinsServerPort
The port of the Jenkins server you are connecting to.

.EXAMPLE
Get-JenkinsLastBuild -JobName <JobName>

.NOTES
General notes
#>

Function Get-JenkinsLastBuild {
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [String]$JobName
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServer = 'https://jenkins.management.corp'
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServerPort = '8443'
    )
    Begin {
        $JenkinAuthHeaders = $(Get-JenkinsAuthHeaders)
        $JekinsUri = "$($JenkinsServer):$($JenkinsServerPort)/job/$($JobName)/lastBuild/api/json"

        $ResultContainer = [PSCustomObject]@{
                'JenkinsServer'              = "$($JenkinsServer)";
                'JenkinsServerPort'          = "$($JenkinsServerPort)";
                'JenkinsJobName'             = "$($JobName)";
                'JenkinsResourceUrl'         = "$($JekinsUri)";
                'Status'                     =  $($Null);
                'Data'                       =  $($Null);
        }
    }
    Process {
        Try {
            Write-Log -LogString "Fetching last build status for job `'$($JobName)`'." -LogLevel Output -LogObject $Jenkins_LogObject
            $Results = Invoke-Restmethod -Method Get -Uri $JekinsUri -Headers $JenkinAuthHeaders -ContentType 'application\json' -ErrorAction Stop
            $ResultContainer.Data = $Results
            $ResultContainer.Status = '200'
        }
        Catch {
            Write-Log -LogString $($_.Exception.message) -LogLevel Error -LogObject $Jenkins_LogObject
            $ResultContainer.Data = $($_.Exception.message)
            $ResultContainer.Status = '400'
        }
    }
    End {
        Write-Log -LogString $($ResultContainer | ConvertTo-Json -Depth 12) -LogLevel Verbose -LogObject $Jenkins_LogObject
        Return $ResultContainer
    }
}