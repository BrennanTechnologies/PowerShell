﻿<#
.SYNOPSIS
A PowerShell command used to one or all Jenkins Jobs.

.DESCRIPTION
A PowerShell command used to one or all Jenkins Jobs.

.PARAMETER JobName
An optional parameter of the Jenkins job you wish to query. If left blank this command will return all available jobs.

.PARAMETER JenkinsServer
The full Uri of the Jenkins server you are connecting to

.PARAMETER JenkinsServerPort
The port of the Jenkins server you are connecting to.

.EXAMPLE
Get-JenkinsJob

.EXAMPLE
Get-JenkinsJob -JobName <JobName>

.NOTES
General notes
#>

Function Get-JenkinsJob {
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$false)]
        [String]$JobName = $Null
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServer = 'https://jenkins.management.corp'
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServerPort = '8443'
    )
    Begin {
        $JenkinAuthHeaders = $(Get-JenkinsAuthHeaders)
        $JekinsUri = "$($JenkinsServer):$($JenkinsServerPort)/api/json/jobs/"

        $ResultContainer = [PSCustomObject]@{
                'JenkinsServer'              = "$($JenkinsServer)";
                'JenkinsServerPort'          = "$($JenkinsServerPort)";
                'JenkinsJobName'             = "$($JobName)";
                'JenkinsResourceUrl'         = "$($JekinsUri)";
                'Status'                     =  $($Null);
                'Data'                       =  $($Null);
        }
    }
    Process {
        Try {
            Write-Log -LogString "Fetching Jenkins Jobs..." -LogLevel Output -LogObject $Jenkins_LogObject
            $JenkinsJobs = $(Invoke-Restmethod -Method Get -Uri $JekinsUri -Headers $JenkinAuthHeaders -ContentType 'application\json' -ErrorAction Stop).jobs

            If (   $True -ne [String]::IsNullOrEmpty($JobName)   ) {
                $JenkinsJob = $JenkinsJobs | ?{$_.name -eq $JobName}
                If (   $True -eq [String]::IsNullOrEmpty($JenkinsJob)   ) {
                    $ResultContainer.Status = 404
                    $ResultContainer.Data = "Job `'$($JobName)`' was not found on the Jenkins server."
                }
                Else {
                    $ResultContainer.Status = 200
                    $ResultContainer.Data   = $JenkinsJob
                }
            }
            Else {
                $ResultContainer.Status = 200
                $ResultContainer.Data   = $JenkinsJobs
            }
        }
        Catch {
            Write-Log -LogString $($_.Exception.message) -LogLevel Error -LogObject $Jenkins_LogObject
            $ResultContainer.Data = $($_.Exception.message)
            $ResultContainer.Status = '400'
        }
    }
    End {
        Write-Log -LogString $($ResultContainer | ConvertTo-Json -Depth 12) -LogLevel Verbose -LogObject $Jenkins_LogObject
        Return $ResultContainer
    }
}