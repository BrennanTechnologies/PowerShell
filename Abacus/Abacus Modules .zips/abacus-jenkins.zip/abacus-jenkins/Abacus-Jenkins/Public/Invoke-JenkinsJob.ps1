﻿<#
.SYNOPSIS
A command for invoking a Jenkins Job build.

.DESCRIPTION
A command for invoking a Jenkins Job build. This can be with or without parameters.

.PARAMETER JobName
The name of the Jenkins job you are looking to execute a build for.

.PARAMETER JobParameterString
An optional parameter to be included if you wish to pass parameters to the build.

.PARAMETER JenkinsServer
The full Uri of the Jenkins server you are connecting to

.PARAMETER JenkinsServerPort
The port of the Jenkins server you are connecting to.

.EXAMPLE
Invoke-JenkinsJob -JobName

.EXAMPLE
Invoke-JenkinsJob -JobName -JobParameterString site=ny&clientcode=tst&domain=ezevonage.corp

.NOTES
General notes
#>

Function Invoke-JenkinsJob {
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [String]$JobName
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JobParameterString
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServer = 'https://jenkins.management.corp'
        ,
        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [String]$JenkinsServerPort = '8443'
    )
    Begin {
        $JenkinAuthHeaders = $(Get-JenkinsAuthHeaders)
        $ResultContainer = [PSCustomObject]@{
                'JenkinsServer'              = "$($JenkinsServer)";
                'JenkinsServerPort'          = "$($JenkinsServerPort)";
                'JobName'                    = "$($JobName)";
                'JenkinsJobParameterString'  = "$($JobParameterString)";
                'JenkinsResourceUrl'         = "$($JenkinsResourceUrl)";
                'Status'                     =  $($Null);
                'Data'                       =  $($Null);
        }
    }
    Process {
        If (   $False -eq [String]::IsNullOrEmpty($JenkinsJobParameters)   ) {
            # Run with Parameters
            $JekinsUri = "$($JenkinsServer):$($JenkinsServerPort)/job/$($JobName)/build?delay=0sec"
            $ResultContainer.JenkinsResourceUrl = $JekinsUri
            Try {
                Write-Log -LogString "Attempting to invoke JenkinsJob $($JobName) with parameters." -LogLevel Output -LogObject $Jenkins_LogObject
                Invoke-Restmethod -Method Post -Uri  $JekinsUri -Headers $JenkinAuthHeaders -ErrorAction Stop
                 $ResultContainer.Status = '200'
            }
            Catch {
                Write-Log -LogString $($_.Exception.message) -LogLevel Error -LogObject $Jenkins_LogObject
                $ResultContainer.Data = $($_.Exception.message)
                $ResultContainer.Status = '400'
            }
        }
        Else {
            # Run without Parameters
            $JekinsUri = "$($JenkinsServer):$($JenkinsServerPort)/job/$($JobName)/buildWithParameters?delay=0sec&$($JobParameterString)"
            $ResultContainer.JenkinsResourceUrl = $JekinsUri
            Try {
                Invoke-Restmethod -Method Post -Uri $JekinsUri -Headers $JenkinAuthHeaders -ErrorAction Stop
                $ResultContainer.Status = '200'
            }
            Catch {
                Write-Log -LogString $($_.Exception.message) -LogLevel Error -LogObject $Jenkins_LogObject
                $ResultContainer.Data = $($_.Exception.message)
                $ResultContainer.Status = '400'
            }
        }
    }
    End{
        Write-Log -LogString "Returning Results" -LogLevel Output -LogObject $Jenkins_LogObject
        Write-Log -LogString $($ResultContainer | ConvertTo-Json -Depth 12) -LogLevel Verbose -LogObject $Jenkins_LogObject
        Return $ResultContainer
    }
}