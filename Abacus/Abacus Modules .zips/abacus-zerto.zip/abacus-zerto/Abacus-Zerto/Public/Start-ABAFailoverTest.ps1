﻿<#
.SYNOPSIS
Initiate Target VPG failover test procedures after target VM nic status.

.DESCRIPTION
Initiate Target VPG failover test procedures after target VM nic status.

.PARAMETER VPGname
The name of the VPG in which you are looking to start the failover test on.
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER IgnoreNicStatus
A parameter that can be specified to bypass VM NIC checks.
    Type: Switch
    Aliases: None
    Default Value: False
    Accept Pipeline Input: False

.PARAMETER Confirm
Determines if a console confirmation menu is prompted prior to any actions taken.
    Type: String
    Aliases: None
    Default Value: True
    Accept Pipeline Input: False

.PARAMETER max_task_threshhold
An integer value matching the total number of tasks that should be able to run at once.
    Type: Int
    Aliases: None
    Default Value: 60
    Accept Pipeline Input: False

.PARAMETER SleepTimer
An integer value that matches the time (in seconds) to wait before checking the task thresh hold before attempting to execute another task.
    Type: Int
    Aliases: None
    Default Value: 60
    Accept Pipeline Input: False

.PARAMETER TimeoutTrysCounter
An integer value that specifies the number of retry attempts before timing out.
    Type: Int
    Aliases: None
    Default Value: 5
    Accept Pipeline Input: False

.EXAMPLE
"VPG1","VPG2" | Start-ABAFailoverTest

.NOTES
https://abacusgroup.atlassian.net/wiki/spaces/DO/pages/187400193/Runbook+-+Zerto+Test+Failover+-+beta
#>

Function Start-ABAFailoverTest {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [String]$VPGname
        ,
        [Switch]$IgnoreNicStatus
        ,
        [ValidateSet($false, $true)]
        [String]$Confirm = $true
        ,
        [int]$max_task_threshhold
        ,
        [int]$SleepTimer = 60
        ,
        [int]$TimeoutTrysCounter = 5

    )
    Begin {

        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        If ( $(Test-ABAVIServer) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a VIServer" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        $All_VPGs = @()
    }

    Process {
        #validate vra
        Write-Log -LogObject $Zerto_global_logobject `
            -LogLevel Output `
            -LogString "Start-ABAFailoverTest target: $VPGname"

        $VPG = Get-ZertoVPG -VPGName $VPGname

        if ($null -eq $VPG) {

            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "$VPGname - not found"

        }
        elseif ($vpg.ActiveProcessesApi.RunningFailOverTestApi.Stage -eq "InTest") {

            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "$VPGname - Already inTest stage"

        }
        else {
            if ($IgnoreNicStatus -eq $false) {
                #test nics
                $all_vms = Get-ABAVMsfromVPG -VPGname $VPG.VpgName
                $all_connected_nics = $all_vms | Get-NetworkAdapter | ? { $_.ConnectionState.connected -eq $true }

                if ($($all_connected_nics | measure).count -gt 0) {
                    $Display_nics = $all_connected_nics | select Parent, name, NetworkName, ConnectionState

                    Write-Log -LogObject $Zerto_global_logobject `
                        -LogLevel Warning `
                        -LogString "Skipping $VPGname - The following VMs are still connected `n Disconnect Nics : Set-VPGVMNics -VPGname $($VPG.VpgName) -Connected False`n or set IgnoreNicStatus flag `n$($Display_nics | out-string)"
                }
                else {
                    $All_VPGs += $VPG
                }
            }
            else {
                $All_VPGs += $VPG
            }
        }
    }
    End {

        $Confirm = [System.Convert]::ToBoolean($Confirm)
        if ($( $All_VPGs | measure).count -gt 0 ) {
            $display_All_VPGs = $All_VPGs | select VpgName, VMscount, SourceSite, TargetSite

            if ($confirm -eq $true) {
                write-host "`n`n"
                write-host '**********************************************************'
                write-host '*************Failover Test Summary************************'
                write-host '**********************************************************'
                while ([String]$input -notmatch "^(Y|N|Yes|No)$") {

                    $input = Read-Host "$($display_All_VPGs|out-string) `nStart Failover test for Above VPG(s) , Continue? (Y|N|Yes|No)"

                }

            }
            else {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Verbose `
                    -LogString "Start-ABAFailoverTest : Confirm set to false bypassing question"
                $input = "Yes"
            }


            switch -regex ($input) {

                '^(N|No)$' {
                    Write-Log -LogObject $Zerto_global_logobject `
                        -LogLevel Output `
                        -LogString "No selected - hopping ship!"
                }

                '^(Y|Yes)$' {
                    $All_tasks = @()
                    foreach ($VPG in $All_VPGs) {
                        #wait for pending tasks

                        $param = @{ }

                        if ($max_task_threshhold) {
                            $param.max_task_threshhold = $max_task_threshhold
                        }

                        Wait-ZertoTasks @param

                        #start failover
                        try {
                            Clear-Variable newZertoTask -ErrorAction SilentlyContinue
                            $All_tasks += Start-ZertoVPGFailoverTest -ZertoVpgIdentifier $VPG.VpgIdentifier -OutVariable newZertoTask

                            #Add a wait & check here to verify that the Zero Task was generated before proceeding.
                            $TimeoutCounter = $TimeoutTrysCounter
                            $newZertoTaskCheck = $Null
                            Write-Log -LogString "Verifying ZeroTask Id has entered the task queue." -LogLevel Output -LogObject $Zerto_global_logobject

                            While (   ($TimeoutCounter -ne 0) -and ($Null -eq $newZertoTaskCheck)   ) {
                                Try {
                                    Get-ZertoTask -ZertoTaskIdentifier $newZertoTask -ErrorAction Stop | Out-Null
                                    $newZertoTaskCheck = $True
                                }
                                Catch {
                                    Write-Log -LogString "Zerto Task Id has not hit the task queue" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    $newZertoTaskCheck = $Null
                                }

                                If ($True -eq $newZertoTaskCheck) {
                                    Write-Log -LogString "Zerto Task Id is present in task queue." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                                Else {
                                    Write-Log -LogString "Waiting an additional $SleepTimer seconds before recheck." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    Sleep $SleepTimer
                                    $TimeoutCounter = $TimeoutCounter - 1
                                    Write-Log -LogString "Trys remaining: $TimeoutCounter" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                            }
                        }
                        catch {
                            Write-Log -LogObject $Zerto_global_logobject `
                                -LogLevel Error `
                                -LogString "Failed to StartZertoFailover`n$($_.exception)"
                        }
                    }
                    Return $All_tasks
                }
            }
        }
        else {
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "There are no VPG targets - END"
        }
    }
}
