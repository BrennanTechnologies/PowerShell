<#
.SYNOPSIS
A PowerShell wrapper around Update-DNSRecords for the Abacus-Zerto module.

.DESCRIPTION
This command is a PowerShell wrapper around the Update-DNSRecords command included in Abacus-WinOps.
This wrapper comamnd however, is specifically designed for Abacus-Zerto as an automation/orchestration tool around DR tasks.

.PARAMETER VPGObjects
An array of one or more VPG Objects that will be targts of the initialize failover orchestration.

.PARAMETER FailBack
A Switch flag that can be used when initiating a failback.
When specified, the failback IP information will be used instead.

.PARAMETER WhatIf
This Switch parameter can be used to see what actions would be taken during a failover without actually performing them.

.PARAMETER DNSServer
What ever server is specified here will be targeted when performing DNS actions for the respective VMs contained within the VPGs.

.EXAMPLE
Initialize-ZertoVpgDnsFailover -VPGObjects $VPGMembersBefore

.EXAMPLE
Initialize-ZertoVpgDnsFailover -VPGObjects $VPGMembersBefore -WhatIf

.EXAMPLE
Initialize-ZertoVpgDnsFailover -VPGObjects $VPGMembersBefore -DNSServer service02.corp

.EXAMPLE
$VPGMembersBefore | Initialize-ZertoVpgDnsFailover

.NOTES
This command accepts objects returned from the Get-ZertoVPGMembers command via Pipeline or passed explicitly through the VPGObjects parameter.
#>

Function Initialize-ZertoVpgDnsFailover {
    Param (
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)]
        [Array[]]$VPGObjects
        ,
        [Switch]$FailBack
        ,
        [Switch]$WhatIf
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DNSServer = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
    )
    Begin {
        If ($WhatIf -eq $True) {
            [Boolean]$WhatIf = $True
        }
        $VPGObjectError = $False
        $ReturnObjects = @()
    }
    Process {
        $VPGObjects | % {
            $CurrentVMName = $($_.VMName)
            $CurrentFailOverIp = $($_.FailOverTestIPInfo.StaticIp)
            $DnsRecordIP = $($_.DNSRecords.IPv4Address)
            $DnsRecordType = $($_.DNSRecords.RecordType)
            $VPGObjectError = $False

            If ($Null -eq $CurrentVMName) {
                Write-Log -LogString "No VMName was detected on this object." -LogObject $Zerto_global_logobject -LogLevel Warning
                $VPGObjectError = $True
            }
            If ($Null -eq $_.DNSRecords) {
                Write-Log -LogString "No DNS Record was attached to the object $CurrentVMName" -LogObject $Zerto_global_logobject -LogLevel Warning
                $VPGObjectError = $True
            }
            If ($Null -eq $_.FailOverTestIPInfo.StaticIp) {
                Write-Log -LogString "No FailOverIp was attached to the object $CurrentVMName" -LogObject $Zerto_global_logobject -LogLevel Warning
                $VPGObjectError = $True
            }

            If ($VPGObjectError -eq $False) {
                If ($FailBack -eq $False) {
                    Try {
                        If ($WhatIf -eq $False) {
                            Write-Log -LogString "Running Update-DNSRecords on HostName `"$CurrentVMName`" from IP `"$DnsRecordIP`" to new IP `"$CurrentFailOverIp`" against DNSServer `"$DNSServer`"" -LogObject $Zerto_global_logobject -LogLevel Output
                            $ReturnObjects += Update-DNSRecords -HostName $CurrentVMName -RecordType $DnsRecordType -Ipv4Address $CurrentFailOverIp -DNSServer $DNSServer -ErrorAction Stop -ErrorVariable UpdateDNSErr
                        }
                        ElseIf ($WhatIf -eq $True) {
                            Write-Log -LogString "-WhatIf flag detected - Command: Update-DNSRecords -HostName $CurrentVMName -RecordType $DnsRecordType -Ipv4Address $CurrentFailOverIp -DNSServer $DNSServer -ErrorAction Stop" -LogObject $Zerto_global_logobject -LogLevel Output
                        }
                    }
                    Catch {
                        Write-Log -LogString "There was an issue updating the `"$DnsRecordType`" DNS Record for `"$CurrentVMName`" against server `"$DNSServer`"" -LogObject $Zerto_global_logobject -LogLevel Warning
                        Write-Log -LogString $UpdateDNSErr -LogObject $Zerto_global_logobject -LogLevel Error
                    }
                }
                ElseIf ($FailBack -eq $True) {
                    If ($CurrentFailOverIp -ne $DnsRecordIP) {
                        Try {
                            If ($WhatIf -eq $False) {
                                Write-Log -LogString "Running Update-DNSRecords on HostName `"$CurrentVMName`" to new IP `"$DnsRecordIP`" against DNSServer `"$DNSServer`"" -LogObject $Zerto_global_logobject -LogLevel Output
                                $ReturnObjects += Update-DNSRecords -HostName $CurrentVMName -RecordType $DnsRecordType -Ipv4Address $DnsRecordIP -DNSServer $DNSServer -ErrorAction Stop -ErrorVariable UpdateDNSErrFailBack
                            }
                            ElseIf ($WhatIf -eq $True) {
                                Write-Log -LogString "-WhatIf flag detected - Command: Update-DNSRecords -HostName $CurrentVMName -RecordType $DnsRecordType -Ipv4Address $DnsRecordIP -DNSServer $DNSServer -ErrorAction Stop" -LogObject $Zerto_global_logobject -LogLevel Output
                            }
                        }
                        Catch {
                            Write-Log -LogString "There was an issue updating the `"$DnsRecordType`" DNS Record for `"$CurrentVMName`" against server `"$DNSServer`"" -LogObject $Zerto_global_logobject -LogLevel Warning
                            Write-Log -LogString $UpdateDNSErrFailBack -LogObject $Zerto_global_logobject -LogLevel Error
                        }
                    }
                    Else {
                        Write-Log -LogString "The FailOver IP `"$CurrentFailOverIp`" matches what is in our Object's DNS IP so there is nothing to change." -LogObject $Zerto_global_logobject -LogLevel Warning
                    }
                }
            }
        }
    }
    End {
        If ($WhatIf -eq $False) {
            Write-Log -LogString "Providing 15 seconds of buffer delay before performing repadmin" -LogLevel Output -LogObject $Zerto_global_logobject
            Sleep 15
            Write-Log -LogString "Executing repadmin against `"$DNSServer`"" -LogLevel Output -LogObject $Zerto_global_logobject
            Start-RepAdmin -Source $DNSServer | Out-Null
        }
        Return $ReturnObjects
    }
}