<#
.SYNOPSIS
A PowerShell command for creating an object containing VPG membership information

.DESCRIPTION
A PowerShell command for creating an object containing VPG membership information of a Zerto VPG along with any available DNS records which match the host name of said hosts

.PARAMETER VpgNames
The name(s) of the VPG(s) to be queried for VM members.
    Type: String[]
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True

.PARAMETER DNSServer
What ever server is specified here will be targeted when performing DNS record queries for any VM returned as a member.
    Type: String
    Aliases: None
    Default Value: $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
    Accept Pipeline Input: True

.EXAMPLE
Get-ZertoVPGMembers -VpgNames <VPGName>

.EXAMPLE
"SomeVpgName" | Get-ZertoVPGMembers

.NOTES
This command requires a connection to a ZVM. Please connect to a ZVM with the 'Connect-ABAZVM' command before using.
#>

Function Get-ZertoVPGMembers {
    Param (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)]
        [String[]]$VpgNames
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DNSServer = $(Get-ADDomainController -Server 'service02.corp' | Select -ExpandProperty HostName)
    )
    Begin {
        If (   $(Test-ZertoZVMConnection) -eq $False   ) {
            Write-Log -LogString "There is currently no connection to a ZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }
        $ZertoLogLocalPath = Split-Path -Parent $Zerto_global_logobject.LogPath
        $ZertoLogRemotePath = Split-Path -Parent $Zerto_global_logobject.AuditLogPath
        $VMs = @()
        $VPGSettingIDs = @()
        $VMResults = @()
    }
    Process {
        ForEach ($VPG in $VpgNames) {
            $VPGID = $Null
            $CurrentVPGID = $Null
            $VM = $Null
            $VMs = @()
            $VPGSettingIDs = @()
            $VPGSetting = @()

            #Create Folders
            New-Item -Path $ZertoLogLocalPath -Name $VPG -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $ZertoLogRemotePath -Name $VPG -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

            Write-Log -LogString "Grabbing VPG ID for $VPG" -LogObject $Zerto_global_logobject -LogLevel Output -LineNumber $(Get-CurrentLineNumber)
            $CurrentVPGID = Get-ZertoVPG -VpgName $VPG -ErrorAction SilentlyContinue | Select -ExpandProperty VpgIdentifier
            If ([String]::IsNullOrEmpty($CurrentVPGID)) {
                Write-Log -LogString "There was an error obtaining the VPG information for $VPG" -LogObject $Zerto_global_logobject -LogLevel Error -LineNumber $(Get-CurrentLineNumber)
            }
            Else {
                Write-Log -LogString "Grabbing VPG Setting ID for $VPG" -LogObject $Zerto_global_logobject -LogLevel Output -LineNumber $(Get-CurrentLineNumber)
                $VPGID += $(Convert-ZertoVPGToVPGSetting -ZertoVpgIdentifier $CurrentVPGID -ErrorAction SilentlyContinue)
                If ([String]::IsNullOrEmpty($VPGID)) {
                    Write-Log -LogString "There was an error obtaining the VPG Setting ID for $VPG" -LogObject $Zerto_global_logobject -LogLevel Error -LineNumber $(Get-CurrentLineNumber)
                }
                Else {
                    $VPGSettingIDs += $VPGID
                }
            }

            ForEach ($VPGSetting in $VPGSettingIDs) {
                $VMs += Get-ZertoVPGSetting -ZertoVpgSettingsIdentifier $VPGSetting | Select -ExpandProperty Vms
                Remove-ZertoVPGSetting -ZertoVpgSettingsIdentifier $VPGSetting | Out-Null
            }

            ForEach ($VM in $VMs) {
                $VMInfo = $Null
                Try {
                    $VMInfo = $(Get-ZertoVM -ZertoVMIdentifier $VM.VmIdentifier)
                }
                Catch [System.SystemException] {
                    Write-Log -LogString "VM is potentially protected in more than one VPG. Attempting to filter..." -LogLevel Warning
                    $ZertoAPIHeaders = @{ }
                    [String]$ZertoServer = $(Get-Content "Env:\ZertoServer")
                    [String]$ZertoPort = $(Get-Content "Env:\ZertoPort")
                    $ZertoKey = $([regex]::Match(   $(Get-Content "Env:\ZertoToken") , '\"(\w|\d)+\"'   ).Value -replace '"', '')
                    $ZertoAPIHeaders.Add('x-zerto-session', $ZertoKey)
                    $VMInfo = Invoke-RestMethod -Uri "https://$($ZertoServer):$($ZertoPort)/v1/vms?vmIdentifier=$($VM.VmIdentifier)" -Method Get -ContentType "application/json" -Headers $ZertoAPIHeaders
                    $VMInfo = $VMInfo | ? { $_.VPGName -eq $VPG }
                }
                $VMResults += [PScustomObject]@{`
                        VMName           = $($VMInfo.VmName);
                    VmIdentifier         = $VM.VmIdentifier; `
                        VpgName          = $($VMInfo.VpgName);
                    FailOverIPInfo       = $($VM.NICs.Failover.Hypervisor.IpConfig);
                    FailOverTestIPInfo   = $($VM.NICs.FailoverTest.Hypervisor.IpConfig);
                    DNSRecords           = $($VMInfo.VmName | Get-DNSRecords -ZoneName 'service02.corp' -DNSServer $DNSServer | Select HostName, RecordType, @{N = 'IPv4Address'; e = { $_.RecordData.Ipv4Address.IpAddressToString } });
                    vCmdCustomAttributes = $(Try { Get-vCmdVMCustomAttribute -VMName $VMInfo.VmName -ErrorAction Stop } Catch { "ERR" } )
                }
            }
        }
    }
    End {
        Write-Log -LogString "Exporting VPGMember results into JSON format" -LogLevel Verbose -LogObject $Zerto_global_logobject
        $Date = $(Get-Date -Format 'yyyy_MM_dd_TH.mm.ss')
        ForEach (   $VpgName in $($VMResults.VpgName | Select -Unique)   ) {
            $JSONResults = $($VMResults | ? { $_.VpgName -eq $VpgName } ) | ConvertTo-Json -Depth 5
            $JSONResults | Out-File -LiteralPath "$ZertoLogLocalPath\$VpgName\$($Date)_$($VpgName).json" -Force
            $JSONResults | Out-File -LiteralPath "$ZertoLogRemotePath\$VpgName\$($Date)_$($VpgName).json" -Force
        }
        Return $VMResults
    }
}