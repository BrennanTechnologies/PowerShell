<#
.SYNOPSIS
This command tests connectivity to a Zerto ZVM

.DESCRIPTION
This command tests connectivity to a Zerto ZVM and attempts to re-establish a connection if the session is expired.

.EXAMPLE
Test-ZertoZVMConnection

.NOTES
If no prior connection is established, or if there is not enough information to attempt to re-establish a connection, this command will fail.
#>

Function Test-ZertoZVMConnection {
    Begin {
        $ZVMServer = Get-Item Env:\ZertoServer -ErrorAction SilentlyContinue
        $LocalSite = Get-ZertoLocalSite -ErrorAction SilentlyContinue
        [Boolean]$ZVMConnectionStatus = $False
    }
    Process {
        If (   ($ZVMConnectionStatus -eq $False) -and ($Null -eq $ZVMServer)   ) {
            Write-Log -LogString "Could not verify a connection to a ZVM and no ZVM is stored to attempt to re-establish a connection. Please connect to a ZVM using Connect-ABAZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }


        If ([String]::IsNullOrEmpty($LocalSite) -eq $True) {
            [Boolean]$ZVMConnectionStatus = $False
            Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Session seems expired - attempting to make new connection"
            Try {
                Connect-ABAZVM -ZVM  $($ZVMServer.Value) -ErrorAction Stop
                [Boolean]$ZVMConnectionStatus = $True
                Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Connection Restablished"
            }
            Catch {
                [Boolean]$ZVMConnectionStatus = $False
                Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Failed to restablish a connection"
            }
        }
        Else {
            [Boolean]$ZVMConnectionStatus = $True
        }

        Switch ($ZVMConnectionStatus) {
            $True {
                Write-Log -LogObject $Zerto_global_logobject -LogLevel Verbose -LogString "Connected to ZVM" -Verbose
            }
            $False {
                Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Not connected to ZVM"
            }
        }
    }
    End {
        Return $ZVMConnectionStatus
    }
}