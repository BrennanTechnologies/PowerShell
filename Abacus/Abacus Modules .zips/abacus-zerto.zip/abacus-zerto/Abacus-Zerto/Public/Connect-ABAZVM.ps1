﻿<#
.SYNOPSIS
This command is used to connect to a Zerto Virtual Manager

.DESCRIPTION
This command is used to connect to a Zerto Virtual Manager

.PARAMETER Site
Site you would like to connect to
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER ZVM
zvm you would like to connect to
    Type: String
    Aliases: None
    Default Value:
    Accept Pipeline Input: False

.PARAMETER RootZVM
root zvm string the site is appended to
    Type: String
    Aliases: None
    Default Value:  mgmtzvm01.management.corp
    Accept Pipeline Input: False

.PARAMETER ZertoPort
Zerto port you are connecting with
    Type: Int32
    Aliases: None
    Default Value: 9669
    Accept Pipeline Input: False

.EXAMPLE
    Connect-ABAZVM -Site <SiteCode>

.NOTES
    If you do not connect to a ZVM first, none of the other Zerto commands will work as there will be no endpoint to authenticate against for the API
    A Site or a ZVM can be supplied for establishing a connection, but one or the other must be supplied.
#>

Function Connect-ABAZVM {
    [CmdletBinding(DefaultParameterSetName = 'BySite')]
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true, ParameterSetName = 'BySite')]
        [ValidateNotNullOrEmpty()]
        [Site]$Site
        ,
        [Parameter(Mandatory = $true, ParameterSetName = 'ByZVM')]
        [ValidateNotNullOrEmpty()]
        [String]$ZVM
        ,
        [String]$RootZVM = "mgmtzvm01.management.corp"
        ,
        [int32]$ZertoPort = 9669
    )
    Begin {
        $Zerto_Credentials = Get-Secret srv-zerto -SecretId 1538 | Convert-secretToKerb
    }
    Process {
        Try {
            If (  [String]::IsNullOrEmpty($ZVM)  ) {
                $ZVM = $site | % { "$_" + "$RootZVM" }
                Connect-ZertoZVM -ZertoServer $ZVM -ZertoPort $zertoPort -credential $Zerto_Credentials -ErrorAction Stop
            }
            Else {
                Connect-ZertoZVM -ZertoServer $ZVM -ZertoPort $zertoPort -credential $Zerto_Credentials -ErrorAction Stop
            }
        }
        Catch {
            Write-Log -LogString "There was an error attempting to connect to the ZVM: '$ZVM`:$ZertoPort'" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }
        # Validate
        $ZVMConnectionTest = $(Test-ZertoZVMConnection)
    }
    End {
        Switch ($ZVMConnectionTest) {
            $True {
                Write-Log -LogString "Connection to ZVM: '$ZVM`:$ZertoPort' was established sucessfully." -LogObject $Zerto_global_logobject -LogLevel Output -LineNumber $(Get-CurrentLineNumber)
            }
            $False {
                Write-Log -LogString "There was an error attempting to connect or verify our connection to the ZVM: '$ZVM`:$ZertoPort'" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
            }
            Default {
                Write-Log -LogString "Unhandled Exception..." -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
            }
        }
    }
}