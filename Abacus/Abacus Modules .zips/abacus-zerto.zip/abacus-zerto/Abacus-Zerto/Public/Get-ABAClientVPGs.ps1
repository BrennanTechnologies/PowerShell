﻿<#
.SYNOPSIS
This command attempts to return a list of VPG names based on a supplied client code using string matching.

.DESCRIPTION
This command attempts to return a list of VPG names based on a supplied client code using string matching.

.PARAMETER ClientCode
The specified ClientCode will be used as an identifier when querying VPGs: "*-$($ClientCode)-*"
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.EXAMPLE
 Get-ABAClientVPGs -ClientCode <ClientCode>

.NOTES
The results should always be validated because since this is using a title sting match
#>

Function Get-ABAClientVPGs {
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [String]$ClientCode
    )

    Begin {

        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }

    }

    Process {
        #getzvra
        $VPGs = Get-ZertoVPG | ? vpgname -like "*-$ClientCode-*"
        return $VPGs
    }

}

