﻿<#
.SYNOPSIS
A command for starting an Operational Failover for Zerto VPG(s)

.DESCRIPTION
A command for starting an Operational Failover for Zerto VPG(s)

.PARAMETER VPGname
The name of the VPG in which is being targeted for the Operational FailOver
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER Confirm
Determines if a console confirmation menu is prompted prior to any actions taken.
    Type: String
    Aliases: None
    Default Value: True
    Accept Pipeline Input: False

.PARAMETER SkipNicCheck
A flag specifying if VM NIC checks should be bypassed.
    Type: Switch
    Aliases: None
    Default Value: $False
    Accept Pipeline Input: False

.PARAMETER max_task_threshhold
An integer value matching the total number of tasks that should be able to run at once.
    Type: Int
    Aliases: None
    Default Value: 15
    Accept Pipeline Input: False

.PARAMETER SleepTimer
An integer value that matches the time (in seconds) to wait before checking the task thresh hold before attempting to execute another task.
    Type: Int
    Aliases: None
    Default Value: 60
    Accept Pipeline Input: False

.PARAMETER TimeoutTrysCounter
An integer value that specifies the number of retry attempts before timing out.
    Type: Int
    Aliases: None
    Default Value: 5
    Accept Pipeline Input: False

.EXAMPLE
NYDC-TST-CTX | Start-ABAOperationalFailover
.EXAMPLE
NYDC-TST-CTX | Start-ABAOperationalFailover -SkipNicCheck

.NOTES
General notes
#>

Function Start-ABAOperationalFailover {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipelineByPropertyName = $True, ValueFromPipeline = $True)]
        [String]$VPGname
        ,
        [ValidateSet($True, $False)]
        [String]$Confirm = $True
        ,
        [Switch]$SkipNicCheck = $False
        ,
        [Int]$max_task_threshhold = 15
        ,
        [Int]$SleepTimer = 60
        ,
        [Int]$TimeoutTrysCounter = 5
    )
    Begin {
        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }
        If ( $(Test-ABAVIServer) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a VIServer" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }
        $All_VPGs = @()
    }
    Process {
        Write-Log -LogObject $Zerto_global_logobject -LogLevel Output -LogString "Start-ABAOperationalFailover target: {$($VPGname)}"
        $VPG = Get-ZertoVPG -VPGName $VPGname

        If ($Null -eq $VPG) {
            Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Target VPG {$($VPGname)} was not found."
        }
        Else {
            If ($True -eq $SkipNicCheck) {
                Write-Log -LogLevel Output -LogString "SkipNicCheck was set to TRUE, ignoring NIC tests." -LogObject $Zerto_global_logobject
                $All_VPGs += $VPG
            }
            Else {
                Write-Log -LogLevel Output -LogString "SkipNicCheck was set to FALSE, performing NIC tests." -LogObject $Zerto_global_logobject
                #test nics
                $all_vms = Get-ABAVMsfromVPG -VPGname $VPG.VpgName
                $all_connected_nics = $all_vms | Get-NetworkAdapter | ? { $_.ConnectionState.connected -eq $True }
                If ($($all_connected_nics | measure).count -gt 0) {
                    $Display_nics = $all_connected_nics | select Parent, name, NetworkName, ConnectionState
                    Write-Log -LogObject $Zerto_global_logobject -LogLevel Warning -LogString "Skipping {$($VPGname)} - The following VMs are still connected `n Disconnect Nics : Set-VPGVMNics -VPGname {$($VPG.VpgName)} -Connected False`n or set IgnoreNicStatus flag `n$($Display_nics | Out-String)"
                }
                Else {
                    $All_VPGs += $VPG
                }
            }
        }
    }
    End {
        $Confirm = [System.Convert]::ToBoolean($Confirm)
        If (   $($All_VPGs | Measure).count -gt 0   ) {
            $display_All_VPGs = $All_VPGs | Select VpgName, VMscount, SourceSite, TargetSite
            If ($Confirm -eq $true) {
                Write-Host "`n`n"
                Write-Host '**********************************************************'
                Write-Host '*************Failover Test Summary************************'
                Write-Host '**********************************************************'
                While ([String]$Input -notmatch "^(Y|N|Yes|No)$") {
                    $Input = Read-Host "$($display_All_VPGs | Out-String) `nStart Operational Failover for Above VPG(s) , Continue? (Y|N|Yes|No)"
                }
            }
            Else {
                Write-Log -LogObject $Zerto_global_logobject -LogString "Start-ABAOperationalFailover : Confirm set to false bypassing question" -LogLevel Verbose
                $Input = "Yes"
            }
            Switch -regex ($Input) {
                '^(N|No)$' {
                    Write-Log -LogObject $Zerto_global_logobject -LogLevel Output -LogString "No selected - hopping ship!"
                }
                '^(Y|Yes)$' {
                    $All_tasks = @()
                    ForEach ($VPG in $All_VPGs) {
                        # Wait for pending tasks
                        $Param = @{ }
                        If ($max_task_threshhold) {
                            $param.max_task_threshhold = $max_task_threshhold
                        }
                        Wait-ZertoTasks @param
                        # Start failover
                        Try {
                            Clear-Variable newZertoTask -ErrorAction SilentlyContinue
                            $All_tasks += Start-ZertoVPGFailover -ZertoVpgIdentifier $($VPG.VpgIdentifier) -OutVariable newZertoTask -TimeToWaitBeforeShutdownInSec 0 -CommitPolicy None -ReverseProtection $False

                            #Add a wait & check here to verify that the Zero Task was generated before proceeding.
                            $TimeoutCounter = $TimeoutTrysCounter
                            $newZertoTaskCheck = $Null
                            Write-Log -LogString "Verifying ZeroTask Id has entered the task queue." -LogLevel Output -LogObject $Zerto_global_logobject
                            While (   ($TimeoutCounter -ne 0) -and ($Null -eq $newZertoTaskCheck)   ) {
                                Try {
                                    Get-ZertoTask -ZertoTaskIdentifier $newZertoTask -ErrorAction Stop | Out-Null
                                    $newZertoTaskCheck = $True
                                }
                                Catch {
                                    Write-Log -LogString "Zerto Task Id has not hit the task queue" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    $newZertoTaskCheck = $Null
                                }

                                If ($True -eq $newZertoTaskCheck) {
                                    Write-Log -LogString "Zerto Task Id is present in task queue." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                                Else {
                                    Write-Log -LogString "Waiting an additional $SleepTimer seconds before recheck." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    Sleep $SleepTimer
                                    $TimeoutCounter = $TimeoutCounter - 1
                                    Write-Log -LogString "Trys remaining: $TimeoutCounter" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                            }
                        }
                        Catch {
                            Write-Log -LogObject $Zerto_global_logobject `
                                -LogLevel Error `
                                -LogString "Failed to StartZertoFailover`n$($_.exception)"
                        }
                    }
                    Return $All_tasks
                }
            }
        }
        Else {
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "There are no VPG targets - END"
        }
    }
}