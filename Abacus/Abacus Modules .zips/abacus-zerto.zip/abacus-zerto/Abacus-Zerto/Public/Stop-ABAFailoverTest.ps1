﻿<#
.SYNOPSIS
Stop an existing started failover test

.DESCRIPTION
Stop an existing started failover test

.PARAMETER VPGname
The name of the VPG in which you want to stop the failover test against.
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER Confirm
Determines if a console confirmation menu is prompted prior to any actions taken.

.PARAMETER max_task_threshhold
An integer value specifying the max number of continous tasks to have running at one time.

.PARAMETER SleepTimer
An integer value matching the amount of wait time (in seconds) between retry checks against the task thresh hold.

.PARAMETER TimeoutTrysCounter
The number of attempts that should be made before timing out.

.EXAMPLE
"VPG1","VPG2" | Stop-ABAFailoverTest

.NOTES
https://abacusgroup.atlassian.net/wiki/spaces/DO/pages/187400193/Runbook+-+Zerto+Test+Failover+-+beta
#>

Function Stop-ABAFailoverTest {
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [String]$VPGname
        ,
        [ValidateSet($false, $true)]
        [String]$Confirm = $True
        ,
        [int]$max_task_threshhold
        ,
        [int]$SleepTimer = 60
        ,
        [int]$TimeoutTrysCounter = 5
    )
    Begin {

        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        $All_VPGs = @()
    }

    Process {

        #validate vra
        Write-Log -LogObject $Zerto_global_logobject `
            -LogLevel Output `
            -LogString "VPGname: $VPGname"

        $VPG = Get-ZertoVPG -VPGName $VPGname
        if ($null -ne $VPGname) {
            if ($vpg.ActiveProcessesApi.RunningFailOverTestApi.Stage -eq "InTest") {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel verbose `
                    -LogString "$VPGname - confirmed inTest stage"
                $All_VPGs += $VPG
            }
            else {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Warning "$VPGname is not currently in a Failover test state"
            }
        }
        else {
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "$VPGname - not found"
        }

    }

    End {
        $Confirm = [System.Convert]::ToBoolean($Confirm)
        if ($( $All_VPGs | measure).count -gt 0 ) {
            $display_All_VPGs = $All_VPGs | select VpgName, VMscount, SourceSite, TargetSite
            if ($confirm -eq $true) {
                write-host "`n`n"
                write-host '**********************************************************'
                write-host '*************Stop Failover Test Summary*******************'
                write-host '**********************************************************'
                while ([String]$input -notmatch "^(Y|N|Yes|No)$") {

                    $input = Read-Host "$($display_All_VPGs|out-string) `nStopping Failover test for all VPGs listed, Continue? (Y|N|Yes|No)"

                }

            }
            else {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Verbose `
                    -LogString "Stop-ABAFailoverTest : Confirm set to false bypassing question"
                $input = "Yes"
            }

            switch -regex ($input) {

                '^(N|No)$' {
                    Write-Log -LogObject $Zerto_global_logobject `
                        -LogLevel Output `
                        -LogString "No selected - hopping ship!"
                }

                '^(Y|Yes)$' {
                    $tasks = @()
                    foreach ($VPG in $All_VPGs ) {
                        #wait for pending tasks
                        $param = @{ }

                        if ($max_task_threshhold) {
                            $param.max_task_threshhold = $max_task_threshhold
                        }

                        Wait-ZertoTasks @param
                        #Stop failover
                        try {
                            Write-Log -LogObject $Zerto_global_logobject `
                                -LogString "Stopping: $($VPG.vpgname)"

                            $tasks += Stop-ZertoVPGFailoverTest -ZertoVpgIdentifier $VPG.VpgIdentifier -OutVariable newZertoTask `
                                -ErrorAction Stop

                            #Add a wait & check here to verify that the Zero Task was generated before proceeding.
                            $TimeoutCounter = $TimeoutTrysCounter
                            $newZertoTaskCheck = $Null
                            Write-Log -LogString "Verifying ZeroTask Id has entered the task queue." -LogLevel Output -LogObject $Zerto_global_logobject

                            While (   ($TimeoutCounter -ne 0) -and ($Null -eq $newZertoTaskCheck)   ) {
                                Try {
                                    Get-ZertoTask -ZertoTaskIdentifier $newZertoTask -ErrorAction Stop | Out-Null
                                    $newZertoTaskCheck = $True
                                }
                                Catch {
                                    Write-Log -LogString "Zerto Task Id has not hit the task queue" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    $newZertoTaskCheck = $Null
                                }

                                If ($True -eq $newZertoTaskCheck) {
                                    Write-Log -LogString "Zerto Task Id is present in task queue." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                                Else {
                                    Write-Log -LogString "Waiting an additional $SleepTimer seconds before recheck." -LogLevel Verbose -LogObject $Zerto_global_logobject
                                    Sleep $SleepTimer
                                    $TimeoutCounter = $TimeoutCounter - 1
                                    Write-Log -LogString "Trys remaining: $TimeoutCounter" -LogLevel Verbose -LogObject $Zerto_global_logobject
                                }
                            }
                        }
                        catch {
                            Write-Log -LogObject $Zerto_global_logobject `
                                -LogLevel Error `
                                -LogString "Failed to StopZertoFailover`n$($_.exception)"
                        }
                    }
                    return $tasks
                }

            }
        }
        else {
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "There are no VPG targets - END"
        }
    }
}
