﻿<#
.SYNOPSIS
This command is a PowerShell wrapper around the Set-VMNics command included in Abacus-WinOps but is specifically designed for Abacus-Zerto as an automation/orchestration piece.

.DESCRIPTION
This command is a PowerShell wrapper around the Set-VMNics command included in Abacus-WinOps but is specifically designed for Abacus-Zerto as an automation/orchestration piece.

.PARAMETER VPGname
The name of the VPG being targeted for having the NIC set.
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER Connected
A Boolean value maching the desired state of the NIC.
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: False

.PARAMETER Confirm
A parameter to specify if a confirmation is needed to run the command.
    Type: Boolean
    Aliases: None
    Default Value:  $True
    Accept Pipeline Input: False

.PARAMETER Max_vm_limter
An integer value to specify the max number of VMs to process in a single request.
    Type: Int32
    Aliases: None
    Default Value: 30
    Accept Pipeline Input: False

.EXAMPLE
$VPGName | Set-VPGVMNics -Connected False


.NOTES
This command accepts objects returned from the Get-ZertoVPGMembers command via Pipeline or passed explicitly through the VPGObjects parameter.
#>

Function Set-VPGVMNics {

    [CmdletBinding(DefaultParameterSetName = 'ByVPGname')]

    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true, ParameterSetName = 'ByVPGname')]
        [ValidateNotNullOrEmpty()]
        [String]$VPGname
        ,
        [Parameter(ValueFromPipeline = $true, Mandatory = $true, ParameterSetName = 'ByVM')]
        [ValidateNotNullOrEmpty()]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl]$VMs
        ,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet($false, $true)]
        [String]$Connected
        ,
        [ValidateSet($false, $true)]
        $Confirm = $true
        ,
        [Int]$Max_vm_limter = 30
    )

    Begin {

        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }

        If ( $(Test-ABAVIServer) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a VIServer" -LogObject $Zerto_global_logobject -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
        }

        $All_VMs = @()
    }

    Process {
        if ($PsCmdlet.ParameterSetName -eq "ByVPGname") {
            $VPGname | % { $All_VMs += Get-ABAVMsfromVPG -VPGname $_ }
        }
        elseif ($PsCmdlet.ParameterSetName -eq "ByVM") {

            $All_VMs = $VMs
        }
    }

    End {
        [bool]$Bool_Connected = [System.Convert]::ToBoolean($Connected)
        [bool]$Bool_Confirm = [System.Convert]::ToBoolean($Confirm)
        $all_vms = $all_vms | ? { $null -ne $_.name }
        $All_VMs_measure = $All_VMs | measure
        if ($All_VMs_measure.count -eq 0) {
            Write-Log -LogObject $Zerto_global_logobject -LogLevel error -LogString "Set-VPGVMNics: No VMs Found"

        }
        else {
            <#
                $all_vms | %{
                    $_ | select Name, PowerState, Folder, VMHost | ft -AutoSize
                    $all_connected_nics = $_ | Get-NetworkAdapter #| ? {$_.ConnectionState.connected -eq $Connected}
                    $Display_nics = $all_connected_nics | select Parent,name,NetworkName,ConnectionState
                    Write-Host -ForegroundColor Yellow "$($Display_nics | out-string)"
                }
            #>
            $all_connected_nics = $all_vms | Get-NetworkAdapter #| ? {$_.ConnectionState.connected -eq $true}

            if ($($all_connected_nics | measure).count -gt 0) {
                $Display_nics = $all_connected_nics | select Parent, name, NetworkName, ConnectionState
                <#
                $Display_nics | %{
                    if($_.ConnectionState -match "NotConnected"){
                        Write-Host -ForegroundColor Cyan "$($_|out-string)"
                    }else{
                        Write-Host -ForegroundColor Cyan "$($_|out-string)"
                    }
                }
                #>
                Write-Host -ForegroundColor Cyan "$($Display_nics|out-string)"

            }


            if ($Bool_Confirm -eq $true) {
                while ([String]$input -notmatch "^(Y|N|Yes|No)$") {

                    $input = Read-Host "$($All_VMs_measure.count) VMs Found - Setting Nic connected status to $connected, Continue? (Y|N|Yes|No)"

                }

            }
            else {
                Write-Log -LogObject $Zerto_global_logobject -LogLevel Verbose -LogString "Set-VPGVMNics: Confirm set to false bypassing question"
                $input = "Yes"
            }


            switch -regex ($input) {

                '^(N|No)$' {
                    Write-Log -LogObject $Zerto_global_logobject -LogLevel Output -LogString "No selected - hopping ship!"
                }

                '^(Y|Yes)$' {
                    $All_VMs | % {
                        Write-Log -LogObject $Zerto_global_logobject -LogLevel Output -LogString "Setting Nic: $($_.name) to Connected: $Bool_Connected"
                        $_ | Set-VMNics -connected $Bool_Connected
                    }
                }
            }
        }
    }
}