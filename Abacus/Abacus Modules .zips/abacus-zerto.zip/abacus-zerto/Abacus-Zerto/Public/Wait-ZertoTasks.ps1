﻿<#
.SYNOPSIS
Wait for tasks to complete based on threshhold or provided taskIDs

.DESCRIPTION
Wait for tasks to complete based on threshhold or provided taskIDs

.PARAMETER zertoTaskID
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER max_task_threshhold
    Type: Int32
    Aliases: None
    Default Value: 15
    Accept Pipeline Input: False

.PARAMETER suppressOverloadCheck
    Type: Switch
    Aliases: None
    Default Value: False
    Accept Pipeline Input: False

.EXAMPLE
"TaskID1","TaskID2" | Wait-ZertoTasks

.NOTES
General notes
#>

Function Wait-ZertoTasks {
    Param(
        [Parameter(ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [String]$zertoTaskID
        ,
        [int]$max_task_threshhold = 15
        ,
        [Switch]$suppressOverloadCheck
    )
    Begin {
        if ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        $zertoTasks = @()
    }
    Process {
        if ($zertoTaskID) {
            foreach ($taskID in $zertoTaskID) {
                $zertoTasks += Get-ZertoTask -ZertoTaskIdentifier $taskID | ? { $_.status.state -notmatch 6 }
            }
        }
    }
    End {
        $Live_TasksIDs = @()
        Do {
            $Live_TasksIDs = $zertoTasks.TaskIdentifier
            $zertoTasks = @() # clear all tasks for next loop check
            if ($($Live_TasksIDs | measure).count -gt 0) {
                $Live_TasksIDs | % {
                    $zertoTasks += Get-ZertoTask -ZertoTaskIdentifier $_ | ? { $_.status.state -notmatch 6 } #Create an array of all live tasks
                }
            }

            if ($($zertoTasks | measure).count -gt 0) {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Output `
                    -LogString "Waiting for Jobs:`n$($zertoTasks | select Started,Type,Status,TaskIdentifier|out-string)"
                sleep 30
            }

        }until($($Live_TasksIDs | measure).count -eq 0)

        if (!$suppressOverloadCheck) {
            #check if there are existing jobs
            $live_Tasks = Get-ZertoTask -Status InProgress | measure

            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Output `
                -LogString "Overload check:`n$($live_Tasks.count) existing zvm jobs running..."

            while ($live_Tasks.count -ge $max_task_threshhold) {
                $live_Tasks = Get-ZertoTask -Status InProgress | measure

                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Output `
                    -LogString "$($live_Tasks.count) running... Waiting until it reduces under $max_task_threshhold..."

                if ($live_Tasks.count -ge $max_task_threshhold) {
                    sleep 30
                }
            }
        }
    }
}
