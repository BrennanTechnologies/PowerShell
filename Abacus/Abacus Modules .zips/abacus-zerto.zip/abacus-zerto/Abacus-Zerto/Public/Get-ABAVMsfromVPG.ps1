﻿<#
.SYNOPSIS
This command returns vSphere VM objects based on the VM names associated with a VPG's membership.

.DESCRIPTION
This command returns vSphere VM objects based on the VM names associated with a VPG's membership.

.PARAMETER VPGname
The name of the VPG you are querying for.
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER Max_vm_limter
Allowed number of results returned per-VPG query.
    Type: Int32
    Aliases: None
    Default Value: 30
    Accept Pipeline Input: False

.EXAMPLE
Get-ABAVMsfromVPG -VPGname <VPGName>

.NOTES
N/A
#>

Function Get-ABAVMsfromVPG {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$VPGname
        ,
        [Int]$Max_vm_limter = 30
    )

    Begin {
        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        If ( $(Test-ABAVIServer) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a VIServer" `
                -LogObject $Zerto_global_logobject `
                -LogLevel TerminatingError `
                -LineNumber $(Get-CurrentLineNumber)
        }
        $All_VMs = @()
    }

    Process {
        if ([string]::IsNullOrEmpty($VPGname)) {
            #Failout if no VPGname
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel error `
                -LogString "Get-ABAVMsfromVPG: VPGname empty"
        }
        else {

            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Output `
                -LogString "Get-ABAVMsfromVPG: $VPGname"

            $VPG = Get-ZertoVPG -VPGName $VPGname
            $VPG_Object_name = $VPG.VpgName

            if ([string]::IsNullOrEmpty($VPG_Object_name)) {
                #Failout if no VPG found
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel error `
                    -LogString "Get-ABAVMsfromVPG: $VPGname not found"
            }
            else {
                $VPG_VMs = Get-ZertoVM -VPGName $VPG_Object_name
                $VPG_VMs_measure = $VPG_VMs | measure

                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Output `
                    -LogString "$($VPG_VMs_measure.count) VMs in vpg found"

                if ($VPG_VMs_measure.count -eq 0) {
                    #Failout if No VPG VMs Found
                    Write-Log -LogObject $Zerto_global_logobject `
                        -LogLevel error `
                        -LogString "Get-ABAVMsfromVPG: No VPG VMs Found"
                }
                elseif ($VPG_VMs_measure.count -gt $Max_vm_limter) {
                    Write-Log -LogObject $Zerto_global_logobject `
                        -LogLevel error `
                        -LogString "Get-ABAVMsfromVPG: Number exceeds VM Limiter - $Max_vm_limter"
                }
                else {
                    $VPG_VMs | % {
                        $vm = VMware.VimAutomation.Core\Get-VM -Name $_.vmname -ErrorAction SilentlyContinue | Select -First 1

                        if ($null -eq $vm) {
                            Write-Log -LogObject $Zerto_global_logobject `
                                -LogLevel Warning `
                                -LogString "$($_.VmName) VM not found"
                        }
                        else {
                            $All_VMs += $vm
                        }
                    }
                }
            }
        }
    }
    End {
        return $All_VMs
    }
}