﻿<#
.SYNOPSIS
A command for commiting an Operational Failover for Zerto VPG(s)

.DESCRIPTION
A command for commiting an Operational Failover for Zerto VPG(s)

.PARAMETER VPGname
The name of the VPG in which is being targeted for the Operational FailOver
    Type: String
    Aliases: None
    Default Value: None
    Accept Pipeline Input: True (ByPropertyName)

.PARAMETER max_task_threshhold
An integer value matching the total number of tasks that should be able to run at once.
    Type: Int
    Aliases: None
    Default Value: 1
    Accept Pipeline Input: False

.PARAMETER SleepTimer
An integer value that matches the time (in seconds) to wait before checking the task thresh hold before attempting to execute another task.
    Type: Int
    Aliases: None
    Default Value: 60
    Accept Pipeline Input: False

.PARAMETER TimeoutTrysCounter
An integer value that specifies the number of retry attempts before timing out.
    Type: Int
    Aliases: None
    Default Value: 5
    Accept Pipeline Input: False

.EXAMPLE
NYDC-TST-CTX | Commit-ABAOperationalFailover

.NOTES
General notes
#>

Function Commit-ABAOperationalFailover {
    Param(
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
        [String]$VPGname
        ,
        [Int]$max_task_threshhold = 1
        ,
        [Int]$SleepTimer = 60
        ,
        [Int]$TimeoutTrysCounter = 5
    )
    Begin {
        If ( $(Test-ZertoZVMConnection) -eq $False ) {
            Write-Log -LogString "There is currently no connection to a ZVM" -LogObject $Zerto_global_logobject -LogLevel TerminatingError
        }
        $All_VPGs = @()
    }
    Process {
        #validate vra
        Write-Log -LogObject $Zerto_global_logobject -LogLevel Output -LogString "VPGname: $VPGname"
        $VPG = Get-ZertoVPG -VPGName $VPGname
        If ($null -ne $VPGname) {
            $All_VPGs += $VPG
        }
        Else {
            Write-Log -LogObject $Zerto_global_logobject `
                -LogLevel Warning `
                -LogString "$VPGname - not found"
        }
    }
    End {
        $All_tasks = @()
        ForEach ($VPG in $All_VPGs) {
            # Wait for pending tasks
            $Param = @{ }
            If ($max_task_threshhold) {
                $param.max_task_threshhold = $max_task_threshhold
            }
            Wait-ZertoTasks @param
            # Start failover
            Try {
                Clear-Variable newZertoTask -ErrorAction SilentlyContinue
                $All_tasks += Invoke-ZertoVPGFailoverCommit -ZertoVpgIdentifier $VPG.VpgIdentifier -OutVariable newZertoTask

                #Add a wait & check here to verify that the Zero Task was generated before proceeding.
                $TimeoutCounter = $TimeoutTrysCounter
                $newZertoTaskCheck = $Null
                Write-Log -LogString "Verifying ZeroTask Id has entered the task queue." -LogLevel Output -LogObject $Zerto_global_logobject
                While (   ($TimeoutCounter -ne 0) -and ($Null -eq $newZertoTaskCheck)   ) {
                    Try {
                        Get-ZertoTask -ZertoTaskIdentifier $newZertoTask -ErrorAction Stop | Out-Null
                        $newZertoTaskCheck = $True
                    }
                    Catch {
                        Write-Log -LogString "Zerto Task Id has not hit the task queue" -LogLevel Verbose -LogObject $Zerto_global_logobject
                        $newZertoTaskCheck = $Null
                    }

                    If ($True -eq $newZertoTaskCheck) {
                        Write-Log -LogString "Zerto Task Id is present in task queue." -LogLevel Verbose -LogObject $Zerto_global_logobject
                    }
                    Else {
                        Write-Log -LogString "Waiting an additional $SleepTimer seconds before recheck." -LogLevel Verbose -LogObject $Zerto_global_logobject
                        Sleep $SleepTimer
                        $TimeoutCounter = $TimeoutCounter - 1
                        Write-Log -LogString "Trys remaining: $TimeoutCounter" -LogLevel Verbose -LogObject $Zerto_global_logobject
                    }
                }
            }
            Catch {
                Write-Log -LogObject $Zerto_global_logobject `
                    -LogLevel Error `
                    -LogString "Failed to Commit ZertoFailover`n$($_.exception)"
            }
        }
        Return $All_tasks
    }
}
