<#
.SYNOPSIS
A command to restore vCmd Custom VM attributes.

.DESCRIPTION
The following command is used to restore previously queried vCommander Custom VM Attributes after an operational failover.
This can also be used with any of the results returned from Get-ZertoHistory for a specific VPG and/org VM to restore tags from a previous date.

.PARAMETER VPGObjects
An array of one or more VPGObjects in which to target for a restore.

.PARAMETER WhatIf
If this Switch parameter is supplied, no action will be taken and only an output of what would have happened will be supplied.

.EXAMPLE
$VPGMembers | Restore-vCmdCustomAttributes

.EXAMPLE
$VPGMembers | Restore-vCmdCustomAttributes -WhatIf

.NOTES
The following command requires the vCmd modules and attempts to connect to the server using Connect-vCmdServer
#>

Function Restore-vCmdCustomAttributes {
    Param (
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)]
        [Array[]]$VPGObjects
        ,
        [Switch]$WhatIf
    )
    Begin {
        Try {
            Write-Log -LogString "Connecting to vCommander's API..." -LogLevel Output -LogObject $Zerto_global_logobject
            Connect-vCmdServer
        }
        Catch {
            Write-Log -LogString "There was an issue attempting to connect to vCommander's API" -LogLevel TerminatingError -LogObject $Zerto_global_logobject
        }

        If ($WhatIf -eq $True) {
            [Boolean]$WhatIf = $True
        }
        $VPGObjectError = $False
    }
    Process {
        $VPGObjects | % {
            $VMName = $Null
            $VPGObjectError = $False

            If ($Null -eq $_.VMName) {
                Write-Log -LogString "No VMName was detected on this object." -LogLevel Warning -LogObject $Zerto_global_logobject
                $VPGObjectError = $True
            }
            ElseIf ($Null -eq $_.vCmdCustomAttributes) {
                Write-Log -LogString "No vCmdCustomAttributes were detected on this object." -LogLevel Warning -LogObject $Zerto_global_logobject
                $VPGObjectError = $True
            }
            Else {
                $VMName = $_.VMName
            }

            If ($VPGObjectError -eq $False) {
                Try {
                    If ($WhatIf -eq $False) {
                        Write-Log -LogString "`nRestoring vCmdCustomAttributes on VM $VMName" -LogLevel Output -LogObject $Zerto_global_logobject
                        $_.vCmdCustomAttributes | % {
                            Write-Log -LogString "Restoring Attribute: '$($_.Name)' Value: '$($_.Value)' to '$VMName'" -LogLevel Output -LogObject $Zerto_global_logobject
                            Set-vCmdVMCustomAttribute -VMName $VMName -CustomAttributeName "$($_.Name)" -CustomAttributeValue "$($_.Value)" -ErrorAction Stop
                        }
                    }
                    ElseIf ($WhatIf -eq $True) {
                        $_.vCmdCustomAttributes | % {
                            Write-Log -LogString "-WhatIf flag detected - Command: Set-vCmdVMCustomAttribute -VMName $VMName -CustomAttributeName `"$($_.Name)`" -CustomAttributeValue `"$($_.Value)`" -ErrorAction Stop" -LogLevel Output -LogObject $Zerto_global_logobject
                        }
                    }
                }
                Catch {
                    Write-Log -LogString "There was an issue restoring one or more vCmdCustomAttributes on VM $VMName" -LogLevel Error -LogObject $Zerto_global_logobject
                }
            }
            Else {
                # For if we want to specifically do anything for failed objects
                <#
                #
                #
                #>
            }
        }
    }
}