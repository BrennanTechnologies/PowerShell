if(!("Site" -as [Type])){
Add-Type -TypeDefinition @'
    public enum Site{
        ny=5,
        ph=2221,
        tx=2221,
        sf=7,
        l1=13,
        l2=2283,
        cf=2578
    }
'@
}

#Get public and private function definition files.
$Public  = @( Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue )

#Dot source the files
Foreach($import in @($Public + $Private))
{
    Try
    {
        #Write-Host "$import"
        . $import.fullname | Out-Null
    }
    Catch
    {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Export-ModuleMember -Function $Public.Basename

try {
    $script_name = "Abacus-Zerto"
    $logname = "Operations.log"
    $audit_logroot = "\\service02.corp\DFS\SHARES\PSAuditLogs\"
    $log_logroot = "C:\ProgramData\PSlogs"

    $audit_logpath = Join-Path $(Join-Path $audit_logRoot $script_name) $logname
    $log_logpath = Join-Path $(Join-Path $log_logroot $script_name) $logname

    Write-Host $audit_logpath
    Write-Host $log_logpath

    $Zerto_global_logobject = Start-Log -LogPath $log_logpath -ScriptName $script_name -Audit True -AuditLogPath $audit_logpath -Global False
}catch{
    throw "Failed to initiate log $($Zerto_global_logobject | Out-String) `n($_.exception)"
}