﻿#Get public and private function definition files.
$Public  = @( Get-ChildItem -Path $PSScriptRoot\Abacus-Panorama\Public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\Abacus-Panorama\Private\*.ps1 -ErrorAction SilentlyContinue )
Import-Module $PSScriptRoot\Abacus-Panorama\Newtonsoft.Json.dll

#Dot source the files
ForEach($Import in @($Public + $Private))
{
    Try
    {
        . $Import.FullName | Out-Null
    }
    Catch
    {
        Write-Error -Message "Failed to import function $($Import.Fullname): $_"
    }
}

Export-ModuleMember -Function $Public.Basename

Try {
    $Script_Name = "Abacus-Panorama"
    $LogName = "Panorama.log"
    $Audit_Logroot = "\\service02.corp\DFS\SHARES\PSAuditLogs\"
    $Log_Logroot = "C:\ProgramData\PSlogs"

    $Audit_Logpath = Join-Path $(Join-Path $Audit_LogRoot $Script_Name) $LogName
    $Log_Logpath = Join-Path $(Join-Path $Log_LogRoot $Script_Name) $LogName

    Write-Host $Audit_Logpath
    Write-Host $Log_Logpath

    $Panorama_LogObject = Start-Log -LogPath $Log_Logpath -ScriptName $Script_Name -Audit True -AuditLogPath $Audit_Logpath -Global False
}
Catch{
    Throw "Failed to initiate log $($Panorama_LogObject | Out-String) `n($_.exception)"
}