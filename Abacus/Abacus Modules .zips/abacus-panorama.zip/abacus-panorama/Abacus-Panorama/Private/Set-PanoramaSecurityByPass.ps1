
<#
.SYNOPSIS
A command for bypassing TLS/SSL errors.

.DESCRIPTION
A command for bypassing TLS/SSL errors.

.EXAMPLE
Set-PanoramaSecurityByPass

.NOTES
General notes
#>
Function Set-PanoramaSecurityByPass {
    Begin {
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
    }
    Process {
        [System.Net.ServicePointManager]::MaxServicePointIdleTime = 1800000
        [System.Net.ServicePointManager]::SetTcpKeepAlive($True, 1000, 1000)
        $AllProtocols = [System.Net.SecurityProtocolType]'Ssl3, tls11, tls, Tls12'
        [System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
    }
}
