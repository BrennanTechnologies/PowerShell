<#
.SYNOPSIS
A command for submitting Panorama Changes from the candidate config to the running config.

.DESCRIPTION
A command for submitting Panorama Changes from the candidate config to the running config.

.PARAMETER CommitMessage
An optional commit message to go with the commit. This will be shown in the email.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIUsername
The username to use for the API connection. The default is srv-panorama which is already configured. If used, credentials for this role-account will be obtained via Secret.

.PARAMETER PanoramaAPIInstance
The instance of the Panorama device you are connecting to, eg. Prod/QA. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER SendToEmailAddress
The send to address for the email report.

.PARAMETER SendFromEmailAddress
The send from address for the email report.

.PARAMETER SMTPServer
The SMTP server to be used for the email.

.EXAMPLE
Submit-PanoramaChanges

.EXAMPLE
Submit-PanoramaChanges -CommitMessage "This is a commit."

.NOTES
General notes
#>

Function Submit-PanoramaChanges {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [String]$CommitMessage
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
        ,
        [String]$APIUserName = $Global:PanoramaAPIUserName
        ,
        [String]$PanoramaAPIInstance = $Global:PanoramaAPIInstance
        ,
        [String]$SendToEmailAddress = 'noc.all@abacusgroupllc.com'
        ,
        [String]$SendFromEmailAddress = 'reports@abacusgroupllc.com'
        ,
        [String]$SMTPServer = 'relay-ny.accessabacus.com'
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $CommitChanges = Get-PanoramaPendingChanges -ReturnAsJson
        If ($Null -eq $CommitChanges) {
            Write-Log -LogString "There are no changes to commit" -LogLevel Warning -LogObject $Panorama_LogObject
            $ProceedWithCommit = $False
        }
        Else {
            $ProceedWithCommit = $True
        }
        If ($True -eq $ProceedWithCommit) {
            $ValidationCheck = $(Test-PanoramaConfig)
            If ($ValidationCheck.result -ne 'OK') {
                Write-Log -LogString "There was an error validating the candidate configuration." -LogLevel Warning -LogObject $Panorama_LogObject
                Return $($ValidationCheck)
                $ProceedWithCommit = $False
            }
            Else {
                Write-Log -LogString "Candidate configuration is valid." -LogLevel Output -LogObject $Panorama_LogObject
            }
        }
        If ($True -eq $ProceedWithCommit) {
            Write-Log -LogString "Performing a backup of the configuration" -LogLevel Output -LogObject $Panorama_LogObject
            $Backup = Backup-PanoramaConfig
            If ($True -eq $BackUp) {
                Write-Log -LogString "A backup of the configuration was taken sucessfully" -LogLevel Output -LogObject $Panorama_LogObject
                $ProceedWithCommit = $True
            }
            Else {
                Write-Log -LogString "Failed to create a backup of the config. Commit will not proceed." -LogLevel Error -LogObject $Panorama_LogObject
                $ProceedWithCommit = $False
            }
        }
        If ($True -eq $ProceedWithCommit) {
            #Setting Variables
            [Boolean]$EmailReportLoop = $True
            [Int]$EmailReportNotSentCounter = 0
        }
    }
    Process {
        If ($True -eq $ProceedWithCommit) {
            Try {
                $CommitCmd = "$($APIUrl)?type=commit&cmd=<commit><partial><admin><member>$($APIUserName)</member></admin></partial></commit>&key=$($APIKey)"
                $CommitCmdResults = (Invoke-RestMethod -Uri $CommitCmd -Method Get)
                $JobId = $($CommitCmdResults.Response.result.job)
                Wait-PanoramaJob -JobType op -JobId $JobId
            }
            Catch {
                Write-Log -LogString "There was an error committing our changes" -LogLevel TerminatingError -LogObject $Panorama_LogObject
            }
            Try {
                # Send Email
                Write-Log -LogString "Attempting to send e-mail report." -LogLevel Output -LogObject $Panorama_LogObject
                [String]$EmailBody = ""
                $EmailBody += "Commit Requested By: $($Env:UserName)`t`n`t`n"
                $EmailBody += "$($CommitMessage)`t`n`t`n"
                $EmailBody += "The following changes were committed to Panorama.`t`n"
                $EmailBody += ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`t`n"
                $EmailBody += $CommitChanges
                $EmailBody += ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`t`n"
                Write-Log -LogString $EmailBody -LogLevel Debug -LogObject $Panorama_LogObject
                While (   ($True -eq $EmailReportLoop)   ) {
                    If ($EmailReportNotSentCounter -ge 10) {
                        $EmailReportLoop = $False
                        Write-Log -LogString "Could not send email report." -LogLevel TerminatingError -LogObject $Panorama_LogObject
                    }
                    Try {
                        Switch ($PanoramaAPIInstance) {
                            'PROD' {
                                Send-MailMessage -Body $EmailBody -From $SendFromEmailAddress -To $SendToEmailAddress -SmtpServer $SMTPServer -Subject 'Changes to Panorama' -ErrorAction Stop
                            }
                            'QA' {
                                Send-MailMessage -Body $EmailBody -From $SendFromEmailAddress -To "sgalazzo@abacusgroupllc.com" -SmtpServer $SMTPServer -Subject 'Changes to Panorama' -ErrorAction Stop
                            }
                        }
                        Write-Log -LogString "E-mail report sent." -LogLevel Output -LogObject $Panorama_LogObject
                        $EmailReportLoop = $False
                    }
                    Catch {
                        Write-Log -LogString "There was an error sending the report email. Retrying..." -LogLevel Warning -LogObject $Panorama_LogObject
                        $EmailReportNotSentCounter++
                        Sleep 5
                    }
                }
            }
            Catch {
                Write-Log -LogString "There was an error sending email report" -LogLevel Warning -LogObject $Panorama_LogObject
            }
        }
    }
}