<#
.SYNOPSIS
A command used to look up various rule types on the Panorama Devices.

.DESCRIPTION
A command used to look up various rule types on the Panorama Devices.

.PARAMETER DeviceGroup
A dynamic parameter of available DeviceGroups which can be used as the target of the rules query.

.PARAMETER RuleType
The rule type in question you want to query.

.PARAMETER RuleCategory
The specific category of rules you want to query.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaRules -DeviceGroup 'Shared' -RuleType 'pre-rulebase' -RuleCategory 'Security'

.EXAMPLE
Get-PanoramaRules -DeviceGroup 'Shared' -RuleType 'post-rulebase' -RuleCategory 'Security'

.EXAMPLE
Get-PanoramaRules -DeviceGroup 'Inside Firewalls' -RuleType 'pre-rulebase' -RuleCategory 'nat'

.EXAMPLE
Get-PanoramaRules -DeviceGroup 'Outside Firewalls' -RuleType 'pre-rulebase' -RuleCategory 'nat'

.NOTES
General notes
#>

Function Get-PanoramaRules {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('pre-rulebase', 'post-rulebase')]
        [String]$RuleType
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('security', 'application-override', 'nat', 'decryption', 'pbf')]
        [String]$RuleCategory
        ,
        [Parameter(Mandatory = $False)]
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [Parameter(Mandatory = $False)]
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    DynamicParam {
        $ParameterName = 'DeviceGroup'
        $DynamicParamDeviceGroup = New-Object System.Management.Automation.ParameterAttribute
        $DynamicParamDeviceGroup.Mandatory = $true
        $DynamicParamDeviceGroup.HelpMessage = 'DeviceGroup returned from Get-PanoramaDeviceGroups'

        $DynamicParamDeviceGroupCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $DeviceGroups = Get-PanoramaDeviceGroups | Select -ExpandProperty Name

        $DeviceGroupCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $DeviceGroupCollection.add($DynamicParamDeviceGroup)

        $DeviceGroupValidateSet = New-Object System.Management.Automation.ValidateSetAttribute($DeviceGroups)
        $DeviceGroupCollection.add($DeviceGroupValidateSet)

        $DeviceGroupParam = New-Object System.Management.Automation.RuntimeDefinedParameter($ParameterName, [string], $DeviceGroupCollection)

        $DeviceGroupDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        $DeviceGroupDictionary.Add($ParameterName, $DeviceGroupParam)
        Return $DeviceGroupDictionary
    }
    Begin {
        $DeviceGroupConfigurations = @()
        $ReturnObject = @()
        $Object = @()
        $ConfigAction = 'get'
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        If ($DeviceGroup -eq 'Shared') {
            $Query = "?type=config&action=get&xpath=/config/shared/$($RuleType)"
            [Xml]$QueryResults = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET -ContentType 'application/xml'
        }
        Else {
            $Query = "?type=config&action=get&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='$($DeviceGroup)']"
            [Xml]$QueryResults = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET -ContentType 'application/xml'
        }
        If ($QueryResults.response.status -eq 'success') {
            Switch ($RuleType) {
                Default {
                    Switch ($RuleCategory) {
                        Default {
                            If ($DeviceGroup -eq 'Shared') {
                                $Data = $QueryResults.response.result.$($RuleType).$($RuleCategory).rules.entry
                                $FilteredQueryResults = [PSCustomObject]@{$($RuleType) = $Data; }
                            }
                            Else {
                                $Data = $QueryResults.response.result.entry."$($RuleType)".$($RuleCategory).rules.entry
                                $FilteredQueryResults = [PSCustomObject]@{$($RuleType) = $Data; }
                            }
                        }
                    }
                }
            }

            $DeviceConfigInJson = [Newtonsoft.Json.JsonConvert]::SerializeObject($FilteredQueryResults.$($RuleType))
            $DeviceConfig = $DeviceConfigInJson | ConvertFrom-Json
            ForEach ($Item in $DeviceConfig.entry) {

                $FullObject = [PSCustomObject]@{ }
                ForEach ($Attribute in $($Item | Get-Member -MemberType NoteProperty) ) {
                    $Object = [PSCustomObject]@{ }
                    If ($Attribute.Name.ToString() -notlike '#whitespace') {

                        If ($Attribute.Definition -like "*System.Object*") {
                            $Object | Add-Member -Name $($Attribute.Name) -value $($Item.$($Attribute.Name) | Select * -ExcludeProperty '#whitespace') -MemberType NoteProperty
                        }
                        Else {
                            $Object | Add-Member -Name $($Attribute.Name) -value $($Item.$($Attribute.Name) | Select -ExcludeProperty '#whitespace') -MemberType NoteProperty
                        }
                        $FullObject | Add-Member -Name "$($Attribute.Name -replace '^@','')" -MemberType NoteProperty -Value $Object.$($Attribute.Name)
                    }
                    Else {
                        Continue
                    }
                }
                $ReturnObject += $FullObject
            }
        }
        Else {
            Write-Log -LogString "Query status returned from the device was not sucessful..." -LogLevel Warning -LogObject $Panorama_LogObject
            Write-Log -LogString "Device Response Message: `"$($QueryResults.response.status)`"" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    End {
        Return $($ReturnObject)
    }
}