<#
.SYNOPSIS
This function can be used to add a Panorama Host Object to an existing Address Group on the Panorama device.

.DESCRIPTION
This function can be used to add a Panorama Host Object to an existing Address Group on the Panorama device.

.PARAMETER HostName
The HostName matching the host object you wish to add to the addressgroup.

.PARAMETER AddressGroup
The name of the AddressGroup that you wish for the host to be added to.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Add-PanoramaHostToAddressGroup -Hostname "TESTSERVER1" -AddressGroup "TestAddressGroup"

.NOTES
General notes
#>

Function Add-PanoramaHostToAddressGroup {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLine = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [String[]]$HostName
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLine = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [String[]]$AddressGroup
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl

        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $AddressError = $False
        $ReturnObject = @()
    }
    Process {
        ForEach ($HostObject in $($HostName)) {
            $AddressError = $False
            $HostObjectCheck = [Boolean]$(Get-PanoramaHost -HostName $HostObject)
            If ([Boolean]$($HostObjectCheck) -eq $False) {
                Write-Log -LogString "No host `"$($HostObject)`" exists within Panorama's running configuration by this name." -LogLevel Warning -LogObject $Panorama_LogObject
            }
            If ($AddressError -eq $False) {
                $AddressGroupCheck = [Boolean]$(Get-PanoramaAddressGroup -AddressGroup $($AddressGroup))
                If ([Boolean]$($AddressGroupCheck) -eq $False) {
                    Write-Log -LogString "No AddressGroup `"$($AddressGroup)`" exists within Panorama's running configuration by this name" -LogLevel Warning -LogObject $Panorama_LogObject
                    $AddressGroupCheck = [Boolean]$(Get-PanoramaAddressGroup -AddressGroup $($AddressGroup) -CandidateConfig)
                    If ([Boolean]$($AddressGroupCheck) -eq $False) {
                        Write-Log -LogString "No AddressGroup `"$($AddressGroup)`" exists within Panorama's candidate configuration by this name" -LogLevel Warning -LogObject $Panorama_LogObject
                        $AddressError = $True
                    }
                    Else {
                        $AddressError = $False
                    }
                }
            }
            If ($AddressError -eq $False) {
                Try {
                    Write-Log -LogString "Adding Host `"$($HostObject)`" to AddressGroup `"$($AddressGroup)`"" -LogLevel Verbose -LogObject $Panorama_LogObject
                    $AddHostToAdrGroupCmd = "?type=config&action=set&xpath=/config/shared/address-group/entry[@name='$($AddressGroup)']&element=<static><member>$($HostObject)</member></static>"
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($AddHostToAdrGroupCmd)&key=$($APIKey)" -Method Get).Response.Msg
                    $ResultObject = @()
                    $ResultObject += [PSCustomObject]@{'HostName' = $($HostObject); 'AddressGroup' = $($AddressGroup); 'ResultMsg' = $cmdResults }
                    $ReturnObject += $ResultObject
                }
                Catch {
                    Write-Log -LogString "There was an issue adding `"$($HostObject)`" to the `"$($AddressGroup)`" AddressGroup." -LogLevel TerminatingError -LogObject $Panorama_LogObject
                }
            }
        }
    }
    End {
        $ReturnObject | % {
            Write-Log -LogString $_ -LogLevel Debug -LogObject $Panorama_LogObject
        }
        Return $($ReturnObject | Format-Table -AutoSize)
    }
}