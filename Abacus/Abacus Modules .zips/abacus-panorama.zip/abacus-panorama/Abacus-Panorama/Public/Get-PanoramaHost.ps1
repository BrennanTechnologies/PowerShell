<#
.SYNOPSIS
Short description

.DESCRIPTION
Long description

.PARAMETER HostName
Parameter description

.PARAMETER CandidateConfig
Parameter description

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaHost

.EXAMPLE
Get-PanoramaHost -HostName "TestHost"

.EXAMPLE
Get-PanoramaHost -HostName "TestHost" -CandidateConfig

.EXAMPLE
Get-PanoramaHost -CandidateConfig

.NOTES
General notes
#>

Function Get-PanoramaHost {
    [CmdletBinding()]
    Param(
        [Alias('Name')]
        [String]$HostName = $Null
        ,
        [Switch]$CandidateConfig = $False
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        If ($True -eq $CandidateConfig) {
            $ConfigAction = 'get'
        }
        Else {
            $ConfigAction = 'show'
        }
        If (   [String]::IsNullOrEmpty($HostName) -eq $False   ) {
            $Query = "?type=config&action=$($ConfigAction)&xpath=/config/shared/address/entry[@name='$($HostName)']"
        }
        Else {
            $Query = "?type=config&action=$($ConfigAction)&xpath=/config/shared/address"
        }
        Try {
            $Results = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET
        }
        Catch {
            Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        If (   $Null -ne $($Results.Response.Result.Entry)   ) {
            Return $($Results.Response.Result.Entry)
        }
        Else {
            Return $($Results.Response.Result.address.entry)
        }
    }
}