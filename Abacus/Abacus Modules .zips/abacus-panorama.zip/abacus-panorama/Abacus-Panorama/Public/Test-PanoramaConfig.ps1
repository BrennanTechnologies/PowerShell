<#
.SYNOPSIS
A command to validate a Panorama candidate configuration.

.DESCRIPTION
A command to validate a Panorama candidate configuration.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Test-PanoramaConfig

.NOTES
General notes
#>

Function Test-PanoramaConfig {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $ChangeSet = Get-PanoramaPendingChanges
    }
    Process {
        If ($Null -eq $ChangeSet) {
            Write-Log -LogString "There are currently no pending changes." -LogLevel Warning -LogObject $Panorama_LogObject
        }
        Else {
            Write-Log -LogString "Validating current configuration" -LogLevel Output -LogObject $Panorama_LogObject
            $ValidateCmd = "?type=op&cmd=<validate><full></full></validate>"
            $JobId = (Invoke-RestMethod -Uri "$($APIUrl)$($ValidateCmd)&key=$($APIKey)" -Method GET).Response.Result.Job
            Write-Log -LogString "JobId: $JobId" -LogLevel Verbose -LogObject $Panorama_LogObject
            $Results = Wait-PanoramaJob -JobType op -JobID $JobId
            $ReturnObject = $Results
            $ReturnObject | Add-Member -MemberType NoteProperty -Name Message -Value $( -join $Results.details.line.'#cdata-section')
            Write-Log -LogString "Configuration Validation Status: `"$($ReturnObject.Result.ToString())`" ; Message: `"$($ReturnObject.Message.ToString())`"" -LogLevel Debug -LogObject $Panorama_LogObject
            Return $($ReturnObject)
        }
    }
}