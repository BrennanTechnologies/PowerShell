<#
.SYNOPSIS
A command used to push Panorama configs.

.DESCRIPTION
A command used to push Panorama configs.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER Raw
A switch parameter to export just the raw results instead of a formatted table.

.EXAMPLE
Push-PanoramaConfig

.EXAMPLE
Push-PanoramaConfig -Raw

.NOTES
General notes
#>

Function Push-PanoramaConfig {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
        ,
        [Switch]$Raw = $False
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $DeviceGroups = Get-PanoramaDeviceGroups
        $Results = @()
        $JobArray = @()
        If ($Null -eq $DeviceGroups) {
            Write-Log -LogString "No device groups were found to push configurations to." -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        ForEach ($Device in $DeviceGroups.Name ) {
            $Query = "?type=commit&action=all&cmd=<commit-all><shared-policy><device-group><entry name=`"$($Device)`"/></device-group></shared-policy></commit-all>"
            Try {
                $QueryResult = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET
                If (   $Null -ne ($QueryResult.response.result.job)   ) {
                    $JobArray += $QueryResult.response.result.job
                }
            }
            Catch {
                Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
            }
        }
        ForEach ($Job in $JobArray) {
            $Results += Wait-PanoramaJob -JobId $Job -JobType op
        }
        If ($Raw -eq $True) {
            Return $Results
        }
        Else {
            Return $($Results | Select id, user, type, tfin, push_type, status, dgname, result | Format-Table -Autosize )
        }
    }
}