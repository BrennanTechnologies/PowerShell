<#
.SYNOPSIS
A command for setting a commit lock on the Panorama device to prevent other commits.

.DESCRIPTION
A command for setting a commit lock on the Panorama device to prevent other commits. This is not really needed now as PanOS now supports user level commits.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Set-PanoramaCommitLock

.NOTES
General notes
#>

Function Set-PanoramaCommitLock {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Command = "$($APIUrl)?type=op&cmd=<request><commit-lock><add><comment>Panorama locked via DevOps API request</comment></add></commit-lock></request>&key=$($APIKey)"
        $Results = (Invoke-RestMethod -Uri $Command -Method Get).Response.Result
        Return $Results
    }
}