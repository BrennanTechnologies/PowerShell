﻿<#
.SYNOPSIS
Short description

.DESCRIPTION
A command used to publish various reports from the Panorama Device.

.PARAMETER SendToEmailAddress
The desired e-mail address which will receive the reports.

.PARAMETER SendFromEmailAddress
The desired e-mail address in which the reports will originate from.

.PARAMETER SMTPServer
The SMTP server in which will be used to send e-mails.

.EXAMPLE
Publish-PanoramaMisconfigurationReport

.NOTES
General notes
#>

Function Publish-PanoramaMisconfigurationReport {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$SendToEmailAddress = 'noc.all@abacusgroupllc.com'
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$SendFromEmailAddress = 'reports@abacusgroupllc.com'
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$SMTPServer = 'relay-ny.accessabacus.com'
    )
    Begin {
        $ReturnObject = @()
        $EmailSentStatus = $False
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        #
        $SecurityRules = @()
        $PreSecurityRules = @()
        $PostSecurityRules = @()
        #

        #
        $SharedPreSecurityRules = $(Get-PanoramaRules -DeviceGroup "Shared" -RuleType pre-rulebase -RuleCategory security)
        $SharedPreSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Shared/pre-rulebase/security'

        $InsidePreSecurityRules = $(Get-PanoramaRules -DeviceGroup "Inside Firewalls" -RuleType pre-rulebase -RuleCategory security)
        $InsidePreSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Inside Firewalls/pre-rulebase/security'

        $OutsidePreSecurityRules = $(Get-PanoramaRules -DeviceGroup "Outside Firewalls" -RuleType pre-rulebase -RuleCategory security)
        $OutsidePreSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Outside Firewalls/pre-rulebase/security'
        #

        #
        $SharedPostSecurityRules = $(Get-PanoramaRules -DeviceGroup "Shared" -RuleType post-rulebase -RuleCategory security)
        $SharedPostSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Shared/post-rulebase/security'

        $InsidePostSecurityRules = $(Get-PanoramaRules -DeviceGroup "Inside Firewalls" -RuleType post-rulebase -RuleCategory security)
        $InsidePostSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Inside Firewalls/post-rulebase/security'

        $OutsidePostSecurityRules = $(Get-PanoramaRules -DeviceGroup "Outside Firewalls" -RuleType post-rulebase -RuleCategory security)
        $OutsidePostSecurityRules | Add-Member -Name 'RuleType' -MemberType NoteProperty -Value 'Outside Firewalls/post-rulebase/security'
        #

        #
        $PreSecurityRules += $SharedPreSecurityRules
        $PreSecurityRules += $InsidePreSecurityRules
        $PreSecurityRules += $OutsidePreSecurityRules

        $PostSecurityRules += $SharedPostSecurityRules
        $PostSecurityRules += $InsidePostSecurityRules
        $PostSecurityRules += $OutsidePostSecurityRules
        #

        #
        $SecurityRules += $PreSecurityRules
        $SecurityRules += $PostSecurityRules
        #
    }
    Process {
        # Security Rules without Logging
        Try {
            $SecurityRulesWithoutLogging = $SecurityRules | ? { $_.'log-setting' -ne 'General' }
        }
        Catch {
            Write-Log -LogString "There was an error gathering the Panorama Rules." -LogLevel Warning -LogObject $Panorama_LogObject
            Write-Log -LogString "$($_.Exception)" -LogLevel Error -LogObject $Panorama_LogObject
        }


        ### Data consolidation about rules to process should go above this line ###


        #Process and filter our Results
        If ($Null -ne $SecurityRulesWithoutLogging) {
            $ReturnObject += [PSCustomObject]@{'Name' = 'SecurityWithoutLogging'; 'Data' = $SecurityRulesWithoutLogging }
        }
    }
    End {
        ForEach ($Object in $ReturnObject) {
            Switch ($Object.Name) {
                "SecurityWithoutLogging" {
                    Write-Log -LogString "Now processing the `"$($Object.Name)`" object." -LogLevel Output -LogObject $Panorama_LogObject
                    $EmailSubject = 'FireWall Security Rules without General Logging.'
                    $EmailObject = $Object.Data | Select Name, `
                    @{Name = 'RuleType'      ; e = { $($_.RuleType) } }, `
                    @{Name = 'action'      ; e = { $($_.action) } }, `
                    @{Name = 'category'    ; e = { $($_.category.member -join ';') } }, `
                    @{Name = 'to'          ; e = { $($_.to.member -join ';') } }, `
                    @{Name = 'from'        ; e = { $($_.from.member -join ';') } }, `
                    @{Name = 'destination' ; e = { $($_.destination.member -join ';') } }, `
                    @{Name = 'source'      ; e = { $($_.source.member -join ';') } }

                    [String]$EmailBody = @()
                    $style = "<style>BODY{font-family: Arial; font-size: 10pt;}"
                    $style = $style + "TABLE{border: 1px solid black; border-collapse: collapse;}"
                    $style = $style + "TH{border: 1px solid black; background: #dddddd; padding: 5px; }"
                    $style = $style + "TD{border: 1px solid black; padding: 5px; }"
                    $style = $style + "</style>"

                    $EmailBody += $($EmailObject | ConvertTo-Html -Head $Style)
                    $EmailSentStatus = $False
                    While ($EmailSentStatus -eq $False) {
                        Try {
                            Write-Log -LogString "Sending Email to `"$($SendToEmailAddress)`" for `"SecurityWithoutLogging`"." -LogLevel Output -LogObject $Panorama_LogObject
                            Send-MailMessage -Body $EmailBody -From $SendFromEmailAddress -To $SendToEmailAddress -SmtpServer $SMTPServer -Subject $EmailSubject  -BodyAsHtml -ErrorAction Stop
                            $EmailSentStatus = $True
                        }
                        Catch {
                            Write-Log -LogString "There was an issue sending the email... Retrying..." -LogLevel Warning -LogObject $Panorama_LogObject
                        }
                    }
                }
                Default {
                    Write-Log -LogString "Unhandled Exception. `"$($Object.Name)`" is not a valid Object Name." -LogLevel Error -LogObject $Panorama_LogObject
                }
            }
        }
        #
        Return $ReturnObject
    }
}