<#
.SYNOPSIS
A command for removing a Panorama Host Object from a Panorama Device.

.DESCRIPTION
A command for removing a Panorama Host Object from a Panorama Device.

.PARAMETER HostName
The name of the host object in question that you are looking to remove.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Remove-PanoramaHost -HostName "HOSTOBJECT"

.NOTES
General notes
#>

Function Remove-PanoramaHost {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [Alias('Name')]
        [String[]]$HostName
        ,
        [String[]]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String[]]$APIKey = $Global:PanoramaAPIKey

    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        ForEach ($HostObject in $HostName) {
            $ExistingHostCheck = [Boolean]$(Get-PanoramaHost -HostName $HostObject)
            If ([Boolean]$($ExistingHostCheck) -eq $False) {
                Write-Log -LogString "No host exists that matches hostname `"$($HostObject)`"." -LogLevel Warning -LogObject $Panorama_LogObject
            }
            Else {
                Try {
                    Write-Log -LogString "Removing Host: $($HostObject) IP: $($IPAddress) Description: $($Description)" -LogLevel Verbose -LogObject $Panorama_LogObject
                    $RemoveHostObjectCmd = "?&type=config&action=delete&xpath=/config/shared/address/entry[@name='$($HostObject)']"
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($RemoveHostObjectCmd)&key=$($APIKey)" -Method Get).response.msg
                    If ($True -eq $cmdResults.line) {
                        $cmdResults = $cmdResults.line[0].'#text' + $cmdResults.line -join $_
                    }
                    $ReturnObject = @()
                    $ReturnObject = [PSCustomObject]@{'HostName' = $HostObject; 'IPAddress' = $($IPAddress); 'ResultMsg' = $cmdResults }
                    Return $ReturnObject | Format-Table -AutoSize
                }
                Catch {
                    Write-Log -LogString "There was an issue removing the host object. `n $_" -LogLevel Error -LogObject $Panorama_LogObject
                }
            }
        }
    }
}