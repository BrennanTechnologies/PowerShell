<#
.SYNOPSIS
A command to list all Panorama AddressGroups or a specific matching one based on its name.

.DESCRIPTION
A command to list all Panorama AddressGroups or a specific matching one based on its name.

.PARAMETER AddressGroup
The name of the Address Group you are looking to retrieve information for. This can be left blank to retrieve all AddressGroups. AddressGroup names are case sensitive.

.PARAMETER Members
A switch parameter to return the membership information for a particular AddressGroup.

.PARAMETER CandidateConfig
A switch parameter to look at the AddressGroup (or it's membership information) on the candidate config instead of the running config.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaAddressGroup

.EXAMPLE
Get-PanoramaAddressGroup -AddressGroup Test

.EXAMPLE
Get-PanoramaAddressGroup -AddressGroup Test -Members

.EXAMPLE
Get-PanoramaAddressGroup -AddressGroup Test -Members -CandidateConfig

.NOTES
General notes
#>

Function Get-PanoramaAddressGroup {
    [CmdletBinding()]
    Param(
        [String]$AddressGroup = $Null
        ,
        [Switch]$Members = $False
        ,
        [Switch]$CandidateConfig = $False
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ( $(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        If ($True -eq $CandidateConfig) {
            $ConfigAction = 'get'
        }
        Else {
            $ConfigAction = 'show'
        }
        If (   [String]::IsNullOrEmpty($AddressGroup) -eq $False   ) {
            $Query = "?type=config&action=$($ConfigAction)&xpath=/config/shared/address-group/entry[@name='$($AddressGroup)']"
        }
        Else {
            $Query = "?type=config&action=$($ConfigAction)&xpath=/config/shared/address-group"
        }
        Try {
            $Results = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method Get
        }
        Catch {
            Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        If (   $Null -ne ($Results.response.result.entry)   ) {
            $Results = $Results.response.result.entry
            If ($True -eq $Members) {
                $Results = $($Results.static.member)
            }
        }
        Else {
            $Results = $($Results.Response.Result.'address-group'.entry)
        }
        Return $Results
    }
}