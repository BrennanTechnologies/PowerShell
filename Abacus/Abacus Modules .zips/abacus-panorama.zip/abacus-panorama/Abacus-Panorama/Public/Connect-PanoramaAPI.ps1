<#
.SYNOPSIS
A command used to connect to the Panorama API via PowerShell.

.DESCRIPTION
A command used to connect to the Panorama API via PowerShell.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER Username
The username to use for the API connection. The default is srv-panorama which is already configured. If used, credentials for this role-account will be obtained via Secret.

.PARAMETER Password
The matching password for the user connecting. If left blank, this will use the password for srv-panorama stored in Secret.

.EXAMPLE
Connect-PanoramaAPI

.NOTES
General notes
#>

Function Connect-PanoramaAPI {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = "https://panorama.management.corp/api/"
        ,
        [String]$Username = "srv-panorama"
        ,
        [String]$Password = $((Get-Secret  $UserName | Convert-secretToString).password)
    )
    Begin {
        Try {
            Set-PanoramaSecurityByPass -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "Could not set the necessary security options to connect to Panorama." -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Password = [Uri]::EscapeDataString($Password)
        # Grab API Key
        Try {
            $APIKey = (Invoke-RestMethod -Uri "$($APIUrl)?type=keygen&user=$($username)&password=$($password)" -Method GET -ErrorAction Stop -ErrorVariable errAPIKey).response.result.key
        }
        Catch {
            Write-Log -LogString "There was an issue grabing the API key with the specified credentials." -LogLevel Warning -LogObject $Panorama_LogObject
            Write-Log -LogString "$($errAPIKey.message)" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        Try {
            $Global:PanoramaAPIKey = $APIKey
            $Global:PanoramaAPIUrl = $APIUrl
            $Global:PanoramaAPIUserName = $UserName
            $Global:PanoramaAPIInstance = "PROD"
            If (   $False -eq $(Test-PanoramaAPI)   ) {
                Write-Log -LogString "Failed to connect to PanoramaAPI" -LogLevel TerminatingError -LogObject $Panorama_LogObject
            }
            Write-Log -LogString "MOTD: `r`n######################################################`r`n $((Invoke-RestMethod -Uri "$($APIUrl)?type=config&action=get&xpath=/config/predefined/motd&key=$($APIKey)" -Method GET -ErrorAction Stop).Response.Result.motd.entry.message) `r`n######################################################`r`n"  -LogLevel Output -LogObject $Panorama_LogObject
        }
        Catch {
            Disconnect-PanoramaAPI
            Write-Log -LogString "Connection Failed... Please double check url and credentials..." -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Backup = Backup-PanoramaConfig
        Return "Connection Sucessful..."
    }
}