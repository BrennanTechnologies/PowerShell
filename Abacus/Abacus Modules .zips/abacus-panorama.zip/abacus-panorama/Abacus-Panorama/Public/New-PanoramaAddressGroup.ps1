<#
.SYNOPSIS
A command for creating a new Address Group in Panorama.

.DESCRIPTION
A command for creating a new Address Group in Panorama.

.PARAMETER AddressGroupName
The name of the new AddressGroup you are looking to create.

.PARAMETER Description
An optional description to append to the new AddressGroup.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
New-PanoramaAddressGroup -AddressGroupname "NewAddressGroup"

.EXAMPLE
New-PanoramaAddressGroup -AddressGroupname "NewAddressGroup" -Description 'A possible description for the new AddressGroup'

.NOTES
General notes
#>

Function New-PanoramaAddressGroup {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [String[]]$AddressGroupName
        ,
        [Parameter(ValueFromPipeLineByPropertyName = $True)]
        [String[]]$Description = $Null
        ,
        [String[]]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String[]]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        ForEach ($Group in $AddressGroupName) {
            $ExistingGroupCheck = [Boolean]$(Get-PanoramaAddressGroup -AddressGroup $Group)
            If ([Boolean]$($ExistingGroupCheck) -eq $True) {
                Write-Log -LogString "An address group already exists by this name" -LogLevel Warning -LogObject $Panorama_LogObject
            }
            Else {
                Try {
                    Write-Log -LogString "Creating AddressGroup: $($Group)" -LogLevel Verbose -LogObject $Panorama_LogObject
                    If (   [String]::IsNullOrEmpty($($Description)) -eq $True   ) {
                        $CreateAddressGroupCmd = "?type=config&action=set&xpath=/config/shared/address-group/entry[@name='$($Group)']&element=<static></static>"
                    }
                    Else {
                        $CreateAddressGroupCmd = "?type=config&action=set&xpath=/config/shared/address-group/entry[@name='$($Group)']&element=<static></static><description>$($Description)</description>"
                    }
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($CreateAddressGroupCmd)&key=$($APIKey)" -Method Get).response.msg
                    $ReturnObject = @()
                    $ReturnObject = [PSCustomObject]@{'AddressGroup' = $($Group); 'Description' = $($Description); 'ResultMsg' = $cmdResults }
                    Return $ReturnObject | Format-Table -AutoSize
                }
                Catch {
                    Write-Log -LogString "There was an issue creating the `"$($Group)`" AddressGroup" -LogLevel Error -LogObject $Panorama_LogObject
                }
            }
        }
    }
}