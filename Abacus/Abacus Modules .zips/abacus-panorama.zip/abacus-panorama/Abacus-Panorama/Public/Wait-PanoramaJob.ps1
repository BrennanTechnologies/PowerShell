<#
.SYNOPSIS
A command used to wait for a Panorama Job request to finish before returning results.

.DESCRIPTION
A command used to wait for a Panorama Job request to finish before returning results.

.PARAMETER JobID
The JobID for the requested job you are waiting for.

.PARAMETER JobType
The job type being requested and waiting for.

.PARAMETER RefreshDelay
The delay time between refresh waits.

.PARAMETER TimeOutDuration
The total time to wait before timing out.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Wait-PanoramaJob

.EXAMPLE
Wait-PanoramaJob -JobId JobId -JobType log

.NOTES
General notes
#>

Function Wait-PanoramaJob {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateNotNull()]
        [Int]$JobID
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNull()]
        [ValidateSet('log', 'op', 'commit')]
        [String]$JobType
        ,
        [ValidateRange(1, 300)]
        [Int]$RefreshDelay = 2
        ,
        [ValidateRange(10, 300)]
        [Int]$TimeOutDuration = 240
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        $TimeOut = $False
        $TimeOutTimer = (Get-Date).AddSeconds($TimeOutDuration)
        Write-Log -LogString "Waiting for Panorama Job to complete..." -LogLevel Output -LogObject $Panorama_LogObject
    }
    Process {
        Switch ($JobType) {
            "log" {
                $QueryString = "$($APIUrl)?type=$($JobType)&action=get&job-id=$($JobId)&key=$($APIKey)"
                $JobResults = $(Invoke-RestMethod -Uri $QueryString -Method GET).response.result.job.status
                While (   ($JobResults -ne 'FIN') -and ($TimeOut -eq $False)   ) {
                    Write-Log -LogString "Refreshing job information..." -LogLevel Verbose -LogObject $Panorama_LogObject
                    $JobResults = $(Invoke-RestMethod -Uri $QueryString -Method GET).response.result.job.status
                    Sleep 2
                    If ( $(Get-Date) -ge $TimeOutTimer) {
                        $TimeOut = $True
                        Write-Log -LogString "The request timed out after $TimeOutDuration seconds." -LogLevel Warning -LogObject $Panorama_LogObject
                    }
                }
                $QueryString = "$($APIUrl)?type=$($JobType)&action=get&job-id=$($JobId)&key=$($APIKey)"
                $Results = $(Invoke-RestMethod -Uri $QueryString -Method GET)
            }
            "op" {
                $QueryString = "$($APIUrl)?type=$($JobType)&cmd=<show><jobs><id>$($JobId)</id></jobs></show>&key=$($APIKey)"
                $JobResults = $(Invoke-RestMethod -Uri $QueryString -Method GET).response.result.job.status
                While (   ($JobResults -ne 'FIN') -and ($TimeOut -eq $False)   ) {
                    Write-Log -LogString "Refreshing job information..." -LogLevel Verbose -LogObject $Panorama_LogObject
                    $JobResults = $(Invoke-RestMethod -Uri $QueryString -Method GET).response.result.job.status
                    Sleep 2
                    If ( $(Get-Date) -ge $TimeOutTimer) {
                        $TimeOut = $True
                        Write-Log -LogString "The request timed out after $TimeOutDuration seconds." -LogLevel Warning -LogObject $Panorama_LogObject
                    }
                }
                $QueryString = "$($APIUrl)?type=$($JobType)&cmd=<show><jobs><id>$($JobId)</id></jobs></show>&key=$($APIKey)"
                $Results = $(Invoke-RestMethod -Uri $QueryString -Method GET).Response.Result.Job
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel TerminatingError -LogObject $Panorama_LogObject
            }
        }
        If ($TimeOut -eq $True) {
            Write-Log -LogString "Requested job has timed out..." -LogLevel Warning -LogObject $Panorama_LogObject
        }
        Else {
            Return $Results
        }
    }
}