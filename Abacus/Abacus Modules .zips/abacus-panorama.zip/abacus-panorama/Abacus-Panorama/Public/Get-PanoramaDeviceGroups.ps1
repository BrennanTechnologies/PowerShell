<#
.SYNOPSIS
A command to look up all avilable device groups listed through Panorama. This does not include "Shared"

.DESCRIPTION
A command to look up all avilable device groups listed through Panorama. This does not include "Shared"

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaDeviceGroups

.NOTES
General notes
#>

Function Get-PanoramaDeviceGroups {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }

        $Query = "?type=op&cmd=<show><devicegroups></devicegroups></show>"
        Try {
            $Results = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET
        }
        Catch {
            Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        If (   $($Results.Response.status) -eq 'success'   ) {
            $Results = $($Results.Response.Result.Devicegroups.Entry)
            $Results += [PSCustomObject]@{"Name" = 'Shared' }
            Return $($Results)
        }
        ElseIf (   $($Results.Response.status) -ne 'success'   ) {
            Write-Log -LogString "No device groups found." -LogLevel Warning -LogObject $Panorama_LogObject
        }
        Else {
            Write-Log -LogString "Unhandled Exception." -LogLevel Error -LogObject $Panorama_LogObject
        }
    }
}