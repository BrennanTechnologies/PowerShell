<#
.SYNOPSIS
A some what quick and dirty command which scraps Panorama's data for potential duplicate host objects.

.DESCRIPTION
A some what quick and dirty command which scraps Panorama's data for potential duplicate host objects.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaDuplicateEntires

.NOTES
General notes
#>

Function Get-PanoramaDuplicateEntries {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $ConfigAction = 'show'
        $Query = "?type=config&action=$($ConfigAction)&xpath=/config/shared/address"
        Try {
            Write-Log -LogString "Generating host list" -LogLevel Verbose -LogObject $Panorama_LogObject
            $HostList = Invoke-RestMethod -Uri "$($APIUrl)$($Query)&key=$($APIKey)" -Method GET
        }
        Catch{
            Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        Write-Log -LogString "Regexing out only identifiers (ip-netmask, fqdn, ip-range)" -LogLevel Verbose -LogObject $Panorama_LogObject
        $HostData = $HostList.response.result.address.entry | Select Name,@{Name='data';Expression={
            [regex]::Matches($_.innerxml,'(<ip-netmask>|<fqdn>|<ip-range>).*(<\/ip-netmask>|<\/fqdn>|<\/ip-range>)').Value -replace '(<\/*[a-z]*\W*[a-z]*>)',''
        } }
        Write-Log -LogString "Generating Array of duplicates" -LogLevel Verbose -LogObject $Panorama_LogObject
        $Array = @()
        ForEach ($Object in $HostData ) {
            If ($Null -ne $Array[0]) {
                If ($True -eq $Array.Identifier.Contains($Object.Data)) {
                    $Position = $Array.Identifier.IndexOf($($Object.data))
                    $Array[$Position].Count ++
                    $Array[$Position].Hosts += ",$($Object.Name)"
                }
                Else {
                    $Array += [PSCustomObject]@{"Identifier"=$($Object.Data);"Count"=1;"Hosts"=$($Object.Name)}
                }
            }
            Else {
                $Array += [PSCustomObject]@{"Identifier"=$($Object.Data);"Count"=1;"Hosts"=$($Object.Name)}
            }
        }
        Write-Log -LogString "Returning Results" -LogLevel Verbose -LogObject $Panorama_LogObject
        Return $Array
    }
}