<#
.SYNOPSIS
A command which can be used to modifiy an existing Host Object and it's properties.

.DESCRIPTION
A command which can be used to modifiy an existing Host Object and it's properties.

.PARAMETER HostName
The name of the Host Object in which you are looking to modify properties for.

.PARAMETER IPAddress
Opational Parameter for settings the IPAddress of the host object.

.PARAMETER IPRange
Opational Parameter for settings the IPRange of the host object.

.PARAMETER FQDN
Opational Parameter for settings the FQDN of the host object.

.PARAMETER Tags
Opational Parameter for settings tag(s) on the host object.

.PARAMETER Description
Opational Parameter for settings the description of the host object.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Set-PanoramaHost -Hostname "HOSTNAME" -IPAddress 10.151.121.27 -Tags QA -Description "Something here"

.EXAMPLE
Set-PanoramaHost -Hostname "HOSTNAME" -IPAddress 10.151.121.28 -Tags PROD -Description "This is an AzureAD server."

.NOTES
General notes
#>

Function Set-PanoramaHost {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantNetMask')]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [Alias('Name')]
        [String[]]$HostName
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByNetMask')]
        [ValidateNotNullOrEmpty()]
        [Alias('IP', 'ip-netmask')]
        [String[]]$IPAddress
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByIPRange')]
        [ValidateNotNullOrEmpty()]
        [Alias('Range')]
        [String[]]$IPRange
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByFQDN')]
        [ValidateNotNullOrEmpty()]
        [String[]]$FQDN
        ,
        [Parameter(Mandatory = $False, ValueFromPipeLineByPropertyName = $True)]
        [Array]$Tags = $Null
        ,
        [Parameter(ValueFromPipeLineByPropertyName = $True)]
        [String[]]$Description = $Null
        ,
        [String[]]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String[]]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $ReturnObject = @()
    }
    Process {
        ForEach ($HostObject in $HostName) {
            $TagArray = @()
            $BooleanHostCheck = $False
            $RunningHostCheck = [Boolean]$(Get-PanoramaHost -HostName $HostObject)
            $CandidateHostCheck = [Boolean]$(Get-PanoramaHost -HostName $HostObject -CandidateConfig)
            If (   ($True -eq $RunningHostCheck) -or ($True -eq $CandidateHostCheck)   ) {
                $BooleanHostCheck = $True
            }
            If ([Boolean]$($BooleanHostCheck) -eq $False) {
                Write-Log -LogString "No host by the name of `"$($HostObject)`" exists within the running or candidate config." -LogLevel Warning -LogObject $Panorama_LogObject
            }
            Else {
                Switch ($PSCmdlet.ParameterSetName) {
                    'ByNetMask' {
                        $Type = "ip-netmask"
                        $Identifier = $IPAddress
                    }
                    'ByIPRange' {
                        $Type = "ip-range"
                        $Identifier = $IPRange
                    }
                    'ByFQDN' {
                        $Type = "fqdn"
                        $Identifier = $FQDN
                    }
                }
                Try {
                    Write-Log -LogString "Updating Host: `"$($HostObject)`" Identifier: `"$($Identifier)`" Description: `"$($Description)`" Tags: `"$($Tags)`"" -LogLevel Verbose -LogObject $Panorama_LogObject
                    If (   [String]::IsNullOrEmpty($($Description)) -eq $True   ) {
                        $UpdateHostObjectCmd = "?&type=config&action=set&xpath=/config/shared/address/entry[@name='$($HostObject)']&element=<$Type>$($Identifier)</$Type>"
                    }
                    Else {
                        $UpdateHostObjectCmd = "?&type=config&action=set&xpath=/config/shared/address/entry[@name='$($HostObject)']&element=<$Type>$($Identifier)</$Type><description>$($Description)</description>"
                    }
                    #Currently an issue removing previously attached tags on an object.
                    If ($Null -ne $($Tags)) {
                        ForEach ($Tag in $Tags) {
                            Write-Log -LogString "Updating Object's Tag information..." -LogLevel Verbose -LogObject $Panorama_LogObject
                            $UpdateHostObjectCmd = $UpdateHostObjectCmd + "<tag><member>$($Tag)</member></tag>"
                            $TagArray += $Tag
                        }
                    }
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($UpdateHostObjectCmd)&key=$($APIKey)" -Method Get).response.msg
                    If ($True -eq $cmdResults.line) {
                        $cmdResults = $( -join $cmdResults.line.'#cdata-section')
                    }
                    $ResultObject = @()
                    $ResultObject += [PSCustomObject]@{'HostName' = $HostObject; 'IPAddress' = $($Identifier); Tags = $( -join "$TagArray"); 'ResultMsg' = $cmdResults }
                    $ReturnObject += $ResultObject
                }
                Catch {
                    Write-Log -LogString "There was an issue creating the host object. `n $_" -LogLevel Error -LogObject $Panorama_LogObject
                }
            }
        }
    }
    End {
        $ReturnObject | % {
            Write-Log -LogString $_ -LogLevel Debug -LogObject $Panorama_LogObject
        }
        Return $($ReturnObject | Format-Table -AutoSize)
    }
}