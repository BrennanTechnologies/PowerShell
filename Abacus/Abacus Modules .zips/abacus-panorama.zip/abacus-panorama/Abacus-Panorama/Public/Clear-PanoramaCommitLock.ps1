<#
.SYNOPSIS
A command to clear the Panorama Commit lock if one is present.

.DESCRIPTION
A command to clear the Panorama Commit lock if one is present.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Clear-PanoramaCommitLock

.NOTES
General notes
#>

Function Clear-PanoramaCommitLock {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Command = "$($APIUrl)?type=op&cmd=<request><commit-lock><remove></remove></commit-lock></request>&key=$($APIKey)"
        $Results = (Invoke-RestMethod -Uri $Command -Method Get).Response.Result
        Return $Results
    }
}