<#
.SYNOPSIS
A command to see if there is an active connection to a Panorama device.

.DESCRIPTION
A command to see if there is an active connection to a Panorama device.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Test-PanoramaAPI

.NOTES
General notes
#>

Function Test-PanoramaAPI {
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Process {
        # Grab API Key
        Try {
            $Results = (Invoke-RestMethod -Uri "$($APIUrl)?type=config&action=get&xpath=/config/predefined/motd&key=$($APIKey)" -Method GET -ErrorAction Stop).Response
            If ($Null -ne $Results) {
                Return $True
            }
            Else {
                Return $False
            }
        }
        Catch {
            Write-Log -LogString "Currently not connected to the panorama server." -LogLevel Warning -LogObject $Panorama_LogObject
            Return $False
        }
    }
}