<#
.SYNOPSIS
A command used to Get information on a Commit lock if one is present.

.DESCRIPTION
A command used to Get information on a Commit lock if one is present.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaCommitLock

.NOTES
General notes
#>

Function Get-PanoramaCommitLock {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Command = "$($APIUrl)?type=op&cmd=<show><commit-locks/></show>&key=$($APIKey)"
        $Results = (Invoke-RestMethod -Uri $Command -Method Get).Response.Result."Commit-Locks".Entry
        Return $Results
    }
}
