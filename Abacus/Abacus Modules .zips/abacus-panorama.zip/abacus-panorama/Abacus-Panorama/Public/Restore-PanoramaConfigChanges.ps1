﻿<#
.SYNOPSIS
A command used to revert [supported] changes made by the connecting user.

.DESCRIPTION
A command used to revert [supported] changes made by the connecting user.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIUserName
The username to use for the API connection. The default is srv-panorama which is already configured. If used, credentials for this role-account will be obtained via Secret.

.EXAMPLE
Restore-PanoramaConfigChanges

.NOTES
General notes
#>

Function Restore-PanoramaConfigChanges {
    [CmdletBinding()]
    Param(
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
        ,
        [String]$APIUserName = $Global:PanoramaAPIUserName
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        $RevertConfigCmd = "?type=op&cmd=<revert><config><partial><admin><member>$($APIUserName)</member></admin></partial></config></revert>"
        $RevertConfigCmdResults = Invoke-RestMethod -Uri "$($APIUrl)$($RevertConfigCmd)&key=$($APIKey)" -Method Get
        If ($Null -eq $($RevertConfigCmdResults.response.result)) {
            Return $($RevertConfigCmdResults.response.msg.line.line)
        }
        Else {
            Return $($RevertConfigCmdResults.response.result)
        }
    }
}