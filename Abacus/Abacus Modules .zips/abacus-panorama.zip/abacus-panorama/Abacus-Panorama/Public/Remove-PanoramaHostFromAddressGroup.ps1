<#
.SYNOPSIS
A command used to remove a Host object from a specified AddressGroup.

.DESCRIPTION
A command used to remove a Host object from a specified AddressGroup.

.PARAMETER HostName
The host name of the object in question that you are looking to remove.

.PARAMETER AddressGroup
The name of the AddressGroup that you are looking to remove the host object from.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Remove-PanoramaHostFromAddressGroup -HostName "HOSTNAME" -AddressGroup "ADDRESSGROUP"

.NOTES
General notes
#>

Function Remove-PanoramaHostFromAddressGroup {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLine = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [String[]]$HostName
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLine = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [String[]]$AddressGroup
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $AddressError = $False
        $ReturnObject = @()
    }
    Process {
        ForEach ($HostObject in $HostName) {
            $AddressError = $False

            If ($AddressError -eq $False) {
                $AddressGroupCheck = [Boolean]$(Get-PanoramaAddressGroup -AddressGroup $($AddressGroup))
                If ([Boolean]$($AddressGroupCheck) -eq $False) {
                    Write-Log -LogString "No AddressGroup `"$($AddressGroup)`" exists within Panorama by this name" -LogLevel Error -LogObject $Panorama_LogObject
                    $AddressError = $True
                }
                Else {
                    $AddressGroupMembership = Get-PanoramaAddressGroup -AddressGroup $($AddressGroup) -Members
                }
            }
            If ($AddressError -eq $False) {
                Try {
                    Write-Log -LogString "Removing Host $($HostObject) from AddressGroup $($AddressGroup)" -LogLevel Verbose -LogObject $Panorama_LogObject
                    $RemoveHostToAdrGroupCmd = "?type=config&action=delete&xpath=/config/shared/address-group/entry[@name='$($AddressGroup)']/static/member[text()='$($HostObject)']"
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($RemoveHostToAdrGroupCmd)&key=$($APIKey)" -Method Get).Response.Msg
                    $ReturnObject += [PSCustomObject]@{'HostName' = $($HostObject); 'AddressGroup' = $($AddressGroup); 'ResultMsg' = $($cmdResults) }
                    #Return $ReturnObject | Format-Table -AutoSize
                }
                Catch {
                    Write-Log -LogString "There was an issue adding `"$($HostObject)`" to the `"$($AddressGroup)`" AddressGroup." -LogLevel TerminatingError -LogObject $Panorama_LogObject
                }
            }
        }
    }
    End {
        Return $ReturnObject | Format-Table -AutoSize
    }
}