<#
.SYNOPSIS
A command to get all [supported] pending changes on a Panorama device.

.DESCRIPTION
A command to get all [supported] pending changes on a Panorama device.

.PARAMETER ReturnAsJson
A switch which can be used to show the results in JSON format instead of a PSObject.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIUserName
The APIUserName for the device connection. If left default, this will be looked up from the environment variables.

.EXAMPLE
Get-PanoramaPendingChanges

.EXAMPLE
Get-PanoramaPendingChanges -ReturnAsJson

.NOTES
General notes
#>

Function Get-PanoramaPendingChanges {
    [CmdletBinding()]
    Param(
        [Switch]$ReturnAsJson = $False
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
        ,
        [String]$APIUserName = $Global:PanoramaAPIUserName
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $Command = "$($APIUrl)?type=op&cmd=<show><config><list><changes><partial><admin><member>$($APIUserName)</member></admin></partial></changes></list></config></show>&key=$($APIKey)"
        $ResultArray = @()
        $ReturnArray = @()
        $ResultNumber = 0
        $Results = (Invoke-RestMethod -Uri $Command -Method Get).Response.Result.Journal
    }
    Process {
        ForEach ($Result in $Results.entry) {
            $ResultObject = [PSCustomObject]@{'changeNumber' = $ResultNumber; 'owner' = $Result.owner; 'xpath' = $Result.xpath; 'action' = $Result.action; 'component-type' = $Result.'component-type' }
            $ResultArray += $ResultObject
            $ResultNumber++
        }
        ForEach ($Result in $ResultArray) {
            $xPath = $Result.xpath
            $Action = -split $Result.action.trim() | Sort-Object
            $ObjectType = [Regex]::Match(   $($Result.xpath), '(?<=shared/)(.*)(?=/entry)'   ).value
            $ObjectName = [Regex]::Match(   $($Result.xpath), "(?<=name=')(.*)(?='.*])"   ).value
            $Running = "$($APIUrl)?type=config&action=show&key=apikey&xpath=$($xPath)&element=element-value&key=$($APIKey)"
            $Candidate = "$($APIUrl)?type=config&action=get&key=apikey&xpath=$($xPath)&element=element-value&key=$($APIKey)"
            ForEach ($Act in $Action) {
                Switch ($ObjectType) {
                    'address' {
                        $After = (Invoke-RestMethod -Uri $Candidate -Method Get).response.result.entry
                        $Before = (Invoke-RestMethod -Uri $Running -Method Get).response.result.entry
                        $BeforeObject = @{Name = $Null; Description = $Null; IPAddress = $Null; IPRange = $Null; FQDN = $Null; Tags = $Null; }
                        $AfterObject = @{Name = $Null; Description = $Null; IPAddress = $Null; IPRange = $Null; FQDN = $Null; Tags = $Null; }
                        If ($Null -ne $Before) {
                            $Before | Get-Member -MemberType Property | % {
                                Switch ($_.Name) {
                                    'Name' {
                                        $BeforeObject.Name = $Before.name.ToString()
                                    }
                                    'description' {
                                        $BeforeObject.Description = $Before.Description.ToString()
                                    }
                                    'ip-netmask' {
                                        $BeforeObject.IPAddress = $Before.'ip-netmask'.ToString()
                                    }
                                    'ip-range' {
                                        $BeforeObject.IPRange = $Before.'ip-range'.ToString()
                                    }
                                    'fqdn' {
                                        $BeforeObject.FQDN = $Before.fqdn.ToString()
                                    }
                                    'tag' {
                                        $BeforeObject.Tags = -join "$($($Before.Tag.member) | %{$_.ToString()})"
                                    }
                                }
                            }
                        }
                        If ($Null -ne $After) {
                            $After | Get-Member -MemberType Property | % {
                                Switch ($_.Name) {
                                    'Name' {
                                        $AfterObject.Name = $After.name.ToString()
                                    }
                                    'description' {
                                        $AfterObject.Description = $After.Description.'#text'.ToString()
                                    }
                                    'ip-netmask' {
                                        $AfterObject.IPAddress = $After.'ip-netmask'.'#text'.ToString()
                                    }
                                    'ip-range' {
                                        $AfterObject.IPRange = $After.'ip-range'.'#text'.ToString()
                                    }
                                    'fqdn' {
                                        $AfterObject.FQDN = $After.fqdn.'#text'.ToString()
                                    }
                                    'tag' {
                                        $AfterObject.Tags = $( -join "$($($After.Tag.member.'#text') | %{$_.ToString()})")
                                    }
                                }
                            }
                        }
                        $ReturnArray += [PSCustomObject]@{Name = $ObjectName; Action = $Act; ObjectType = $ObjectType; Before = $BeforeObject; After = $AfterObject }
                    }
                    'address-group' {
                        If ($Act -eq 'CREATE') {
                            $After = (Invoke-RestMethod -Uri $Candidate -Method Get).response.result.entry.static.member | Select -ExpandProperty '#text' -ErrorAction SilentlyContinue
                            $ReturnArray += [PSCustomObject]@{ObjectType = $ObjectType; Name = $ObjectName; Before = $Null; After = $Null; Action = $Act }
                        }
                        If ($Act -eq 'DELETE') {
                            $Before = (Invoke-RestMethod -Uri $Running -Method Get).response.result.entry.static.member | Select -ExpandProperty '#text' -ErrorAction SilentlyContinue
                            $ReturnArray += [PSCustomObject]@{ObjectType = $ObjectType; Name = $ObjectName; Before = $Before; After = $Null; Action = $Act }
                        }
                        If ($Act -eq 'EDIT') {
                            $AfterObject = @()
                            $After = @()
                            $Before = (Invoke-RestMethod -Uri $Running -Method Get).response.result.entry.static.member
                            $AfterArray = (Invoke-RestMethod -Uri $Candidate -Method Get).response.result.entry.static.member
                            ForEach ($Item in $AfterArray) {
                                If ($True -eq $Item.'#text') {
                                    $After += $Item.'#text'
                                }
                                Else {
                                    $After += $Item
                                }
                            }
                            If ($Null -eq $Before) { $Before = @() }
                            If ($Null -eq $After) { $After = @() }
                            $Added = $(Compare-Object -ReferenceObject $Before -DifferenceObject $After) | ? { $_.SideIndicator -eq '=>' } | Select -ExpandProperty InputObject
                            $Removed = $(Compare-Object -ReferenceObject $Before -DifferenceObject $After) | ? { $_.SideIndicator -eq '<=' } | Select -ExpandProperty InputObject
                            $Added | % {
                                $AfterObject += [PSCustomObject]@{Name = $($_); Action = "Added" }
                            }
                            $Removed | % {
                                $AfterObject += [PSCustomObject]@{Name = $($_); Action = "Removed" }
                            }
                            If ($Before.count -eq 0) {
                                $Before = "Null"
                            }
                            ElseIf ($Before.count -gt 10) {
                                $Before = $($Before.Count)
                            }
                            ElseIf ($Before.count -le 10) {
                            }
                            $ReturnArray += [PSCustomObject]@{Name = $ObjectName; Action = $Act; ObjectType = $ObjectType; Before = $Before; After = $AfterObject }
                        }
                    }
                    Default {
                        Write-Log -LogString "Unhandled Exception: Object: `"$ObjectName`" - Type: `"$($Result.'component-type'.ToString())`" - xPath: `"$($Result.xpath.ToString())`"" -LogLevel Warning -LogObject $Panorama_LogObject
                    }
                }
            } # ForEach Action
        } # Results Array Loop
        If ($True -eq $ReturnAsJson) {
            Return $($ReturnArray | Sort -Property Action, Name | ConvertTo-Json -Depth 5)
        }
        Else {
            Return $($ReturnArray | Sort -Property Action, Name )
        }
    }
}