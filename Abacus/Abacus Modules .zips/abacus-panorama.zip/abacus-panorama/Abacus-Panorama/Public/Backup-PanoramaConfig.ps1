<#
.SYNOPSIS
This function can be used to backup the existing configuration of the Panorama Device.

.DESCRIPTION
This function can be used to backup the existing configuration of the Panorama Device. This also occurs by default whenever connecting to a Panorama device with the included connect functions in this module.

.PARAMETER FileName
The name of the backup configuration file you are going to export.

.PARAMETER ExportLocation
The relative path where we will be backing up the configuration file.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER PanoramaAPIInstance
The instance of the Panorama device you are connecting to, eg. Prod/QA. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Backup-PanoramaConfig -FileName "BackUp" -ExportLocation "C:\Backups"

.NOTES
General notes
#>

Function Backup-PanoramaConfig {
    Param(
        [String]$FileName
        ,
        [String]$ExportLocation = "\\service02.corp\dfs\SHARES\PSAuditLogs\Abacus-Panorama\ConfigBackups"
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
        ,
        [String]$PanoramaAPIInstance = $Global:PanoramaAPIInstance
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        If ($Null -ne $FileName) {
            Switch ($PanoramaAPIInstance) {
                'PROD' {
                    $FileName = "PROD-CFG$(Get-Date -format yyyyMMdd-hhmmss).xml"
                }
                'QA' {
                    $FileName = "QA-CFG$(Get-Date -format yyyyMMdd-hhmmss).xml"
                }
                Default {
                    Write-Log -LogString "Unhandled Exception with API instance..." -LogLevel TerminatingError -LogObject $Panorama_LogObject
                }
            }
        }
    }
    Process {
        $ExportCmd = "?type=export&category=configuration"
        Try {
            Invoke-RestMethod -Uri "$($APIUrl)$($ExportCmd)&key=$($APIKey)" -Method GET -OutFile "$ExportLocation\$FileName" -ErrorAction Stop
            Write-Log -LogString "Running Configuration file exported sucessfully." -LogLevel Output -LogObject $Panorama_LogObject
            Return $True
        }
        Catch {
            Write-Log -LogString "There was an issue exporting the running configuration file." -LogLevel TerminatingError -LogObject $Panorama_LogObject
            Return $False
        }
    }
}