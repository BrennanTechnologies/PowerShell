<#
.SYNOPSIS
A command used to clear connections to the Panraoam device.

.DESCRIPTION
A command used to clear connections to the Panraoam device.

.EXAMPLE
Disconnect-PanoramaAPI

.NOTES
General notes
#>

Function Disconnect-PanoramaAPI {
    Param(
    )
    Process {
        $Global:PanoramaAPIKey = $Null
        $Global:PanoramaAPIUrl = $Null
        $Global:PanoramaAPIUserName = $Null
        $Global:PanoramaAPIInstance = $Null
        Return "Connections Cleared"
    }
}