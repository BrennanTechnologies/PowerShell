<#
.SYNOPSIS
A command to locate a Panorama Host within Address Groups

.DESCRIPTION
A command to locate a Panorama Host within Address Groups

.PARAMETER HostName
The HostName you are looking to find.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Find-PanoramaHostInAddressGroup -HostName "TestHost"

.NOTES
General notes
#>

Function Find-PanoramaHostInAddressGroup {
    [CmdletBinding()]
    Param(
        [Alias('Name')]
        [Parameter(Mandatory = $True)]
        [String]$HostName
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }

        $ConfigAction = 'show'

        Try {
            $Groups = Get-PanoramaAddressGroup -APIUrl $APIUrl -APIKey $APIKey -Members
            $Matches = $Groups | ? { $_.static.member -eq ("$($HostName)") }
            $Results = [PSCustomObject]@{HostName = $HostName; AddressGroups = $Matches.name }
        }
        Catch {
            Write-Log -LogString "Could not query AddressGroups for the hostname..." -LogLevel Warning -LogObject $Panorama_LogObject
        }
    }
    Process {
        Return $Results
    }
}