<#
.SYNOPSIS
A command used to query Panorama logs.

.DESCRIPTION
A command used to queryvarious types of logs from a Panorama device.

.PARAMETER LogType
The type of log you want to query. As the log types differ in how the information is queried and displayed, currently only two types are supported.

.PARAMETER LogCount
The max amount of logs to display. There is a limit imposed by the API of 5000 log entries.

.PARAMETER QueryString
An optional query string that can be used as a filter.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
Get-PanoramaLog -LogType config

.EXAMPLE
Get-PanoramaLog -LogType config -LogCount 250

.NOTES
General notes
#>

Function Get-PanoramaLog {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [ValidateSet('config', 'system')]
        #[ValidateSet('auth', 'config', 'corr', 'corr-categ', 'corr-detail', 'data', 'external', 'gtp', 'hipmatch', 'iptag', 'sctp', 'system', 'threat', 'traffic', 'tunnel', 'url', 'userid', 'wildfire')]
        [String]$LogType
        ,
        [ValidateRange(1, 5000)]
        [Int]$LogCount = 50
        ,
        [String]$QueryString = $Null
        ,
        [String]$APIUrl = $Global:PanoramaAPIUrl
        ,
        [String]$APIKey = $Global:PanoramaAPIKey
    )
    Begin {
        $JobID = $Null
        $ReportString = "?type=log&log-type=$($LogType)&nlogs=$($LogCount)"
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        If (   [String]::IsNullOrEmpty($QueryString) -eq $False   ) {
            $Query = "&query=($($QueryString))"
        }
        Else {
            $Query = $Null
        }
        Try {
            If (   [String]::IsNullOrEmpty($Query) -eq $True   ) {
                $Results = Invoke-RestMethod -Uri "$($APIUrl)$($ReportString)&key=$($APIKey)" -Method GET
            }
            Else {
                $Results = Invoke-RestMethod -Uri "$($APIUrl)$($ReportString)$($Query)&key=$($APIKey)" -Method GET
            }
            If (   $Null -ne [Boolean]($Results.response.Result.Job)   ) {
                $JobID = $($Results.Response.Result.Job)
                Write-Log -LogString "A panorama Job ID was received: `"$JobId`"" -LogLevel Output
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
    }
    Process {
        If ($Null -ne $JobID) {
            $Results = Wait-PanoramaJob -JobId $JobId -TimeOutDuration 60 -JobType 'log'
            If (   $Null -ne $($Results.Response.Result.log.logs.entry)   ) {
                Return $($Results.Response.Result.log.logs.entry)
            }
            Else {
                Write-Log -LogString "No entries found, but response returned $($Results.Response.Status)" -LogLevel Output -LogObject $Panorama_LogObject
            }
        }
        Else {
            Write-Log -LogString "JobID was invalid, fetching failed." -LogLevel Warning -LogObject $Panorama_LogObject
        }
    }
}