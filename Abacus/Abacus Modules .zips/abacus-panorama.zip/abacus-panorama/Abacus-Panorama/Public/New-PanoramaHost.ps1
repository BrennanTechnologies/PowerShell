<#
.SYNOPSIS
A command for create new Host Objects on the Panorama device.

.DESCRIPTION
A command for create new Host Objects on the Panorama device.

.PARAMETER HostName
The desired HostName for the new object you are creating.

.PARAMETER IPAddress
The desired IPAddress for the new object you are creating. *If Selected, IPRange and FQDN cannot be used.

.PARAMETER IPRange
The desired IPRange for the new object you are creating.  *If Selected, IPRange and IPAddress cannot be used.

.PARAMETER FQDN
The desired FQDN for the new object you are creating.  *If Selected, IPRange and IPAddress cannot be used.

.PARAMETER AddressGroup
An optional parameter to add the newly created object into an AddressGroup after creation.

.PARAMETER Tags
An optional parameter to include tags to the host object.

.PARAMETER Description
An optional parameter to include a description to the host object.

.PARAMETER APIUrl
The Panorama Uri of the device you are connecting to. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.PARAMETER APIKey
The Secret Panorama APIKey used as credentials. If you use the default connect commands included in the module, this parameter will be lookedup from the environment variables.

.EXAMPLE
New-Panoramahost -HostName "NEWHOSTNAME" -IPAddress 10.121.151.5

.EXAMPLE
New-Panoramahost -HostName "NEWHOSTNAME" -IPAddress 10.121.151.5 -Tags QA

.EXAMPLE
New-Panoramahost -HostName "NEWHOSTNAME" -IPAddress 10.121.151.5 -AddressGroup "SOMEADDRESSGROUP"

.EXAMPLE
New-Panoramahost -HostName "NEWHOSTNAME" -FQDN "NEWHOSTNAME.TESTGRP.CORP" -AddressGroup "SOMEADDRESSGROUP"

.NOTES
General notes
#>

Function New-PanoramaHost {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantNetMask')]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True)]
        [ValidateNotNullOrEmpty()]
        [Alias('Name')]
        [String[]]$HostName
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByNetMask')]
        [ValidateNotNullOrEmpty()]
        [Alias('IP', 'ip-netmask')]
        [String[]]$IPAddress
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByIPRange')]
        [ValidateNotNullOrEmpty()]
        [Alias('Range')]
        [String[]]$IPRange
        ,
        [Parameter(Mandatory = $True, ValueFromPipeLineByPropertyName = $True, ParameterSetName = 'ByFQDN')]
        [ValidateNotNullOrEmpty()]
        [String[]]$FQDN
        ,
        [Parameter(Mandatory = $False, ValueFromPipeLineByPropertyName = $True)]
        [String[]]$AddressGroup = $Null
        ,
        [Parameter(Mandatory = $False, ValueFromPipeLineByPropertyName = $True)]
        [Array]$Tags = $Null
        ,
        [Parameter(ValueFromPipeLineByPropertyName = $True)]
        [String[]]$Description = $Null
        ,
        [String[]]$APIUrl = $Global:PanoramaAPIUrl

        ,
        [String[]]$APIKey = $Global:PanoramaAPIKey

    )
    Begin {
        If ($(Test-PanoramaAPI) -eq $False) {
            Write-Log -LogString "No active session established to Panorama" -LogLevel TerminatingError -LogObject $Panorama_LogObject
        }
        $ReturnObject = @()
    }
    Process {
        ForEach ($HostObject in $HostName) {
            $TagArray = @()
            $ExistingHostCheck = [Boolean]$(Get-PanoramaHost -HostName $HostObject)
            If ([Boolean]$($ExistingHostCheck) -eq $True) {
                Write-Log -LogString "A host already exists by this name `"$($HostObject)`"" -LogLevel Warning -LogObject $Panorama_LogObject
            }
            Else {
                Switch ($PSCmdlet.ParameterSetName) {
                    'ByNetMask' {
                        $Type = "ip-netmask"
                        $Identifier = $IPAddress
                    }
                    'ByIPRange' {
                        $Type = "ip-range"
                        $Identifier = $IPRange
                    }
                    'ByFQDN' {
                        $Type = "fqdn"
                        $Identifier = $FQDN
                    }
                }
                Try {
                    Write-Log -LogString "Creating Host: `"$($HostObject)`" Identifier: `"$($Identifier)`" Description: `"$($Description)`" Tags: `"$($Tags)`"" -LogLevel Verbose -LogObject $Panorama_LogObject
                    If (   [String]::IsNullOrEmpty($($Description)) -eq $True   ) {
                        $CreateHostObjectCmd = "?&type=config&action=set&xpath=/config/shared/address/entry[@name='$($HostObject)']&element=<$Type>$($Identifier)</$Type>"
                    }
                    Else {
                        $CreateHostObjectCmd = "?&type=config&action=set&xpath=/config/shared/address/entry[@name='$($HostObject)']&element=<$Type>$($Identifier)</$Type><description>$($Description)</description>"
                    }
                    If ($Null -ne $($Tags)) {
                        ForEach ($Tag in $Tags) {
                            $CreateHostObjectCmd = $CreateHostObjectCmd + "<tag><member>$($Tag)</member></tag>"
                            $TagArray += $Tag
                        }
                    }
                    $cmdResults = (Invoke-RestMethod -Uri "$($APIUrl)$($CreateHostObjectCmd)&key=$($APIKey)" -Method Get).response.msg
                    If ($True -eq $cmdResults.line) {
                        $cmdResults = $( -join $cmdResults.line.'#cdata-section')
                    }
                    If (   $False -eq [String]::IsNullOrEmpty($($AddressGroup))   ) {
                        ForEach ( $Group in $($AddressGroup -split ',').trim() ) {
                            Try {
                                Write-Log -LogString "Attempting to add host `'$($HostObject)`' to AddressGroup `'$($Group)`'" -LogLevel Verbose -LogObject $Panorama_LogObject
                                Add-PanoramaHostToAddressGroup -HostName $($HostObject) -AddressGroup $($Group) -ErrorAction Stop | Out-Null
                            }
                            Catch {
                                Write-Log -LogString "There was an issue adding host `'$($HostObject)`' to AddressGroup `"$($Group)`"" -LogLevel Warning -LogObject $Panorama_LogObject
                            }
                        }
                    }
                    $ResultObject = @()
                    $ResultObject += [PSCustomObject]@{'HostName' = $HostObject; 'IPAddress' = $($Identifier); AddressGroup = $($AddressGroup); Tags = $( -join "$TagArray"); 'ResultMsg' = $cmdResults }
                    $ReturnObject += $ResultObject
                }
                Catch {
                    Write-Log -LogString "There was an issue creating the host object. `n $_" -LogLevel Error -LogObject $Panorama_LogObject
                }
            }
        }
    }
    End {
        $ReturnObject | % {
            Write-Log -LogString $_ -LogLevel Debug -LogObject $Panorama_LogObject
        }
        Return $($ReturnObject | Format-Table -AutoSize)
    }
}