Describe 'Add-O365DistributionListMember' {
    Sleep 230
    It 'Adds a member to an O365 distributiongroup.' {
        $Results = Add-O365DistributionListMember -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' `
                                                    -EmailAddress 'BuildTestDL@ezevonage.com' `
                                                    -MemberName 'buildtestuser@ezevonage.onmicrosoft.com' `
                                                    -Office365Instance US 
        
        $Results.CompanyName        | Should -Be 'Eze Vonage (DEV)'
        $Results.TenantId           | Should -Be '488b4305-738f-4af7-a8a8-08cae817e0e5'
        $Results.Office365Instance  | Should -Be 'US'
        $Results.Status             | Should -Be '200'
    }
}