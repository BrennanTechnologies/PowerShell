Describe 'Remove-O365DistributionList.tests' {
    it 'It can remove a MailEnabledDistributionGroup' {
        $MailEnabledDistributionGroupResults = Remove-O365DistributionList -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' `
        -EmailAddress 'BuildTestDL@ezevonage.com' `
        -Office365Instance US 
        $MailEnabledDistributionGroupResults.Status | Should -Be '200'
    }

    it 'It can remove a Unified Group' {
        $UnifiedResults = Remove-O365DistributionList -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' `
                                -EmailAddress 'BuildTestDLUnified@ezevonage.onmicrosoft.com' `
                                -Office365Instance US 
        $UnifiedResults.Status | Should -Be '200'
    }
}