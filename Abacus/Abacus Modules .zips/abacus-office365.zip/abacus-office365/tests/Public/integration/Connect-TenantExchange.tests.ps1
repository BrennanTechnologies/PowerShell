Describe 'Connect-TenantExchange' {
    it 'Connects to an Office365 Exchange Environment.' {
        { Connect-TenantExchange -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' } | Should -Not -Throw
    }
}