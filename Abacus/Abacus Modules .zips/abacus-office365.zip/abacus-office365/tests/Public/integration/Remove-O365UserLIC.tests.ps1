Describe Remove-O365UserLIC {
    it 'Should remove an allocated E3 license from a user.' {
      { Remove-O365UserLic -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -UserPrincipalName 'buildtestuser@ezevonage.onmicrosoft.com' -LicenseType 'ENTERPRISEPACK' -Office365Instance US } | Should -Not -Throw
    }
}