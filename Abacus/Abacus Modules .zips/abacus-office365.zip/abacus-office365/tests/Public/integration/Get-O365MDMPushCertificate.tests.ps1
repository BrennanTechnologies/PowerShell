Describe 'Get-O365MDMPushCertificate' {
    It 'Can retrieve MDM Push Certificate information from a tenant.' {
        $Results = Get-O365MDMPushCertificate -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Office365Instance 'US'
        $Results.CompanyName                | Should -Be 'Eze Vonage (DEV)'
        $Results.TenantId                   | Should -Be '488b4305-738f-4af7-a8a8-08cae817e0e5'
        $Results.Office365Instance          | Should -Be 'US'
        $Results.Status                     | Should -Be '200'
        $Results.Data                       | Should -Not -Be $Null
        $Results.Data[0].id                 | Should -Not -Be $Null
        $Results.Data[0].expirationDateTime | Should -Not -Be $Null
    }
}