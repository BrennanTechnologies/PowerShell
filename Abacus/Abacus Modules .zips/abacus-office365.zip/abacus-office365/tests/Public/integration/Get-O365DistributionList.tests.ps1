Describe 'Get-O365DistributionList' {
    # US
    Start-O365MsolService -Office365Instance US
    $Tenant = Get-O365TenantInfo -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Office365Instance 'US'
    $EmailToCheck = 'BuildTestDL@ezevonage.com'
    Sleep 120
    $Results = Get-O365DistributionList -TenantId $($Tenant.TenantId) -EmailAddress $EmailToCheck -Office365Instance US
    
    It 'Company attribute should be present and expected.' {
        $Results.CompanyName | Should -Not -Be $Null
        $Results.CompanyName | Should -Be $($Tenant.CompanyName)
    }

    It 'TenantId attribute should be present and expected.' {
        $Results.TenantId | Should -Not -Be $Null
        $Results.TenantId | Should -Be $($Tenant.TenantId)
    }

    It 'O365 instance attribute should be present and expected.' {
        $Results.Office365Instance | Should -Not -Be $Null
        $Results.Office365Instance | Should -Be 'US'
    }

    It 'Status attribute should return a response of 200.' {
        $Results.Status | Should -Not -Be $Null
        $Results.Status  | Should -Be '200'
    }

    It 'Data should not be NULL' {
        $Results.Data | Should -Not -Be $Null
    }
}