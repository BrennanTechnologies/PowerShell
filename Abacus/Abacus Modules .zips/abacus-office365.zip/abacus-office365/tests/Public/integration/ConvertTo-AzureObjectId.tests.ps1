Describe 'ConvertTo-AzureObjectId' {
    $Secret   = $(Get-O365Credentials -SecretName 'ABAEXCHANGEAPP(US)' -SecretType MSAppID)
    $AppId    = $($Secret | Select -ExpandProperty AppId)
    $Password = $($Secret | Select -ExpandProperty Key)

    $ClientAdminSecret = (Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType EXCHRefreshToken -ErrorAction Stop)
    $EXCHRefreshToken = $ClientAdminSecret.Data.Value

    $Credentials  = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))
    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $EXCHRefreshToken -Credentials $Credentials -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Resource 'https://graph.microsoft.com/'

    $Headers = @{}
    $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
        
        
    it 'Can convert a User Object into an AzureObjectId' {
        $DirectoryObjectUser = ConvertTo-AzureObjectId -Object 'buildtestuser@ezevonage.onmicrosoft.com' -AccessTokenHeaders $Headers
        
        $DirectoryObjectUser.Object   | Should -Be 'buildtestuser@ezevonage.onmicrosoft.com'
        $DirectoryObjectUser.Resource | Should -Contain "https://graph.microsoft.com/v1.0/users`$filter=userPrincipalName eq 'buildtestuser@ezevonage.onmicrosoft.com'"
        $DirectoryObjectUser.Status   | Should -Be '200'
        $DirectoryObjectUser.Data     | Should -Not -Be $Null
    }
    
    it 'Can convert a Group Object into an AzureObjectId' {
        $DirectoryObjectGroup = ConvertTo-AzureObjectId -Object 'BuildTestDL@ezevonage.com' -AccessTokenHeaders $Headers

        $DirectoryObjectGroup.Object   | Should -Be 'BuildTestDL@ezevonage.com'
        $DirectoryObjectGroup.Resource | Should -Contain "https://graph.microsoft.com/v1.0/groups/?`$filter=mail eq 'BuildTestDL@ezevonage.com'"
        $DirectoryObjectGroup.Status   | Should -Be '200'
        $DirectoryObjectGroup.Data     | Should -Not -Be $Null
    }
}