Describe 'Get-AccessToken' {
    it 'Can fetch a Microsoft AccessToken' {
        $SecretUser = Get-O365Credentials -SecretName "srv-O365USProvisioner" -SecretType RefreshToken
        $SecretAppId = Get-O365Credentials -SecretName "srv-O365USProvisioner Microsoft AppId" -SecretType MSAppID
        $RefreshToken = $($SecretUser.Data.Value)
        $TenantId = $SecretUser.TenantId
        $AppId = $SecretAppId | Select -ExpandProperty AppId
        $AppKey = $SecretAppId | Select -ExpandProperty Key
        $Credentials = New-Object PSCredential -ArgumentList $AppId, $("$AppKey" | ConvertTo-SecureString -AsPlainText -Force)
        $Token = Get-AccessToken -AppId $AppId -RefreshToken $RefreshToken -Credentials $Credentials -TenantId $TenantId -Resource 'https://login.microsoftonline.com/'
        
        $Token.AccessToken     | Should -Not -Be $Null
        $Token.AccessTokenType | Should -Be 'Bearer'
        $Token.ExpiresOn       | Should -Not -Be $Null
        $Token.RefreshToken    | Should -Not -Be $Null
    }
}