Describe Get-O365LicenseType {
    it 'Returns values for FlexHybrid' {
        $FlexHybridResults = Get-O365LicenseType -AccountType 'FlexHybrid'
        $FlexHybridResults.FullName  | Should -Be  'Office 365 E3'
        $FlexHybridResults.Code      | Should -Be  'ENTERPRISEPACK'
        $FlexHybridResults.OfferId   | Should -Be  '796B6B5F-613C-4E24-A17C-EBA730D49C02'
    }

    it 'Returns values for EmailOnly' {
        $EmailOnlyResults = Get-O365LicenseType -AccountType 'EmailOnly'
        $EmailOnlyResults.FullName  | Should -Be  'Office 365 E1'
        $EmailOnlyResults.Code      | Should -Be  'STANDARDPACK'
        $EmailOnlyResults.OfferId   | Should -Be  '91FD106F-4B2C-4938-95AC-F54F74E9A239'
    }

    it 'Returns values for ServiceAccounts' {
        $ServiceAccountResults = Get-O365LicenseType -AccountType 'ServiceAccount'
        $ServiceAccountResults.FullName  | Should -Be  'Office 365 E1'
        $ServiceAccountResults.Code      | Should -Be  'STANDARDPACK'
        $ServiceAccountResults.OfferId   | Should -Be  '91FD106F-4B2C-4938-95AC-F54F74E9A239'
    }
}