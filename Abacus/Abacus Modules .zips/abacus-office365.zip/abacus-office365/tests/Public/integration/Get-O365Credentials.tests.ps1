Describe 'Get-O365Credentials' {
    it 'Can fetch Office365 Administrative Account Credential Objects.' {
        $CredentialObject = Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType 'O365Login'
        $CredentialObject.UserName | Should -Not -Be $Null
        $CredentialObject.Password | Should -Not -Be $Null
    }

    it 'Can fetch Office365 MSAppIds' {
        $CredentialObject = Get-O365Credentials -SecretName 'ABAEXCHANGEAPP(US)' -SecretType 'MSAppID'
        $CredentialObject.AppId | Should -Not -Be $Null
        $CredentialObject.Key   | Should -Not -Be $Null
    }

    it 'Can fetch Office365 RefreshTokens' {
        $CredentialObject = Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType 'RefreshToken'
        $CredentialObject.SecretName | Should -Not -Be $Null
        $CredentialObject.SecretId   | Should -Not -Be $Null
        $CredentialObject.SecretType | Should -Not -Be $Null
        $CredentialObject.Data       | Should -Not -Be $Null
        $CredentialObject.Data.Name  | Should -Be 'RefreshToken'
        $CredentialObject.Data.Value | Should -Not -Be $Null
    }

    it 'Can fetch Office365 MDMRefreshTokens' {
        $CredentialObject = Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType 'MDMRefreshToken'
        $CredentialObject.SecretName | Should -Not -Be $Null
        $CredentialObject.SecretId   | Should -Not -Be $Null
        $CredentialObject.SecretType | Should -Not -Be $Null
        $CredentialObject.Data       | Should -Not -Be $Null
        $CredentialObject.Data.Name  | Should -Be 'MDMRefreshToken'
        $CredentialObject.Data.Value | Should -Not -Be $Null
    }

    it 'Can fetch Office365 SPRefreshTokens' {
        $CredentialObject = Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType 'SPRefreshToken'
        $CredentialObject.SecretName | Should -Not -Be $Null
        $CredentialObject.SecretId   | Should -Not -Be $Null
        $CredentialObject.SecretType | Should -Not -Be $Null
        $CredentialObject.Data       | Should -Not -Be $Null
        $CredentialObject.Data.Name  | Should -Be 'SPRefreshToken'
        $CredentialObject.Data.Value | Should -Not -Be $Null
    }

    it 'Can fetch Office365 EXCHRefreshTokens' {
        $CredentialObject = Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType 'EXCHRefreshToken'
        $CredentialObject.SecretName | Should -Not -Be $Null
        $CredentialObject.SecretId   | Should -Not -Be $Null
        $CredentialObject.SecretType | Should -Not -Be $Null
        $CredentialObject.Data       | Should -Not -Be $Null
        $CredentialObject.Data.Name  | Should -Be 'EXCHRefreshToken'
        $CredentialObject.Data.Value | Should -Not -Be $Null
    }
}