Describe 'Get-O365TenantInfo.tests' {
    

    it 'Can get results by TenantId.' {
        $ResultsByTenantId = Get-O365TenantInfo -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Office365Instance US
        
        $ResultsByTenantId.TenantId    | Should -Be '488b4305-738f-4af7-a8a8-08cae817e0e5'
        $ResultsByTenantId.CompanyName | Should -Be 'Eze Vonage (DEV)'
        $ResultsByTenantId.DomainName  | Should -Contain 'ezevonage.onmicrosoft.com'
    }

    it 'Can get results by CompanyName' {
        $ResultsByCompanyName = Get-O365TenantInfo -CompanyName 'Eze Vonage (DEV)' -Office365Instance US

        $ResultsByCompanyName.TenantId    | Should -Be '488b4305-738f-4af7-a8a8-08cae817e0e5'
        $ResultsByCompanyName.CompanyName | Should -Be 'Eze Vonage (DEV)'
        $ResultsByCompanyName.DomainName  | Should -Contain 'ezevonage.onmicrosoft.com'
    }

    it 'Can get results by DomainName' {
        $ResultsByDomainName = Get-O365TenantInfo -DomainName 'ezevonage.onmicrosoft.com' -Office365Instance US

        $ResultsByDomainName.TenantId    | Should -Be '488b4305-738f-4af7-a8a8-08cae817e0e5'
        $ResultsByDomainName.CompanyName | Should -Be 'Eze Vonage (DEV)'
        $ResultsByDomainName.DomainName  | Should -Contain 'ezevonage.onmicrosoft.com'
    }
}