﻿Describe "Add-O365TenantLIC" {
    
    It "Can add a single license to a Tenant" {
        $ExistingLicQuantity = Get-O365TenantLIC -TenantId 488b4305-738f-4af7-a8a8-08cae817e0e5 -OnlyActive -Office365Instance US | ?{$_.OfferId -eq '796B6B5F-613C-4E24-A17C-EBA730D49C02'} | Select -Expand Quantity
        $ExistingLicQuantity | Should -BeGreaterOrEqual 1

        $OneLicResults = Add-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Quantity 1 -LICOfferId '796B6B5F-613C-4E24-A17C-EBA730D49C02' -Office365Instance US
        $OneLicResults | Should -Not -Be $Null
        $OneLicResults.UnitType | Should -Be 'Licenses'
        $OneLicResults.FriendlyName | Should -Be 'Office 365 Enterprise E3'
        $OneLicResults.OfferName | Should -Be 'Office 365 E3'
        $OneLicResults.Quantity | Should -BeExactly $($ExistingLicQuantity+1)
    }
    

    It "Can add more than one license to a Tenant" {
        $ExistingLicQuantity = Get-O365TenantLIC -TenantId 488b4305-738f-4af7-a8a8-08cae817e0e5 -OnlyActive -Office365Instance US | ?{$_.OfferId -eq '796B6B5F-613C-4E24-A17C-EBA730D49C02'} | Select -Expand Quantity
        $ExistingLicQuantity | Should -BeGreaterOrEqual 1

        $TwoLicResults = Add-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Quantity 2 -LICOfferId '796B6B5F-613C-4E24-A17C-EBA730D49C02' -Office365Instance US
        $TwoLicResults | Should -Not -Be $Null
        $TwoLicResults.UnitType | Should -Be 'Licenses'
        $TwoLicResults.FriendlyName | Should -Be 'Office 365 Enterprise E3'
        $TwoLicResults.OfferName | Should -Be 'Office 365 E3'
        $TwoLicResults.Quantity | Should -BeExactly $($ExistingLicQuantity+2)
    }
}
