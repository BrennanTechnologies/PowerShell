Describe 'New-O365DistributionList' {
    it 'It can create a MailEnabledDistributionGroup' {
        $MailEnabledDistributionGroupResults = New-O365DistributionList -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' `
                                -PrimarySmtpAddress 'BuildTestDL@ezevonage.com' `
                                -mailNickname BuildTestDL `
                                -DisplayName BuildTestDL `
                                -GroupType MailEnabledDistributionGroup `
                                -Owners 'admin@ezevonage.onmicrosoft.com' `
                                -Office365Instance US 
        $MailEnabledDistributionGroupResults.Status | Should -Be '200'
    }

    it 'It can create a Unified Group' {
        $UnifiedResults = New-O365DistributionList -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' `
                                -PrimarySmtpAddress 'BuildTestDLUnified@ezevonage.onmicrosoft.com' `
                                -mailNickname BuildTestDLUnified `
                                -DisplayName BuildTestDLUnified `
                                -GroupType Unified `
                                -Owners 'admin@ezevonage.onmicrosoft.com' `
                                -Office365Instance US 
        $UnifiedResults.Status | Should -Be '200'
    }
}