Describe 'Test-O365MsolService' {   
    it 'Throws error when not conneted to Office365' {
        { Test-O365MsolService -Office365Instance UK } | Should -Throw
    }

    it 'Returns TRUE when conneted to Office365' {
        { Test-O365MsolService -Office365Instance US -ConnectToPartnerCenter  } | Should -Be $True
    }
}