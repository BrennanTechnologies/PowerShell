Describe 'Disconnect-TenantExchange' {
    it 'Disconnects from an Office365 Exchange Environment.' {
        { Disconnect-TenantExchange } | Should -Not -Throw
    }
}