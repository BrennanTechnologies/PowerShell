Describe 'Start-O365MsolService' {
    it 'Can connect to Office365' {
        { Start-O365MsolService -Office365Instance US } | Should -Not -Throw
    }

    it 'Can connect to Office365 and PartnerCenter' {
        { Start-O365MsolService -Office365Instance US -ConnectToPartnerCenter } | Should -Not -Throw
    }
}