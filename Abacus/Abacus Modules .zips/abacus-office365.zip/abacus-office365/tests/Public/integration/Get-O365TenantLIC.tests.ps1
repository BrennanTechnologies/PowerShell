Describe 'Get-O365TenantLIC' {
    
    Start-O365MsolService -Office365Instance US -ConnectToPartnerCenter

    It 'Can get Tenant LIC information - OnlyActive & Summary' {
        { Get-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -OnlyActive -Summary -Office365Instance US } | Should -Not -Throw
    }

    It 'Can get Tenant LIC information - Sumamry Only' {
        { Get-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Summary -Office365Instance US } | Should -Not -Throw
    }

    It 'Can get Tenant LIC information - OnlyActive Only' {
        { Get-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -OnlyActive -Office365Instance US } | Should -Not -Throw
    }

    It 'Can get Tenant LIC information - No Switches' {
        { Get-O365TenantLIC -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Office365Instance US} | Should -Not -Throw
    }
}