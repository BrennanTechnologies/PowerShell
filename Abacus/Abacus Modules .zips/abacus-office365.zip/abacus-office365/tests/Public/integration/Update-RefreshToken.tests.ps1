Describe 'Update-RefreshToken' {

    It 'Can update a Microsoft MDMRefreshToken' {
        $ClientAdminSecret = (Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType MDMRefreshToken -ErrorAction Stop)    
        $MDMRefreshToken = $ClientAdminSecret.Data.Value
    
        $Secret   = $(Get-O365Credentials -SecretName 'ABAMDMAPP(US)' -SecretType MSAppID)
        $AppId    = $($Secret | Select -ExpandProperty AppId)
        $Password = $($Secret | Select -ExpandProperty Key)
        $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))
    
        $Headers = @{}
        $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
    
        $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $MDMRefreshToken -Credentials $Credentials -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Resource 'https://graph.microsoft.com/'
        {  Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken) } | Should -Not -Throw
    }

    It 'Can update a Microsoft SPRefreshToken Token' {
        $ClientAdminSecret = (Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType SPRefreshToken -ErrorAction Stop)    
        $SPRefreshToken = $ClientAdminSecret.Data.Value
    
        $Secret   = $(Get-O365Credentials -SecretName 'ABASHAREPOINTAPP(US)' -SecretType MSAppID)
        $AppId    = $($Secret | Select -ExpandProperty AppId)
        $Password = $($Secret | Select -ExpandProperty Key)
        $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))
    
        $Headers = @{}
        $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
    
        $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $SPRefreshToken -Credentials $Credentials -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Resource 'https://graph.microsoft.com/'
        { Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken) } | Should -Not -Throw
    }

    It 'Can update a Microsoft EXCHRefreshToken' {
        $ClientAdminSecret = (Get-O365Credentials -SecretName 'Eze Vonage (DEV)' -SecretType EXCHRefreshToken -ErrorAction Stop)    
        $EXCHRefreshToken = $ClientAdminSecret.Data.Value
    
        $Secret   = $(Get-O365Credentials -SecretName 'ABAEXCHANGEAPP(US)' -SecretType MSAppID)
        $AppId    = $($Secret | Select -ExpandProperty AppId)
        $Password = $($Secret | Select -ExpandProperty Key)
        $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))
    
        $Headers = @{}
        $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
    
        $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $EXCHRefreshToken -Credentials $Credentials -TenantId '488b4305-738f-4af7-a8a8-08cae817e0e5' -Resource 'https://graph.microsoft.com/'
        { Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken) } | Should -Not -Throw
    }
}