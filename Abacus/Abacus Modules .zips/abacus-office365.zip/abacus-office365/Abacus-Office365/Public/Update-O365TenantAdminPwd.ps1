<#
.SYNOPSIS
A command that can be used to change an O365 admin password...

.DESCRIPTION
A command that can be used to change an O365 admin password along with running the dependent applications to regenerate a new access token for each.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER CompanyName
If TenantId is not supplied, the company name can be supplied to locate which tenant this account lives under.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER NewPassword
The desired new password to bet set.

.EXAMPLE
Update-O365TenantAdminPwd -TenantId <TenantId> -Office365Instance US

.NOTES
Please be sure to update all access tokens if changing the admin account password.
#>

Function Update-O365TenantAdminPwd {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantId')]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByTenantId')]
        [String]$TenantId = $Null
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByCompanyName')]
        [String]$CompanyName = $Null
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory = $True)]
        [String]$Office365Instance
        ,
        [Parameter(Mandatory = $False)]
        [String]$NewPassword = $(New-SecurePassword -PasswordLength 12)
    )
    Begin {
        $SecretObjectUpdateArray = @{ }

        If (   $($Host.Name) -eq 'Windows PowerShell ISE Host' -or $($Host.Name) -like '*ISE*'   ) {
            Write-Log -LogString "This command can not be run from an ISE shell due to Microsoft O365 dependencies which will crash if run through ISE. Please run this from a standalone PowerShell window." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        Switch ($PSCmdlet.ParameterSetName) {
            'ByTenantId' {
                $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
                $CompanyName = $TenantInfo.CompanyName
            }
            'ByCompanyName' {
                $TenantInfo = Get-O365TenantInfo -CompanyName $CompanyName -Office365Instance $Office365Instance
                $CompanyName = $TenantInfo.CompanyName
            }
            Default {
                Write-Log -Logstring "No valid identifier supplied. Unhandled Exception" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        #Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }

        Write-Log -LogString "Performing a lookup for SecretObject matching company {$($CompanyName)}." -LogLevel Output -LogObject $O365_global_logobject
        $SecretObject = Get-O365credentials -SecretName $($CompanyName) -SecretType O365Login -ReturnSecretObject
        If ($Null -eq $SecretObject) {
            Write-Log -LogString "Could not locate a SecretObject for company {$($CompanyName)}." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            Write-Log -LogString "Enumerating attributes on SecretObject {$($SecretObject.SecretName)} with id {$($SecretObject.SecretId)}" -LogLevel Output -LogObject $O365_global_logobject
            $SecretObjectAttributes = $SecretObject | Get-SecretAttributes
        }
    }
    Process {
        [String]$AdminUserName = $($SecretObjectAttributes | ? { $_.FieldName -eq 'UserName' } | select -Expand Value)

        Try {
            If ($True -eq [String]::IsNullOrEmpty($AdminUserName)) {
                Write-Log -LogString "The AdminUserName returned from the SecretObject was empty." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
            Else {
                $ContinueToResetADPwd = $True
            }
        }
        Catch {
            $ContinueToResetADPwd = $False
            $TenantContainer.Status = "ERR"
            $TenantContainer.Data = "Error: The AdminUserName returned from the SecretObject was empty."
        }

        If ($True -eq $ContinueToResetADPwd) {
            # Reset AzureAD password
            Try {
                $Results = Set-MsolUserPassword -TenantId $TenantId -UserPrincipalName $AdminUserName -NewPassword $NewPassword -ForceChangePassword:$False -ErrorAction Stop
                $TenantContainer.Status = "200"
                $TenantContainer.Data = "Password was changed sucessfully."
                $ContinueToSecretPwd = $True
            }
            Catch {
                $ContinueToSecretPwd = $False
                $TenantContainer.Status = "ERR"
                $TenantContainer.Data = "$_"
                Write-Log -LogString "There was an error updating the Admin Account password for Company $($CompanyName).`n Exception: {$($_)}" -LogLevel Warning -LogObject $O365_global_logobject
            }
        }

        If ($True -eq $ContinueToSecretPwd) {
            # Update SecretSecret Password
            Try {
                $SecretObjectUpdateArray.Add('Password', $NewPassword)
                $SecretObject | Update-Secret -ArgumentList $SecretObjectUpdateArray -Confirm:$False -ErrorAction Stop
                $TenantContainer.Status = "200"
                $TenantContainer.Data = "Password was changed sucessfully."

                #Run the updates
                Write-Host -ForegroundColor Cyan "Please use the following information to update this accounts AccessTokens."

                Write-Host -ForegroundColor Magenta "$($AdminUserName)`n$($NewPassword)"
                Get-O365DistributionList -TenantId $($TenantId) -Office365Instance $Office365Instance -FirstRun -TestOnly | Out-Null

                Write-Host -ForegroundColor Magenta "$($AdminUserName)`n$($NewPassword)"
                Get-O365MDMPushCertificate -TenantId $($TenantId) -Office365Instance $Office365Instance -FirstRun -TestOnly | Out-Null

                Write-Host -ForegroundColor Magenta "$($AdminUserName)`n$($NewPassword)"
                Get-O365AuditLogLogins -TenantId $($TenantId) -Office365Instance $Office365Instance -FirstRun -TestOnly | Out-Null

                Write-Host -ForegroundColor Magenta "$($AdminUserName)`n$($NewPassword)"
                Get-O365SharePointSummary -TenantId $($TenantId) -Office365Instance $Office365Instance -FirstRun -TestOnly  | Out-Null
            }
            Catch {
                #Roll Back
                Write-Log -LogString "There was an issue updating the O365 Admin account password. Attempting rollback" -LogLevel Warning -LogObject $O365_global_logobject
                $Results = Set-MsolUserPassword -TenantId $TenantId -UserPrincipalName $AdminUserName -NewPassword $($SecretObjectAttributes | ?{$_.FieldName -eq 'Password'} | Select -Expand Value) -ForceChangePassword:$False -ErrorAction Stop
                $TenantContainer.Status = "ERR"
                $TenantContainer.Data = "Password change failed... Rolled back"
            }
        }
    }
    End {
        Return $TenantContainer
    }
}