<#
.SYNOPSIS
A command for creating the base Android OneDrive App.

.DESCRIPTION
A command for creating the base Android OneDrive App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365AndroidOneDriveApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365AndroidOneDriveApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{"@odata.type":"#microsoft.graph.androidStoreApp","appStoreUrl":"https://play.google.com/store/apps/details?id=com.microsoft.skydrive","categories":[{"displayName":"Productivity","id":"ed899483-3019-425e-a470-28e901b9790e"}],"description":"Microsoft OneDrive","developer":"","displayName":"Microsoft OneDrive","informationUrl":"https://play.google.com/store/apps/details?id=com.microsoft.skydrive","isFeatured":true,"roleScopeTagIds":[],"largeIcon":{"type":"image/pngapplication/octet-stream","value":"iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAIAAACyr5FlAAAAA3NCSVQICAjb4U/gAAAgAElEQVR4nO19eZQkR3nnF5EZedTd1cd0j0YazciaGaSHDtsrbK4H5gGWbGzewsLD7LK7BmzvAY9d49Uf9j4Wr1k/n7CPNXrgtdcYg7GxHzbgAzBYGJAF6AmEDkbHoHNGMyNNX9VdR2ZGfPtHVmVlxlGVVV3T0zPK3x/dVZFxfBHxi98XGRGZRRARChTQgV5oAwrsXRTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGBEQY4CRhTkKGCEfaEN2BPoCegEUbvHCemHUEoqHivbZGS6SxzPLXJEAtvdsNvjJ1c7Dz2+fu+p7T8+sWWf7bYisUWgCwCpl7I2EBoA3Sp7+VWVVx2qXLavcvSyasVnZZ+5zLpgddhFkOfCS2oR4LEzrQdOrD329PYXT2z+9f1bEHAoW+AQYBQsAJKhRSalQAgRegJ6AroIV3i/dkPj2P7yFVc0jh1sVN1LeXRdyuQQiM9u9r7y3TN/9U+nvt+K7lwPgQA4lNkkxQZM/siQAgkAYigQAoRAQMn6l1X7qiP1t77i4KGVmmNfgrO3S5Mc57aCR55Y+9OvnvzfX3oWahZULSAkpkQKZlpowlH6FiIAIgQIpwM46H/6dQevv3r+0EptVlXYC7jUyMER/+rOpz59+1Mff6IDFrE9SsDQ03nUQgpSriICEIgihFZ03aLzth+af8MtV++re9NXYC/h0iFHqxPecd+ZH//tB6BCoW4DJQzMna2G65sBTVcRso4JIEKAroATvVvftP+drz2yf6E8cR32GC4RctzxwNk//Pzjf3DvBp1jlml2OYFgyE5E+qoXk/gjgajFr6ra//Vly2/9qaOudRHPRS56cjy92v7w5x557z8/C4xYDqUwiVqMiKy9OpoWKUQCoS1eMc9+7WevuenYEr04l0suYnIgwF3Hn7npQ/dDwKFiG5wITOlHlAipdhqpK6kLUYhwKvi9f3PwZ26+ulF2TPH2LC5WcoRcfOAvj/+320+DS5lFAHYoGDvwI5rMhxc4ALb4q68s3fbz11109zIXJTlOr7Z/5sPf/ccTW9Bgo2ad2ktT3I/kiKZNEEMAiADhRO/237rxxdevWBePj7n4yPHQUxu/cNt3/3EzYi49j9OLiWmBowuNEKAVvf+nL3/X664xZbHXcJGR447vnX3Re78DKw6zyASrF5rwkf2NBuXJ4UeMkREiAHgm+MVXLr3v39/g2hfB7szFRI4v3H3qtX/4YMehTCPM5/N+ZFQL6QRDyTP5JwDEFv/FH51/39tu3Pv8uGjIcfu9Z17+29+FJmOyz96jfiT1NRMkAMRm9HM/OHfbu26iZE/PPy6OJZo77jvz8t+7H+adLDOw30PasavxI2i6ipgwA6dnhpQtapgBABTBqtofuXv9Vz/6nZALUwF7ARcBOZ482/rJ2x4AV/ImE92mjvQjJsHQZ46ACjOMtFDVCQCAAJCq9d4vnPmdP79fV8ZewV53K6fXOyu//A1g0F/MANj95c7UpVwTT30WShhHxCd6n/qla17/ssPmIi8k9rRydAL+Pz/5PSA4YMZM/UiOaMOsEGVmYDZ+/6tBLTK60s/NAoDL3Vs/9siDj57TlnrBsafJ8aHPPPihb67aLh028KR+RO2sEX5EC9WJqJFRG6qNmfluAXwf4Nh//9bmds9Q/IXE3iXH3Y888+4/fxIaFqDo95DW02uYkbqavjCcLeAYAiUXVD+Sc3qh2pbVnuSbxQggvv8T94q9598v/JwDATjHSGAvFKc2ws3tKAz45lZ421ee/txqUKOIQkQ84oKjEACQGCwf7Drft6kzUgs1bw4IG9GX3nXtj73goMmgC4ILRo5WT5xe7a2u9e452b37VPfDD/egFYFFwCJAACwCZWs5uXElQACE4JxzHgVRGHIehmEgUBAgRLq9zWLC3dQpVy+MeWabV2ns/nceYtMmD/z6i/Y199ARoQtAjhPPdP7p3s1vnmh/bS26b52DBWCTBZvYdNBW8uwi3RV9JgiBiJxHYae9GYY9QghRXOTO98w08U2CMR0tUoF8PfofN6+859/daLZvt7F75Hi2Fd73WOvlXzgHTwRQt8GBKiGlkYM+DjWNfAAAQighgovO9mYQdDiPEhnZy35EO7nmCLAa3v2+f3Hj0SWTlbuM3XjsotXjf/fNc5+6d+svnujRMl1aZjIhNQ2eUosR7BXIAQmAX2m4ohL1Otvbm0JwQqic8kLQwuREtPlbANy3Pnv749ccnnMZM5m7mzi/ytEO+Ffu33jjp8+2KAEblikxNZcaNIYZmrHXf7Sk19lub28gYl9F9qofUb9yQDgb3vMbP3zd0WWdubuN80iOe5/Yfv/nz/6/E91KzdLPskYLhj5CP1zfqwgAhBDKo6Db2ex2tgkhIN/UxHFz0sJgwWR+RCcYpplpV9xywP+b//Uyfbm7i/NCjiASf/a1Z97y1XVAWGZEU8LUfsREi/6f5OA5AQJh0NveXBWCy/cze8OP6KMR4A90HvrkS68+0NSUvruY/SLY6Y3eG/7vY2/5+9U5iyzbCjNQ2zQ5mIEjBQNJwgwEQEQUaDO3Mb9SKteBEEQBAOOXO9Fsh2S5tKCuWTBDXSopY5SjIcAh52N/+0jf4AuKGZPjwZPbr/v9J/76TLhctxxDO2SBwyv6CENaKFodL3kmtMBhPv0oiIheqVqrLzquL6JIm3PWFp0dqmGKYOgTjKUFSuEIgMDIN45vPnW2JVu765gZORDg68fXj73vsTt6uE91JXpapLpzoolnP3RICzDng4iU2pXaUq25TC02kBBtz+WjhW4VXE6gp93oWvW5YlHyhYc7Dxw/O9K/7gZmRo6/+/bqiz9+pnqA7VMXtXV+ZIR+J7F0OypJaEYttLuhybhEACG4xdxKY7FUngOBw5nWCHqOpIXiR3S0kIUBhgZJgZL41Kw/ueN0FIX6ifNuYTYT0r+/Z/Xmj5/x6lY9x6LW8Mo0agEgvz7B7Iz0VwjyqLO9EfbagPGK6zhagMaPjC8sp1pAlkwAACAA8Xj37GdfsThXhQt3lHAGyvHPD67f/KmzfmMsM3IIhs5ZD2NLs85UfH10ff6CUKtcXyjX5i3GUHCtAamQ3IJhzMRUq5SEZNoFKQDMWV+/97T2NnzXsFNyPH62/dpPngGPDh/mGu1HNEo7jKW7qPcj+kxSfkQxAVPMRBTcdv1yfcmvNBAHXmYkLZTzgWY/Ituko0u/UogCkQvkAjlHHmHEkXPkAirwtbvOAHC4cNiRW9loh43f/T4g7Bv9QGIOP6K7YvAjkzmj+JLOMgQAIIQKwbtb62F3O/6uSZJnUUtT9ig/glwAIHVdy3Ms17FLJeo4lNnEtgm1CCEA+Ew7AIu8et5+zX5nX9O5dp9brdgLdcezdklPpidHyMX7P3vq1m9v73PV54tijNwzS4WPnF5AhhJmJ6K5qKOSrroECPBet7O1xqNgsC/Tz8Fsm8aAMQYhAqKIOCHEW2o69RphjDoOoQQQcKAl6WQ9AVscgcdPzMFL5+2XLLIfvtK/6Vh1f+28779MT47Pfevsa/7i3FLdUvZLYHx3Di7pBaMfSqanBYxSC1M+hNLu1nrQaQkhCFEXdnWFmcRSoQVyQSxKXcfft+DUawikbw1K2RplSQCsCQAhgAN0xBuO+L/80sbV+8u+c76O801JjrV20HzPiXrd8mSFy45Wc4+aaZFPLUbkk1cwdPYSglHU297odbYJJWlj5MJyqQUCAnIOhHrzdWeuYZVLAASEUNOZaKHKLyJwgM0QoSV+6frSa2+svfDoeXl+fzpy4G/+5VO33tPe58prGheJH5GvZc0mAMDDXntrTUSBfms3x/QChSAIxKb+4rwzPwfU0lijVjL9EZWoCjtXQwQBb7vCec9r9h1outpaTo1pyHH3I+s/9PEzczZJvY5kZ34EADAzRnW9nMl8Fn4ka68UkxAA6G1vBu2WENFwIpLDjyDnQIhTK7tzc6xeJZQILjQJR/oRzTgz6FYI0AoQQvGnr5p7/QsX7Nmti0x82EcI8cd3roOAATN2Pr2YQC30JUzrR7Q6N9RuBKdUY26501oNe9uU0Ozuv9JniCgECvQWm/7iPHUYUIpCYKRVC22pkuXa6YtcIRuhyWDbpm/6/NqJ073/8OPLzfJsznBNrBz3PLp+w++eWl6xUdLk6f3IDqYpBoUxM2MULcBQF0IoD7qdrTUeDrxM1iAUAoDYvuM259z5JqEURWRc0ZcKGEELxRKdumSyWusKoOT7v3Dg0JKvlD0xJp3o4ie/ug7zVrxshEnvmHrUuJsK0nInoCEffSZxuByMuifTsvH7H5Ocs+XobEBAwSlzyvVFrzIXzzCTXJALDCNWrdR/4GDtqkPewjwgCh6h0PVruvxsfaX1Ntk8XeNguvqDj3MeBQKv+ujJ753c1rXCZJhIOfD4k61bPvr0OQAvO4vXxc3tR0ZKjv76TKcXRuVTExECArubz4bdDiJaDnPn6t7iPLHtZAV25MkmfZVG+RFtI+pntcO81jhCgN956/7rD1Y16XNjAnIg8o99+fS/vb215JlWvfI4EdB1V858ZkyLbBS5dE2vIqBAFMQtC3CBs5LtOIgcZBcrJcteyO9HVA0z5CPlBTE/InjsPx04uFiCaTGBW2ltB19+pAP2pD0ahxKNYEzgjDJ+YRhmciIwdDomfzEM19ib8QEIgAIwQhTgz3nLz28uPG9l4fBKY76EIkKB+upI3msKPyLVNCczEABhjhIg8M4/O31mY/qncPMrBx5/fO15Hzy91DC8rGhG9yP6i7snGPJYRoGCo1tmpabnL5RsxxrelxIihNje6HXaEaS2ZUb7Ec3qRTrCVH5Ekx8CAKx3xNsPuh95+0H9KetxyKUciAgg7jrRAabcRMcDXXtOrn+GD5JRbxSM7OhSLuUWDLUcrWBoR3mWUgiAAoMuZ569dKw5f3SuslKhFhGRSI4goRCEQLXhNhd9ahHB04qnr1JWLZRtaJXEyY5xNld57p3KJx0855PfP975zF3P6hprPHIphxBIaUh+/VEawkJCJ+NAj23Mt6gFwzbUhWtoYcRUt6lqQQIROTCPujW3ur9qe5aIRNKVwzTZfAglne1we6MX78toSlcFA+UAJb7Bj5iERGfhJkJN4Nd/dv81l088Oc2lHATw2Y0ebIh6ihkS6QdmZs5egGmkDuKCdnoB+jRmtVCYgXLDalQEZeMEQtATtmM1D9UWjjQbVzYsm4pAgEi3u/5YhxDolVhjwfdLTl9CUmZjxqxsndVGRP1tqpRX5lLGqMyXGoH1ED761VWEiY+zjycHIhKCT57tgkUoDGsnxUrRAmRh12QKoGmWfnmT+RGp6/PQYmgVxplzjkDAK9v7r1vcd+1iab5EHQu5QJFNrXOfyScUSC1aaXjNpbJlEWXRRVdnjWAoFUi3gq5smatKTesu+c1vbN/18IZc2DjknHPwB57uAQFLP9B1T46ArksG0UF7BZX6j6aFOo3Rtp5Ki0TREKNQWIw2ViqLx+YXjs3bvt138/IINx0PlEY2oECLkfpSqVJ3AYhILRZqdEuuqU4V1FbICkYmVDcGCAA0rA98cTUSysMZIzF+ER4RQYjWagSa1Y2kzjs7rDXRzUiqDH33j1EsBAREFAjMs+YPVZ2qQyyKgIJn7Buqhb4eqgZkUnhlmzlWe6vX2Q5J+pk7vVqouetKT7MQzNEU20oWfOLp8B0Pb/7I0bn8dy65dmi2uuHTLQ7q22H7tACluxSYaAETMkOlRB61SEIQORe2a/tVVtlXZmUnfjYu86RCxlkoSqZ+0g4KBESgFqnO+X7J2d7o9XqR9pW0U9+mpkpSM01/QABgAMDhS9/ZvPFwNf8j/GPcSqyx3UCc6+KAcNiv+ohHzSRDtcxAvc8Y60eGMq0qsy5wYC9GAQcCzYO1xaPNuUMN22diMKsYRkuMVezIFCq3fpazaQ/A0Wa0Nu/XGp4QmLz4K3Yi8uMzWj+SviTNbZU5kJxJar5tOeRX7ututiZYE8ujHBgE0XaY2kqawW3qpH5klFqMskGAEMKyqVOyq/urbs2N+0QIzCZOZz65HzFY1a8+AgK4Zbbgs/ZGt9OOENH4qqpJblP1MVO2pQ2rElhv45fv33jjS0o555pjyBGrruAiiuKnCHe+1qkJnsCJKKn1ZiAAYhShzUhtpeTP+azEAAG5UMrO2mvSeLnplZqoBmQrEa9blOc85kXtVi/ocUqzkziTE5GKmZwWg+wRfPKJb7ff+BKBSEiOM0E5JqSAnAshMovDY5mRkxaQgxmT0kIIJARsRhsHy96cTwgQIKi+yXEKWoCu9ibB0EUSAm3XqrmloB1trXcR4yfuTGXr7oQNMZPYhmZBAHBs+Mzj4bObvYWqn2damutuBfueeRwtQF8FKWnWYGOpmXJy0oIjtUi56ZYWfLfmAgDyeMNq5PpknllnqgpG3qRCVHGRbHZLNnPLnVbQafUgPYyTHCSLxwiGublSNjCAwIITJ9sLx7zhm4/MyOFWYg+NattoDM2pDLP1I4iAXBBK6iul0lKJMkoIQW6g8Uz8yGgnoo0rFYRAKPHrruPZW+udKBTDe5n804tB1marMjnZAEDJg6d7LzjKgYyfdowiRzyXRkRqgW0Tzdw4ZZO+u/MzQ9uS42ghOBJK3LJdXij58x4hRHABYtiiZsGYmBYmq3RqAWM0JlW45VqN5Wqv1eu0Ah4JeW93hB+RRqvOj2hSEVg/G4Sc2/b4G9o8dyuEUnCsURTWjc6JnIiSZjQtEDgXgFBZ9CtLvu0zQkl6uWIitdCXm6+PdRZqU6ZiSoECEdAtO8y1O61guxVQqn/0P2ubgRZqqUM/hQAABE9u8a0ur5d37FbibB2bLLhES8bZ+xFtzw0ChUACxHZpbaFcXioRSuKlbhSoN0ke1lraKMnGWjUVLWRapmebAgklfsN1yqy91g0DTiA1ZVRsG81mjZFJCkLOtUW3G9VLOHbakWdCCp5Nmp5sh44CmuA8tDAkzdRXcESAcsMtL/hO1SE2QYFpTujKTgfO/jZVTwttRcZpfpLQtmltsdTdDjqtQEQi03n5Zp3SJXW/JggxDENEhJ2TAwAIIZVaP2vVMI1xfbPMOar6bxCMWBgIJdVFr7pcIYz2PYh2HySb23g/MgNamFIOkxjbRR1jg8he2XF81lnvddshScWexo9ISQhwAYILRBx7LzueHIQQINYPzAMIENq74/PjR4RARPCrrNT0/KZHmSUiAQCZBe8xtJidH0mFzEowJFqkIQQAkFLTd8qsu9HrdUNCiRxzhB+RNmyyNcW4bfWeL4NR5EhpDlloEODIpQTT+pExtODIOVaaTm1/1fYsYlEUGDNDSqX2vLn5L6gfSQfJ9DUmRCEsh5bnfda2ttZ7gOlbGVPdDIKRrgUOlq7G/XTpGOXo84NYBxr2kVr3oYDOD98qPks/ghCf+gfHt/yGW1kuW8wSXCCmpAKUfsqGm/zITGmRTbJjP2JIOIiKAABu2XVKbnut0+uEKFCeJ2gFw1ARQLBtJLS/8adYn8H4lRBKKSEgwP5XBwVEfSPkOo56RACSBbRhg2abQQgMe8ItsYXDtYUjzdqBKqGER9kVb5RaLBPeD0T9WWf50yD2sCao5Jv6OjAb0ykVO/qKrW+XtJFqI0iH/LJR+14AsTTnV/vH31MNEX+UDiJrK9JvHGQWSb0cZBQ/cu3OUUoJZS+9UkCg32TXI9v4qt2IwDlSSsoN98D1C4vHmv6cT20iOGppAUp3ZJpRN72Q6ZjhgmH0Z4tLsQiUlLIl2ZAMl/W0kBNmo0rnvxAtZlUXK+X5EiHDk+Hm82OyqMSW7y9Bycl13me8WyGEUEoJtRZq9o/M8zvb1nz6dQRaZmhbPltPHqFXYeWm5815lmv170t13a+klgJRuawvdKxVmuJS//RMUjlpuk1VjVSrlKaF0Sp0y4y5Vnez190KIHleRq5puqCMSfUyuHaupw5ykSPmR71i//SB7p3fs4BOuWcWnz5BALdk1/dXWZkRiyD270tz0QKkZsy/3JmXFqmo2bi6KmcVzkwLJfmI7VaFbcp1AYQQv+G5JWdrtc3D7Jv/U2ohFYsAIGBlngDQ2WzZE0Isy7Isy3Xcay/vLD2EbUy/tkUqXM8MRBBcOD7zanZ1qWx5DFGggAnUApRmynObqg59NV8NLUwpUzFNgqERshF9j1LvjRkJ6awEUJvWlqu9raDb6opQXjFTrY4AQMDhJRLvuo0Vj1zkiJWDUvvIPnpdVfzDptWU5iojaCEgCoVbsppX1N2aYzErJko2Vjof9WNuWmh63ShjhpzHJRlxM6LPzZQwvx/JRpaKEOhWHOba3Va3uxlQqh4PGSJAAAsPzFEECoOeNcQFyEkOSqllWZZtu6738zds/sPny1DWjIX0v3iObTvUq7La/opTZsjl83n5BQMNX9Ry1aCxgmGMqxZkUgtQ+szoRJSoE6mFTpaQC6DgN3y34m6f244CQdSfVQUAABHCu49xhzFC6FhmQM7l85gctm1T2716H33lUvjFTdakQyanGwUReCSYazVWSm7DY74NCCISmr5Tvo9pJs3QU5JNSYtsEp3AGAVD7TCjYChRdYKhHwl6bzUcl4hILFJZrESdcHu9Gx9wkWsRwEsOcSSM0hkdE4SUeNi2XfL9t1y79cWv24Ji+lf24gkEtQjzrIX9NbfuAhBARC7flmarZ7iU04+kP2m9wWhawJASI5g0mhbGtNo9wWn9iGwXDuxQGtcusbrHOpvdYDtI77u2BLx6mR9o2pZlUzq7CSkAxMywbdtm7rWXbf/cSvCR06xpAcYeJELboeUFz5/3nIoD/T107bxb82UiPzJaMIwjGJRWVpVirB9JB+3Aj8jRJ/IjCS10BvcDCZTmfKfEuhvdsBv1JYTDKw/yWsWnlhWTYyw/8r68Jb5nsW2bMVby/dff0IE2CQXE28rNK6r7rpmvXV5zSg5yHJzczBhsGihy+PAUl7ziiOleTDffYO0yc1VXPCaUyC6NKnbEQi2FjFzu1CeUo6JunTR9ffhFLQViP4J6gyVjBdqOVV4olxfKiNgSeNjG669Ah7nWbMkRZ2RZFmPMcRzmeAfmvd+6qdXyncUjzctuXKosl6lFAPsHLOS+y1ht1slxy53yp2HHZnkzurixgnF+VsF1bEsXnhoWKF1KAkcKhoI4NvPtxmV18LzXXRUcXrIt26GUzsytxEhPO2zbDm3vRYe7b/bdL3HX5YMfxlKGa9bYUeGZoaNNp2lZBKmfdMVlc1A/ZhOpapHKRSt+uoQjVy/khkp91w8btaqTACEEAg33J58XIa3YtmVZVh7ZgIncCqU0diuu67quV6uU3rr41AGM2kimZIY0RHRnDDTMyDqFdD7a4lJSlNIYtSBpZKe/p0a1Wg2U/IjkCtPfZEnIqgumowzTp6o7DRDgDIcPXrm6UHcd17NtO3YredJO8MK4ND8YY8zxFivOOxtPPYoQAEkrotwc+mqnAzVPlmQ7MxUqBau0SBMREzLpMhzEG7XcOc6PgBTVlK3cCCOnFwiQbLROS4sYZ5DcUu794HLHcf1Y9ZM5x9i005DDGcByy9fORR+sPf2o9rUx6vBNfc/QAnXppGTqsFcjpDpArxQ6WkgjNc2M0bRIC8Soq3Lfpy6rtIC+6XoeT4gIIArpO64606j4jDmMMdu2c8oGTPoG44Qfbh+O61deuLD5G9XTxwUd8kMavtnw1KDX0ELTi9quVgUj/V+NqyQZTQvQuQNdwmxUHS2y1uVa19qJH0kgAE5z8oFDpw/MOczxHcdhjOWfcMB05IinpbF4MMaYV3vx3Pqvlk4fR5qWQY1gSKMne1HWA8wMezNvsoqdj0l6PzLITRYMfUIlqmHiqREibSkz8iMxCMApTv9Lc+NHVzq2W457KvYp+ckxzev1LcsCACEEIor+78rUbyGrjVX+zo3LrqLIVEGQ2ki+KH2SiaChRSZH+Z8+T03hkFELHZt1CZWoO14FV+zeEQjAk5y+vdF685FnXX8umQbEPuV8uRVIbdLGax6u6/ZZ6ddeOL/xwdqTJwRsYeqodJ7pRfqTogCa0Z8Zj/E/nc5IZU23eiEnnHB6kTAjpXCZzGbnR2LEzPjXle03X/kM8+qO6ybMiGVjgqwmeTH+EIjIOY+iqNfrdTqdTqfT7XbDMAw7rSda8Adrh/4mco8SQTKdl81B8ynTuZqr2a+qUugFBtSRrR/VWntGRB17KmeUYGAqgxnRAgAigNOcvqO58abDZ0ulmueXXNetVCrxDDH/fUqMKX+1JZmZxp4ldpeEEMTKQdp9l/3IodX9/6c7d5gKNoEfGd/HSoQxSS7wJrtkcCr3mdMCAHoAz3DyK4vnfuLgql+qOa6XlvZJmQE7/F1ZIQTnPAzDWD96vV63242iKAx63U77eMt/99oVPbBWiGBSc8m0gJyCkY2gTTmMoHXtSS5q7xsS7mi5c3dogQAnBQHAPzr01NFm6PkV1/Mcx/F93/M83/eT+5SJst0ROWLBSPgRUyQIgjAMozDkYXet3btjY/FP2vMPIztCBj+uPFs/ojP/vKyCS1dlvsrqIued+JGZ0oIArCHZEvCfGxs3X/bMcs21HD8WDNd1S6VSf0VqkpuUBDv6MbBkNz9mWHxefjgZJqRBrFc5567dWv9ya/FDnQUg4iBBN9NykwjG3vcjaimQooXO4KkhALaRbHB6tR3cevDpI82e73m268erDK7rep43xdpGGjtSjhiJfnDOeymEYRhFEZBX6wgAAAONSURBVOecRyGE7dVO9LWNlbt6tb+NXAByFRF2epI+nhagI0kmyYXxIyNoMbBhVoIRd28P4KygQMRPOcFr9p19/sKWzSqUuTEtGGOe53meF8828u/BaorbOTliCCGEEFEUJS4m5kcYhpxzLoSIQhF21rrk8XbpoW7ld3p14A4QsZ+gAxj/8mL/3eoDDLignWmAFC/bhVrRBzneCAEAowNC9bJaysDWmdCCAwiAHpJ1JCAIWNF/rG6+oNm6rNKtlRi1PXsAx3FiWnieN9E2ihYzIwdA//5WCBGGYRAEQRD0er0gCGLGxOxBwXkUhBEPwvBMzznRqX+rU10XbBXpJpKTQEOE/giRJMXACUVyVHKN/aoUYSor/WVMZM0O81RAIHiYYIPiPsqPltvPr28ernSYY7vMoRajlm1ZNDlqkwgGY2wnmhFjluQAgHjBNF4CiSkSC0niYkQKKCLgIfKgFZH1wN2K2Ca3u9wGpPGIG28aSq+/yXaz9s046lc1z+l+2KifPGXDVLkk6QgAsbhj8QUnKjvhoh8y2wbqEIvFmxiEkP7RTcZc140dSrL1Ot08I40ZkwMGU5DkLjeKopgi8ec0RZKYgIjIAQXGgfEr3/IQZGY/vpwf573I/osNgAAhlBAglBAKhBJiERo/m0rSpzbT++Tp9YwdMgPOBzliJItjsYrEQhLzoz8LyVJkgDhpvJ4GhORRj0sN6brHHZxsWQBA3PexHxmerWFshoKRYDa/a60irkxcveSBStu2oyiybTtmTMwPznlCjdgrDciR07VcakgIkbRe6qFDmrRkQo6YEzMUjKEl57v107KQsCGetKa/pimSaMhzHBIz4u6PqZAQIkYSbcYG7E43JDKQuJLErUizVBjMauE5KRsx0t4krRnS30QqZk6Lvhm73AFxcTE/IHUoRHIrz1lapCEpR/pDPP84f7ToG3ChuiE9pUhLxXBn6rnNj0Q8kr8JIZK/592GPdIHqU3//hT9uawfWknYHUJkSnzOdkCBsZj4mGCB5w4KchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQwoiBHASMKchQw4v8Dx4wX9PLRhWcAAAAASUVORK5CYII="},"minimumSupportedOperatingSystem":{"v8_0":true},"notes":"","owner":"","privacyInformationUrl":"","publisher":"Microsoft Corporation"}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            $CatCounter = 0
            While ($CatCounter -le 10) {
                Try {
                    $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                    Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                    $CatCounter = 10
                    Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
                }
                Catch {
                    $CatCounter++
                    Sleep 2
                }
            }

            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}