<#
.SYNOPSIS
A function used to retrieve tenant information based on certain passed parameters.

.DESCRIPTION
This function is used to retrieve information about a tenant from the AzureAD environment as a Partner Admin. By supplying a TenantID (preferred unique identifier), the CompanyName, or a DomainName, this function will return back all of the information if a matching tenant is found otherwise it will return $NULL.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER DomainName
The Domain Name the Client Tenant being referenced.

.PARAMETER CompanyName
The Company Name the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Get-O365TenantInfo -TenantId 9b03cdab-f4c4-4042-8ffa-62a58ac0a998 -Office365Instance US

.EXAMPLE
Get-O365TenantInfo -CompanyName 'Eze Vonage (DEV)' -Office365Instance US

.EXAMPLE
Get-O365TenantInfo -DomainName 'Ezevonage.com' -Office365Instance US

.NOTES
In almost all scenarios it is preferred to use a TenantId for looking up a tenant as this is the most unique identifier used by Microsoft to distinguish tenants.
In some cases where a TenantId is not known, a CompanyName or DomainName can be supplied in order to query for a matching result.
#>

Function Get-O365TenantInfo {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantId')]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByTenantId')]
        [String]$TenantId = $Null
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByDomainName')]
        [String]$DomainName = $Null
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByCompanyName')]
        [String]$CompanyName = $Null
        ,
        [ValidateNotNull()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
    }
    Process {
        $TenantInfoObject = [PSCustomObject]@{DomainName = ""; TenantId = ""; CompanyName = "" }
        Switch ($PSCmdlet.ParameterSetName) {
            'ByTenantId' {
                Write-Log -LogString "Fetching TenantInfo based on TenantID: $TenantId" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $TenantInfo = Get-MsolPartnerContract | ? { $_.TenantId -eq $TenantId }
                $TenantInfoObject.TenantId = $TenantInfo.TenantId.Guid
                $TenantInfoObject.CompanyName = $($TenantInfo.Name)
                $TenantInfoObject.DomainName = $(Get-MsolDomain -TenantId $TenantInfo.TenantId.Guid) | Select -ExpandProperty Name
            }
            'ByDomainName' {
                Write-Log -LogString "Fetching TenantInfo based on DomainName: $DomainName" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $TenantInfo = Get-MsolPartnerContract -DomainName $DomainName
                $TenantInfoObject.TenantId = $TenantInfo.TenantId.Guid
                $TenantInfoObject.CompanyName = $($TenantInfo.Name)
                $TenantInfoObject.DomainName = $(Get-MsolDomain -TenantId $TenantInfo.TenantId.Guid) | Select -ExpandProperty Name
            }
            'ByCompanyName' {
                Write-Log -LogString "Fetching TenantInfo based on CompanyName: $CompanyName" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $TenantInfo = Get-MsolPartnerContract | ? { $_.Name -eq $CompanyName }
                $TenantInfoObject.TenantId = $TenantInfo.TenantId.Guid
                $TenantInfoObject.CompanyName = $CompanyName
                $TenantInfoObject.DomainName = $(Get-MsolDomain -TenantId $TenantInfo.TenantId.Guid) | Select -ExpandProperty Name
            }
            Default {
                Write-Log -Logstring "No valid identifier supplied for command Get-O365TenantInfo" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }
        #TenantId is the Unique identifier that is absolute -- if this is null then something is wrong.
        #Some commands, when left null, such as 'Get-MsolDomain -TenantId $NULL' will return all values depsite providing a null TenantId. As such the default is to exit without assuming anything
        If ($Null -eq $TenantInfoObject.TenantId) {
            Return $null
        }
        Else {
            Return $TenantInfoObject
        }
    }
}