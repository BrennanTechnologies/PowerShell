<#
.SYNOPSIS
A command used to obtain Tenant Admin account credentials or AppIds.

.DESCRIPTION
By specifying O365Login or MSAppId, this command is used to get specific O365 Administrative credentials or AppId information contained within the Secret server.

.PARAMETER SecretName
The identifier used to locate the corresponding Secret Object.

.PARAMETER SecretType
The Secret type that is desired to be queried for.

.PARAMETER ReturnSecretObject
A switch statement which can be used to return the raw secret object when needed.

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType O365Login

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType O365Login -ReturnSecretObject

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType MSAppID

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType RefreshToken

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType MDMRefreshToken

.EXAMPLE
Get-O365Credentials -SecretName EzeVonage -SecretType SPRefreshToken

.NOTES
By default, without the -ReturnSecretObject switch, this command will return the credentials of the object in question. If the -ReturnSecretObject switch is supplied, than the Secret Object without credentials will be returned instead. This is useful if you need to get the raw data from a secret object rather than a credential object.
#>

Function Get-O365Credentials {
    [CmdletBinding()]
    Param(
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$SecretName
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [ValidateSet("O365Login", "MSAppID", "RefreshToken", "MDMRefreshToken", "SPRefreshToken", "EXCHRefreshToken", "REPORTRefreshToken")]
        [String]$SecretType
        ,
        [ValidateNotNull()]
        [Switch]$ReturnSecretObject = $False
    )
    Begin {

        Switch ($SecretName) {
            "US" {
                [String]$SecretName = "srv-O365USProvisioner"
            }

            "UK" {
                [String]$SecretName = "srv-O365UKProvisioner"
            }
        }
    }
    Process {
        If ($SecretType -eq "O365Login") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Temporary Fix for This Secret
            If ($SecretName -eq 'Abacus Group LLC - Client') {
                $Secret = Get-Secret -SecretId 9291
            }

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $SecretAttributes = $($Secret | Get-SecretAttributes)
            $UserName = $SecretAttributes | ? { $_.FieldName -eq 'UserName' } | Select -ExpandProperty Value
            $Password = $SecretAttributes | ? { $_.FieldName -eq 'Password' } | Select -ExpandProperty Value
            $Credentials = $(New-Object pscredential -ArgumentList $($UserName), $($($Password) | ConvertTo-SecureString -AsPlainText -Force))
        }
        ElseIf ($SecretType -eq "MSAppId") {
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6039
            $SecretAttributes = $Secret | Get-SecretAttributes
            $AppId = $SecretAttributes | ? { $_.FieldName -eq 'AppId' } | Select -ExpandProperty Value
            $AppIdKey = $SecretAttributes | ? { $_.FieldName -eq 'Key Password' } | Select -ExpandProperty Value
            $Credentials = [PSCustomObject]@{"AppId" = $AppId; "Key" = $AppIdKey }
        }
        ElseIf ($SecretType -eq "RefreshToken") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $Data = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'RefreshToken' } | Select -ExpandProperty Value)
            $Credentials = [PSCustomObject]@{SecretName = $($Secret.SecretName); SecretId = $($Secret.SecretId); SecretType = $($Secret.SecretTypeName); TenantId = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'TenantId' } | Select -ExpandProperty Value); Data = $([PSCustomObject]@{Name = $('RefreshToken'); Value = $($Data); }) }
        }
        ElseIf ($SecretType -eq "MDMRefreshToken") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $Data = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'MDMRefreshToken' } | Select -ExpandProperty Value)
            $Credentials = [PSCustomObject]@{SecretName = $($Secret.SecretName);
                SecretId                                = $($Secret.SecretId);
                SecretType                              = $($Secret.SecretTypeName);
                TenantId                                = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'TenantId' } | Select -ExpandProperty Value);
                Data                                    = $([PSCustomObject]@{Name = $('MDMRefreshToken'); Value = $($Data); })
            }
        }
        ElseIf ($SecretType -eq "SPRefreshToken") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $Data = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'SPRefreshToken' } | Select -ExpandProperty Value)
            $Credentials = [PSCustomObject]@{
                SecretName = $($Secret.SecretName);
                SecretId   = $($Secret.SecretId);
                SecretType = $($Secret.SecretTypeName);
                TenantId   = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'TenantId' } | Select -ExpandProperty Value);
                Data       = $([PSCustomObject]@{Name = $('SPRefreshToken'); Value = $($Data); })
            }
        }
        ElseIf ($SecretType -eq "EXCHRefreshToken") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $Data = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'EXCHRefreshToken' } | Select -ExpandProperty Value)
            $Credentials = [PSCustomObject]@{
                SecretName = $($Secret.SecretName);
                SecretId   = $($Secret.SecretId);
                SecretType = $($Secret.SecretTypeName);
                TenantId   = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'TenantId' } | Select -ExpandProperty Value);
                Data       = $([PSCustomObject]@{Name = $('EXCHRefreshToken'); Value = $($Data); })
            }
        }
        ElseIf ($SecretType -eq "REPORTRefreshToken") {
            #Grab all Secrets matching the company name with the specific ID type matching Office365
            $Secret = Get-Secret -SecretName "$SecretName" -SecretTypeID 6032

            #Check to see if multiple secrets were found e.g Abacus, Abacus Group LLC, Abacus is Awesome.
            If ($Secret.count -gt 1) {
                If ($Secret.SecretName.Contains("$SecretName - Office 365 Admin") -eq $True ) {
                    $Secret = $Secret | ? { $_.SecretName -eq "$SecretName - Office 365 Admin" }
                }
                Else {
                    Write-Log -LogString "Found multiple potential matching secrets but unable to fine '$_ - Office 365 Admin' " -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            ElseIf ($Secret.count -lt 1) {
                Write-Log -LogString "Unable to find a matching secret on the secret server." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            #Setting Credentials for the Exchange Session
            $Data = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'REPORTRefreshToken' } | Select -ExpandProperty Value)
            $Credentials = [PSCustomObject]@{
                SecretName = $($Secret.SecretName);
                SecretId   = $($Secret.SecretId);
                SecretType = $($Secret.SecretTypeName);
                TenantId   = $($Secret | Get-SecretAttributes | ? { $_.FieldName -eq 'TenantId' } | Select -ExpandProperty Value);
                Data       = $([PSCustomObject]@{Name = $('REPORTRefreshToken'); Value = $($Data); })
            }
        }
        Else {
            Write-Log -LogString "Script encountered an unhandled exception while fetching/converting credentials." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    End {
        If ($ReturnSecretObject -eq $True) {
            Return $Secret
        }
        Else {
            Return $Credentials
        }
    }
}