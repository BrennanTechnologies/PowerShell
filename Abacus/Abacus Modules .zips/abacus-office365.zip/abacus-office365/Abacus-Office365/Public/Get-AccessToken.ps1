﻿<#
.SYNOPSIS
A function for grabbing Access Tokens for Accessing the Microsoft Graph API

.DESCRIPTION
This command is used to fetch or generate an Access Tokens to be used against Microsoft's Graph API for a given application.

.PARAMETER AppId
The AppId matching the application that will be leveraged with the Graph API.

.PARAMETER RefreshToken
The Microsoft provided RefreshToken for the account that has access to utilize the application. This is needed to fetch an access token.

.PARAMETER Resource
The resource URI that is leveraged by the app. Depending on what information the application fetches, this URI can be different from app to app.

.PARAMETER Credentials
A PSCredential object that contains the AppId and encoded private key of the application which is needed to use the application.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER PromptConsent
A Boolean value switch statement which is mainly only used on the first run of the application or any consecutive times when admin consent to use the application is needed.

.EXAMPLE
Get-AccessToken -AppId <AppID> -RefreshToken <RefreshToken> -Resource 'https://graph.microsoft.com/' -Credentials <Credentials> -TenantId <TenantId>

.EXAMPLE
Get-AccessToken -AppId <AppID> -RefreshToken <RefreshToken> -Resource 'https://graph.microsoft.com/' -Credentials <Credentials> -TenantId <TenantId> -PromptConsent

.NOTES
N/A
#>

Function Get-AccessToken {
    [cmdletbinding()]
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $AppId
        ,
        $RefreshToken = ""
        ,
        [Parameter(Mandatory = $True)]
        [ValidateSet('https://graph.microsoft.com/', 'https://graph.windows.net/', 'https://login.microsoftonline.com/', 'https://management.core.windows.net/', 'https://api.partnercenter.microsoft.com')]
        [String]$Resource
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $Credentials
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $TenantId
        ,
        [Switch]$PromptConsent = $False
    )
    Begin {
    }
    Process {
        Try {
            If ([String]::IsNullOrEmpty($RefreshToken) -eq $False) {
                Write-Log -LogString "Retriving Access Token from Resource `"$($Resource)`"..." -LogLevel Output -LogObject $O365_global_logobject
                $Token = New-PartnerAccessToken -ApplicationId $AppId `
                    -Environment GlobalCloud `
                    -RefreshToken $RefreshToken `
                    -Credential $Credentials `
                    -TenantId $TenantId `
                    -Resource $Resource `
                    -ErrorAction Stop `
                    -ErrorVariable err
            }
            Else {
                If ($True -eq $PromptConsent) {
                    New-PartnerAccessToken -ApplicationId $AppId -Consent -Environment GlobalCloud -Credential $Credentials -Resource $Resource -TenantId $TenantId -ErrorAction Stop -ErrorVariable err
                }
                Else {
                    Write-Log -LogString "RefreshToken was empty & Consent flag was not raised." -LogLevel Error -LogObject $O365_global_logobject
                }
            }
        }
        Catch {
            Write-Log -LogString "There was an error while retriving our Access Token..." -LogLevel Warning -LogObject $O365_global_logobject
            Write-Log -LogString "$($_.Exception)" -LogLevel Error -LogObject $O365_global_logobject
        }
    }
    End {
        Return $Token
    }
}