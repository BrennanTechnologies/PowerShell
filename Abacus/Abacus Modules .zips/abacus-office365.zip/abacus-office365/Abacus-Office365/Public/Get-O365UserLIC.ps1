<#
.SYNOPSIS
A wrapper function to easily inspect assigned license(s) on a user within a specific Tenant environment

.DESCRIPTION
A wrapper function to easily inspect assigned license(s) on a user within a specific Tenant environment

.PARAMETER UserPrincipalName
The UserPrincipalName of the account that will be targeted for a user license to be removed.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Get-O365UserLIC -UserPrincipalName {UserPrincipalName} -TenantId {TenantId} -Office365Instance {US/UK}

.NOTES
N/A
#>

Function Get-O365UserLIC {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$UserPrincipalName
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance = "US"
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "There was an error finding the Tenant based on the supplied TenantId" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        # Get User Info
        $TenantUser = (Get-MsolUser -UserPrincipalName $UserPrincipalName -TenantId $TenantInfo.TenantId -ErrorAction SilentlyContinue)
    }

    Process {
        # Does the user exist and can we find him/her?
        If ([Boolean]$TenantUser -eq $False) {
            Write-Log -LogString "No User was found" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        # Get LIC(s)
        Try {
            Write-Log -LogString "Attempting to remove the user license..." -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $Licenses = (Get-MsolUser -UserPrincipalName $UserPrincipalName -TenantId $TenantInfo.TenantId -ErrorAction Stop).Licenses | Select AccountSkuId
        }
        Catch {
            Write-Log -LogString "There was an error trying to remove a License on $UserPrincipalName under $($TenantInfo.CompanyName)" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
    End {
        # Return Licenses
        $ReturnObject = [PSCustomObject]@{
            UserPrincipalName = $UserPrincipalName;
            TenantId = $TenantInfo.TenantId;
            Licenses = $Licenses
        }
        Return $ReturnObject
    }
}