<#
.SYNOPSIS
A command for creating an Authentication Policy to Block Basic Auth

.DESCRIPTION
A command for creating an Authentication Policy to Block Basic Auth

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by the Connect-TenantExchange command which can be used to invoke commands against the Tenant's remote exchange environment.

.EXAMPLE
Disable-O365BasicAuthentication

.NOTES
This function requires Connect-TenantExchange to have already been run and have a connection established.
#>
Function Disable-O365BasicAuthentication {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
    }
    Process {
        # Set the Default RemoteDomain's TNEF setting to FALSE
        Try {
            Write-Log -LogString "Attempting to create the Authentication Policy to disable Basic Auth." -LogLevel Output -LogObject $O365_global_logobject
            Import-PSSession $ExchangeSession -AllowClobber
            New-AuthenticationPolicy -Name "Block Basic Auth" -ErrorAction Stop
            # Add a delay before setting the new auth policy settings.
            Sleep 12
            Set-AuthenticationPolicy -Identity "Block Basic Auth" `
                -AllowBasicAuthActiveSync `
                -AllowBasicAuthAutodiscover `
                -AllowBasicAuthMapi `
                -AllowBasicAuthOfflineAddressBook `
                -AllowBasicAuthOutlookService `
                -AllowBasicAuthReportingWebServices `
                -AllowBasicAuthRpc `
                -AllowBasicAuthWebServices `
                -AllowBasicAuthPowershell `
                -ErrorAction Stop
            Set-OrganizationConfig -DefaultAuthenticationPolicy "Block Basic Auth"  -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an issue creating the basic authentication block policy.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
}