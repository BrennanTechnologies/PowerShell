<#
.SYNOPSIS
A wrapper function to easily assign a license to a user within a specific Tenant environment

.DESCRIPTION
This function provides a convenient wrapper around base MSOnline functions for assigning unassigned licenses within a Tenant's environment to a user.

.PARAMETER UserPrincipalName
The UserPrincipalName of an account within the tenant's environment that will the target of the assigned license.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER LicenseType
The desired user license type which will be assigned to the targeted user.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Add-O365UserLIC -UserPrincipalName {UserPrincipalName} -TenantId {TenantId} -Office365Instance {US/UK}

.EXAMPLE
Add-O365UserLIC -UserPrincipalName {UserPrincipalName} -TenantId {TenantId} -Office365Instance {US/UK} -LicenseType ENTERPRISEPACK

.NOTES
You can also use this function to assign different license types that are not included by default by changing the LicenseType parameter.
#>

Function Add-O365UserLIC {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$UserPrincipalName
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet('ENTERPRISEPACK','STANDARDPACK','ENTERPRISEPREMIUM','DESKLESSPACK','AAD_PREMIUM','EMS')]
        [String]$LicenseType = "ENTERPRISEPACK"
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance = "US"
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject
            Start-O365MsolService -Office365Instance $Office365Instance
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "There was an error finding the Tenant based on the supplied TenantId" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Get User Info
        $TenantUser = (Get-MsolUser -UserPrincipalName $UserPrincipalName -TenantId $TenantInfo.TenantId -ErrorAction SilentlyContinue)

        # Set LIC Usage Location based off of selected Office365 Instance
        Switch ($Office365Instance) {
            "US" {
                [String]$LICUsageLocation = "US"
            }
            "UK" {
                [String]$LICUsageLocation = "GB"
            }
        }
    }
    Process {
        # Does the user exist and can we find him/her?
        If (   [Boolean]$TenantUser -eq $False   ) {
            Write-Log -LogString "No User was found" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Is the User Already Licensed
        If (   [Boolean]$TenantUser.isLicensed -eq $True   ) {
            Write-Log -LogString "This user already has one or more licenses assigned." -LogLevel Output -ForegroundColor Magenta -LogObject $O365_global_logobject
        }

        # Get LIC
        $TenantLICs = Get-MsolAccountSku -TenantId $TenantInfo.tenantId | ? { $_.SkuPartNumber -eq $LicenseType } | Select -ExpandProperty AccountSkuId

        # Assign LIC
        If (  [String]::IsNullOrEmpty($TenantUser.isLiceUsageLocation) -eq $true ) {
            Write-Log -LogString "There is currently no LIC 'UsageLocation' set on this user." -LogLevel Output -ForegroundColor Magenta -LogObject $O365_global_logobject
            Write-Log -LogString "Setting 'UsageLocation' value to {$($LICUsageLocation)}" -LogLevel Output -LogObject $O365_global_logobject
            Try {
                Set-MsolUser -UserPrincipalName $UserPrincipalName -TenantId $TenantInfo.TenantId -UsageLocation $LICUsageLocation -ErrorAction Stop
            }
            Catch {
                Write-Log -LogString "There was an error trying to add the usage location to account {$($UserPrincipalName)} to {$($LICUsageLocation)} under instance {$($TenantInfo.CompanyName)}." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
        }
        Try {
            Write-Log -LogString "Attempting to add the user license..." -LogLevel Output -LogObject $O365_global_logobject
            Set-MsolUserLicense -UserPrincipalName $UserPrincipalName -AddLicenses $TenantLICs -TenantId $TenantInfo.TenantId -ErrorAction Stop
            Write-Log -LogString "The user license has been added sucessfully" -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an error trying to add a License on {$($UserPrincipalName)} under instance {$($TenantInfo.CompanyName)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
}