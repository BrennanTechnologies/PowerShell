<#
.SYNOPSIS
A command for creating the base Window 10 Security Policy.

.DESCRIPTION
A command for creating the base Window 10 Security Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365Win10SecurityPolicy -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>

Function New-O365Win10SecurityPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @'
{
    "@odata.type":  "#microsoft.graph.windows10EndpointProtectionConfiguration",
    "version": 1,
    "description":  "Windows 10 - Security",
    "displayName":  "Windows 10 - Security",
    "localSecurityOptionsAdministratorAccountName":  "AGAdmin",
    "localSecurityOptionsBlockUsersInstallingPrinterDrivers":  "True",
    "localSecurityOptionsDisableGuestAccount":  "True",
    "localSecurityOptionsFormatAndEjectOfRemovableMediaAllowedUser":  "administratorsAndInteractiveUsers",
    "localSecurityOptionsMachineInactivityLimitInMinutes":  15,
    "localSecurityOptionsAdministratorElevationPromptBehavior":  "elevateWithoutPrompting",
    "localSecurityOptionsStandardUserElevationPromptBehavior":  "promptForCredentials",
    "localSecurityOptionsSwitchToSecureDesktopWhenPromptingForElevation":  "True",
    "localSecurityOptionsDetectApplicationInstallationsAndPromptForElevation":  "True",
    "localSecurityOptionsAllowUIAccessApplicationsForSecureLocations":  "True",
    "localSecurityOptionsUseAdminApprovalMode":  "True",
    "localSecurityOptionsUseAdminApprovalModeForAdministrators":  "True",
    "localSecurityOptionsLogOnMessageTitle":  "",
    "localSecurityOptionsLogOnMessageText":  ""
}
'@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}