﻿<#
.SYNOPSIS
A function for creating a SharedMailbox in a Tenant's Office365 environment.

.DESCRIPTION
This function is used to create a SharedMailbox in a Tenant's Office365 environment.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER CompanyName
The name of the company to create the shared mailbox in if tenantId is not supplied.

.PARAMETER DisplayName
The DisplayName of the shared mailbox being created.

.PARAMETER SamAccountName
The SamAccountName of the shared mailbox being created.

.PARAMETER Owners
An array of owners to be added to the shared mailbox once created.

.PARAMETER Description
An optional description of the shared mailbox.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
New-O365TenantSharedMailbox -TenantId <TenantId> -DisplayName 'Shared Mailbox' -SamAccountName 'sharedmailboxacc' -Owners batman -Description 'A Shared Mailbox' -Office365Instance US

.EXAMPLE
New-O365TenantSharedMailbox -CompanyName <CompanyName> -DisplayName 'Shared Mailbox' -SamAccountName 'sharedmailboxacc' -Owners batman -Description 'A Shared Mailbox' -Office365Instance US

.NOTES
This command requires an underlying connection to be established to the Tenant's Exchange Environment. Before using this command, ensure that you have connected to the Tenant's Exchange by using the Connect-TenantExchange function and then importing the PSSession to your console.
Both the Members and Owners parameters can take array values. These values must be SamAccountNames not UserPrincipalNames.
#>

Function New-O365TenantSharedMailboxLEGACY {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantId')]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByTenantId')]
        [String]$TenantId = $Null
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByCompanyName')]
        [String]$CompanyName = $Null
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$DisplayName
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$SamAccountName
        ,
        [ValidateNotNull()]
        [Array]$Owners
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$Description
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Try {
            Switch ($PSCmdlet.ParameterSetName) {
                'ByTenantId' {
                    $TenantInfo = Get-O365TenantInfo -TenantId $TenantId
                }
                'ByCompanyName' {
                    $TenantInfo = Get-O365TenantInfo -CompanyName $CompanyName
                }
                Default {
                    Write-Log -Logstring "No valid identifier supplied. Unhandled Exception" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
        }
        Catch {
            Write-Log -Logstring "Failed to get tenant information based on the supplied query method." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        $OnMicrosoftDomain = $(   (Get-MsolCompanyInformation -TenantId $TenantInfo.TenantId | select -ExpandProperty DirSyncServiceAccount) -replace '^admin', ''   )
    }
    Process {
        #Create new user tenant instance
        Try {
            Connect-TenantExchange -CompanyName $($TenantInfo.CompanyName) -Office365Instance $Office365Instance
        }
        Catch {
            Disconnect-TenantExchange
        }
        Try {
            Write-Log -LogString "Attempting to create a shared mailbox" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            New-Mailbox -DisplayName $DisplayName `
                -Name $DisplayName `
                -Password $(New-SecurePassword | ConvertTo-SecureString -AsPlainText -Force) `
                -Alias $SamAccountName `
                -Shared `
                -ErrorAction stop `
                -ErrorVariable errO365CreateMsolResource

            #Set Description of Shared mailbox
            Get-Mailbox -Identity $SamAccountName | Set-Mailbox -CustomAttribute12 $Description

            #Add Owners afterwards
            If ($Owners) {
                $Owners | % {
                    Write-Log -LogString "Adding $_ as an owner to the shared mailbox" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                    Try {
                        Add-MailboxPermission -Identity $SamAccountName -User $_ -AccessRights Full -AutoMapping:$true -ErrorAction Stop
                    }
                    Catch {
                        Write-Log -LogString "There was an error attempting to add Identity `"$_`" as an owner." -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                    }
                }
            }
        }
        Catch {
            Write-Log -LogString "There was an error attempting to create the resource to the Office365 instance" -LogLevel Warning -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Disconnect-TenantExchange
            Write-Log -LogString "Could not create resource" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        #Post Creation Steps?
        Disconnect-TenantExchange
    }
}