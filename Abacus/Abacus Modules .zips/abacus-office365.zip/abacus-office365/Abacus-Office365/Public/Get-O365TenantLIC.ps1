<#
.SYNOPSIS
A function for grabbing a tenant's license information from the PartnerCenter.

.DESCRIPTION
This function reaches out through the PartnerCenter to lookup a specific tenant and pull the available licenses information for the tenant in question. The base command will return all license information while adding the summary flag will only show active licenses and the available versus used licenses quantity.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER OnlyActive
A Boolean switch flag which can be supplied to only return back active subscriptions.

.PARAMETER Summary
A Boolean flag which can be used in order to provide a more human-readable output of a tenant's subscriptions in a summary format.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Get-O365TenantLIC -TenantId {TenantID} -Office365Instance {US/UK}

.EXAMPLE
Get-O365TenantLIC -TenantId {TenantID} -Office365Instance {US/UK} -Summary

.EXAMPLE
Get-O365TenantLIC -TenantId {TenantID} -Office365Instance {US/UK} -OnlyActive

.NOTES
By default the command will display all license information including suspended licenses. The "OnlyActive" switch can be used to filter these suspended licenses out while the "Summary" flag can be used to provide a more easily human-readable table.
#>

Function Get-O365TenantLIC {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [Switch]$OnlyActive = $False
        ,
        [ValidateNotNullorEmpty()]
        [Switch]$Summary = $False
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance -ConnectToPartnerCenter
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "Could not find a valid tenant based on the supplied TenantId." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }

    Process {
        Write-Log -LogString "Gathering LIC information for Tenant `"$($TenantInfo.CompanyName)`"" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        Try {
            If ($Summary -eq $True) {
                $CustomerSubInfo = Get-MsolAccountSku -TenantId $TenantInfo.TenantId
            }
            ElseIf (   $OnlyActive -eq $True   ) {
                $CustomerSubInfo = Get-PartnerCustomerSubscription -CustomerId $TenantInfo.TenantId | ? { $_.Status -eq 'Active' }
            }
            Else {
                $CustomerSubInfo = $(Get-PartnerCustomerSubscription -CustomerId $TenantInfo.TenantId)
            }
        }
        Catch [System.Management.Automation.PSInvalidOperationException] {
            Write-Log -LogString "There is no active connection to the PartnerCenter. Please use the Start-O365MsolService command with the -ConnectToPartnerCenter flag." -LogLevel Warning -LogObject $O365_global_logobject
            Write-Log -LogString "No active connection to the PartnerCenter." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue gathering License information from the PartnerCenter." -LogLevel Warning -LogObject $O365_global_logobject
            Write-Log -LogString "$($_.Exception)" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Return $CustomerSubInfo
    }
}