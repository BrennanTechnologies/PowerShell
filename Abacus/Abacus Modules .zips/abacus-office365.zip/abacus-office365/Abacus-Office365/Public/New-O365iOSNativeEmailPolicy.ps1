<#
.SYNOPSIS
A command for creating the base iOS Native Email Policy.

.DESCRIPTION
A command for creating the base iOS Native Email Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER CompanyName
The name of the Company to include in the Outlook Policy.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365iOSNativeEmailPolicy -Headers {Headers} -CompanyName {CompanyName} -TargetId {TargetId}

.NOTES
General notes
#>
Function New-O365iOSNativeEmailPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [String]$CompanyName
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
            {
                "id":  "00000000-0000-0000-0000-000000000000",
                "displayName":  "iOS - Native Email (No Outlook)",
                "description":  "iOS - Native Email (No Outlook)\nCreated via automation",
                "roleScopeTagIds":  [

                                    ],
                "@odata.type":  "#microsoft.graph.iosEasEmailProfileConfiguration",
                "blockMovingMessagesToOtherEmailAccounts":  true,
                "blockSendingEmailFromThirdPartyApps":  false,
                "blockSyncingRecentlyUsedEmailAddresses":  false,
                "durationOfEmailToSync":  "userDefined",
                "requireSmime":  false,
                "requireSsl":  true,
                "usernameSource":  "userPrincipalName",
                "easServices":  "calendars, contacts, email, notes, reminders",
                "easServicesUserOverrideEnabled":  true,
                "accountName":  "$($CompanyName)",
                "hostName":  "outlook.office365.com",
                "usernameAADSource":  "userPrincipalName",
                "emailAddressSource":  "primarySmtpAddress",
                "authenticationMethod":  "usernameAndPassword",
                "useOAuth":  true,
                "userDomainNameSource":  null,
                "customDomainName":  null
            }
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}