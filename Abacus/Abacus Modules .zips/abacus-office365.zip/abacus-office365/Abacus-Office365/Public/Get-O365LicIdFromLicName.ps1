<#
.SYNOPSIS
A utility command to map O365 license Ids to License names.

.DESCRIPTION
A utility command to map O365 license Ids to License names.

.PARAMETER LICName
A Microsoft License Name (From the PartnerCenter) we want to the the License OfferId for.

.PARAMETER TenantLicName
A Microsoft License Name (From the Tenant side and not the Partner Center) we want to the the License OfferId for.

.EXAMPLE
Get-O365LicIdFromLicName -LICName {LICName}

.EXAMPLE
Get-O365LicIdFromLicName -TenantLicName {TenantLicName}

.NOTES
General notes
#>

Function Get-O365LicIdFromLicName {
    [CmdletBinding(DefaultParameterSetName = 'ByPartnerLicName')]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByPartnerLicName')]
        [String]$LICName
        ,
        [Parameter(Mandatory = $True, ParameterSetName = 'ByTenantLicName')]
        [String]$TenantLicName
    )
    Begin {
        [String]$LICOfferId = ""
    }
    Process {
        Switch ($PSCmdlet.ParameterSetName) {
            'ByPartnerLicName' {
                Switch ($LICName) {
                    'Office 365 E1' { $LICOfferId = '91FD106F-4B2C-4938-95AC-F54F74E9A239' }
                    'Office 365 E3' { $LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02' }
                    'Office 365 E5' { $LICOfferId = 'A044B16A-1861-4308-8086-A3A3B506FAC2' }
                    'Office 365 F1' { $LICOfferId = '6FBAD345-B7DE-42A6-B6AB-79B363D0B371' }
                    'Azure Active Directory Premium P1' { $LICOfferId = '16C9F982-A827-4003-A88E-E75DF1927F27' }
                    'Enterprise Mobility + Security E3' { $LICOfferId = '79C29AF7-3CD0-4A6F-B182-A81E31DEC84E' }
                    Default {
                        $LICOfferId = $Null
                        Write-Log -LogString "Unhandled Exception.`nException {No known  matching LicenseId for {$($LICName)} license name.}" -LogLevel Warning -LogObject $O365_global_logobject
                    }
                }
            }
            'ByTenantLicName' {
                Switch ($TenantLicName) {
                    'STANDARDPACK' { $LICOfferId = '91FD106F-4B2C-4938-95AC-F54F74E9A239' }
                    'ENTERPRISEPACK' { $LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02' }
                    'ENTERPRISEPREMIUM' { $LICOfferId = 'A044B16A-1861-4308-8086-A3A3B506FAC2' }
                    'DESKLESSPACK' { $LICOfferId = '6FBAD345-B7DE-42A6-B6AB-79B363D0B371' }
                    'AAD_PREMIUM' { $LICOfferId = '16C9F982-A827-4003-A88E-E75DF1927F27' }
                    'EMS' { $LICOfferId = '79C29AF7-3CD0-4A6F-B182-A81E31DEC84E' }
                    Default {
                        $LICOfferId = $Null
                        Write-Log -LogString "Unhandled Exception.`nException {No known  matching LicenseId for {$($TenantLicName)} license name.}" -LogLevel Warning -LogObject $O365_global_logobject
                    }
                }
            }
        }
    }
    End {
        Return $LICOfferId
    }
}