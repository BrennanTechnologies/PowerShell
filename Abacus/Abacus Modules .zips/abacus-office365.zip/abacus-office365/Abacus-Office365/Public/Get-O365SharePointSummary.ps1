<#
.SYNOPSIS
A function to grab an Azure Tenant's SharePoint Folders/Documents permissions and metadata.

.DESCRIPTION
This function connects to AzureAD with the supplied Tenant Id and attempts to grab a summary of files/folders and their respective permissions/metadata via the SharePoint API.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER Depth
A parameter to specify how many levels deep to query SharePoint data.

.PARAMETER FoldersOnly
A Boolean parameter to specify if files should be include in the query.

.PARAMETER ReturnAsJson
A Boolean switch flag which can be supplied to return the output of the following command as a JSON object instead of a PowerShell Object.

.PARAMETER FirstRun
This flag can be provided which will call the PartnerCenter function in order to generate a new Access Token for the application.

.PARAMETER TestOnly
An optional flag which can be provided to test the command's access to the API-- at this will run a basic query, this can be used to create/refresh an Access Token without needed to run a full query which can be taxing.

.EXAMPLE
Get-O365SharePointSummary -TenantId <TenantID> -Office365Instance US

.NOTES
Use the -ReturnAsJson switch option if you wish to get the result in the form of a JSON object rather than a PowerShell Object
#>

Function Get-O365SharePointSummary {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNull()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [ValidateNotNull()]
        [Int]$Depth = 3
        ,
        [ValidateNotNull()]
        [Boolean]$FoldersOnly = $True
        ,
        [ValidateNotNull()]
        [Switch]$ReturnAsJson = $False
        ,
        [Switch]$FirstRun = $False
        ,
        [Switch]$TestOnly = $False
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABASHAREPOINTAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError
                }
            }
            'UK' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABASHAREPOINTAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance

        #Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType SPRefreshToken -ErrorAction Stop)
        $SPRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($SPRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object pscredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

            If (   $True -ne $FirstRun   ) {
                Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose
                If ($RefreshTokenStatus -eq $False) {
                    Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError
                }
                Else {
                    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $SPRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                }
            }
            Else {
                Write-Log -LogString "FirstRun flag detected, will prompt for consent." -LogLevel Verbose
                $ResponseToken = Get-AccessToken -AppId $AppId -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -PromptConsent -Resource 'https://graph.microsoft.com/'
            }

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel TerminatingError
            }

            Write-Log -LogString "Attempting to get SharePoint information for company $($TenantInfo.CompanyName)" -LogLevel Output
            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))


            If ($True -eq $TestOnly) {
                $ReturnObject = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/drive/root" -ContentType "application/json" -Headers $Headers -Method Get
                $TenantContainer.Data = $ReturnObject
                $TenantContainer.Status = "200"
            }
            Else {
                $Sites = @()
                Write-Log -LogString "Enumerating O365 Groups..." -LogLevel Output
                $Office365Groups = Get-O365DistributionList -TenantId $TenantId -Office365Instance $Office365Instance -ReturnAll -ErrorAction Stop
                $Office365Groups = $Office365Groups.Data | ? { $_.GroupType -eq 'Unified' } | Select DisplayName, id
                $Sites += Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Method Get -Uri "https://graph.microsoft.com/beta/sites/root"
                Write-Log -LogString "Attempting to match O365 Groups to SharePoint Sites." -LogLevel Output
                ForEach ( $Office365Group in $Office365Groups ) {
                    Try {
                        $Sites += Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Method Get -Uri "https://graph.microsoft.com/beta/groups/$($Office365Group.id)/sites/root" -ErrorAction Stop
                    }
                    Catch {
                        Write-Log -LogString "Could not find a SharePoint Site assocaited with O365 group {$($Office365Group.DisplayName)} with id {$($Office365Group.id)}" -LogLevel Warning
                    }
                }
                $Sites = $Sites | Select -ExpandProperty id -Unique
                $ReturnObjectCollection = @()
                ForEach ($Site in $Sites) {
                    #
                    Try {
                        Write-Log -LogString "Enumerating drives for site {$($Site)}" -LogLevel Output
                        $Drives = (Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives" -ContentType "application/json" -Headers $Headers -Method Get).Value
                    }
                    Catch {
                        Write-Log -LogString "Thre was an error enumerating drives for the following site: {$($Site)}" -LogLevel TerminatingError
                    }
                    ForEach ($Drive in $Drives) {
                        $Children = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/root/children?`$top=9999&filter=folder ne null" -ContentType "application/json" -Headers $Headers -Method Get | Select -Expand value | Select id, name, parentreference, folder
                        $Data = @()
                        $CheckArray = $Children
                        $Check = $True
                        $DepthCounter = 1
                        $ReturnObject = @()

                        # Grab the data from the Root directory
                        If ($True -eq $FoldersOnly) {
                            $Data = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/root/children?`$top=9999&select=name,createdDateTime,createdBy,lastModifiedDateTime,lastModifiedBy,id,webUrl,size,parentReference,folder&filter=folder ne null" `
                                -ContentType "application/json" `
                                -Headers $Headers `
                                -Method Get | Select -Expand value
                        }
                        Else {
                            $Data = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/root/children?`$top=9999&select=name,createdDateTime,createdBy,lastModifiedDateTime,lastModifiedBy,id,webUrl,size,parentReference,folder" `
                                -ContentType "application/json" `
                                -Headers $Headers `
                                -Method Get | Select -Expand value
                        }


                        ForEach ($Object in $Data) {
                            Clear-Variable Perms -ErrorAction SilentlyContinue | Out-Null
                            Clear-Variable DataObject -ErrorAction SilentlyContinue | Out-Null
                            $Perms = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/items/$($Object.id)/permissions" `
                                -ContentType "application/json" `
                                -Headers $Headers `
                                -Method Get | Select -Expand value

                            $DataObject = New-Object PSObject -Property @{
                                "@odata.etag"          = $($Object.'@odata.etag');
                                "createdDateTime"      = $($Object.createdDateTime);
                                "id"                   = $($Object.id);
                                "lastModifiedDateTime" = $($Object.lastModifiedDateTime);
                                "name"                 = $($Object.name);
                                "webUrl"               = $($Object.webUrl);
                                "size"                 = $($Object.size);
                                "createdBy"            = $($Object.createdBy);
                                "lastModifiedBy"       = $($Object.lastModifiedBy);
                                "folder"               = $($Object.folder);
                                "parentReference"      = $($Object.parentReference);
                                "Permissions"          = $Perms
                            }
                            $ReturnObject += $DataObject
                        }

                        # Enumerate list of SubFolders + Permissions
                        If (  $ResponseToken.ExpiresOn.LocalDateTime -le (Get-Date).AddMinutes(30)   ) {
                            $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $SPRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                            Write-Log -LogString "Refreshing our Access Token so it does not expire..." -LogLevel Output
                            $Headers = @{ }
                            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
                        }

                        While ( $True -eq $Check ) {
                            Write-Log -LogString "Enumerating subfolders and permission data at depth {$($DepthCounter)} ( Total depth set to {$($Depth)} )" -LogLevel Output -ForegroundColor Cyan

                            $GrandChildrenPerCheck = @()
                            ForEach ($Id in $CheckArray) {
                                Write-Log -LogString "Checking Id: {$($Id.Id)} - {$($Id.Name)} - {$($Id.Folder)} - {$($id.parentReference.path)}" -LogLevel Verbose -ForegroundColor Cyan
                                If (  $ResponseToken.ExpiresOn.LocalDateTime -le (Get-Date).AddMinutes(30)   ) {
                                    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $SPRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                                    Write-Log -LogString "Refreshing our Access Token so it does not expire..." -LogLevel Output
                                    $Headers = @{ }
                                    $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
                                }
                                $GrandChildren = @()
                                If ($True -eq $FoldersOnly) {
                                    $GrandChildren += Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/items/$($Id.id)/children?`$top=9999&select=name,createdDateTime,createdBy,lastModifiedDateTime,lastModifiedBy,id,webUrl,size,parentReference,folder&filter=folder ne null" `
                                        -ContentType "application/json" `
                                        -Headers $Headers `
                                        -Method Get | Select -Expand value
                                }
                                Else {
                                    $GrandChildren += Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/items/$($Id.id)/children?`$top=9999&select=name,createdDateTime,createdBy,lastModifiedDateTime,lastModifiedBy,id,webUrl,size,parentReference,folder" `
                                        -ContentType "application/json" `
                                        -Headers $Headers `
                                        -Method Get | Select -Expand value
                                }
                                $GrandChildrenPerCheck += $GrandChildren

                                ForEach ($GrandChild in $GrandChildren) {
                                    If (  $ResponseToken.ExpiresOn.LocalDateTime -le (Get-Date).AddMinutes(30)   ) {
                                        $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $SPRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                                        Write-Log -LogString "Refreshing our Access Token so it does not expire..." -LogLevel Output
                                        $Headers = @{ }
                                        $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
                                    }

                                    Clear-Variable Perms -ErrorAction SilentlyContinue | Out-Null
                                    Clear-Variable DataObject -ErrorAction SilentlyContinue | Out-Null
                                    $Perms = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/sites/$($Site)/drives/$($Drive.id)/items/$($GrandChild.id)/permissions" `
                                        -ContentType "application/json" `
                                        -Headers $Headers `
                                        -Method Get | Select -Expand value

                                    $DataObject = New-Object PSObject -Property @{
                                        "@odata.etag"          = $($GrandChild.'@odata.etag');
                                        "createdDateTime"      = $($GrandChild.createdDateTime);
                                        "id"                   = $($GrandChild.id);
                                        "lastModifiedDateTime" = $($GrandChild.lastModifiedDateTime);
                                        "name"                 = $($GrandChild.name);
                                        "webUrl"               = $($GrandChild.webUrl);
                                        "size"                 = $($GrandChild.size);
                                        "createdBy"            = $($GrandChild.createdBy);
                                        "lastModifiedBy"       = $($GrandChild.lastModifiedBy);
                                        "folder"               = $($GrandChild.folder);
                                        "parentReference"      = $($GrandChild.parentReference);
                                        "Permissions"          = $Perms
                                    }

                                    $ReturnObject += $DataObject

                                } # End GrandChild Loops
                            } # End CheckArray

                            If ($GrandChildrenPerCheck.Count -eq 0) {
                                Write-Log -LogString "No more subfolders detected..." -LogLevel Output -ForegroundColor Cyan
                                $Check = $False
                            }
                            Else {
                                Write-Log -LogString "More subfolders {$($GrandChildrenPerCheck.Count)} detected." -LogLevel Output -ForegroundColor Cyan
                                #$IDArray += $GrandChildren
                                $CheckArray = $GrandChildrenPerCheck
                            }
                            If (   $True -eq ($DepthCounter -eq $Depth)   ) {
                                Write-Log -LogString "Max Depth of {$($Depth)} reached." -LogLevel Output
                                $Check = $False
                                Write-Log -LogString "Total folderId count to check {$($IdArray.Count)}" -LogLevel Output -ForegroundColor Cyan
                            }
                            Else {
                                # Increment DepthCounter
                                $DepthCounter++
                            }
                        }
                        $ReturnObjectCollection += $ReturnObject
                        $Check = $True
                    }
                }

                $TenantContainer.Data = $ReturnObjectCollection

                If ($Null -ne $ReturnObject) {
                    $TenantContainer.Data = $ReturnObjectCollection
                    $TenantContainer.Status = "200"
                }
                Else {
                    $TenantContainer.Data = "NULL"
                    $TenantContainer.Status = "200"
                }
            }
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "401"
                    $TenantContainer.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "400"
                    $TenantContainer.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(404)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(503)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(504)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(?)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning
            $TenantContainer.Status = "ERR(?)"
            $TenantContainer.Data = "$_"
        }
    }
    End {
        If ($True -eq $ReturnAsJson) {
            Write-Log -LogString "ReturnAsJson was selected, outputting results in JSON format." -LogLevel Verbose
            Return $($TenantContainer | ConvertTo-Json -Depth 5)
        }
        Else {
            Return $TenantContainer
        }
    }
}