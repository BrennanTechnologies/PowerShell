<#
.SYNOPSIS
A command for creating the base Android Word App.

.DESCRIPTION
A command for creating the base Android Word App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365AndroidWordApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365AndroidWordApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{"@odata.type":"#microsoft.graph.androidStoreApp","appStoreUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.word","categories":[{"displayName":"Productivity","id":"ed899483-3019-425e-a470-28e901b9790e"}],"description":"Microsoft Word","developer":"","displayName":"Microsoft Word","informationUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.word","isFeatured":true,"roleScopeTagIds":[],"largeIcon":{"type":"image/pngapplication/octet-stream","value":"iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAIAAACyr5FlAAAAA3NCSVQICAjb4U/gAAAX0ElEQVR4nO2dW5AcV3nH/985Pdedve9Kq9X9YmPZ2FZMDAHDAwZzCXGA4EpIKg+kUklRRR4owkNSVC4PPOAUValKSKUcqNwJDxQFZRNIABNjg2MMyMY3Icm6S7ta7axmd2d2di7d58tDd8+cvs3KmtlVOzq/stXTPd2nj3T+/X3f+c45PcTMMBjiEDe6Aob0YsRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSMSIw5CIEYchESMOQyJGHIZErBtdgWvCvCcCABFt8R3TKw5mAAwwAURGHACDmUCErRJKSsXBzMzs2K1KzX5lrrGw0sbNbTykpDt2FraPZsaHcwyBLdEHpdBiMzOY7XbjH/937W9O8SuUmZZ0kwdHTWC56fz2iPPJI/LNt44oSCLabH2kURxKqVaz+fc/WP3MfPbeHFlIXQ1vFFVFy7bzr2/BW94wArJuRnGwsp94efn+n9D9eZG6yt1o1pnGVOvLDxbHR4okNteeps5aM7NynP8+4xzJSqOMKEXi/2pZL15cJ9r0xzqN4nAc9fBZe0Le6KqklT0ZcabsAGqzg/TUiQPMihWw1X361xEEZhJQm25YUycOBux222ijBxJkO45SzmbfKH3iYLZtI45eCILtKKXUpt9os2/wWmFmx3GMW+mBAJRix3E2u6eZOnEAvAXPxOsacvt0zDehOMgfVTH0hHmz7WsKxWFcygbQVj06qRSHIR0YcRgSMeIwJGLEYUjEiMOQiBGHIREjDkMiRhyGRIw4DImkUBwmcZ4WUrc0QQiSgtBuKFsOcGCJQCAwiEiAqJOi3/qVQq8jBiOOZluVK41GSw3guWdVXWliaanu1DiptI1vEjmDCEREwsplMsU8RJasjDa/2ogkhgGI4+cnl7/2nbkfnlv/nxUHQPzExtiBVvcAs/cYd74nzEBdutzsnkbulrtHvDb1V0qGy47oihkACcrkRGkqN75nTKJE0gIEQK5IjEBC9CuOR79/6YMPn8HOzKiFGSICd8ZUu63DHDPQ2jnYUQZ1NiyJdK24Z5CvEfcgM4PhHSS/zM41nTu6B4kYYEZzXa2fWVu9XN/zyztkbkhYORCDCUTMbPSh05c4jp+rfvBvz23bn80Rh2wDdzaxy1xDcunaBsT5DI7ZXks4wt1adI4QIC1qrvPS6aWpWyRJCUgiArPRR4jrF4cCvvvUPEZELmjDAwYDkbYONWq3veOLCB1MDFGjx6NThrRzhKRauTWyvZobzwoLzAxyF6BuwRyafvH+Gpsv4usXR7XWPj7XgLa6JKkl4o/EygJxyuhs46OZxBuFZaoVTGC7jcsvXcgOXaVMHhAkvF4M6S4pfRBwvAHnLRI0utnd/usXh+2olYZyF+QFHvAYt5AQinbO5tD0prAsEFVGT6HEbrQyvZtKS1o5iywLQpKQAIFEyt0Kuf9vyTrRPmIOhlLMPR7Q6MEeIgopo4csQl8Hb9SrMposAADEylZ2S8gMMbEiEsK9W8r1sWVpwv56K6EeQYhrkcVrshYx92K334LQv1i8Cwv1hZmVA3agHCZBJExyNkT/eY6ETFVcu15j1IlrDy+6iY6E0+I8S8eTsXLYsVkpEgpKMYgEb0Gg93qhP3Fw3MO2YeAZbanQdsNgVjvS02AECo/pO7Fi5bBySEmWeoLG6AMY5NhKgib8vagyrs2PxAYcoUs3Di/i5cFKsXLAipkJChBGGTqbMPC2sSwiJ12rH4nVWIKeolFOpDCwAjvun8TWTf7asSh9i4ODMYfmRGI7p9fqR2JCmUgTR20Vwcu99jIYWgzLCszMCgAzEzg+03+z0qc4EvsjKw7XqgqKA62SFzuLorcs5hoOav5aWbeZmSFpYkTkhNZukahz0Vb2igMVPFoSM7ngnJVAz4ZdfYDN6twY+g5IEZYFgFWH370j99BD07KrBFiCTl5Y+8z3l3bmCQl+ZK7hfPLIyK/cPcFON94UhJW6/cXvXj69rnKh+3l7vGjzg7vyH/md7VJ07YYQ9MxLlb9+pjKTp+h1/uXc/WukP3O+tfSd54hLYFjAMxXnS/fNTI7m9NNfPr3y+acrLaUysYO0AJr8q/dte+C+naEvbcaxV5Z/eqy2I3SlrzC7pt57z8RHP3BAat/bCpev1NFi5CmsKGb2BMqszYdjdx23UQiAfqcJahGGHisOSbr80vrV5Wbo9JnJ/Ae2W+Xo+4qYAawzjoxb+3YPR+9jEfbtL6HhG3/23U3nc4v37yjIYKM2m+1/+XFFxikj/NdgE4zG0O8c0pAsukmnMTp2ZiV08sRobveoFfDv3G2WquJDJblj21Dsje77pSmUHW/Kh5fh9G5nMzAiRsbzoUsaTXX026vTWX8+iPde5Nh+ryGGfsTBiJWF+2SOii89fiV0AQHb9w6jqYCALNwL7ZbaPZsv5ePfInj40AROOCFZwA1+lXr/pLVvthS65PlfLGHWjUGYOdL9CVfAEKbv2eesP3ndFpvOiMd+Xov2Ae49PIqKEzb0YGJgVb3jTZNJ9xnKCbxvaKnd7dB6MmG0FLYX5fh4MXTJkz9fwoQMjg36mohqxRCh75iDw5/crQQgcOp8NXTFrfvHcdEOFsJeVmTePnI4URwA/unXZ5rLjn8H34QAsHlyJp+LWJwfPbWIovaK5o6pYMAEnddAP+LoTP4MPMvuRwFGBi+eXA5dMzWSwbBUbtzA7HUYAFsBw3L3tkLnzHrTWa0HZHTHwRGsKKaAZyEAq869d42HbjRfri+2VakziqZHr140a0zHBvRnOShgLQAv5PNaQtLFiOUA8IcPTczXnWDkgCt151MfmiAtzTW3uH5+vqZfOD1VLB3MNpxQszIWncP7w+L4xemVFxpcQNBg+JtOX8fQg0G4lc4zGfr3tuiVS+uVait00bvvnkBN6866DVVTb3/juNTEUanUz88FtDU1Xvj47aXlVuTep9SBSAf4wrlltJWgsMGAnvcy9GQAeQ5PFpHh8mkLj5ysV1bC2Y7b9pZQVZ0rO6XsmglElCcurh19JeCVSkXrwPY82ppbYdRsxruLhWDE0Wg65+bXkSGooCzQmRhkBLIxg1grG5NTYgAZAZxvlZfWQ6ePjOaKt+QbTnd53LLD73lDfmZ7IMOxcL5avrTmBMs+eHgCbaXfsLqmPve+Sd3kAFhebTzy05VitrtYSjMa/jHvsCGRvvIcFM0s6nEeA6PiuRPhmHS0lP3Y/lxFizXXHb5jOjs51s1irbfUwnLrdKVdvhrQ1uEDY2h2X/rNYKw5B3aHMxzVWuvS0fqwhYAf8SIPE4leKwNaZd9JHgQplsTHHwunwkaGs7fOFuBmLNyr2rxntlDUXMNSpX70wvpjp1sXgjHp7m1FZOW6l0VjMNCiW3aFk6o/e2UJk142NTBlTO94m4h0IwYijmhC2tPKWIbw+FqtEXi/vwCmtxXheJadACw5d98ZyHCsLDe/d6yBpnNlYS1U9p9+YHqtZrvBb0Nh94Hs0Eg4cf6VH17BmPSH1fyUV4xKDL3oP0MamuzDesgHAAfkybNhz3L7oVEwO52TztiHD03oJ5w8XwMxSuJnJ1bsYNxx/5umUXbc/MWKrd67K+CPXB79XHkqL6JTwnSVmD7Lhgz25S0c2ACsGNPiiZ8shs7bu2u0ZLPtugVmDImZ8cDg/o9eXEJJTBTEn3+jbLcDhueuQ2NoQbkqdHjvVG4sODHg1MUqbiMRSqRofqRzOBgfmRA1zIDmkLLeCJ0NA0BeXDxXU0EZjpcsZYkWOAuU15w/+thUqLzPf31pcrfMCuDV5uVKc9+Obj1zOfmRdw1/7dT6TJbQ4uGpfEjgL5xYwnaBUI0Y3Jl/4tdWCEFSCimFlLCkkBJSEgkS6f0JMQKQAWgrpq4NbA5psC26e1mBE4vNy4v12elAGuNT75/+7LcWhkckys6Db5vRvzq/UMfZVnZvgRnYI4++dGXfjv2db0tDuQfuGv/aC2uclag4994VFtbJF8oY7rRuoHp6mo4ItXKttrhC2TpkjmQWIkNkQbgLnFIKAVhmtXcYtGez79XnNMGIIY5M+h0X+Oal5tzCWkgcb719DF+Zx4iETQeC3Y2TZ5axT3pTL8bFd55e/I0HuuKQAjt3DMFmgLHk7J4d0a9dXWudv9qE24nVkhqxdSNBQkjKSJIWWRYJideFOPLeOwE2m4HeIzTplxlgAWBVzV+uh86989A4FtV8Wz341qHRkUDQ8N0fL2BSuoWJLJ07t1ZrBKzoof2jt03JqgJOqN3bApq7vFj/9+NrI4L00cBwN9vbfV1GpFtZ44HmObzPmmdxPw/RcyeW23aggYcKFu7Ko67ednBopNQVR8vB1Yt1+NO3hoETa875ucCksj07Rw8Py/q6M/v7Y6GKlBfXVk428/ra/4RlcOz3ow1J9CmOSO6r043tjpnwaIH+4slKqx0QR6Fg/cm9w1hVe2aKuUy3GguLtTMr7Sx5gssTTi87Z4MzDos5MT5bwBX7z+4PBxy/OLOKEeGbLV2ygap6CTSTB+vJYCYYe59dZXDAagAoWoSn61eDI3D5nHXHvhLafPCWwGj72Qur37vQGhNamYLPXKzawWnJH37nLH7cfOMbAtkRpfiR7y9gRIRdht6Z2vyfRvt/w0AG3rqjF0FZaKnJg9Yrr17VLyJgaqoAgb07A6PtV67U0VKBicR5+umr1Xq9rZ92x62TgLMrGHC0bH72kcp0zp+FGEnqc8D3GYlswCDmkIYV4X+hWXRMyi8/Ph+6dPds6f0H8zMT3fxms+U8f2IF3qo4L5Sczop/frSyWg0YntnJPH5tvFDI6AdfPFHGIepMNu/WkYPzzk1y9Nro060EFNGNNQI5dQazlcGVM2ut4G8oT4zm7r434BeaLeezP1wezgeSVYIAUmfnAiNwIPr8QzOF4FT1Z18sY6elWbKgE2HfYOghsyGZwcw+13qMkYw1A0CJ6HyTL8yt6pfm89l3HgkEHJWVFp6pF63gEA0ztlmPP7ugnykF3XnrhGUFxHHsuUUMC9ajTr2eQdUar7IhA4g5Qqmm8GEAQJ5wrOocP1XRD46WMtu3B6ZivHCijH2yG23Aa9DSiPjL/wh4JSLat2skm+mK48rV9XNLbffthhxWRjceQlcjZmLHBvQvjng/EukuMJjn5tf05hCEw3tH9bL+89kyxrXRVN8EZAWw2l7U1ldKSQdmS5a2APLCfPWbi+0xEZyzyGF7xh1DZzzLRvSf5+htMjSvn6PnX61W1wLzjbOZQAWef3rJKohgqzEYkoFx+cKxwOiuFVwaO3d+BQstq1OHTp4jZDD06pnXf/VkcHmOSELMW4ToM5Glv3tmtb4W6JHqXFxYKwOFbrHdpiUAOTr1aiXp2rajTl+qYaiTGY3zIx0dd9Pnhl70uW7F3cSsLgyvTWXOCuBC60JkkKXDSyeWTjVV3p/dp3eQGYwMjp+tVtft2Gvr9fYXnyyjKCIdKH+VrC44/6PRR2/67srGySKYUdC8/jbxk5fDE386zF+sQrmTlkM9IAYjm6EnTtUrlfBcdpfaWvvlf1udyuhqiiye7r1riDDIUdlwZjo425uZM2PyE49ejr223nROX1pDhrTHPtDdHJV09Nm1lUq84Tl26ipuI38lQiS20Ivy06bGr2zIYGaCdTNW3UOBRnY3YxYtzje++u3TtqO0wwChvm5/+8XVoTxFZdHd3Wv9wzfOvP3sqtJmlTI4l5GP/uAS9ma6ouDItdpno4lrZADiiMk1dT8HNsQ8PWP95sPHAPhvG/T9h0XFcTnkdkD0p9z7kQsAmC6KLzxV/sI3F7zi3P4IAQ4wJafyxLGSiqmlSYFdE33PBGPuzorgBFloiiGFbds6AyLRKYaBR757sX98qihQFOF7EWKGWoNxj1ajkCExvdlEBj3BOEYW/q7uCrTdXn7E+xhnmbRuarAzEi4kRnmaOzP0oP8JxqF/9DhZIF4ZG8oCHWXElRYOdOLKCRuMBIEaYun/xfiuWe/sAxsZDI4sEUDwMsR8GzU2MUZC24vRa0IlDYkM4g3GjEAjxDymYUvS+wX41+RH4i5M9CN6BUJGyJDMINatuFvEyiIuvEgoARvLoqcPCviRUDneh94VMYToSxwM36XExoPR1ugRIsT6Ao77NqGokP3S76rVRSs2OBJkiNKXOCRBe3WOjh9ZeDuvJbzgiCx6+pFQQQjshornriwAgEAECGi/bN/9kFbIn167BVy/OCxJw3kZ34l1/+ja83hlRJxI4HIEn/ZwOUlqS7IWna2uFHZYETmKyQYssA0GSG7Nby9eP44ipHut7HApd+uuIp5ZRlZbmIpg+/YyGK8l6owzHsnhRZy1CBwCQHAaduU8hCCrQCILmREkmSwmEilfDnmxza1bBv2GhBiu/waC8MC79mLeqXcMBScrQ3Pw/usota8QN1krcG24HO9/3WBohiHGj/hX+RUUTuMy21UiCSbtx9JT7FEAxPrwTaMv9R3eP/b1v7q99mTjSt1ZsrmluM1oM2yHbUfZCraCrdj/D7bidneXbYdtR9tV3FbcdpSj0P1te0YweCEGaSOqBCZwt0G9b70d0kog7aXFFreXnfJRkgWQgHBL6PyXbrawjv12ZT/03gPPPTH61cdOPXWi9tSi3Y313G5Md/DCzXu5Ta71cAJt718rMIxWVgSOh+KQzl7HibBXdOc4wEqfj+SdaDdV/ZK9/LzMTkBYXoTn/cwwdytpGMjYypHbJm87MF6u1BtNJ9niccyneFStunrPnZ8eeuNEKO0Z12z6wUjgSZ0fCyK/bwI4dXYalB1lkSEIAAxXhqT1VgzAoAbe8lmxa3v4fY/Xh+PYKxUHOOrU7xxIgYBrHQSRJJKwcpQdI5EhkiQESBDBe90FkTEcOpvw06H9oRQ7ioFpsgrA9QZf4QYmAkFIkARZJCwICSFAAkJ2leH9adThkTpx+BRIZDY+qwddf+IHPSRBkoRFZEFYIAskCQJwX+VjZBEmteIoQmaBPrpt3oRS3x4QEQSEJJKuMvyXPEmQgCsOs4wlSHrFQSI3gAjA658SQYBc4yGoYzaEBPlmwziUCCkWh5XrO9tDfoelM4xCRAIkISRRBiQAiaBPMQLpkFpx5GHlqF9xdBIt5L7IAUREEhBeNEqSXINBwmgjSjrFwUDBcyv94Le3Zz08x+HKgohkx5yA0DUeJvLwSac4AGRJWAN6jsn/340+yBs08EIN0fneECLN4sgOYITJz4qTm/1kLd+lp039U8mYDY3UisOCsIDBjEB6CqGgFAI6MMqIIbXikCAx4GR2p+fi73d2jSxiSa04xOa83jskAjKy6EF6xWGa7YaT3vlwhhuOEYchESMOQyKpFIcJNtJBKsUBAoRZjZbIVi3VS504iEgI8buf2LGy6mx89s3JaXv3rjEAm/1zY6kTBwAhxHvevhMXjThiWG7wXfcP3X7LtFKbPkSYOnEQERHdc+fsH39s2/Kc3VAmBAHgDQQtNxkN9ek/uGVkpCjEprddGpNgQshcLvPR37rdyh9/+FvlxryN0ZteIAqYU+94YOj3Prz7njtnhZBbkCSMvIHvRqOUqtfr5XJ5dXVlrb5eqzZOXayWrzZSVs0thoUQt+4bnhwvjI4UCvmhicmJ8fHxbDa7qRJJneUgokwmk8/nG42GbdvWmHzzxBCRv/r5JoUJcN/dalnZfCGfy+Usy9ps45FGcViWVSgU2u22bdvtdlsp5b9y+KbFGzqWUubz+aGhoVwutwVuJXXiACCEKBQKbmS6vr7u6gO4efXh6sCyrGw2OzQ0VCqVcrncFgSkqYs5XJRSjuM0Go1ms9lqtZRS6aznluEa1JyPEFsxap1ScQBgZlcijuOYH4N1fYoQQkrp2tStuGnK/9FTXr0tZovnuKRdHIYbSOoypIb0YMRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSMSIw5CIEYchESMOQyJGHIZEjDgMiRhxGBIx4jAkYsRhSOT/AOHkLPMV3YROAAAAAElFTkSuQmCC"},"minimumSupportedOperatingSystem":{"v8_0":true},"notes":"","owner":"","privacyInformationUrl":"","publisher":"Microsoft Corporation"}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            $CatCounter = 0
            While ($CatCounter -le 10) {
                Try {
                    $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                    Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                    $CatCounter = 10
                    Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
                }
                Catch {
                    $CatCounter++
                    Sleep 2
                }
            }

            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}