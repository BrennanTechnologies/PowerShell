<#
.SYNOPSIS
A command used to set the Tenant's Mailboxes' Send/Receive Size Limit and Organization setting.

.DESCRIPTION
A command used to set the Tenant's Mailboxes' Send/Receive Size Limit and Organization setting.

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by the Connect-TenantExchange command which can be used to invoke commands against the Tenant's remote exchange environment.

.PARAMETER MaxSendSize
An integer matching the Max Send Size; Default 50 (in MB)

.PARAMETER MaxReceiveSize
An integer matching the Max Receive Size; Default 50 (in MB)

.EXAMPLE
Set-O365TenantMailBoxMessageSizeLimit -MaxSendSize 50 -MaxReceiveSize 50

.NOTES
Max Send/Receive Size variables are of type Integer and default to MB.
#>

Function Set-O365TenantMailBoxMessageSizeLimit {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
        ,
        [Int]$MaxSendSize = "50"
        ,
        [Int]$MaxReceiveSize = "50"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
        Import-PSSession $ExchangeSession -AllowClobber
    }
    Process {
        Write-Log -LogString "Attempting to set the Tenant's Mailbox Plan; MaxSendSize: {$($MaxSendSize)MB} ; MaxReceiveSize: {$($MaxReceiveSize)MB} " -LogLevel Output -LogObject $O365_global_logobject
        Try {
            Get-MailboxPlan -ErrorAction Stop | Set-MailboxPlan -MaxSendSize "$($MaxSendSize)MB" -MaxReceiveSize "$($MaxReceiveSize)MB" -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an error increasing the Retension duration.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        Try {
            Write-Log -LogString "Attempting to set all MailBoxes' Max Send/Receive limits; MaxSendSize: {$($MaxSendSize)MB} ; MaxReceiveSize: {$($MaxReceiveSize)MB} " -LogLevel Output -LogObject $O365_global_logobject
            $Mailboxes = @()
            $Mailboxes = Get-Mailbox -ResultSize unlimited -ErrorAction Stop
            $Mailboxes | Set-Mailbox -MaxSendSize "$($MaxSendSize)MB" -MaxReceiveSize "$($MaxReceiveSize)MB" -ErrorAction Stop
        }
        Catch {
            $Mailboxes = @()
            Write-Log -LogString "There was an error increasing the Retension duration.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    End {
        Write-Log -LogString "Set-O365TenantMailBoxMessageSizeLimit completed..." -LogLevel Output -LogObject $O365_global_logobject
    }
}