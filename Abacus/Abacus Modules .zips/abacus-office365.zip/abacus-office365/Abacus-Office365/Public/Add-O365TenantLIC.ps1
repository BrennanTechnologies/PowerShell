<#
.SYNOPSIS
A wrapper function to easily add additional licenses to an Office365 Tenant

.DESCRIPTION
This function is used to more easily increment licenses for an Office365 Tenant via the CLI through API calls to the PartnerCenter.

.PARAMETER LICName
The Microsoft License Name matching the desired license(s) that are to be added to the Tenant's subscription.

.PARAMETER LICOfferId
The Microsoft OfferID matching the desired license(s) that are to be added to the Tenant's subscription.

.PARAMETER Quantity
A integer value matching the number of licenses in which will be added to the tenant's subscription.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Add-O365TenantLIC -LICName {LICName} -Quantity 1 -TenantId {$TenantId} -Office365Instance US

.EXAMPLE
Add-O365TenantLic -LICOfferId {LicOfferID} -Quantity 1 -TenantId {TenantId} -Office365Instance US

.NOTES
By replacing the LICOfferID, this function can be used to increase other licenses types outside the default.
#>

Function Add-O365TenantLIC {
    [CmdletBinding(DefaultParameterSetName = 'ByLicenseId')]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(ParameterSetName = 'ByLicenseId')]
        [String]$LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("Office 365 E1", "Office 365 E3", "Office 365 E5", "Office 365 F1", "Azure Active Directory Premium P1", "Enterprise Mobility + Security E3")]
        [Parameter(ParameterSetName = 'ByLicenseName')]
        [String]$LICName = 'Office 365 E3'
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [Int]$Quantity
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateSet("US", "UK")]
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$Office365Instance
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject
            Start-O365MsolService -Office365Instance $Office365Instance -ConnectToPartnerCenter
        }

        Switch ($Office365Instance) {
            'US' {
                $CountryCode = 'US'
            }
            'UK' {
                $CountryCode = 'GB'
            }
        }

        # Check Partner Center Connection
        Try {
            Write-Log -LogString "Testing to see if we already have connection to the Partner Center" -LogLevel Output -LogObject $O365_global_logobject
            Get-PartnerLegalProfile -ErrorAction Stop | Out-Null
        }
        Catch {
            Write-Log -LogString "Connection to Partner Center is not started or has failed: `n $($_.Exception)" -LogLevel TerminatingError  -LogObject $O365_global_logobject
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "There was an error finding the Tenant based on the supplied TenantId" -LogLevel TerminatingError  -LogObject $O365_global_logobject
        }

        Switch ($PSCmdlet.ParameterSetName) {
            'ByLicenseId' {
                $LicenseType = $(Get-PartnerOffer -CountryCode $($CountryCode) -OfferId $LICOfferId)
                If (   $Null -eq $LicenseType   ) {
                    Write-Log -LogString "Not Matching LicenseType was found based on the provided license ID {$($LICOfferId)}. Please verify the ID and try again." -LogLevel TerminatingError  -LogObject $O365_global_logobject
                }
            }
            'ByLicenseName' {
                $LICOfferId = Get-O365LicIdFromLicName -LICName $LICName
                $LicenseType = $(Get-PartnerOffer -CountryCode $($CountryCode) -OfferId $LICOfferId)
                If (   $Null -eq $LicenseType   ) {
                    Write-Log -LogString "Not Matching LicenseType was found based on the provided license ID {$($LICOfferId)}. Please verify the ID and try again." -LogLevel TerminatingError  -LogObject $O365_global_logobject
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception." -LogLevel TerminatingError  -LogObject $O365_global_logobject
            }
        }
    }
    Process {
        Write-Log -LogString "Gathering information for tenant $($TenantInfo.CompanyName)" -LogLevel Output -LogObject $O365_global_logobject
        $CustomerSubInfo = Get-O365TenantLIC -TenantId $TenantInfo.TenantId -Office365Instance $Office365Instance -OnlyActive | ? { ($_.OfferId -eq $LicenseType.OfferId) -and ($_.BillingCycle -eq 'Monthly') }

        $CurrentLicCount = 0
        If ($Null -eq $CustomerSubInfo) {
            Try {
                Write-Log -LogString "No available {$($LicenseType.Name)} licenses detected on $($TenantInfo.CompanyName)..." -LogLevel Output -LogObject $O365_global_logobject
                $CustomerSubInfo = Get-O365TenantLIC -TenantId $TenantInfo.TenantId -Office365Instance $Office365Instance | ? { ($_.OfferId -eq $LicenseType.OfferId) -and ($_.BillingCycle -eq 'Monthly') }
                If ($Null -eq $CustomerSubInfo) {
                    Write-Log -LogString "Attempting to add an initial {$($LicenseType.Name)} licenses to {$($TenantInfo.CompanyName)}..." -LogLevel Output -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId -Country $CountryCode -UserCount $Quantity -LICOfferId $($LicenseType.OfferId) -ErrorAction Stop
                    $CustomerSubInfo = Get-O365TenantLIC -TenantId $TenantInfo.TenantId -Office365Instance $Office365Instance -OnlyActive | ? { ($_.OfferId -eq $LicenseType.OfferId) -and ($_.BillingCycle -eq 'Monthly') }
                    Write-Log -LogString "{$($Quantity)} {$($LicenseType.Name)} licenses were sucessfully initialized for {$($TenantInfo.CompanyName)}." -LogLevel Output -LogObject $O365_global_logobject
                }
                Else {
                    Write-Log -LogString "Attempting to rehydrate a suspended subscription of license type {$($LicenseType.Name)} to {$($TenantInfo.CompanyName)}..." -LogLevel Output -LogObject $O365_global_logobject
                    Set-PartnerCustomerSubscription -CustomerId $($TenantInfo.TenantId) -SubscriptionId $($CustomerSubInfo[0].SubscriptionId) -Status Active -ErrorAction Stop -ErrorVariable errSetSubLic
                    $CustomerSubInfo = Get-O365TenantLIC -TenantId $TenantInfo.TenantId -Office365Instance $Office365Instance -OnlyActive | ? { ($_.OfferId -eq $LicenseType.OfferId) -and ($_.BillingCycle -eq 'Monthly') }
                    Write-Log -LogString "{$($Quantity)} {$($LicenseType.Name)} licenses were sucessfully initialized for {$($TenantInfo.CompanyName)}." -LogLevel Output -LogObject $O365_global_logobject
                }
            }
            Catch {
                Write-Log -LogString "There was an issue initializing {$($LicenseType.Name)} licenses for {$($TenantInfo.CompanyName)}." -LogLevel TerminatingError  -LogObject $O365_global_logobject
            }
        }
        Else {
            $CustomerSubInfo | % {
                $CurrentLicCount += ($_.Quantity)
            }
            $DesiredLicCount = ($CurrentLicCount + $Quantity)
            Try {
                Write-Log -LogString "Attempting to increase the {$($LicenseType.Name)} LIC by {Quantity: $($Quantity)} to {Total: $($DesiredLicCount)} from {Current: $($CurrentLicCount)} for {$($TenantInfo.CompanyName)}" -LogLevel Output -LogObject $O365_global_logobject
                If ($CustomerSubInfo.Count -gt 1) {
                    Set-PartnerCustomerSubscription -CustomerId $TenantInfo.TenantId `
                        -SubscriptionId $($CustomerSubInfo.SubscriptionId[0]) `
                        -Quantity $($CustomerSubInfo[0].Quantity + $Quantity) `
                        -ErrorAction Stop `
                        -ErrorVariable errSetSubLic
                }
                Else {
                    Set-PartnerCustomerSubscription -CustomerId $TenantInfo.TenantId `
                        -SubscriptionId $($CustomerSubInfo.SubscriptionId) `
                        -Quantity $($CustomerSubInfo[0].Quantity + $Quantity) `
                        -ErrorAction Stop `
                        -ErrorVariable errSetSubLic
                }
            }
            Catch {
                Write-Log -LogString "There was an issue trying to increment {$($LicenseType.Name)} licenses.`n Exception: {$($errSetSubLic)}" -LogLevel TerminatingError  -LogObject $O365_global_logobject
            }
        }
    }
}