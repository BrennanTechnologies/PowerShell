<#
.SYNOPSIS
A utility command to map O365 license names to License OfferIds.

.DESCRIPTION
A utility command to map O365 license names to License OfferIds.

.PARAMETER LICOfferId
A Microsoft License Offer Id we want to get the matching License name for.

.EXAMPLE
Get-O365LicNameFromLicOfferId -LICOfferId {LICOfferId}

.NOTES
General notes
#>

Function Get-O365LicNameFromLicOfferId {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True)]
        [String]$LICOfferId
    )
    Begin {
        [String]$LICName = ""
    }
    Process {
        Switch ($LICOfferId) {
            '91FD106F-4B2C-4938-95AC-F54F74E9A239' { $LICName =  'Office 365 E1' }
            '796B6B5F-613C-4E24-A17C-EBA730D49C02' { $LICName =  'Office 365 E3' }
            'A044B16A-1861-4308-8086-A3A3B506FAC2' { $LICName =  'Office 365 E5' }
            '6FBAD345-B7DE-42A6-B6AB-79B363D0B371' { $LICName =  'Office 365 F1' }
            '16C9F982-A827-4003-A88E-E75DF1927F27' { $LICName =  'Azure Active Directory Premium P1' }
            '79C29AF7-3CD0-4A6F-B182-A81E31DEC84E' { $LICName =  'Enterprise Mobility + Security E3' }
            Default {
                $LICName =  $Null
                Write-Log -LogString "Unhandled Exception.`nException {No known  matching LicenseId for {$($LICName)} license name.}" -LogLevel Warning -LogObject $O365_global_logobject
            }
        }
    }
    End {
        Return $LICName
    }
}