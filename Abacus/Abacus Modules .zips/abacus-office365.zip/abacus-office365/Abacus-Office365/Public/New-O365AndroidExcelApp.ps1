<#
.SYNOPSIS
A command for creating the base Android Excel App.

.DESCRIPTION
A command for creating the base Android Excel App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365AndroidExcelApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365AndroidExcelApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{"@odata.type":"#microsoft.graph.androidStoreApp","appStoreUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.excel","categories":[{"displayName":"Productivity","id":"ed899483-3019-425e-a470-28e901b9790e"}],"description":"Microsoft Excel","developer":"","displayName":"Microsoft Excel","informationUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.excel","isFeatured":true,"roleScopeTagIds":[],"largeIcon":{"type":"image/pngapplication/octet-stream","value":"iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAIAAACyr5FlAAAAA3NCSVQICAjb4U/gAAAWrklEQVR4nO2de5hcRZnG369O32am55YQQ0IC4Q5BFDAuEMAQkauACjziekFwV/HBFZXNurLeFq8sj8guCmaXi7txQUXUgAisiMEIBiQmiAsB5JYESAJJJjM9M90zfbq+/ePc65zqmUz39Bx26vdM0t11qupUn3r7q68upw4xMwyGJMRUF8CQXow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxajDgMWow4DFqMOAxaMlNdgHFh9okAQEStPmNqr7tfMAKh1ZclCQam8FKRc0UYRGiVUFJqOZiZmWu23TfY/+TW57f0v8ZTWDMMkbFQyEyVOhiwhHX4HvvObp/Z29HNxGiJPtJoOZxfiG3bN6/5ycefuxu1flhtaLlRDRVIotCO+XOmrAAAwKgOn5fbe9m8U4+e/yZJkogmWx9pFIeUcmRkdPnqFZe9/Ks5uRltEFNq0MHM+UKhOHePKSyDwy62n63ZD+3z3mPnvwli0sWRxt4KgdY8t+6yzffsm5tZADGYvRZ/qv4w1QVw/ropc3Am+4WNd/YN9WPyf9WpEwczy1rt7hcfQbYzDW5o2uiEtYr7Hn/1OSIx2X5YKsUh+eoX79jXaktdg5cSrMLzg1ta0HtKnTgAMEvI2lR6oKmHBaZjswLAtm2QNdWlSDNUq9ks5WSfJnXiYOZqtQpKXcFSBJFdq9Vq01IctVothQVLFTWWUtYm+yxprAMpJWhqhzZSD0NKnuwxqjSKw8H4o3VwO7GTfInSKA6e2imu1wOtuTxpFIchJRhxGLQYcRi0GHEYtBhxGLQYcRi0GHEYtBhxGLQYcRi0pFIc5AwMm1HSKSZ1tyYIEpYQGK1yVTJzk6cPiECRu2Baf6fQ64jmiKNij+4Y2FmujkxseVI4DTEGB0oYsqtiMDTruJuztPG4jiYIwsqIfJYsgYyAf+tUWm6cShdNEMdjmzbc/vDKB1/d8NvyVkAGFRmpoVBIQni0Mkl0Wl3D5X4vJgPxhF6QdCcnQ3EZHJOTZ4QEWZlcIV/sEoUMMsKf2WSwsSIKjYrjzkfvfdfPT0fXUoh8J2VdF4bDV5n9GWYXgnd3H7P/CaHqZcoQeRXs1XNcGRxMW3PonxsYxA/NbjMk2yPlUrUy3DFztlXIIiNAABMIzEYfERoSx1Nbnn/XLy7Kz3hn0bfJTpX4V5gZRM6lj+DUNSmplMRe9Sc2VRyt/IiRiL2LhhCRlLWRgV0FMUMIgiBXTEYfUSYuDgnct/4+FPYvghLMOPyqVQPjrYoaya9tnbVI+JSsg4QQx44QVauVXLlC2XaC8PpHvgWL6oMBnsp7dcM416Y1+p24OErDpWe2b4JVcD8rda6pV/3vPZZJXWWEUo9bFuFXZrAceGEjCJS1PHfVtXCK8WApC9095dJQC+4GGAcEuyT33q8FoxATF0dN1krVYbBQ/b44HBOCEhAYHo3BCOWcIIt4SPCRlED2syIBS0AAGQsCEOR0WkImxEMSZS1RyKVBHASglodoxQDVxMXBzDJysTSGl+O2v64PUd9gaGWBJGUgrLZAFn4CyZCgDIMJEhCO36FZmzn1wvBoVUmaNAimMRhjyCIcOKa1iGfi2pCxes5BOkVSDMkAWDKRWdCcQOPi4ERlJK2aT/Q6qb4sgojhHIKDXi836iTEctKcWjIASIYgSAkICDYq8WlYHEmtwO4YjCQNKaYhnIPOPCRFSxCo6uswGJBgyWQ5mjDKCGje3EpyHxXRygi9212DkZi7Rjpx9yLBBXbKLEEswULbj53GNE0ciWKI1cdueZ2J8cfsoSQaDI3pkiBmZhADDG801uDSmDic+h5Pf8RXBiNWAVFZUDQwWSjh8fZg/Hx8BsNxdBggRxbkfgsvgpGHR4OWg4P2YcwfNwPATllFeTNIePXkpRf5TH52J1lJfdpISF9tFJWNsTiE3JyeTFv01IkGQ7FSDJbETnfW6CJCQ+LgRGcwOOy9eEd21kZPnnXQ3y36bKkyGK4JAkqV4ase/dEmu1x0duaI5+koQ9onds7+xGnLRu2RUDhZwnrg6TXLX/hdT6ZNIwvNoG3YkiW6QdOYhsRBpFGGxr0oWtn7Nt1x+0eu7sq1K1kxQNXRj/3+u5zbQ62rcN47Vl1z4RNHLFioJN/Wv/199387K3LJjmdMGfXuTzcti0djo7B+0xAOCbsX0SrIgZCdf/3dN8nYj5SA0445PVuzh8J902gOfZVX//aof4wrA8C1d/07Brd1kBWRlOcS1VVGclENaHgNqXrV3cDEa80M5vZsz+Xrbn5m87PxvOb37vmFRRdVy6+460cjPgePsISQly79cDzh2uce/8b65e3te6k1rciCXaKpNaNwhobFEWoBEuvDP+xVSR4E0XHx7V+2OWFjmk+cciFgl9w9azjIlzE8uvO6oy89fMGhSpL+4dK/3XUd8nvlELIWiI7bxkXBrlh38/tOLxqf3GO13xE5GFh1vy5mZIqrN//wfx5bHc9rRrHnxiWfrw6/EM4ejCqAnevPWfKeeJK71t733xtv6MkUI+6FYjASimRkMTYNi8PvCCQqw4sSfcvoOenKe779ct82JQUBpyx6x/E9b+xj28scAAYHHrnxvFv37JqpxN86sOODN57b3fl2d8OXJPci3G2NrD8y8hiLBh1SjSzgjUgF7mkoHmMGWQ8OPnvnw3fHrc38mXPOP/xMlLeA3XHLPrty9MwT3330aUrMqqxde8f12OstxDLuXkBpSXxZhGQ6wW89bWi8t6KEBEZbUUe0F8LFtnmX3PeR57ZsjGWBC97xfgw+NcLSreDRbf+09OMzi71KtEc3/PGbj32nmO1KtBZagxHyYwz1aeqCIqUdSezoei9ZJhSP+/SP/7kWq6WuQseKc348XFoPUL+sLplxxMmLTlLilCpD77vtc8gfkIn1RxKKpBQmLFmDnsbEEdzzEVgLVRas1E3wq+3OtP1y60OrkjzTJYcft2jGcbukje2rv3jGp9qyeSXCf666bXP/n3utYLw8wb2ItHpJKjH6qEvDPofXSQl5nQi7F5GQkDwAFgDyc7907zVbd72qZLz3rL0+c8wHMPDAh4+47MTDjlGO/vnFJy/9zbeynW9kcMLohTo7E7ZeEf0YbdSnGQ5p+EL7com7fhGhuHFmiPyaHX+85aGV8bzfefyZ2IILjz3XEpF90Efs0RUP3AbKdLjz7Up59O2IO2vrzLU19L2nCU3wOTjhBxocjL5GhMKAZNndcciyn1/8/GublZTd+Y5bLl35lgPfrIT/ev3qb/3hiu78zLruBSKy8D5GZgrNUMdYNDxCGq4JxNwL1eGIyoPZzWLPY6+58/oRe1TJ/fzFZ3UWOsIhfcMDZ956MnrfFmo74u4FglP7RoOjyjAtyjhofG5FIwIkNflBhUbGKItW+3c3rHj0qT8quVuxZyf86Fc/hnVItx+eOHoRjHm4CgxkwdECG+rSjFnZuB+K2A80LCHlFgHmDBiF/U744SdLlaE6Z3v0mccuWf3lQn62nzB6zvBH9pURKWpi2cZLetTUImk3vvo8cod89G2kMqJ15Ye7Ib1Wvq/0/A333XLZWR/Tner9Ky5Gbl6eKDaohfjHqCyQKGImQBAsYguUIRbk3HRP0fvJWDIsITKp2eiGsrBEC+TR2EowAJDxVmO3ZOEGMDD6ytye2XVOd96h775y7XJY+2qsRexUHI8TLhhld1Uzu2pUsMiyyBIQRIJAIKJw4UiiOrOy7dVtafBhCYTys3zMWyD0N+c1iQbEkWDYERfKONeC7xrZcd7+F5173DvrnPCSUz7866dXrR0d6hbZMQxGHaMSUhITOEvICmQEBMgSri1Rb6RmZKxMLlenbC2EgF5YrbhXtimzstEPfn8kcTA75nAAGOQarMIV534uK+qJdf6suZef9mkMPc3REwWeMEc+heIoTmgQt86XSS+tMmDNEmDk6qteJ5Kqw/tEDLv0+A9O+szCvQ9SMt24/WUl5JzFZ5wx99SB0VK4mwonbxnqjygqiThwzrBq6y7x65dmLPaJyyLBPIRD2A1kBqOvVoHV94GT3qvku2XXazev/H78fN/+0BUorR/1xjiZw9mHGg7myEewN4/vqalFLv/rmGZYjoj9VmSBqCz8PzewzBKj25+49CnFr5Lg5b+86Sv/e+3jzz2hnO2geQfc9J4flMsvSda0I6EXtd1BqGkzS8zHojk+Bytr7zhaYeGQkHoIGClvvnrxJw/dJ9agvPLiV/50C9Dxk4d/Ed0FBAS86/izFuUXlKStmiVljMtbHhYaB4sq1VCXJiz2SXAvQi/e25Ar4NFnV5Z2Hfbxsz4av9Xsip9dg5rs7ljwtXsu/9MLTypHZxa7r7nwKry2Jsjft0ZKYxGscI1p10zLjkVD4tC7F7FqCFcEMzNLBrav+fr5X26PrdV47IUn/2vtd3rysyAl5hz1ryuvi8+hHrfwrcuO++LA0ObkNoVDBoNj5THuxvhoRBxjuhestCNAsIZvoPzS1ad9968OPlLJtGKPXv/z6/GGtzoROzIdKzbdu2r975RoBFx8xkWHdi4Y8G9xiNonzwFKMmAw8hgXTXNIk9wLtQL8BmhA2id0HvT+k86PT639dv2DN2y8s2gVnMQWA1b3TQ/cWiqr0y4HzN33K6d+Cn1riMmXZmCk6rjGxniMj8YX+3Ds56i5RSBcW689+Pmz/37Pnj2U/IYqw1/41XXIvcEKeRFdma4fPrn8kQ3qnC2Ac5acjQL67WFHi4HXqXONw82cYSyaNwrL3v/1ZcHoH3rpU4u/dOpRS+N5/OTBO9Zu+ll3piOQHAOQonfxydctqdZstfQknlj2FCpbh6X07Eb9diSIwEYiY9GkZiW47uG6iS3tZO7n6mHt8y49/SPxbHYO9X/63q+jZzEHUzauD9EBgULv3b+/J57qkH0OvPL4y+zyRqWTErQjMXvm6lVxkgwxmnXHW91bzeB7AIRdD33j7Mv323OfeE4/vf/2/upgF1lq1TqrxQoHXHv/za/sUG+SEyQ+9p6P7p+dV5KjIWMTSs4xWYSKbqhDw+Mc9d0L1wa4e6T0j+w8e8GHzj76lHhOm1596bO/W4783NhiLfely8r/5uWV9697IJ62t73rOx/4Jrau9fYk9ZNHWhnNeIxBSzNnfpNvEZCuekakDSGvueCriWmvvus/dlW2d5E3K5vQA+Jc97EX3Py+/spgPPnSI4//h7d/qTT6mhdZVW1Er75ojD7q0qzVTbFlG7HFWhVZvWD+iX94et3DGx4NRyRQle1rV3+1e88TQk5iuNvpvhRAo3scdPn3v7Z04bFVuxqOkM1mO9uLoGzQi04smRk+3x2aIA51TWhSvYLRLfIrNj+y4plbAc85cA9KUK579tuYpZIEYG/nP/dIV26P7z2x8nvr/iWUv0du/878LG07wkqp/Me7GLQ0uNVk9PYg1VarxqPbKqD4xqhH6MZhNx81CfteixfUmZ+B/OJoX6OuhxG3Fu6sLEVDDSqNWw5nG9AkawGlmr33+jiKsPRTqazKyIuZ1EUKJVS71nW/2bSnqRvjJ1Sz96L2HxPiKIdiKaPSCTL0I6q9JjVhyJYwzGMSxqbBfUjjW1/EqhzK2Bg7jkSydxLJINFg+K96rzOcNslgJORvSKIZ962EXAeEX+K+BWK1leg+jttaQJFF/XZEOYW7aaGxH1qasfd5ghcZjgBVGYgdjd6/mBAhCEn0SqKHEmSRpCE2shiDBh7j5f6n3klWz2Ao7YL3fox2ZJyVHcREWE+6mBx0ZY1Kkpm4OAhkQcRqwnlBxGKr7U7wcVyyiEbYjXZEGYFRVMtQJVsHSpOEWlWSiYsjY1ld+Q6wO40ekoX3orQuUe/BE4ziSCrxIwnHGNSKCii0LXtUQMrHcV1oAhMkp2XYrNaiTvjExVHs6Dxw1n74y11sFd2ghB99QrMStS6olzZRFhhbGYgrw7cWHmQzjbL7xFAvLPmrCmT6q5n+avLR1jOwFQtbsTXRxCfeLNDJx5yCoWcGgkHMBOfUew2v+PUje0fZe/GDWaMMjg2rREKiM/J+N5ujvhGDCTRQFSMSQoQePduqRz03gPvo2/HavIZoaFZ24d4H/vSDd+KVBwdG+gZk1WZZk1yTssbOH7sfpaxJtplrLL2j7B1lN7L73o3v5F9vJziOyIKjugi0xVHNOekEqFLLvDyCrHCDUuVS1MX9Hi0pbaPjHOcsOWvdXo/ftur237y0/g+lp3wXBOxc8lrQYwyq1g79jqX7Q4ZvTgiiWKAZmbg/G3yMBLLSdijvnQBn/o4ZNouBqvXyCBVzEOQ8UZbAgPV60UfLaMKs7JEHHH7I3gdd0r+jPFKp5/mP04diDA0OHnXYEcUl+4ZCKRIjklXs8VsceUi5nwE5j6ivsrCJChYEEZHz/Hp2tuRgYfQRpjnrOdpy+fmz5jYlKyllf98uAFSym+GTO0+oZxIEIhKEjKA2izKCSDhbcZDzHyc9xX56k5qtjDyklDVZA0BZC+M2NxGi1UwgEDuWA0KQ5WzfQxD+Pi0EYiZB5smyUVInDh/KWJjwELfapggigAQEueKwXJWQgGc6/MiNlPr/FSkWh2VNzHCE83BfhePnEpGnDEEkBARBEJynUXv+h8EnxeLINGNjGfIcVrdZIadxgQVnezjPbBhRJJBicWQbtxxuTo7DySASBAESwnFOybUcxmYkk2ZxeCNUE8Qb7mTHqxAEgIgE4JsQx2w4o44w+lBJqzjmuA5pY7n4HRawu38kAZ4+CBAJyjBNjE9axdEOIRr2OYjhuhzeMIZT8QQIEIQ3am7UkExaxVEALNEEy+HaBXLHVV3X07MTvpEwZiOJtIojC8o0o56CeSqKTDL6BiN0EqMMhbSKw4I7dtkgugyUcKOLJNIqDuG1BZOMUUUd0isOU21TTis23ze8TjHiMGhJozgYZughFaRRHBQ8dNKgoSVbBKRRHACQUxcDGkJwa4xr6sRBREKIv3n7J7ZVdkx1WdIIETBUmj9nnjuhOJmkThwAhBBLjzgB5WenuiBpZFu1fMT84xcuOFhO/iPX0ygOEnTkwW9aduxntw7+ZZSlu1bH/IG22mVpDy4785Lurq4WjAOlcRBMCFHI5f/69PMzudxV634qSxuQmzPdOzBcw8i2JQvOvHDJe4885M3OIrbJPiclPNpzSpFSlsvl7du3D/QPDJeHS4Ol57du2j6wk1lOY32wEJkD5+4zs3tmd7Grrb2tt7e3t7c3l8tNqkRSZzmIyLKsQqFQqVTsmt3T3bOod4ZZpAVASsngTDZTKBTy+Xwmk5ls45FGcWSz2UKh0N7ebtv26Oioc1HSZuFaibsIRVDGyuTz+ba2tnw+P319jra2NiIionK5XK1WpZSIb8QwbXB0YFlWPp/v6OgoFov5fL4JK+XGPG86r7iUslarVSqVkZER13ikspwtQwhhWVYul3PaFCGmpUPqw8yORGq1WsKTz6cZjivmSIRadaNNesXhkPLitZgWr3FJuzgMU0gaR0gNKcGIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6DFiMOgxYjDoMWIw6Dl/wDpcZgJhox+mwAAAABJRU5ErkJggg=="},"minimumSupportedOperatingSystem":{"v8_0":true},"notes":"","owner":"","privacyInformationUrl":"","publisher":"Microsoft Corporation"}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            $CatCounter = 0
            While ($CatCounter -le 10) {
                Try {
                    $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                    Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                    $CatCounter = 10
                    Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
                }
                Catch {
                    $CatCounter++
                    Sleep 2
                }
            }


            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}