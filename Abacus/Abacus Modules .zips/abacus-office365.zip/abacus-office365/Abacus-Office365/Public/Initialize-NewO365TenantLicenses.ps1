<#
.SYNOPSIS
A wrapper function for accepting the MSCloud EULA and adding initial licenses.

.DESCRIPTION
This function is used in conjunction with New-O365Tenant in order to accept the Microsoft Cloud Agreement which is now required for MSPs along with assigning some initial licenses based on the number supplied.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Country
The Country ID in which the tenant is located.

.PARAMETER UserCount
An integer value matching the number of users the tenant will have as this will generate the respective number of licenses.

.PARAMETER ContactFirstName
The given name of the primary contact for the company.

.PARAMETER ContactLastName
The family name of the primary contact for the company.

.PARAMETER ContactEmail
The e-mail address of the priamry contact for the company,.

.PARAMETER LICOfferId
The License OfferId matching the desired license types to be used when assigning licenses to the company.

.PARAMETER LicenseBillingCycle
The desired billing cycle to be used for the new license subscription. By default this is value is set to monthly.

.PARAMETER AcceptanceDate
The acceptance date of the cloud agreement.

.EXAMPLE
 Initialize-NewO365TenantLicenses -TenantId 9b03cdab-f4c4-4042-8ffa-62a58ac0a998 -Country US -UserCount 1 -AcceptanceDate 'Friday, November 30, 2018 11:48:25 AM' -ContactFirstName Allan -ContactLastName Sheyman -ContactEmail asheyman@abacusgroupllc.com

.NOTES
This is a required setup option when adding new Tenants as Microsoft requires this EULA to be accepted in order to use the PartnerCenter for obtaining licenses and such.
#>

Function Initialize-NewO365TenantLicenses {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [String]$TenantId
        ,
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [String]$Country
        ,
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [String]$UserCount
        ,
        [ValidateNotNull()]
        [String]$ContactFirstName
        ,
        [ValidateNotNull()]
        [String]$ContactLastName
        ,
        [ValidateNotNull()]
        [String]$ContactEmail
        ,
        [ValidateNotNull()]
        [String]$LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
        ,
        [ValidateNotNull()]
        [String]$LicenseBillingCycle = 'Monthly'
        ,
        [ValidateNotNull()]
        [DateTime]$AcceptanceDate = $(Get-Date)
    )
    Begin {
        Try {
            Write-Log -LogString "Attempting to query the PartnerCenter for the Tenant's information" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $CustomerInfo = Get-PartnerCustomer -CustomerId $TenantId -ErrorAction Stop
            Write-Log -LogString "Tenant information queried sucessfully" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Catch {
            Write-Log -LogString "There was an error querying the tenant's information via the PartnerCenter" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
    Process {
        # If no Contact is supplied, assuming Agreement was already accepted.
        If ([String]::IsNullOrEmpty($ContactFirstName) -eq $False) {
            # Before we can add any licenses to our tenant we must first accept the EULA
            Try {
                Write-Log -Logstring "Generating request to accept the Microsoft Cloud Agreement for the tenant" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $MicrosoftCloudAgreement = $(Get-PartnerAgreementDetail | ? { $_.AgreementType -eq 'MicrosoftCloudAgreement' } | Select-Object -First 1)
                New-PartnerCustomerAgreement -TemplateId $($MicrosoftCloudAgreement.TemplateId) `
                    -AgreementType MicrosoftCloudAgreement `
                    -CustomerId $TenantId `
                    -ContactEmail $ContactEmail `
                    -ContactFirstName $ContactFirstName `
                    -ContactLastName $ContactLastName `
                    -DateAgreed $AcceptanceDate `
                    -ErrorAction Stop
            }
            Catch {
                Write-Log -Logstring "There was an issue accepting the Microsoft Cloud Agreement for the tenant.`n {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
            # A small wait just in case there is a little bit of processing time
            Sleep 5
        }
        $CustomerOffer = Get-PartnerOffer -CountryCode $($Country) | ? { $_.OfferId -eq $LICOfferId }
        If (   ($Null -eq $CustomerOffer)   ) {
            Write-Log -LogString "There was an issue enumerating license information for the tenant" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Else {
            Write-Log -LogString "Available Offers were found" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        #Create a LineItem object for our order containing the licenses type, name, id, and quanitity which matches our supplied user count
        Try {
            Write-Log -LogString "Generating our LineItems for our upcoming cart creation" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $LineItems = @()
            $lineItems += $(New-Object Microsoft.Store.PartnerCenter.PowerShell.Models.Carts.PSCartLineItem$lineItems)
            $lineItems[0].FriendlyName = $($CustomerOffer.Name)
            $lineItems[0].BillingCycle = $($LicenseBillingCycle)
            $lineItems[0].CatalogItemId = $($CustomerOffer.OfferId)
            $lineItems[0].Quantity = $UserCount
            Write-Log -LogString "LineItems: $($LineItems | ConvertTo-Json)" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Catch {
            Write-Log -LogString "Failed to create our LineItems for our license create" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Try {
            Write-Log -LogString "Generating a cart object for our license purchase order" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $Cart = New-PartnerCustomerCart -CustomerId $($CustomerInfo.CustomerId) -LineItems $LineItems -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "Failed to generate a valid cart" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        #Place the order for subscription
        Try {
            Write-Log -LogString "Place a license request order to Microsoft with our cart and lineitems" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Submit-PartnerCustomerCart -CartId $($Cart.CartId) -CustomerId $($CustomerInfo.CustomerId)
            Write-Log -LogString "Order placed sucessfully" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Catch {
            Write-Log -LogString "There was an error with our License order to Microsoft" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
}