<#
.SYNOPSIS
A wrapper command around Abacus-Okta to create a new client configuration.

.DESCRIPTION
A wrapper command around Abacus-Okta to create a new client configuration.

.PARAMETER TenantId
The TenantId of the tenant you are looking to create an Okta config for.

.PARAMETER Office365Instance
The Office365 instance where the tenant's environment lives.

.PARAMETER CloudRegion
The matching region in where the client is located. This is used for Okta groups.

.EXAMPLE
New-O365OktaClientConfiguration -TenantId {TenantId} -Office365Instance {Office365Instance} -CloudRegion EAST

.EXAMPLE
New-O365OktaClientConfiguration -TenantId {TenantId} -Office365Instance {Office365Instance} -CloudRegion WEST

.EXAMPLE
New-O365OktaClientConfiguration -TenantId {TenantId} -Office365Instance {Office365Instance} -CloudRegion UK

.NOTES
General notes
#>

Function New-O365OktaClientConfiguration {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [String]$TenantId
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("EAST", "WEST", "UK")]
        [String]$CloudRegion
    )
    Begin {
        $TenantInfo = Get-O365TenantInfo -TenantId $Tenantid -Office365Instance $Office365Instance
        $TenantDomains = $($TenantInfo.DomainName)
        $TenantDomainsCount = $($TenantInfo.DomainName | Measure).Count
        $TenantDomain = $($TenantInfo.DomainName | ? { $_ -notlike "*onmicrosoft.com" })
        If (   $True -eq [String]::IsNullOrEmpty($TenantDomain)   ) {
            If ($TenantDomainsCount -gt 1) {
                $TenantDomain = $TenantDomains
            }
            Else {
                $TenantDomain = $TenantDomains
            }
        }
        $OktaApp = Get-O365Credentials -SecretName "$($TenantInfo.CompanyName) - Abacus Okta - Microsoft AppId" -SecretType MSAppID


        If ( $Null -eq $OktaApp.AppId -or $Null -eq $OktaApp.Key ) {
            Write-Log -LogString "Okta app for Tenant {$TenantId} could not be located in secret... Please ensure it exists..." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        If ($False -eq [Boolean]$(Get-Module -Name Abacus-Okta -ListAvailable) ) {
            Write-Log -LogString "Could not locate the Abacus-Okta module..." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            Try {
                Import-Module Abacus-Okta -Force
                Connect-Okta -ErrorAction Stop
            }
            Catch {
                Write-Log -LogString "There was an issue loading out headers to connect to Okta..." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
        }
    }
    Process {
        $Group = New-OktaGroup -Name "Company-$($TenantDomain)" -Description "Created for tenant $($TenantInfo.CompanyName) through Abacus automation."

        Sleep 2

        $IDPS = New-OktaIDPS -Name "Azure - $($TenantDomain)" `
            -Type MICROSOFT `
            -AppId $($OktaApp.AppId) `
            -AppSecret $($OktaApp.Key) `
            -Assignments "Company-$($TenantDomain)", "FlexPublicCloudUsers", "AppPublicCloud$($CloudRegion)"

        Sleep 2

        $RoutingRule = New-OktaRoutingRule -PolicyName "$($TenantDomain)" `
            -IdentityProviderId $($IDPS.id) `
            -Domains $TenantDomains
    }
    End {
        Return $Results
    }
}