<#
.SYNOPSIS
As Azure's Graph API requires an object ID for most add/remove commands, this function is used to convert a UserPrincipalName into an object ID by querying a tenant for the matching object.

.DESCRIPTION
As Azure's Graph API requires an object ID for most add/remove commands, this function is used to convert a UserPrincipalName into an object ID by querying a tenant for the matching object.

.PARAMETER Object
The Object identifier (generally a UserPrincipalName or e-mail address) which is passed to Microsoft when querying for the respective Object.

.PARAMETER AccessTokenHeaders
The AccessToken provided by Microsoft which is used in the headers of the request for authentication against the Graph API.

.EXAMPLE
ConvertTo-AzureObjectID -Object <Object> -AccessTokenHeaders <HeadersContainingAccessToken>

.NOTES
This can be used for User Objects as well as DistributionGroups
#>

Function ConvertTo-AzureObjectId {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        $Object
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        $AccessTokenHeaders
    )
    Begin {
        $ReturnResults = [PSCustomObject]@{
            'Object'       = $($Object); `
            'Resource'     = "https://graph.microsoft.com/v1.0/users`$filter=userPrincipalName eq '$($Object)'", "https://graph.microsoft.com/v1.0/groups/?`$filter=mail eq '$($Object)'";
            'Status'       = "NULL";
            'Data'         = "NULL";
        }
    }
    Process {
        Try {
            Write-Log -LogString "Querying GraphAPI for an object matching: $($Object)" -LogLevel Output -LogObject $O365_global_logobject
            $QueryResults = $(Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/users?`$filter=userPrincipalName eq '$($Object)'" -Method Get -Headers $AccessTokenHeaders -ErrorAction Stop)
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "401"
                    $ReturnResults.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "400"
                    $ReturnResults.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "ERR(404)"
                    $ReturnResults.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "ERR(503)"
                    $ReturnResults.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "ERR(504)"
                    $ReturnResults.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $ReturnResults.Status = "ERR(?)"
                    $ReturnResults.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning -LogObject $O365_global_logobject
            $ReturnResults.Status = "ERR(?)"
            $ReturnResults.Data = "$_"
        }

        If ($Null -eq $QueryResults.value.'userPrincipalName') {
            Try {
                $QueryResults = $(Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/?`$filter=mail eq '$Object'" -Method Get -Headers $AccessTokenHeaders -ErrorAction Stop)
                If ($Null -eq $QueryResults.value.'mail') {
                    $ReturnResults.Data = "Object not found"
                    $ReturnResults.Status = "404"
                }
                Else {
                    Write-Log -LogString "Query returned group `"$($QueryResults.value.'mail')`"." -LogLevel Output -LogObject $O365_global_logobject
                    $ReturnResults.Data = $QueryResults
                    $ReturnResults.Status = "200"
                }
            }
            Catch [System.Net.WebException] {
                $CurrentError = $_
                Switch ($_.Exception.Message) {
                    "The remote server returned an error: (401) Unauthorized." {
                        Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "401"
                        $ReturnResults.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                    }
                    "The remote server returned an error: (400) Bad Request." {
                        Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "400"
                        $ReturnResults.Data = "Bad Request --> $($CurrentError.Exception.message)"
                    }
                    "Unhandled Error: The remote server returned an error: (404) Not Found." {
                        Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "ERR(404)"
                        $ReturnResults.Data = "$($CurrentError.Exception.message)"
                    }
                    "The remote server returned an error: (503) Server Unavailable." {
                        Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "ERR(503)"
                        $ReturnResults.Data = "$($CurrentError.Exception.message)"
                    }
                    "The remote server returned an error: (504) Gateway Timeout." {
                        Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "ERR(504)"
                        $ReturnResults.Data = "$($CurrentError.Exception.message)"
                    }
                    Default {
                        Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                        $ReturnResults.Status = "ERR(?)"
                        $ReturnResults.Data = "$($CurrentError.Exception.message)"
                    }
                }
            }
            Catch {
                Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning -LogObject $O365_global_logobject
                $ReturnResults.Status = "ERR(?)"
                $ReturnResults.Data = "$_"
            }
        }
        Else {
            Write-Log -LogString "Query returned user `"$($QueryResults.value.'userPrincipalName')`"." -LogLevel Output -LogObject $O365_global_logobject
            $ReturnResults.Data = $QueryResults
            $ReturnResults.Status = "200"
        }
    }
    End {
        Return $ReturnResults
    }
}