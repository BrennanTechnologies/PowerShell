<#
.SYNOPSIS
This command is utilized to create a new Office365 Tenant in AzureAD under Abacus' control visible through the PartnerCenter.

.DESCRIPTION
This command will create a new Office365 Customer (Tenant) that is managed by Abacus Group LLC. In creating the tenant, the following will also be completed: Create a new Tenant In the AzureAD Environment, Create a secret on the secret server for the new admin account for the tenant, sets a randomized password for the admin account, adds Office365 licenses to the new tenant, disables content to 3rd party apps on the tenant, creates a proofpoint AppId and posts it to secret, enables the admin audit log for the tenant, and disables TNEF settings in the exchange environment.

.PARAMETER OnMicrosoftDomainName
The @*.onmicrosoft.com domain that will be used for the new tenant.

.PARAMETER CompanyName
The Company Name for the new tenant.

.PARAMETER ContactEmail
The e-mail address of the contact.

.PARAMETER Country
The country code where the company is located.

.PARAMETER Region
The region where the client is located. This always the same as the two letter state code.

.PARAMETER City
The city address in where the client is located.

.PARAMETER State
The two letter state code where the client is located.

.PARAMETER Address
The mail address of where the client is located.

.PARAMETER PostalCode
The postal code of where the client is located.

.PARAMETER ContactFirstName
The given name of the contact at the company.

.PARAMETER ContactLastName
The family name of the contact at the company.

.PARAMETER ContactPhoneNumber
The phone number of the contact at the company.

.PARAMETER UserCount
An integer value matching the number of users that the company has and will need licenses for once created.

.PARAMETER Disclaimer
A Boolean value if the company has a custom disclaimer message. This currently does nothing.

.PARAMETER DisclaimerMsg
The custom disclaimer message for a company. This currently does nothing.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER Language
The two letter language code matching the primary language of the company. Generally this is always set to 'en'.

.PARAMETER AcceptanceDate
The date of when the cloud agreement has been accepted. This is usually today's date.

.PARAMETER ClientType
A variable specifying an Abacus specific client type which will configure certain aspects of the O365 differently resepectively.

.EXAMPLE
New-O365Tenant -OnMicrosoftDomainName 'sheymanislands.onmicrosoft.com' -CompanyName 'Sheyman Islands' -ContactEmail 'asheyman@abacusgroupllc.com' -Country 'US' -Region 'NY' -City 'New York' -State 'NY' -Address '655 3rd Avenue Floor 8' -PostalCode '10017' -ContactFirstName 'Allan' -ContactLastName 'Sheyman' -ContactPhoneNumber '6467016956' -UserCount 1 -Office365Instance 'US' -Language 'en' -ClientType FlexHybrid

.EXAMPLE
New-O365Tenant -OnMicrosoftDomainName 'sheymanislands.onmicrosoft.com' -CompanyName 'Sheyman Islands' -ContactEmail 'asheyman@abacusgroupllc.com' -Country 'US' -Region 'NY' -City 'New York' -State 'NY' -Address '655 3rd Avenue Floor 8' -PostalCode '10017' -ContactFirstName 'Allan' -ContactLastName 'Sheyman' -ContactPhoneNumber '6467016956' -UserCount 1 -Office365Instance 'US' -Language 'en' -ClientType FlexPublicCloud

.NOTES
This is usually called by a wrapper script that is handled via a vCommander workflow and almost not directly called with this function.
#>

Function New-O365Tenant {
    [CmdletBinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$OnMicrosoftDomainName
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$CompanyName
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$ContactEmail
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$Country
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$Region
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$City
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$State
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$Address
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$PostalCode
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$ContactFirstName
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$ContactLastName
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [String]$ContactPhoneNumber
        ,
        [ValidateNotNullOrEmpty()]
        [Int]$UserCount = 1
        ,
        [ValidateSet($True, $False)]
        [Boolean]$Disclaimer = $False
        ,
        [String]$DisclaimerMsg = $Null
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
        ,
        [ValidateNotNullOrEmpty()]
        [String]$Language = 'en'
        ,
        [ValidateNotNullOrEmpty()]
        [DateTime]$AcceptanceDate = $(Get-Date)
        ,
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [ValidateSet("FlexHybrid", "FlexPublicCloud")]
        [String]$ClientType
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject
            Write-Log -LogString "Attempting to establish a connection to Office365" -LogLevel Verbose -LogObject $O365_global_logobject
            Start-O365MsolService -Office365Instance $Office365Instance -ConnectToPartnerCenter
        }

        # Check Partner Center Connection
        Try {
            Write-Log -LogString "Testing to see if we already have connection to the Partner Center" -LogLevel Output -LogObject $O365_global_logobject
            Get-PartnerLegalProfile -ErrorAction Stop | Out-Null
        }
        Catch {
            Write-Log -LogString "Connection to Partner Center is not started or has failed.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    Process {
        # Create the new Tenant
        Try {
            Write-Log -LogString "Parameter List..."
            Write-Log -LogString "OnMicrosoftDomainName: {$($OnMicrosoftDomainName)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "CompanyName: {$($CompanyName)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "ContactEmail: {$($ContactEmail)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "Country: {$($Country)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "Region: {$($Region)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "City: {$($City)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "State: {$($State)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "Address: {$($Address)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "PostalCode: {$($PostalCode)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "ContactFirstName: {$($ContactFirstName)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "ContactLastName: {$($ContactLastName)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "ContactPhoneNumber: {$($ContactPhoneNumber)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "UserCount: {$($UserCount)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "Office365Instance: {$($Office365Instance)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "Lanuage: {$($Language)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "AcceptanceDate: {$($AcceptanceDate)}" -LogLevel Output -LogObject $O365_global_logobject
            Write-Log -LogString "ClientType: {$($ClientType)}" -LogLevel Output -LogObject $O365_global_logobject

            # Create new Customer in Partner Portal
            Write-Log -LogString "Attempting to create the new customer" -LogLevel Verbose -LogObject $O365_global_logobject
            New-PartnerCustomer -ContactEmail "$ContactEmail" `
                -Language "$Language" `
                -Name "$CompanyName" `
                -BillingAddressCountry "$Country" `
                -BillingAddressRegion "$Region" `
                -BillingAddressCity "$City" `
                -BillingAddressState "$State" `
                -BillingAddressLine1 "$Address" `
                -BillingAddressPostalCode "$PostalCode" `
                -ContactFirstName "$ContactFirstname" `
                -ContactLastName  "$ContactLastName" `
                -ContactPhoneNumber "$ContactPhoneNumber" `
                -Domain "$OnMicrosoftDomainName" `
                -Culture "en-US" `
                -OutVariable NewPartnerCustomerOutput `
                -ErrorAction Stop

            Write-Log -LogString "The new customer was created successfully" -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an error trying to create the customer account.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        $TenantId = $($NewPartnerCustomerOutput.Id)
        $Arguments = @{
            Domain   = " `"$($Office365Instance)`" Partner Instance - onmicrosoft.com"
            UserName = "admin@$OnMicrosoftDomainName"
            Notes    = "O365 Admin account for $($CompanyName). Type: $($ClientType)"
            TenantId = "$($TenantId)"
        }

        Write-Log -LogString "Generating O365 Admin Account Secret for $($CompanyName)" -LogLevel Output -LogObject $O365_global_logobject
        Try {
            Write-Log -LogString "Posting Secret to Secret server" -LogLevel Output -LogObject $O365_global_logobject
            Add-Secret -SecretName "$($CompanyName) - Office 365 Admin" -FolderName 'Office365 Client Logins' `
                -SecretTemplate 'Office365 Account' `
                -Password $(New-SecurePassword) `
                -ArgumentList $Arguments
            Write-Log -LogString "The secret was added to the secret server successfully" -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an error trying to create the secret on the secret server.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Now that the secret is populated in the secret server we can use the stored credentials to get the new tenant information
        Write-Log -LogString "Wait before getting tenant information as Microsoft needs to post." -LogLevel Output -LogObject $O365_global_logobject
        While (   $Null -eq $(Get-O365TenantInfo -TenantId $TenantID -Office365Instance $Office365Instance -ErrorAction SilentlyContinue)  ) {
            Sleep 12
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantID -Office365Instance $Office365Instance -ErrorAction SilentlyContinue
        If (     [String]::IsNullOrEmpty($TenantInfo)      ) {
            Write-Log -LogString "There was an error retreiving the tenant information" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            Write-Log -LogString "Tenant Information looked up successfully" -LogLevel Verbose -LogObject $O365_global_logobject
        }

        # Adding a sleep to wait for Microsoft as sometimes changing the admin account info fails.
        Write-Log -LogString "Waiting four minutes before attempting to modify newly created admin account" -LogLevel Output -LogObject $O365_global_logobject
        Sleep 240

        # Set admin account DisplayName
        Try {
            Write-Log -LogString "Setting the new admin account's Name/DisplayName." -LogLevel Output -LogObject $O365_global_logobject
            Set-MsolUser -UserPrincipalName "admin@$($OnMicrosoftDomainName)" `
                -TenantId $TenantId `
                -FirstName 'Admin' `
                -LastName '' `
                -DisplayName "Admin - $($CompanyName)" `
                -ErrorAction Stop
            Write-Log -LogString "The admin account's Name/Displayname was changed successfully" -LogLevel Verbose -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue setting the admin account's Name/DisplayName.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Set admin account password to the newly created secret
        Try {
            Write-Log -LogString "Setting the new admin account's password." -LogLevel Output -LogObject $O365_global_logobject
            Set-MsolUserPassword -UserPrincipalName "admin@$($OnMicrosoftDomainName)" `
                -TenantId $TenantId -NewPassword $(Get-O365Credentials -SecretName $CompanyName -SecretType O365Login -ReturnSecretObject | Convert-secretToString).password `
                -ForceChangePassword:$False -ErrorAction Stop | Out-Null
            Write-Log -LogString "The admin account's password was changed successfully" -LogLevel Verbose -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue setting the admin account's password.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        Try {
            Switch ($ClientType) {
                "FlexHybrid" {
                    Write-Log -LogString "Creating an E3 license for the tenant." -LogLevel Verbose -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId `
                        -Country $Country `
                        -UserCount $UserCount `
                        -AcceptanceDate $AcceptanceDate `
                        -ContactFirstName $ContactFirstName `
                        -ContactLastName $ContactLastName `
                        -ContactEmail $ContactEmail `
                        -LICOfferId $(Get-O365LicIdFromLicName -LICName 'Office 365 E3') `
                        -ErrorAction Stop

                    Write-Log -LogString "Creating a P1 license for the tenant." -LogLevel Verbose -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId `
                        -Country $Country `
                        -UserCount 1 `
                        -AcceptanceDate $AcceptanceDate `
                        -ContactFirstName $ContactFirstName `
                        -ContactLastName $ContactLastName `
                        -ContactEmail $ContactEmail `
                        -LICOfferId $(Get-O365LicIdFromLicName -LICName 'Azure Active Directory Premium P1') `
                        -ErrorAction Stop
                }
                "FlexPublicCloud" {
                    Write-Log -LogString "Creating an E3 license for the tenant." -LogLevel Verbose -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId `
                        -Country $Country `
                        -UserCount $UserCount `
                        -AcceptanceDate $AcceptanceDate `
                        -ContactFirstName $ContactFirstName `
                        -ContactLastName $ContactLastName `
                        -ContactEmail $ContactEmail `
                        -LICOfferId $(Get-O365LicIdFromLicName -LICName 'Office 365 E3') `
                        -ErrorAction Stop


                    Write-Log -LogString "Creating an EMS license for the tenant." -LogLevel Verbose -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId `
                        -Country $Country `
                        -UserCount $UserCount `
                        -AcceptanceDate $AcceptanceDate `
                        -ContactFirstName $ContactFirstName `
                        -ContactLastName $ContactLastName `
                        -ContactEmail $ContactEmail `
                        -LICOfferId $(Get-O365LicIdFromLicName -LICName 'Enterprise Mobility + Security E3') `
                        -ErrorAction Stop

                    Write-Log -LogString "Creating a P1 license for the tenant." -LogLevel Verbose -LogObject $O365_global_logobject
                    Initialize-NewO365TenantLicenses -TenantId $TenantId `
                        -Country $Country `
                        -UserCount 1 `
                        -AcceptanceDate $AcceptanceDate `
                        -ContactFirstName $ContactFirstName `
                        -ContactLastName $ContactLastName `
                        -ContactEmail $ContactEmail `
                        -LICOfferId $(Get-O365LicIdFromLicName -LICName 'Azure Active Directory Premium P1') `
                        -ErrorAction Stop
                }
            }
        }
        Catch {
            Write-Log -LogString "There was an issue trying to purchase the initial O365 licenses for the tenant.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }


        # Disable 3rd party applications
        Try {
            Write-Log -LogString "Disable 3rd party Apps on the tenant environment" -LogLevel Output -LogObject $O365_global_logobject
            Set-MsolCompanySettings -TenantId $TenantId -UsersPermissionToUserConsentToAppEnabled:$False -UsersPermissionToCreateLOBAppsEnabled:$False -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "Disabling of 3rd party Apps possibly failed.`n Exception: {$($_.Exception)}" -LogLevel Warning -LogObject $O365_global_logobject
        }


        # Update or Disable password rotation
        Try {
            Switch ($ClientType) {
                "FlexHybrid" {
                    Write-Log -LogString "Disable password rotation." -LogLevel Output -LogObject $O365_global_logobject
                    Set-MsolPasswordPolicy -ValidityPeriod 2147483647 `
                        -NotificationDays 30 `
                        -DomainName $OnMicrosoftDomainName `
                        -TenantId $TenantId `
                        -ErrorAction Stop
                }
                "FlexPublicCloud" {
                    Write-Log -LogString "Setting 90 day password rotation." -LogLevel Output -LogObject $O365_global_logobject
                    Set-MsolPasswordPolicy -ValidityPeriod 90 `
                        -NotificationDays 30 `
                        -DomainName $OnMicrosoftDomainName `
                        -TenantId $TenantId `
                        -ErrorAction Stop
                }
            }
        }
        Catch {
            Write-Log -LogString "Update password rotation configuration failed.`n Exception: {$($_.Exception)}" -LogLevel Warning -LogObject $O365_global_logobject
        }

        # Configure ProofPoint AppId
        Write-Log -LogString "Attempting to create Abacus Proofpoint AppID" -LogLevel Output -LogObject $O365_global_logobject
        Try {
            New-O365TenantApp -AppType 'ProofPoint' -TenantId $TenantId -Office365Instance $Office365Instance
            Write-Log -LogString "ProofPoint AppId created successfully" -LogLevel Verbose -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an error creating the ProofPoint AppID.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Set a timeout of 360 seconds (6 minutes)
        $ExchangeConnectionStatus = $False
        $currentTime = Get-Date
        $Timeout = 360
        $TimeoutTimer = (Get-Date).AddSeconds($Timeout)
        $ProvisioningStatus = $(Get-MsolSubscription -TenantId $TenantId | ? { $_.SkuPartNumber -eq 'ENTERPRISEPACK' } | Select -ExpandProperty ServiceStatus | ? { $_.ServicePlan.ServiceName -like "*Exchange*" }).ProvisioningStatus



        Write-Log -LogString "Waiting for the Tenant's Exchange environment to be provisioned" -LogLevel Output -LogObject $O365_global_logobject
        While (   $ProvisioningStatus -ne 'Success'  ) {
            # Wait 5 Seconds and recheck Exchange service provisioning status
            Sleep 5
            $ProvisioningStatus = $(Get-MsolSubscription -TenantId $TenantId | ? { $_.SkuPartNumber -eq 'ENTERPRISEPACK' } | Select -ExpandProperty ServiceStatus | ? { $_.ServicePlan.ServiceName -like "*Exchange*" }).ProvisioningStatus
            If ( $(Get-Date) -ge $TimeoutTimer ) {
                Write-Log -LogString "Connection attempts to the tenant's Exchange environment have timed out..." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
        }

        Sleep 10

        # Assign new licenses
        Write-Log -LogString "Attempting to assign the necessary licenses to the Tenant's Administrator account." -LogLevel Output -LogObject $O365_global_logobject
        Switch ($ClientType) {
            "FlexHybrid" {
                Try {
                    Add-O365UserLIC -UserPrincipalName "admin@$OnMicrosoftDomainName" `
                        -TenantId $TenantId `
                        -Office365Instance $Office365Instance `
                        -LicenseType 'ENTERPRISEPACK' `
                        -ErrorAction Stop

                    Add-O365UserLIC -UserPrincipalName "admin@$OnMicrosoftDomainName" `
                        -TenantId $TenantId `
                        -Office365Instance $Office365Instance `
                        -LicenseType 'AAD_PREMIUM' `
                        -ErrorAction Stop
                }
                Catch {
                    Write-Log -LogString "There was an issue assigning our new licenses to the admin account.`nException: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
                }

            }
            "FlexPublicCloud" {
                Try {
                    Add-O365UserLIC -UserPrincipalName "admin@$OnMicrosoftDomainName" `
                        -TenantId $TenantId `
                        -Office365Instance $Office365Instance `
                        -LicenseType 'ENTERPRISEPACK' `
                        -ErrorAction Stop

                    Add-O365UserLIC -UserPrincipalName "admin@$OnMicrosoftDomainName" `
                        -TenantId $TenantId `
                        -Office365Instance $Office365Instance `
                        -LicenseType 'EMS' `
                        -ErrorAction Stop

                    Add-O365UserLIC -UserPrincipalName "admin@$OnMicrosoftDomainName" `
                        -TenantId $TenantId `
                        -Office365Instance $Office365Instance `
                        -LicenseType 'AAD_PREMIUM' `
                        -ErrorAction Stop
                }
                Catch {
                    Write-Log -LogString "There was an issue assigning our new licenses to the admin account.`nException: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
        }

        Write-Log -LogString "Tenant's Exchange provisioned sucessfully." -LogLevel Output -LogObject $O365_global_logobject
        Write-Log -LogString "Allowing up to 300 seconds of Microsoft postconfiguration steps." -LogLevel Output -LogObject $O365_global_logobject
        Sleep 300

        Write-Log -LogString "Attempting to connet to the Tenant's Exchange environment..." -LogLevel Verbose -LogObject $O365_global_logobject
        Connect-TenantExchange -TenantId  $TenantId -Office365Instance $Office365Instance
        Import-PSSession -Session $(Get-PSSession -Name "Office365Exchange") -DisableNameChecking -AllowClobber | Out-Null

        # Enable logging on Tenant Exchange
        Try {
            Write-Log -LogString "Enable Admin Audit logging on the tenant's exchange environment" -LogLevel Output -LogObject $O365_global_logobject
            Enable-O365AdminAuditLog -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was a warning enabling the AuditLog.`n Exception: {$($_.Exception)}" -LogLevel Warning -LogObject $O365_global_logobject
        }

        # Disable WinMail.dat
        Try {
            Write-Log -LogString "Diabling WinMail.dat" -LogLevel Output -LogObject $O365_global_logobject
            Disable-O365WinMailDotDat -ErrorAction Stop
            Write-Log -LogString "Configured sucessfully." -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue disabling WinMail.dat.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Disable Basic Auth
        Try {
            Write-Log -LogString "Disabling Basic Authentication" -LogLevel Output -LogObject $O365_global_logobject
            Disable-O365BasicAuthentication -ErrorAction Stop
            Write-Log -LogString "Configured sucessfully." -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue disabling basic authentication.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        # Create Mail Connectors
        Try {
            Write-Log -LogString "Creating Mail Connectors" -LogLevel Output -LogObject $O365_global_logobject
            New-O365MailConnectors -ErrorAction Stop
            Write-Log -LogString "Configured sucessfully." -LogLevel Output -LogObject $O365_global_logobject
        }
        Catch {
            Write-Log -LogString "There was an issue creating the Exchange Mail connectors.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    End {
        Disconnect-TenantExchange
        Write-Log -LogString "Tenant has been created sucessfully" -LogLevel Output -LogObject $O365_global_logobject
    }
}