﻿<#
.SYNOPSIS
This function leverages Abacus' Partner Center to scrape all tenant environments for unallocated licenses which are being paid for, but not utilized (allocated to an account). All matching licenses are then unallocated from the tenant by reducing the max license count.

.DESCRIPTION
This function leverages Abacus' Partner Center to scrape all tenant environments for unallocated licenses which are being paid for, but not utilized (allocated to an account). All matching licenses are then unallocated from the tenant by reducing the max license count.

.PARAMETER Instances
A value specifying the Azure Regions to be used when enumerate the client list for clients to target.

.PARAMETER smtpServer
A value specifying the desired SMTP server to be used for sending an e-mail report upon command completion.

.PARAMETER smtpFrom
The e-mail address which will be shown in the "from" field on the e-mail report.

.PARAMETER smtpSubj
The subject that will be shown in the "subject" field on the e-mail report.

.PARAMETER smtpTo
The e-mail address which will be shown in the "to" field on the e-mail report.

.PARAMETER DevOps
The respective e-mail address matching a DevOps distribution list which will also receive the resulting e-mail report.

.EXAMPLE
Compress-O365TenantLics

.NOTES
General notes
#>

Function Compress-O365TenantLics {
    [CmdletBinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [Array]$Instances = @("US", "UK")
        ,
        [ValidateNotNullOrEmpty()]
        [String]$smtpServer = 'relay-ny.accessabacus.com'
        ,
        [ValidateNotNullOrEmpty()]
        [String]$smtpFrom = 'reports@accessabacus.com'
        ,
        [ValidateNotNullOrEmpty()]
        [String]$smtpSubj = 'Office365 License CleanUp Utility'
        ,
        [ValidateNotNullOrEmpty()]
        [String]$smtpTo = '#SYSTEMS.ALL@abacusgroupllc.com'
        ,
        [ValidateNotNullOrEmpty()]
        [String]$DevOps = "#DEVOPS.ALL@abacusgroupllc.com"
    )
    Begin {
        Try {
            Start-Log -LogPath "C:\PSlogs\Abacus-Office365\Compress-O365TenantLics.log" `
                -ScriptName "Compress-O365TenantLics.ps1" `
                -AttachToExistingLog True `
                -Audit True `
                -AuditLogPath "\\service02.corp\DFS\SHARES\PSAuditLogs\Abacus-Office365\Compress-O365TenantLics.log" -ErrorAction Stop
        }
        Catch {
            Throw "There was an error initiating our log files."
        }
        $Array = @()
        $ResultArray = @()
        $TotalLicsRemoved = 0
        #[Array]$LicsToIgnore = "16C9F982-A827-4003-A88E-E75DF1927F27"
    }
    Process {
        ForEach ($Instance in $Instances) {
            Try {
                Test-O365MsolService -Office365Instance $Instance | Out-Null
            }
            Catch {
                Write-Log -LogString "Attempting to establish a connection to the `"$($Instance)`" Azure Instance." -LogLevel Verbose -LogObject $O365_global_logobject
                Start-O365MsolService -Office365Instance $Instance -ConnectToPartnerCenter
            }

            $GUIDs = Get-MsolPartnerContract | Select Name, TenantId
            ForEach ($GUID in $GUIDs) {
                Try {
                    $DataResults = $(Get-O365TenantLIC -TenantId $GUID.TenantId -Office365Instance $Instance -OnlyActive -ErrorAction Stop)
                    $Data2Results = $(Get-MsolAccountSku -TenantId $GUID.TenantId -ErrorAction Stop | Select SkuPartNumber, ActiveUnits, ConsumedUnits, SuspendedUnits, SubscriptionIds)
                    $Array += [PSCustomObject]@{Tenant = $($GUID.Name); TenantId = $($GUID.TenantId); Instance = $Instance; Data = $DataResults; Data2 = $($Data2Results) }
                }
                Catch {
                    $Array += [PSCustomObject]@{Tenant = $($GUID.Name); TenantId = $($GUID.TenantId); Instance = $Instance; Data = "ERR"; Data2 = "ERR" }
                    Write-Log -LogString "Could not gather Tenant LIC information for Tenant `"$($GUID.Name)`" - `"$($GUID.TenantId)`"." -LogLevel Warning -LogObject $O365_global_logobject
                }
            }
        }

        $ArrayToEvaluate = $Array | ? { ($Null -ne $_.Data -and $_.Data -ne "ERR") -and ($Null -ne $_.Data2 -and $_.Data2 -ne "ERR") }

        ForEach ($Client in $ArrayToEvaluate) {
            Try {
                Test-O365MsolService -Office365Instance $($Client.Instance) | Out-Null
            }
            Catch {
                Write-Log -LogString "Attempting to establish a connection to the `"$($Client.Instance)`" Azure Instance." -LogLevel Verbose -LogObject $O365_global_logobject
                Start-O365MsolService -Office365Instance $($Client.Instance) -ConnectToPartnerCenter
            }
            $ResultObject = [PSCustomObject]@{Client = $Client.Tenant; TenantId = $Client.TenantId; PartnerCenter = $Client.Instance; TotalLicensesRecovered = 0 }

            $LicArray = @()
            $ClientData1 = $Client.Data
            $ClientData2 = $Client.Data2 | ? { $_.ActiveUnits -gt 0 }
            ForEach ($License in $ClientData1) {
                $LicArray += [PSCustomObject]@{
                    'FriendlyName'            = $License.FriendlyName ;
                    'OfferId'                 = $License.OfferId ;
                    'OfferName'               = $License.OfferName ;
                    'PartnerLicTotal'         = $License.Quantity ;
                    'ActiveMinusConsumedLics' = $Null
                }
            }

            ForEach (   $License in $Client.Data2   ) {
                $LIC = $(Get-O365LicIdFromLicName -TenantLicName $($License.SkuPartNumber))
                If (   $False -eq [String]::IsNullOrEmpty($LIC)   ) {
                    $LICName = $(Get-O365LicNameFromLicOfferId -LICOfferId $LIC)
                    If (   $False -eq [String]::IsNullOrEmpty($LICName)   ) {
                        Try {
                            ($LicArray | ? { $_.OfferName -eq "$($LICName)" }).ActiveMinusConsumedLics = ($License.ActiveUnits - $License.ConsumedUnits)
                        }
                        Catch {
                            Write-Log -LogString "{$($Client.Tenant)} - {$($Client.TenantId)} - {$($LICName)} - {$($License.SkuPartNumber)} `nException: {$($_.Exception.message)}" -LogLevel Debug
                        }
                    }

                }
            }

            # Ignore Lics
            <#
            ForEach ($License in $LicsToIgnore) {
                $LicArray = $LicArray | ? { $_.OfferId -ne $License }
            }
            #>

            ForEach ($LicenseType in $LicArray) {
                If (   $True -eq ($LicenseType.ActiveMinusConsumedLics -ge 1) -and ($LicenseType.PartnerLicTotal -ge $LicenseType.ActiveMinusConsumedLics)   ) {

                    # If P1, ensure that at least 1 P1 license is present, do not delete all.
                    If ($LicenseType.OfferId -eq '16C9F982-A827-4003-A88E-E75DF1927F27') {
                        If (   $LicenseType.PartnerLicTotal -eq 1) {
                            Continue
                        }
                        Else  {
                            $LicenseType.PartnerLicTotal --
                        }
                    }

                    Try {
                        Write-Log -LogString "Will now Remove a quantity of ($($LicenseType.ActiveMinusConsumedLics)) from ($($Client.Tenant)) under instance ($($Client.Instance)) for Subscription ($($LicenseType.FriendlyName) - $($LicenseType.OfferId))" -LogLevel Output -LogObject $O365_global_logobject
                        Remove-O365TenantLIC -TenantId $($Client.TenantId.Guid) -Quantity $($LicenseType.ActiveMinusConsumedLics) -LICOfferId $($LicenseType.OfferId) -Office365Instance $($Client.Instance) -ErrorAction Stop
                        $TotalLicsRemoved += $($LicenseType.ActiveMinusConsumedLics)
                        If ( $Null -eq $ResultObject.$($LicenseType.OfferName) ) {
                            $ResultObject | Add-Member -Name $($LicenseType.OfferName) -MemberType NoteProperty -Value $($LicenseType.ActiveMinusConsumedLics)
                        }
                        $ResultObject.TotalLicensesRecovered += $($LicenseType.ActiveMinusConsumedLics)
                    }
                    Catch [System.Management.Automation.RuntimeException] {
                        If ($_.Exception -like "*Microsoft.Store.PartnerCenter.PowerShell.Exceptions.PartnerPSException*") {
                            Write-Log -LogString "Could not remove licenses from customer $($Client.Tenant) - Please check if the Cloud Agreement was signed." -LogLevel Warning -LogObject $O365_global_logobject
                            Write-Log -LogString "$($_.Exception)" -LogLevel Error -LogObject $O365_global_logobject
                        }
                        Else {
                            Write-Log -LogString "Could not remove licenses for customer ($($Client.Tenant)) under instance ($($Client.Instance))." -LogLevel Warning -LogObject $O365_global_logobject
                            Write-Log -LogString "$($_.Exception)" -LogLevel Error -LogObject $O365_global_logobject
                        }
                    }
                    Catch {
                        Write-Log -LogString "Could not remove licenses for customer ($($Client.Tenant)) under instance ($($Client.Instance))." -LogLevel Warning -LogObject $O365_global_logobject
                        Write-Log -LogString "$($_.Exception)" -LogLevel Error -LogObject $O365_global_logobject
                    }
                }
            }
            $ResultArray += $ResultObject
        }
        $ResultArray = $ResultArray | ? { $_.TotalLicensesRecovered -ne 0 }
    }
    End {
        # Send Email
        [String]$EmailBody = @()
        $EmailResultArray = $ResultArray | ? { $_.TotalLicensesRecovered -ne 0 }
        If ($Null -ne $EmailResultArray) {
            Try {
                $EmailBody = $($EmailResultArray | ConvertTo-Json -Depth 10)
                $EmailReportLoop = $True
                $EmailReportNotSentCounter = 0
                Write-Log -LogString "Attempting to send e-mail report." -LogLevel Output -LogObject $O365_global_logobject
                Write-Log -LogString $EmailBody -LogLevel Debug
                While (   ($True -eq $EmailReportLoop)   ) {
                    If ($EmailReportNotSentCounter -ge 10) {
                        $EmailReportLoop = $False
                        Write-Log -LogString "Could not send email report." -LogLevel TerminatingError  -LogObject $O365_global_logobject
                    }
                    Try {
                        Send-MailMessage -Body $EmailBody -From $smtpFrom -To $smtpTo -SmtpServer $smtpServer -Subject $smtpSubj -ErrorAction Stop
                        Write-Log -LogString "E-mail report sent." -LogLevel Output -LogObject $O365_global_logobject
                        $EmailReportLoop = $False
                    }
                    Catch {
                        Write-Log -LogString "There was an error sending the report email. Retrying..." -LogLevel Warning -LogObject $O365_global_logobject
                        $EmailReportNotSentCounter++
                        Sleep 5
                    }
                }
            }
            Catch {
                Write-Log -LogString "There was an error sending email report" -LogLevel Warning -LogObject $O365_global_logobject
            }
        }
        Else {
            Try {
                Send-MailMessage -To $DevOps -From $smtpFrom -SMTPServer $smtpServer -Subject $smtpSubj -Body "No O365 Tenant LICs to Compress.`n`t Task ran successfully." -ErrorAction Stop
            }
            Catch {
                Write-Log -LogString "There was an error sending our E-mail Report." -LogLevel Warning -LogObject $O365_global_logobject
            }
            Write-Log -LogString "E-mail Report Sent" -LogLevel Output -LogObject $O365_global_logobject
        }
        Write-Log -LogString "Results: " -LogLevel Verbose -LogObject $O365_global_logobject
        Write-Log -LogString $($EmailResultArray | ConvertTo-Json -Depth 12) -LogLevel Verbose -LogObject $O365_global_logobject
        Return $EmailResultArray
    }
}