<#
.SYNOPSIS
A command to enable Abacus Mail connectors within a Tenant's O365 environment.

.DESCRIPTION
A command to enable Abacus Mail connectors within a Tenant's O365 environment.

.PARAMETER TenantExchangeSession
The name of the PSSession to look for to import commands from.

.EXAMPLE
New-O365MailConnectors

.NOTES
Please ensure you are connected to a Tenant's Exchange environment before running this commad.
#>

Function Enable-O365MailConnectors {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
        Import-PSSession $ExchangeSession -AllowClobber
    }
    Process {
        Try {
            Set-InboundConnector -Identity 'Inbound Email from Proofpoint' -Enabled:$True
            Set-OutboundConnector -Identity 'Outbound Email to Proofpoint' -Enabled:$True
            New-HostedConnectionFilterPolicy -Name 'Abacus Connection Filters' -IPAllowList '199.192.65.7', '199.192.65.8', '199.192.65.9', '199.192.67.8', '199.192.67.9'
            #Set-HostedConnectionFilterPolicy -Identity 'Default' -IPAllowList '199.192.65.7', '199.192.65.8', '199.192.65.9', '199.192.67.8', '199.192.67.9'
        }
        Catch {
            $Err = $($_.Exception)
        }
    }
    End {
        If ($Null -ne $Err) {
            Write-Log -LogString "Failing to Enable Mail connectors...`n Exception: {$($Err)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            Write-Log -LogString "Enable-O365MailConnectors completed..." -LogLevel Output -LogObject $O365_global_logobject
        }
    }
}