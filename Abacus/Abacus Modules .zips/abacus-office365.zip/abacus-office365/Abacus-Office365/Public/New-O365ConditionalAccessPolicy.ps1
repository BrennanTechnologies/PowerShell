<#
.SYNOPSIS
A command to create a new Conditional Access Policy for a tenant.

.DESCRIPTION
A command to create a new Conditional Access Policy for a tenant.

.PARAMETER ConditionalAccessType
The type of conditional Access Policy to create based on Abacus standards.

.PARAMETER policyState
A parameter to specify if the newly created Access Policy should be enabled or disabled upon creation.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
New-O365ConditionalAccessPolicy -policyState Disabled -TenantId {TenantId} -Office365Instance {US/UK} -ConditionalAccessType "Default MFA"

.EXAMPLE
New-O365ConditionalAccessPolicy -policyState Disabled -TenantId {TenantId} -Office365Instance {US/UK} -ConditionalAccessType "LockDownGlobalAdmin"

.EXAMPLE
New-O365ConditionalAccessPolicy -policyState Disabled -TenantId {TenantId} -Office365Instance {US/UK} -ConditionalAccessType "ForceDeviceEnrollment(Modern Apps) - ActiveSync"

.NOTES
General notes
#>

Function New-O365ConditionalAccessPolicy {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [ValidateSet("Default MFA", "LockDownGlobalAdmin", "ForceDeviceEnrollment(Modern Apps) - ActiveSync", "ForceDeviceEnrollment(Modern Apps) - Containerization","Force Device Enrollment (Legacy Auth Apps)")]
        [Parameter(Mandatory = $True)]
        [String]$ConditionalAccessType
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("Enabled", "Disabled")]
        [Parameter(Mandatory = $True)]
        [String]$policyState = "Disabled"
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory = $True)]
        [String]$Office365Instance
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAREPORTAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAREPORTAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        $TenantAdminAccount = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType O365Login).UserName
        $TenantAdminGuid = (Get-MsolUser -TenantId $TenantId -UserPrincipalName "$($TenantAdminAccount)" | Select -ExpandProperty ObjectId).Guid
        [Array]$ExcludeNetworkId = @()

        # Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType REPORTRefreshToken -ErrorAction Stop)
        $REPORTRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($REPORTRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning -LogObject $O365_global_logobject
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object pscredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

            If (   $True -ne $FirstRun   ) {
                Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose -LogObject $O365_global_logobject
                If ($RefreshTokenStatus -eq $False) {
                    Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
                Else {
                    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $REPORTRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                }
            }
            Else {
                Write-Log -LogString "FirstRun flag detected, will prompt for consent." -LogLevel Verbose -LogObject $O365_global_logobject
                $ResponseToken = Get-AccessToken -AppId $AppId -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -PromptConsent -Resource 'https://graph.microsoft.com/'
            }

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            Write-Log -LogString "Attempting to get Conditional Access Policy information for company $($TenantInfo.CompanyName)" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))

            # Actions

            $NamedLocations = (Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/namedLocations" -ContentType "application/json" -Headers $Headers).value

            Switch ($ConditionalAccessType) {
                "Default MFA" {
                    Write-Log -LogString "Running {Default MFA}" -LogLevel Verbose -LogObject $O365_global_logobject

                    [Array]$ExcludeNetworkId += $NamedLocations | ? { $_.displayName -eq 'Abacus Management IPs' -or $_.displayName -eq 'Abacus Datacenter IPs' }
                    $ExcludeNetworkIdCount = ($ExcludeNetworkId | Measure).count
                    If (   ($ExcludeNetworkIdCount -lt 2) -or ($ExcludeNetworkIdCount -gt 2)   ) {
                        Write-Log -LogString "Two networkIds were expected 'Abacus Management IPs' and 'Abacus Datacenter IPs', instead found {$($ExcludeNetworkIdCount)} total matching." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $ExcludeNetworkId = $ExcludeNetworkId.id -join "','"
                        $ExcludeNetworkId = "$($ExcludeNetworkId)"
                    }

                    $JSON = @"
                    {
                        "displayName": "Default MFA",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [],
                            "applications": {
                                "includeApplications": ['All'],
                                "excludeApplications": ['797f4846-ba00-4fd7-ba43-dac1f8f63013']
                            },
                            "users": {
                                "includeUsers": ['All'],
                                "excludeUsers": ["$($TenantAdminGuid)"]
                            },
                            "locations": {
                                "includeLocations": ['All'],
                                "excludeLocations": [
                                    '$($ExcludeNetworkId)'
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "OR",
                            "builtInControls": [
                                "mfa",
                                "compliantDevice"
                            ]
                        }
                    }
"@
                }

                "LockDownGlobalAdmin" {
                    Write-Log -LogString "Running {LockDownGlobalAdmin}" -LogLevel Verbose -LogObject $O365_global_logobject

                    [Array]$ExcludeNetworkId += $NamedLocations | ? { $_.displayName -eq 'Abacus Management IPs' }
                    $ExcludeNetworkIdCount = ($ExcludeNetworkId | Measure).count
                    If (   ($ExcludeNetworkIdCount -lt 1) -or ($ExcludeNetworkIdCount -gt 1)   ) {
                        Write-Log -LogString "One networkIds were expected 'Abacus Management IPs', instead found {$($ExcludeNetworkIdCount)} total matching." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $ExcludeNetworkId = $ExcludeNetworkId.id -join "','"
                        $ExcludeNetworkId = "$($ExcludeNetworkId)"
                    }

                    $JSON = @"
                    {
                        "displayName": "LockDownGlobalAdmin",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [],
                            "applications": {
                                "includeApplications": ['All']
                            },
                            "users": {
                                "includeUsers": ["$($TenantAdminGuid)"]
                            },
                            "locations": {
                                "includeLocations": ['All'],
                                "excludeLocations": [
                                    '$($ExcludeNetworkId)'
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "OR",
                            "builtInControls": [
                                "block"
                            ]
                        }
                    }
"@
                }

                "ForceDeviceEnrollment(Modern Apps) - ActiveSync" {
                    Write-Log -LogString "Running {ForceDeviceEnrollment(Modern Apps)}" -LogLevel Verbose -LogObject $O365_global_logobject

                    $DynamicGroupAll = Get-MsolGroup -TenantId $TenantInfo.TenantId -All | ? { $_.displayName -eq 'DynamicGroupAll' }

                    If (   ($DynamicGroupAll | Measure).Count -lt 1 -or ($DynamicGroupAll | Measure).count -gt 1   ) {
                        Write-Log -LogString "DynamicGroupAll was expected, but was not found contained in this tenant instance." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $DynamicGroupAllGuid = $DynamicGroupAll.ObjectId.Guid
                    }

                    $JSON = @"
                    {
                        "displayName": "Force Device Enrollment (Modern Apps) - ActiveSync",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [
                                "browser",
                                "modern",
                                "easUnsupported"
                                ],
                            "applications": {
                                "includeApplications": [
                                    '00000002-0000-0ff1-ce00-000000000000',
                                    '00000003-0000-0ff1-ce00-000000000000'
                                    ]
                            },
                            "users": {
                                "includeGroups": [
                                    "$($DynamicGroupAllGuid)"
                                    ]
                            },
                            "platforms": {
                                "includePlatforms": [
                                    "android",
                                    "iOS",
                                    "macOS"
                                ],
                                "excludePlatforms": [
                                    "windows"
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "OR",
                            "builtInControls": [
                                "compliantDevice"
                            ]
                        }
                    }
"@
                }

                "ForceDeviceEnrollment(Modern Apps) - Containerization" {
                    Write-Log -LogString "Running {ForceDeviceEnrollment(Containerization)}" -LogLevel Verbose -LogObject $O365_global_logobject

                    $DynamicGroupAll = Get-MsolGroup -TenantId $TenantInfo.TenantId -All | ? { $_.displayName -eq 'DynamicGroupAll' }

                    If (   ($DynamicGroupAll | Measure).Count -lt 1 -or ($DynamicGroupAll | Measure).count -gt 1   ) {
                        Write-Log -LogString "DynamicGroupAll was expected, but was not found contained in this tenant instance." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $DynamicGroupAllGuid = $DynamicGroupAll.ObjectId.Guid
                    }

                    $JSON = @"
                    {
                        "displayName": "Force Device Enrollment (Modern Apps) - Containerization",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [
                                "browser",
                                "modern",
                                "easUnsupported"
                                ],
                            "applications": {
                                "includeApplications": [
                                    '00000002-0000-0ff1-ce00-000000000000',
                                    '00000003-0000-0ff1-ce00-000000000000'
                                    ]
                            },
                            "users": {
                                "includeGroups": [
                                    "$($DynamicGroupAllGuid)"
                                    ]
                            },
                            "platforms": {
                                "includePlatforms": [
                                    "android",
                                    "iOS"
                                ],
                                "excludePlatforms": [
                                    "windows",
                                    "macOS"
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "AND",
                            "builtInControls": [
                                "compliantDevice",
                                "approvedApplication"
                            ]
                        }
                    }
"@

                    $JSON2 = @"
                    {
                        "displayName": "Modern Apps - macOS",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [
                                "browser",
                                "modern",
                                "easUnsupported"
                                ],
                            "applications": {
                                "includeApplications": [
                                    '00000002-0000-0ff1-ce00-000000000000',
                                    '00000003-0000-0ff1-ce00-000000000000'
                                    ]
                            },
                            "users": {
                                "includeGroups": [
                                    "$($DynamicGroupAllGuid)"
                                    ]
                            },
                            "platforms": {
                                "includePlatforms": [
                                    "macOS"
                                ],
                                "excludePlatforms": [
                                    "windows",
                                    "iOS",
                                    "android"
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "OR",
                            "builtInControls": [
                                "compliantDevice"
                            ]
                        }
                    }
"@
                }

                "Force Device Enrollment (Legacy Auth Apps)" {
                    Write-Log -LogString "Running {Force Device Enrollment (Legacy Auth Apps)}" -LogLevel Verbose -LogObject $O365_global_logobject

                    $DynamicGroupAll = Get-MsolGroup -TenantId $TenantInfo.TenantId -All | ? { $_.displayName -eq 'DynamicGroupAll' }

                    If (   ($DynamicGroupAll | Measure).Count -lt 1 -or ($DynamicGroupAll | Measure).count -gt 1   ) {
                        Write-Log -LogString "DynamicGroupAll was expected, but was not found contained in this tenant instance." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $DynamicGroupAllGuid = $DynamicGroupAll.ObjectId.Guid
                    }


                    $JSON = @"
                    {
                        "displayName": "Force Device Enrollment (Legacy Auth Apps)",
                        "state": "$($PolicyState)",
                        "conditions": {
                            "clientAppTypes": [
                                "browser",
                                "easSupported",
                                "easUnsupported"
                                ],
                            "applications": {
                                "includeApplications": [
                                    '00000002-0000-0ff1-ce00-000000000000',
                                    '00000003-0000-0ff1-ce00-000000000000'
                                    ]
                            },
                            "users": {
                                "includeGroups": [
                                    "$($DynamicGroupAllGuid)"
                                    ]
                            },
                            "platforms": {
                                "includePlatforms": [
                                    "android",
                                    "iOS",
                                    "macOS"
                                ],
                                "excludePlatforms": [
                                    "windows"
                                ]
                            }
                        },
                        "grantControls": {
                            "operator": "OR",
                            "builtInControls": [
                                "compliantDevice"
                            ]
                        }
                    }
"@
                }

                Default {
                    Write-Log -LogString "Running {Default}" -LogLevel Verbose -LogObject $O365_global_logobject
                    Write-Log -LogString "Running {Unhandled Exception}" -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }

            #
            # (Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/policies" -ContentType "application/json" -Headers $Headers).Value
            $ReturnObject =  @()
            $ReturnObject += Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/policies" -ContentType "application/json" -Headers $Headers -Method Post -Body $JSON
            If ($Null -ne $JSON2) {
                $ReturnObject += Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/policies" -ContentType "application/json" -Headers $Headers -Method Post -Body $JSON2
            }

            #

            If ($Null -ne $ReturnObject) {
                $TenantContainer.Data = $ReturnObject
                $TenantContainer.Status = "200"
            }
            Else {
                $TenantContainer.Data = "NULL"
                $TenantContainer.Status = "200"
            }
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "401"
                    $TenantContainer.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "400"
                    $TenantContainer.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(404)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(503)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(504)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(?)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning -LogObject $O365_global_logobject
            $TenantContainer.Status = "ERR(?)"
            $TenantContainer.Data = "$_"
        }
    }
    End {
        If ($True -eq $ReturnAsJson) {
            Write-Log -LogString "ReturnAsJson was selected, outputting results in JSON format." -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Return $($TenantContainer | ConvertTo-Json -Depth 5)
        }
        Else {
            Return $TenantContainer
        }
    }
}