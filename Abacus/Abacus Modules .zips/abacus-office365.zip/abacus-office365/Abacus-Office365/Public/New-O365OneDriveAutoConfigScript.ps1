<#
.SYNOPSIS
A command for creating the base OneDrive AutoConfig Script.

.DESCRIPTION
A command for creating the base OneDrive AutoConfig Script.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365OneDriveAutoConfigScript -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>

Function New-O365OneDriveAutoConfigScript {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [String]$TenantId
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $ScriptContents = @"
`$OneDriveRegistryPath = 'HKLM:\SOFTWARE\Policies\Microsoft\OneDrive'
`$DiskSizeRegistryPath = 'HKLM:\SOFTWARE\Policies\Microsoft\OneDrive\DiskSpaceCheckThresholdMB'
`$DisableTelemetryPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'
`$TenantGUID = '$($TenantId)'
`$LongNTFSPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem'
IF(!(Test-Path `$OneDriveRegistryPath))
{New-Item -Path `$OneDriveRegistryPath -Force}
IF(!(Test-Path `$DiskSizeregistryPath))
{New-Item -Path `$DiskSizeregistryPath -Force}
IF(!(Test-Path `$DisableTelemetryPath))
{New-Item -Path `$DisableTelemetryPath -Force}
New-ItemProperty -Path `$OneDriveRegistryPath -Name 'SilentAccountConfig' -Value '1' -Force | Out-Null
New-ItemProperty -Path `$DiskSizeRegistryPath -Name `$TenantGUID -Value '102400' -Force | Out-Null
"@


            $Bytes = [System.Text.Encoding]::Unicode.GetBytes( $ScriptContents )
            $ScriptContents = [Convert]::ToBase64String($Bytes)
            $JSON = @"
{
    "@odata.type":  "#microsoft.graph.deviceManagementScript",
    "version": 1,
    "description":  "Created through Abacus automation",
    "displayName":  "OneDriveConfig-SYSTEM",
    "runAsAccount":  "system",
    "scriptContent":  "$($ScriptContents)",
    "enforceSignatureCheck":  "False",
    "fileName":  "OneDriveAutoconfig.ps1",
    "runAs32Bit":  "True"
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceManagementScripts" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {

                If ($TargetId -eq 'ALL') {
                    $JSON2 = @"
{"deviceManagementScriptAssignments":[{"target":{"@odata.type":"#microsoft.graph.allLicensedUsersAssignmentTarget"}},{"target":{"@odata.type":"#microsoft.graph.allDevicesAssignmentTarget"}}]}
"@
                }
                Else {
                    $JSON2 = @"
{
    "deviceManagementScriptAssignments":  [{
        "target":  {
            "@odata.type":  "#microsoft.graph.groupAssignmentTarget",
            "groupId":  "$($TargetId)"
        }
    }]
}
"@
                }


                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceManagementScripts/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}