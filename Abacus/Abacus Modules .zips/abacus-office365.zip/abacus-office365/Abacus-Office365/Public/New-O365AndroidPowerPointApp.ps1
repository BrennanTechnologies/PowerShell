<#
.SYNOPSIS
A command for creating the base Android PowerPoint App.

.DESCRIPTION
A command for creating the base Android PowerPoint App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365AndroidPowerPointApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365AndroidPowerPointApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{"@odata.type":"#microsoft.graph.androidStoreApp","appStoreUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.powerpoint","categories":[{"displayName":"Productivity","id":"ed899483-3019-425e-a470-28e901b9790e"}],"description":"Microsoft Powerpoint","developer":"","displayName":"Microsoft Powerpoint","informationUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.powerpoint","isFeatured":true,"roleScopeTagIds":[],"largeIcon":{"type":"image/pngapplication/octet-stream","value":"iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAIAAACyr5FlAAAAA3NCSVQICAjb4U/gAAAewElEQVR4nO19e7QkR3nf91VVP+Z59+7efWgfSLvSrlYvtEISQkhI2AeBUHCOsWUIYIKDiI0TO1GMozg+5uBwYhLF2BExIRhBcLAxkQAFGUsWR0jWQRiktbTo/WClXbTv9907c+fV3VVf/qiZnn7e3ZWm5/as+qernZnq6qqa6V9/36++ejQSERQokAS22A0okF8U5CiQioIcBVJRkKNAKgpyFEhFQY4CqSjIUSAVBTkKpKIgR4FUFOQokIqCHAVSUZCjQCoKchRIRUGOAqkoyFEgFQU5CqSiIEeBVBTkKJCKghwFUlGQo0AqCnIUSEVBjgKpKMhRIBUFOQqkoiBHgVQU5CiQioIcBVJRkKNAKgpyFEhFQY4CqRCL3YBFRn8HiuBGFIgECKgPD9KAYJAFEf1/T2+8/shBBIhqcKUJkQAUIgHoP3nssGw0QElQBIjAGHCOlSpbtpwBIMDwX6UQETVRiOC0o8vrhRykAUgMlVKy3VadtvJcb8cL8uABPnvAefCPsDPLOaBYCrwKgMStZRdeCZ4HQEASXMd1u1LYsOWfuHZdrVzDVp+FwkC7xOwy54wRIRAAnjZGBU/vnX2ISNsDhagA3COHvZ9tV3tfoT076OV/hBfvZlMzYC4HUQV7CWBIgRFjy87ZCFJGigS3A0qC15Pto7TyQrnybJpZJ1esUavPMpbNcACu+n5p0llyepJDfykFQACe43rNOe+l59y7b2edJrQPgdNCswZGCbgxUBUJP0IKOQJABCVBueD2SJhkVh1ryrvk53HTG3mpwg2DATDUGSeSJacbOYgIiBSAZMw5dMDbuV0+84/qrz/BVyyF6S3AOCACnNSlOjE5YnUDSeg1vMZ+780fUmeeTxvOE0umhSKGhIATJ0pOH3L41kIh9o4d7T3wt/DEg7B3K4oqlGeAINE8LFTgqZJjCAS3TU5HLj/becNF8sp3WlNLOJF2WhNkRU4HcvTFJjLP83q7djg/vA/+179lF1wC9lJgr15xvwZy+EUocDvU2NO57IPqTW8Xq9cZnLPJEa0TTw5NDMlY98Be9/t/o37wV8xpQH0dkHqtJb92cvjoNqQouRf8nHvptdaKM7hSbBKCJRNMjj4tANx2u3PvN+lbN7Op88CqA/JT9SDJ5Y+QHABABF5PzR9uv/1j7NJrjWqNAyHm2oRMKjmISBF4DNs/+nt595fYvq2wZOOIqxgtOXy0jrjTZzrXvp9t3mIiMiDIK0Umjxx9g4HYmz3W+9ZX4Md/hdY0GOWRWItQRRmRAxCkQ57TPedK9Y73W7U6y2tQZJLI0e+PEHlE3Wd/4tx2EyeE6qqsqsuKHAM48y6x3ns/ITZsNhiy/NmPCSOHInKI2vd8C779aaysBG6N3GAMq8uaHACgpHK77S038Hf9iqlU3vgxGeTQjfSInGaj/Ucf53sehGVvyrzSMZBDo320s+oi+Yu/YS2ZFnnixwTM5/BFRmfXzs6tv81nd8LMpYvdqJGiPFM6st36xq29I4c8RKVeayd8VMg7OTQzPIDWju29m89hs7vAnoZJsHanAgKzYnSPl776+70dL7oESqk8WPRck6PPDMT2k4+5/+lDfO07QJQWu1GZgZvcMMvf+m/O01s9xvpTDBYVeSeHZKy97RHvv9/EKlVAvtgtyhhMMGFW7/1c77mfeMgKciSDiJRSHlFr26Py1nez+hnAzcVu1FjAOJaXVu7+096Tj3qwyPojp+QAAMVYZ+d2+YVbcObSyDSc0x3IrGrlvv/Z271DMraI/Mjdj97XGUSt3T9zf/08tE3gxmI3auxgnFnVyh2f6e3bLcPTn8faikWpdWFIgt6xI+7nb2Gbf+701xlpQMYYs+76s97ccbVI4jRf5NAxUNd1Ol/4FDu26/WiM9IgLKN9WHznz3sEi8KPPJGj71CgfffX2fPfJnuaCDL5G6xCmACYFfvg8/TA/3OVGn/nNk9LExAVYvsnWzt3f5Yt2QJeVnFrGoSn9fIThshwOK3Uj17nJYht10qPf6d95ia+6SJOapzB9YzGVqi9d7c33yKFC/zG0YoRe635A7fepAhBWEk5ANPv+NRDSfPL9ZxwQOCMmaZhW6bFUESGNTgf09jKCUHKaxzo/ruv2tUaH+Pgy+gthzt3bM83vtH83pfce55Sbmq2xAuJAtjbloCokT6eSI7hwsTAYUoukIb/B2YYB7MibxumUZ+aWra0xNDgzJ+cvugxqCGQifIS/v1vuv/01xhjYyPHiC1H9+C+7Td/zH3h73DFGchLgMnrQijlHQEMx01i7Qq3lFLSI4nxCuI5iaTH60uXrFxRM7lA1v/xGZvZuCkXlgMAAKjbaN/wW+aFlwsc08ygEQvS3V/8Y+fpv2OrNwC3Sa83IwI1VIN9VRVODKVDslyk0FXusyhgRSB0OMyMfkpyTgIA5EI2jjUb844CSaSb1j+cG/uBZtn8/v9x2vNjU6ajJIfXmJ39w9v4metDTQ8YgugXGh5aIBNAlBmRlFC2uB9JNBg0WP7kpyBjTuN4VypPKUWUUsOiggmjdxz+4Xt6WG4cFY6wrNa+fWiGL0SiiwgxgCg5U+Bw4P4PpyQVGTARBAlsG1iROFGZas93JUkFqm88ckcPKE2XnrzX2btL4ThmaY2SHKrXgWkAGFySyEWPJsavewiRw/34RJJ28V1ApKpk30TRlvkVISlXKY+UIurPp8gfPRgCf+pHnuuNoWkj1RxEejniMCGpg0ARa5F0Z8etRaSQYFmRetIkMIUrS2RbVypPgaSB8ujXnieOGGXr8bvkwT2UvW0bdYSU9C44YZ8fZsYwZ/KdHT2c5kQSVGdyjQN5QeEiIgUSAIBUpC3HMJCaJ2JoMKuKD/+NxzL3LKMPn6e0l6IGI+nw4Fjo/k4uP2IwYpwYpCcolChPhiWio5SnyFOkCBQpGBiPfMEol19+uHdgP2WsPEZMDvLLi8qLhPRhWujwMDGBGXF5kXb1kqxusMyhXhk0EAFcSbLPDCIClUO7oWFPmU887KnJsRxEAHpiSuDCndCPxA3Ggv2RJO9B0WwDt5BY0eAM8rf9GSYO1AbRkIB5GWMJgZti19Ny9mim7Bi1W5FJUuEEtIAUIxM4O9H/x4qlWLmJZSZ3ZQmIQJKSilRIjeZloUAITPD9z9Ku7TJLWZrFkH3ydY/kCBzu358EQHpgY/BHfvQdAZD0PTxMDBboMyPWjogMjViLYHMRQCoiAM2MPocwqb7FB2F1hj3xoMwyWjr6gbe0MTOIXbv+K6I8+DP1JCQdS0msAC4HXAK45AzkZprqTDh94WwIvs0g0nzMp1MBAABhlV68p9H4V8bUkqxqGG1x4T5E+FDMmBABIMg9P1v57/+8dtFltOAQ19CEEMnm8d7Bfe2d2+f+4DMOgLgE2NQqQAPSOBE7QJDUSCIFekPSgVqlgRnLIYhg6UZ86hF17Q2MKIuhuFFbjpQx+khMIvAW1XNQO+ecmUtPde0rkVR0yx/OPfvEvu9+t/Hdz5FqsPq6aCZIshYQZUZ/+I2COXTIBohyvPusUbZ2POle9S7BM5nRN+pCYz/jwORHu7YUOGNhm5FWE3LODGN6y+UXfPLTm7/ykH3FTd4ru4MXMk14JjIDtOLRHZ0+T/KoNUJAzuePqIN7FWAW0boM55CGu6n9l3hYIsULnRqmL7rk4j/+XO0XPyr37gK9V3Wkm5o0vh8d+6Ykq5JnIOL8ITi8XwFkYd4yIIe+6QJ8gGFfNJZ3dAFIXq5c/Nkv21e8T87uCgmcpO4xhGmRSJ2JAOMcD7wiXTeLPsuoNYcM3nuhl7jBAAr6+Sh6h/ZLp9e/IQgACBnjhmEuPyO1dsQNt/z+8x+5E5QLLHUpVIQWgdNTC84vuMmP7FGuS4YYefNHGiEFIi/wSb+kGIyFOjYAoLztt3/p8XXrt609a9vas7atO2vbuvWPrzlz64rVDyM+9Ylfn3vx+cTNJJdeePH0B/+rah6ExHhY0GDETcUkmg5hiefukb1OFs4wi6UJiV2EwQGAsF9PoTsi44a4DLC2Jng6ApBSzftvf/JPbz/7vr9dc931wKJL4mbeeuXh3wW8Nlx1mrUIJk0iOQiEWZWNWZpeNvKyM9EcJ2LGMMUfGU/AYJqv/iNiQIyIAQo2s05cs/yl69/T2LEjft7SCy6KPujgJJgxEl28GCCwa7DrJZWBTxz1qKxaILY91KWn1i1IHBxhNtsEu/7yC/Hsoj49yBTyIwmSc3B4MmkxADOMxhFPjT6OPmrLEZYBYWkRvkFP4oukDo4QARFfueL4p29LPNEEUFIuTIsMB6zGDKMEL21TACMnebZxjmR2wMkxI+YCokEtbvRSzsUKDOVquh8JJvQJNIkdFkDT63py9JNPMpkJRhD04xF2xGRHelEYyJMwmqoobXsGpwXIeczwkG8wKJwWbdakgQsm5xsjj4ONWnNQhAgA6Z3W1F5NIEOgQxyqhQjlkX3L/sNvJJwmHQkQNgJ9mkRaEaDOSRu0HAIBlKeOj37iTwYTjMMvicJzKB1C2WN5IEEvDD4p+RysuvGj8RMbO15CgMHsj3RaBNo4uRHSPgjAcUYuojKLcwzfhg/AyYYT+kPlA1M5LBSBusfko61Vn79tZssl8RP3P/RDcQ5AOvGiHdvJ5UQQGWxdmgE5KNlaACSYkdSxFQLpOt42YMt2+xqBXIB5UACl97xlzZ03r//lG+MRsM7B/cfuuwuXlhOve9QGRTtCCe3F4Uuekcn62dFP9knzI8mj52k/OuLMW6+sfO3LyHg/eql36bSs+nkXWUuXlVasTDxv3/33du/6nrhqdbwVQeEZ69n2XxkiY/0nGDDGhBAIEpHnagekGIghMCBFCmCUW6iNkhzJxoIAMGofTsxxZKt//p2n2oAjP3ns5Q9/zL56DSXLlBS3NiAfIp9tzJd73DOFzdAU3H3+RQYg9N4/uQUReA5/u6yO2r5lu+0T+Xd9KDH8cUR1HXvmqWc/eJ195ZKYpoBkWoSaRgAACN1Or6u4kB4xlAzd1rxgyDDf26CSInd+WqmRr7/KYoLxYHZd7ECSnR/B91FOb9fd397xqx/iFwtgKwKF+y1KtRbDlvUfNQ4Dn4LIGOeMIeO5fIzSEKSIzCxUUSYTjBOXmsVSBn2P1wCvPX/wkR/t/+bX5r74deOq5QDBOcZ96mHMYNBwAzHyU4DCc0v8wEeOWRECY+lzY14lRkqOpP5rkgWJdRsSC0sexCPZanaPHJo/cODwA/e1Xt7TufMv8Rwwrl4NsUBFgk8L2oo8roJ9tWAmGqM3HhkK0iRrEc2V2pVV3rZP/sGRz9zKwn3M4KInfj5gBfibVuu6T1J1+h9ixm1yuaKAT2G9jpMR5zi52NdCXwXRrE+VtwDU10YC8cOrSPGCT05eQLxIgOSldJMAIjBsVqqOvOBMBGksKT0tzRISEIGSwPRCciItE9KNU399yQmZEaEFBEudTG6A9GBVnbHR97ZHPfAW+7jwPggnV2jfHlA4LTQ4Mszop/nTzPof4i6MIGBJJtWtIHR347lvZjD61QlZxTmS7Htyn2WhSzK47hFanKCeuLxIDm9E841c7Y8J3TauXJPFzsYZuBVKEXyJvdmFvs7CYZBU4RlyEtFtOhJCXwEDtEBj8goEmANce5ZguSdHcucx2sMkHO5XlPp9KBxlWEh1UixwAWm0SDo6dCwTCCIC4NMzWTyweLRxjpOzFgEhktqVjczVWaCb2pcbYdWJ0QzJvZUol2lSIl5D9BrqHR8xbIuz0Yf4xzdkH1UXOtvCVyO8C0xCsWkXniJH4xrjRNJkUuAcgzVnC8vmnOfbcgBAilJIGSaF0GWMlTPQJMlXLlpIzI+E0lINRuDDJLJDzbM3bDRsO4unKYw4Qhq9sYkij0GJ6ce4SgGAoEWJd1fCdcYdU0x1DjVJzI+EeiswOSMpGiRp+Ztx5SqDjd5sQKZD9pENohNp0Y9KMgYA5D8jExGJgGH0rPjNvjAzYkYhRItwhmFRE2Q+pEvLNohVawwxUeRI9yMQEQfijbD3O3ceffY58garsBGBaH7rD6BSC54EMXqk+pFQvlSDQZETF+5Z5w4I7ZfUBR+zSmUhBJsIQUoEMRkZORy6qFhfPf/3t8/dETDpCogBO6OCZh0gRotER0SptFjYWkSzTBAQ8BVPXXyFxVkWahQyjXMkyLukeCgpgMpqvmHAGwosZoIEZixEi8jQ2YmYQUDhZ9DRJIkOp+W97Z3W8pW2aXKeydN3s1plH9YKFJ8dHV4qEtg1GAAIQA3K6V/ipMGR4ZKUwVUfCpyw1gwWRP5RbcMoln8igHj8p941N1pCGIaRhU+BEfdWElesJ4YnFtZ+J/Ij0dPD4c4T+hGIMGeQe5LGVpQj11+H6zeWLHsyyBFFIgViA+QLTfqNy4uTiIInf0iiRajwJGLnF25TbbrMmFlhW1n5FMiKHCmWITL9InZW8JRYhggZku3B4HVhaxH54Nu2yeEGNne5l11dsUumaWakRiGb8PkCfqR/5NQG2eHEzEixBkn9kTTjNDnMgN6cd9H7xPqNZcvMzqdAdlswBD+HZuVEtaovOIcfopPFyZeUQXGZfK6fQsPCKLmugZqlYeNG/mNkAjy6s/euD5QRbDuTIRUfo7QcyHlwPV5sAGVBeXES1iJFXsSypsiLYDtSdAws9HT1nKBzyHn37/I1b6iUypoc2VU1SnIY1Zr/Ky8kL5IkQvSmTYmCxz6mTRhOlBfRioINQwAPgDPq34fBf3MEAhDulrdWKhXbtjIKjPoYZdHTGzcrAPKciB8JYegDAqY/nIESmUEpfiQoPuLSZGhOwhXFIjFIqskNAxD7C/YQh0XnBIjzr7hv/QDbsKliWZZlCSEm6RlvG++6w3nkSD+GleQpAoqkH2ePXDAKsyCoYILnBjniv0QURkheBHKGK+0fdQFnTctkfXYg6PnueVoGqRwyljnXvLsieKlUsiwri2H6IEbcWznzF97buu1PDtz8CbYJ0BoGwvsXx/8YJI2/3SgiiCnk1vCU8OMLMHgAhhn8JH+fl8GhACcCRQ2yBRiiaJdZAiFE/8ceTCNhObIdOP9s+/1/ZiyZLpdKWUvRfo1Z2KX9W3+0/8GH3P37EkRp5D0BSSk9V/U6Skl3z/PO4e1gTyVnhSHJ/LnJiqg/D4Pi+SJ2JdgC0myRAB1ke4VpW8aU4HWD2ZyXBLM4mgw56r/FX0iNvTn3gnd1f/mj01P1pUuX1ut10zQnkhwAQNJz5ucT0uMpRN1e79jRo41m89iePfff+Cu0eRqFBYOJQrH5oCfdhvBHDL1HBsAZEmMoWJ3zusFKnJUFtwUrcWZyNBkKRJYHchCxnU8e/+z95eUrly6Zmp6eLpfLmfZTNLIKnyMX1sk9e4wAhOdJYZBlk2Vf/oXP//iTvyVWnwGM0SDDq2xDejoiYwgc0RJoIrM5MxgKhoIhR2AADKH/3+KLDsLmjubv/G9rZkWlZFcqFdu2M+2k+Mh285aTAQJwxmzLKpdK3U533Zsum33/v9xxx+3WmesycfgISIAIHJEzMBkzGJocDcY0MzgiQ2B9buQA7f3ONR9Xm84vGaJSqZRKpTHYDI3FJwcAIKJlWeVyudfrSSkv+NBHWs/8sHV4O6usHn1dAIjIADkjhmggMziYHA0GAjU/UHcCWB4e/tdr0IoLO9f9Usm2K5VKuVw2TXM8ZgOy0xynCqWU67qNRmN2drbVbh/ftev5//IpVx4C3XkZBYJhLTawEAZDwZjJwOLcYGgx1IZEIHKGDJDr3suieBe3Q+Uzmjf9nr18Za1cXrpsWbVaHYMO9ZEXcgCAlLLT6czNzc3NNVqddnPH9hff9wFx1VmAfFT+pc8PJL27k/YsBkOBzOIoECzOOEODIQdNDj3NeTHIQRK7h+f/xZ/ghs21cqler09PT49NbWjkiBxEJKVstVpzc3Nzc3M9Rccf/cGhL/4O1tcBG5X700+ARETQwoIzFAhaigpEg6FA5AiMIQNk2F+vMG75oTycf2b+175KF1xSFXxqampqakr3UMZJ0xyRAwCIyHXdZrM5OzvbarU6jtP6hwcbX/k9XHnuSLw/6S3hdAxUk0MrU0SOwBkaWo0i6t0lcaBRXnvVp9RMbDzZvvFz3mVXlwWv1WrT09OVSsUwjDG3JBeCNAghRKVSkVKCHpi55p0CqHvHf4T6ufH9ik8V/vo5JNArjxmCDnj0VYiWq4vIDCVx7un2h7/ovfHysuCVSqVWq5XL5WHwdozIFzn09zcMo1KpKKWklNRuw9XXcc7VHbfQ1Hmj2BEUgfSoiXYuiADaWiABY4AwZMa4oTzs7Om87zb3kreUSJVKpWq1uig2QyNfbkVDi49er3f8+PFms9nudHqepKe2si/9a5g5F7j5WisIKIggFfQeBhhmxviuitcF51j7n/1n7/xLSoKXSqWpqal6va5HX8fUhjDySA4AICKlVKvVmp+fbzQanU6nB0g/fc74v7ehe4yMyqubtoX9IRgE/wH1Qyr0mQGLwAyE3hxV17Vu/DidvdkiVa1Wq9VqvV4fzwBbarPySQ4AICLP89rtdrPZbDQa3W7XkUodPlD6H7+KJKiy9lWU6Yc6/AE5nw2Rn3+snYLWbrVkw/w//xSuWGlxblnW1NRUrVYrlUqLIjWGDcstOWDgXzqdTrPZbDabnU7HkdJ1eqV77zB+/FWonQWvSoIEx/Oig3NjvhJE2NrtXvHh1ns+aDBuCl4ulyuVytTU1OLaDI28kwMAPM/rdDrav/S63Z7nea5rPP1Y+ev/Bupnk1k7YTn5BDpNOPJy6+O3e+deYAjDNAzbtmu1WrVaHX9II7mFeSaHhrYf3W632Wy2Wq12q+V6nksEB/eX7v2GePluKm0AZuRtTl86EJSLnX3euTe0bvgAW7ZSIJiGUSqVarVarVYzTXNxvcmwofknBwz0abfbbbfbjUaj3W47juMBSNeztj5k3f8VkB0ozSx2M08K2NpL1tLuu3/T2XIFF4bBUHfdtQgdw+S/k8dkkAMG/HAcp9VqNZvNPj+k9BTR8aPl791pPPEXVDkbjNHv8jwyOA1s7XCu+u3u226A6RmBIDjXw9E60qVHXHPCDJggcgD0V+r7EqTVavV6PcdxJJGLTOz8qbX1AePxL1NlI5jVHC1RQgRnHpvb3bf8Zu+ya+SGzUJ6gjEhhG3bOszld0zywwyYLHLAgB9agrRarVar1W63Pc+TUnqIqtvhu3eU7vuaeOEBtfxsMCqAfDG1CElwO+zQS96F13eu/7Bcu56ZpiDinJumadu29iaWZWn5mStmwMSRQ0O7GNd1tUrtdrvdbtfzPKmUJPA45ztesB97WOx4HI8+SpXzwLDHakgQwe3g/Atq1dvk2vO6V18v1643pGQIfGAwdJfVtm09PyNvtNCYSHJo6MGXbrfb6XRarVa323Vd1/M8pZQHqJRkhw4YO39qPHaPePYhWnEGWTOALMNJoUR6EgYeO+id9w738hvcDZvUzHLOOCfSz5o0DKNUKpXL5XK5rA3GOOdnnCommBwwMCGe52mKtNttTREppSJSAEop5Tp49LD95I/FM4+gMwvt/SgqxEsgSn4xr6ryQRTN66LskOyAvYIqK9zz39y7+EpaupwJwRnTM2QZY5oWmhmm2V8dn0+D4WOyyaGhVYj2Mp1Op9frdTodLUSU0g9qRsm56nXEgb18325x4BV2aDd/6i4wAOwaGMvJrJ5CsFUpcJvoHMBuhxDkee+Vy9fJdRvlilXe6jcww2BScSD9ZFrOuWEYlmVpZliWlbcuyQI4HcgBAaHqum6v19Md3V6vpx0NaQsDQIgKkHpdcHrQ7bDZQ2LfbrbvZePF72LjGHAAri1CcOKIDrVL0EugFKipVXLT9XLNRm/VWjW9HGwbTAttmylCIIYIANpfmKZpWZZt27ZtB2kxEcyA04YcPpRS2tFocnS7XcdxHMfRhkSTRH9hRUSIhEwhEDIlJW8eZ/NN8DxUaihg9TxBxsg0ZLmq6tPIGCPFiBgBkhoscAF94TnnQgjLsrQf0W8mwonEcbqRQ8OniOu6TgBajvgsgcHwTf8pH4DkzxXzQf4cUkICBNKZYTBK53NCexDTNLXB0O+1CZkgaxHE6UkODd/X6H6vJod2ND5LtCbpKxMI7Tzkr97uD+Ei+tdYX28tKYQQOm4hhNBKUwihd86YUE74OJ3JoeFfdU0Fz/O0i9Es0V3fvnRVigbwT/SNhAZjTHNCQwxgGIZOOQ044eP0J0cQ+suqAXxO+G+C/PDJEWcGG8B/7+dZ7K84Sry+yBFE4GlRUQSPamAYwZTxt3xseP2SYwEk/ianNw8SUZCjQCryG9gvsOgoyFEgFQU5CqSiIEeBVBTkKJCKghwFUlGQo0AqCnIUSEVBjgKpKMhRIBUFOQqkoiBHgVQU5CiQioIcBVJRkKNAKgpyFEhFQY4CqSjIUSAVBTkKpKIgR4FUFOQokIqCHAVSUZCjQCoKchRIRUGOAqn4//aUiXwshGeRAAAAAElFTkSuQmCC"},"minimumSupportedOperatingSystem":{"v8_0":true},"notes":"","owner":"","privacyInformationUrl":"","publisher":"Microsoft Corporation"}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            $CatCounter = 0
            While ($CatCounter -le 10) {
                Try {
                    $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                    Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                    $CatCounter = 10
                    Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
                }
                Catch {
                    $CatCounter++
                    Sleep 2
                }
            }

            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}