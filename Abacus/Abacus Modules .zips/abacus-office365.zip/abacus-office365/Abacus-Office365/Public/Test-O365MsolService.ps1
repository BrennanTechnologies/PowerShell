
<#
.SYNOPSIS
A command for Testing if a connection to the AzureAD instance already exists

.DESCRIPTION
While this command almost never needs to be run manually, this command is used as a sanity check for underlying functions in an attempt to ensure that a connection to an AzureAD environment is already open before running executing commands. Additionally, this test will attempt to verify to make sure that there is an expected comparison in the region supplied in the Office365Instance variable to the result of the country code returned by the base Get-MsolCompanyInformation MSOnline command.

.PARAMETER Office365Instance
A value specifying the Region to test if a connection is open. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Test-O365MsolService -Office365Instance US

.EXAMPLE
Test-O365MsolService -Office365Instance UK

.NOTES
Most of the other commands within this module utilize this command for sanity checking and connection verification.
#>
Function Test-O365MsolService {
    [CmdletBinding()]
    Param(
        [ValidateNotNull()]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
    )
    Begin {
        $CountryCode = ""
        Switch ($Office365Instance) {
            'US' { $CountryCode = "US" }
            'UK' { $CountryCode = "GB" }
        }
    }
    Process {
         # Store AccessTokens
         If (   ($global:o365Atoken.ExpiresOn.LocalDateTime -le (Get-Date).AddMinutes(30)) -and ($True -eq [Boolean]$($global:o365Atoken))   ){
            If ( $Null -ne $global:o365Ptoken ) {
                Write-Log -LogString "Refreshing AccessToken for MS Login + PartnerCenter." -LogLevel Output -LogObject $O365_global_logobject
                Start-O365MsolService -Office365Instance $Office365Instance -ConnectToPartnerCenter
            }
            Else {
                Write-Log -LogString "Refreshing AccessToken for MS Login" -LogLevel Output -LogObject $O365_global_logobject
                Start-O365MsolService -Office365Instance $Office365Instance
            }
         }

         $ConnectionInfo = Get-MsolCompanyInformation -ErrorAction SilentlyContinue

        If (    ($ConnectionInfo -eq $null) -or (($ConnectionInfo.DisplayName).contains("Abacus") -ne $True) -or ($ConnectionInfo.CountryLetterCode -ne $CountryCode)     ) {
            Throw [System.Exception]@{Source = "Test-0365MsolService"; }
        }
        Else {
            Return $True
        }
    }
}