<#
.SYNOPSIS
A command for querying one or more Mobile Apps.

.DESCRIPTION
A command for querying one or more Mobile Apps.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER Name
The DisplayName of the Mobile App you are looking for. If left blank this will query all possible.

.EXAMPLE
Get-O365MobileApps -Headers $Headers

.EXAMPLE
Get-O365MobileApps -Headers $Headers -Name 'Microsoft Outlook'

.NOTES
General notes
#>
Function Get-O365MobileApps {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$Name = $Null
    )
    Begin {
    }
    Process {
        Try {
            If (   $False -eq [String]::IsNullOrEmpty($Name)   ) {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps?`$filter=displayname eq '$($Name)'" `
                    -Method Get `
                    -ErrorAction Stop
            }
            Else {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                    -Method Get `
                    -ErrorAction Stop
            }
        }
        Catch {
            Write-Log -LogString "There was an error querying the endpoint for Mobile Apps.`nException: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    End {
        Return $Results
    }
}