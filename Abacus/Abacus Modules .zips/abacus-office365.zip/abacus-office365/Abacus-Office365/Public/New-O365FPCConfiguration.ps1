<#
.SYNOPSIS
A command for applying various Abacus specific FPC configuration options to an O365 Tenant.

.DESCRIPTION
A command for applying various Abacus specific FPC configuration options to an O365 Tenant.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER UseExistingDynamicGroupAll
An optional Switch parameter to use if DynamicGroupAll already exists and to not attempt to create it.

.EXAMPLE
New-O365FPCConfiguration -Office365Instance US -TenantId <TenantId>

.NOTES
General notes
#>

Function New-O365FPCConfiguration {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [ValidateNotNullorEmpty()]
        [Switch]$UseExistingDynamicGroupAll = $False
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType MDMRefreshToken -ErrorAction Stop)
        $MDMRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($MDMRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning -LogObject $O365_global_logobject
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

            Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose -LogObject $O365_global_logobject
            If ($RefreshTokenStatus -eq $False) {
                Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
            Else {
                $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $MDMRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
            }

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel Error -LogObject $O365_global_logobject
            }


            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))

            Write-Log -LogString "Attempting to obtain MDM Device information for Company `"$($TenantInfo.CompanyName)`"" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $DataResults = @()
        }
        Catch {
            Write-Log -LogString "There was an error initalizing our connection.`nException {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        ### Actions ###

        If ($False -eq $UseExistingDynamicGroupAll) {
            # Create the Dynamic Group First
            Write-Log -LogString "Creating DynamicGroupAll..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365SecurityGroup -TenantId $TenantId -Office365Instance $Office365Instance -MembershipType Dynamic -DisplayName 'DynamicGroupAll' -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "200" {
                    $DataResults += [PSCustomObject]@{Action = "CreateDynamicGroupAll"; Result = "SUCCESS"; Data = $($cmdResult.Data) }
                    $DynamicGroupAllId = $($cmdResult.Data.id)
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateDynamicGroupAll"; Result = "FAILED"; Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #
        }
        Else {
            # Query If the Dynamic Group already exists
            Write-Log -LogString "Checking for existing DynamicGroupAll..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = Get-O365DistributionList -Displayname 'DynamicGroupAll' -TenantId $TenantId -Office365Instance $Office365Instance
            Switch ($cmdResult.Status) {
                "200" {
                    If (   $Null -ne $cmdResult.Data   ) {
                        Write-Log -LogString "Existing DynamicGroupAll was detected successfully." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Cyan
                        $DynamicGroupAllId = $($cmdResult.Data.id)
                        $DataResults += [PSCustomObject]@{Action = "LocateDynamicGroupAll"; Result = "SUCCESS"; Data = $($cmdResult.Data) }
                    }
                    Else {
                        Write-Log -LogString "No existing DynamicGroupAll was detected.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }

                }
                Default {
                    Write-Log -LogString "No existing DynamicGroupAll was detected.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #
        }

        If ($DataResults.Result -eq 'SUCCESS') {

            Sleep 30

            # Create the Windows 10 Device Restriction Policy
            Write-Log -LogString "Creating Win10DeviceRestrictionsPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10DeviceRestrictionsPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10DeviceRestrictionsPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10DeviceRestrictionsPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Windows 10 RDP Policy
            Write-Log -LogString "Creating Win10RDPPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10RDPPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10RDPPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10RDPPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Windows 10 Security Policy
            Write-Log -LogString "Creating Win10SecurityPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10SecurityPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10SecurityPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10SecurityPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Windows 10 Outlook Policy
            Write-Log -LogString "Creating Win10OutlookPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10OutlookPolicy -Headers $Headers -CompanyName $($TenantInfo.CompanyName) -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10OutlookPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10OutlookPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Windows 10 Update Policy
            Write-Log -LogString "Creating Win10UpdatePolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10UpdateRingPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10UpdatePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10UpdatePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the iOS Native Email Policy
            Write-Log -LogString "Creating iOSNativeEmailPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSNativeEmailPolicy -Headers $Headers -CompanyName $($TenantInfo.CompanyName) -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "iOSNativeEmailPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "iOSNativeEmailPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the MacOS Policy
            Write-Log -LogString "Creating MacOSSecurityPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365MacOSSecurityPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSSecurityPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSSecurityPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the MacOS Device Restriction Policy
            Write-Log -LogString "Creating MacOSDeviceRestrictionPolicy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365MacOSDeviceRestrictionPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the iOS Device Restriction Policy
            Write-Log -LogString "Creating iOS Device Restriction Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSDeviceRestrictionPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android Device Restriction Policy
            Write-Log -LogString "Creating Android Device Restriction Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidDeviceRestrictionPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidDeviceRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Samsung Native Mail Restriction Policy
            Write-Log -LogString "Creating Samsung Native Mail Restriction Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365SamsungNativeMailRestrictionPolicy -Headers $Headers -CompanyName $($TenantInfo.CompanyName) -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateSamsungNativeMailRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateSamsungNativeMailRestrictionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android Managed App Protection Policy
            Write-Log -LogString "Creating Android Managed App Protection Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidManagedAppProtectionPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidManagedAppProtectionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidManagedAppProtectionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the iOS Managed App Protection Policy
            Write-Log -LogString "Creating iOS Managed App Protection Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSManagedAppProtectionPolicy -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSManagedAppProtectionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSManagedAppProtectionPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Disable Firewall Script
            Write-Log -LogString "Creating Disable Firewall Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365DisableFirewallScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateDisableFirewallScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateDisableFirewallScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Enable Long Path Script
            Write-Log -LogString "Creating Enable Long Path Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365EnableLongPathScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateEnableLongPathScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateEnableLongPathScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the AGAdmin Creation Script
            Write-Log -LogString "Creating AGAdmin Creation Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365CreateAGAdminScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAGAdminCreationScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAGAdminCreationScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the Disable Telemetry Script
            Write-Log -LogString "Creating Disable Telemetry Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365DisableTelemetryScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateDisableTelemetryScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateDisableTelemetryScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Enable Outlook SSO Script
            Write-Log -LogString "Creating Outlook SSO Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365OutlookSSOScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateOutlookSSOScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateOutlookSSOScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the OneDrive Auto Config Script
            Write-Log -LogString "Creating OneDrive Auto Config Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365OneDriveAutoConfigScript -Headers $Headers -TargetId "ALL" -TenantId $($TenantInfo.TenantId) -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateOneDriveAutoConfigScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateOneDriveAutoConfigScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the OneDrive EnableADAL Script
            Write-Log -LogString "Creating OneDrive EnableADAL Script..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365OneDriveEnableADALScript -Headers $Headers -TargetId "ALL" -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateOneDriveEnableADALScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateOneDriveEnableADALScript"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            ######


            # Create the Office Suite Managed App
            Write-Log -LogString "Creating Office Suite Managed App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365OfficeSuiteManagedApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateOfficeSuiteManagedApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateOfficeSuiteManagedApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the MacOS Office Suite Managed App
            Write-Log -LogString "Creating MacOS Office Suite Managed App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365MacOSOfficeSuiteManagedApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSOfficeSuiteManagedApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSOfficeSuiteManagedApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Update Automatic Device Cleanup Rules
            Write-Log -LogString "Updating Automatic Device Cleanup Rules..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = Update-O365AutoDeviceCleanupRules -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "UpdateAutoDeviceCleanupRules"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "UpdateAutoDeviceCleanupRules"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # New SharePoint Configuration
            Write-Log -LogString "Creating SharePoint Configuration Template..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365SharePointConfiguration -Headers $Headers -TargetId $DynamicGroupAllId -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateSharePointConfigurationTemplate"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateSharePointConfigurationTemplate"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # New Block Removable Storage Policy
            Write-Log -LogString "Creating Block Removable Storage Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365BlockRemovableStoragePolicy -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateBlockRemovableStoragePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateBlockRemovableStoragePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # New Win10 Bitlocker Configuration Profile
            Write-Log -LogString "Creating Win10 Bitlocker Configuration Profile..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10BitlockerProfile -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10BitlockerConfigurationProfile"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10BitlockerConfigurationProfile"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # New Win10 Bitlocker Compliance Policy
            Write-Log -LogString "Creating Win10 Bitlocker Compliance Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365Win10BitlockerCompliancePolicy -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10BitlockerConfigurationPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateWin10BitlockerConfigurationPolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # New MacOS Bitlocker Compliance Policy
            Write-Log -LogString "Creating MacOS Bitlocker Compliance Policy..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365MacOSBitlockerCompliancePolicy -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSBitlockerCompliancePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateMacOSBitlockerCompliancePolicy"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            ##################

            # Create the Android Outlook App
            Write-Log -LogString "Creating Android Outlook App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidOutlookApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidOutlookApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidOutlookApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android OneDrive App
            Write-Log -LogString "Creating Android OneDrive App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidOneDriveApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidOneDriveApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidOneDriveApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android SharePoint App
            Write-Log -LogString "Creating Android SharePoint App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidSharePointApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidSharePointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidSharePointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android Teams App
            Write-Log -LogString "Creating Android Teams App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidTeamsApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidTeamsApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidTeamsApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android Excel App
            Write-Log -LogString "Creating Android Excel App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidExcelApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidExcelApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidExcelApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android PowerPoint App
            Write-Log -LogString "Creating Android PowerPoint App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidPowerPointApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidPowerPointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidPowerPointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #


            # Create the Android Word App
            Write-Log -LogString "Creating Android Word App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365AndroidWordApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidWordApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateAndroidWordApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            ##################

            # Create the iOS Outlook App
            Write-Log -LogString "iOS Outlook App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSOutlookApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSOutlookApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSOutlookApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS OneDrive App
            Write-Log -LogString "iOS OneDrive App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSOneDriveApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSOneDriveApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSOneDriveApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS SharePointApp
            Write-Log -LogString "iOS SharePoint App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSSharePointApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSSharePointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSSharePointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS Teams
            Write-Log -LogString "iOS Teams App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSTeamsApp -Headers $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSTeamsApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSTeamsApp"; $Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS Excel
            Write-Log -LogString "iOS ExcelApp..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSExcelApp $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSExcelApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSExcelApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS Word
            Write-Log -LogString "iOS Word App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSWordApp $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSWordApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSWordApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            # Create the iOS PowerPoint
            Write-Log -LogString "iOS PowerPoint App..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = New-O365iOSPowerPointApp $Headers -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSPowerPointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "CreateiOSPowerPointApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #

            ###

            # Update Branding & Customization
            Write-Log -LogString "Updating Branding & Customization..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
            $cmdResult = Update-O365CompanyPortalApp $Headers -Office365Instance $Office365Instance -ErrorAction Continue
            Switch ($cmdResult.Status) {
                "SUCCESS" {
                    $DataResults += [PSCustomObject]@{Action = "UpdateCompanyPortalApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
                Default {
                    $DataResults += [PSCustomObject]@{Action = "UpdateCompanyPortalApp"; Result = $($cmdResult.Status); Data = $($cmdResult.Data) }
                }
            }
            Clear-Variable cmdResult -ErrorAction SilentlyContinue
            #
        }
        Else {
            Write-Log -LogString "There was an error with creating/querying DynamicGroupAll.`nException: {$($DataResults.Data | ConvertTo-Json)}" -LogLevel Error -LogObject $O365_global_logobject
        }
    }
    End {
        Return $(   $DataResults  | Convertto-Json   )
    }
}