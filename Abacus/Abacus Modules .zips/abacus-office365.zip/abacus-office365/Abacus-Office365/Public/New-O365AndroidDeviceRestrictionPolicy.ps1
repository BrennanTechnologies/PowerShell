<#
.SYNOPSIS
A command for creating the base Android Device Restriction Policy.

.DESCRIPTION
A command for creating the base Android Device Restriction Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365AndroidDeviceRestrictionPolicy -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>
Function New-O365AndroidDeviceRestrictionPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{
    "displayName":  "Android - Device Restrictions",
    "description":  "Android - Device Restrictions",
    "roleScopeTagIds":  [

                        ],
    "@odata.type":  "#microsoft.graph.androidGeneralDeviceConfiguration",
    "passwordSignInFailureCountBeforeFactoryReset":  10,
    "passwordRequiredType":  "numeric",
    "passwordRequired":  true,
    "passwordMinimumLength":  4,
    "passwordMinutesOfInactivityBeforeScreenTimeout":  5
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}