<#
.SYNOPSIS
A command for updating the Client's Company Portal App Information.

.DESCRIPTION
A command for updating the Client's Company Portal App Information.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER Office365Instance
The Office365Instance of the tenant, used to determine the phone number.

.EXAMPLE
Update-O365CompanyPortalApp -Headers <Headers> -Office365Instance <US>

.NOTES
N/A
#>

Function Update-O365CompanyPortalApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("US","UK")]
        [String]$Office365Instance
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            Switch ($Office365Instance) {
                'US' {
                    $PhoneNumber = '+1-866-997-3999'
                }
                'UK' {
                    $PhoneNumber = '+44-207-936-1799'
                }
            }
            # Action(s)
            $JSON = @"
{
    "displayName":  "Abacus Group LLC",
    "privacyUrl":  "http://www.abacusgroupllc.com/privacy-policy",
    "contactITName":  "Abacus Group LLC",
    "contactITPhoneNumber": "$PhoneNumber",
    "contactITEmailAddress":  "helpdesk@abacusgroupllc.com",
    "onlineSupportSiteName":  "Abacus Group LLC",
    "onlineSupportSiteUrl":  "https://www.abacusgroupllc.com",
    "contactITNotes":  "Trusted IT Solutions for Investment Management Firms",
    "themeColor":  {
        "r":  0,
        "g":  114,
        "b":  198
    },
    "isRemoveDeviceDisabled":  false,
    "isFactoryResetDisabled":  false,
    "showLogo":  false,
    "showDisplayNameNextToLogo":  true,
    "customPrivacyMessage":  ""
}
"@
Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $BrandingId = $(Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/intuneBrandingProfiles").Value[0].id

            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/intuneBrandingProfiles('$($BrandingId)')" `
                -Method Patch `
                -Body $JSON `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}