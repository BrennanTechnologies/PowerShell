<#
.SYNOPSIS
A function for creating an AzureAD application.

.DESCRIPTION
This function is used for creating an Application within a Tenant's AzureAD environment such as ProofPoint.

.PARAMETER AppType
The type of App to be created.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER ExpirationDate
The desired expirationdate of the application secret key.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
New-O365TenantApp -AppType {ProofPoint} -TenantId {TenantId} -Office365Instance {US/UK}

.EXAMPLE
New-O365TenantApp -AppType {Okta} -TenantId {TenantId} -Office365Instance {US/UK}

.NOTES
N/A
#>

Function New-O365TenantApp {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [ValidateSet("ProofPoint", "Okta")]
        [String]$AppType
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNull()]
        [String]$ExpirationDate = $((Get-Date).AddYears(99))
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }

        #Gather Creds
        Switch ($Office365Instance) {
            "US" {
                [String]$SecretName = 'srv-O365USProvisioner'
                Write-Log -LogString "`$SecretName has been set to $SecretName" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)

            }
            "UK" {
                [String]$SecretName = 'srv-O365UKProvisioner'
                Write-Log -LogString "`$SecretName has been set to $SecretName" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
            Default {
                Write-Log -LogString "There was an unhandled error" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        Try {
            Switch ($SecretName) {
                "srv-O365USProvisioner" {
                    $Credentials = (Get-O365Credentials -SecretName "srv-O365USProvisioner" -SecretType O365Login)
                    Write-Log -LogString "`$Credentials have been set" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }

                "srv-O365UKProvisioner" {
                    $Credentials = (Get-O365Credentials -SecretName "srv-O365UKProvisioner" -SecretType O365Login)
                    Write-Log -LogString "`$Credentials have been set" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
                Default {
                    Write-Log -LogString "Unhandled error" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
        }
        Catch {
            Write-Log -LogString "There was an issue gathering credentials" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        Try {
            $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an issue gathering the Tenant Information." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        #Connect to AzureAD under the Tenant's environment with the partner account
        Try {
            Connect-AzureAD -TenantId $TenantId -Credential $Credentials
        }
        Catch {
            Write-Log -LogString "There was an issue connecting to the Azure AD environment" -LogLevel Warning -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "$($_.Exception)" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
    Process {
        #Create new Base64 Symmetric Key
        $SymmetricKey = New-Object Byte[] 32
        [System.Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($SymmetricKey)
        $Base64Key = [Convert]::Tobase64String($SymmetricKey)

        #Create new app


        #Set App Perms
        Switch ($AppType) {
            'ProofPoint' {
                $AppDisplayName = "Abacus Proofpoint"
                Write-Log -LogString "Creating new AzureAD App" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-AzureADApplication -DisplayName $AppDisplayName -OutVariable newMsolService
                #Set Spam Reply Url
                Write-Log -LogString "Set spam url on new App" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                Set-AzureADApplication -ObjectId $newMsolService.ObjectId `
                    -ReplyUrls "https://spam.accessabacus.com" `
                    -Homepage "https://spam.accessabacus.com"

                #Set App Password
                Write-Log -LogString "Setting a new App password" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-AzureADApplicationPasswordCredential -ObjectId $newmsolservice.ObjectId `
                    -EndDate $ExpirationDate `
                    -Value $Base64Key `
                    -CustomKeyIdentifier "ProofpointKey"

                #Create Array Containing permissions for the AppId
                $Perms = @()
                $Perms += [PSCustomObject]@{Id = "5778995a-e1bf-45b8-affa-663a9f3f4d04"; Type = "Role" }
                $Perms += [PSCustomObject]@{Id = "5778995a-e1bf-45b8-affa-663a9f3f4d04"; Type = "Scope" }
                $Perms += [PSCustomObject]@{Id = "6234d376-f627-4f0f-90e0-dff25c5211a3"; Type = "Scope" }
                $Perms += [PSCustomObject]@{Id = "cba73afc-7f69-4d86-8450-4978e04ecd1a"; Type = "Scope" }
                $Perms += [PSCustomObject]@{Id = "311a71cc-e848-46a1-bdf8-97ff7156d8e6"; Type = "Scope" }

                #Create Permission Model used to apply permissons on the AppId object
                Write-Log -LogString "Creating permissions scope for the App" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $Resource = New-Object Microsoft.Open.AzureAD.Model.RequiredResourceAccess
                $Perms | % {
                    $Resource.ResourceAccess += $(New-Object Microsoft.Open.AzureAD.Model.ResourceAccess("$($_.id)", "$($_.type)"))
                }

                #Set the Windows AzureAD Resource Type GUID
                $Resource.ResourceAppId = "00000002-0000-0000-c000-000000000000"

                #Apply the permissions on the AppID
                Write-Log -LogString "Setting the permissions on our App with the new scope" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                Set-AzureADApplication -ObjectId $newmsolservice.ObjectId -RequiredResourceAccess $Resource

                #Create a SPN for the new App
                Write-Log -LogString "Creating a service principal" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-MsolServicePrincipal -AppPrincipalId $newmsolservice.AppId `
                    -DisplayName $AppDisplayName `
                    -AccountEnabled:$true `
                    -TenantId $TenantId `
                    -Value $Base64Key `
                    -StartDate $(Get-Date) `
                    -EndDate $ExpirationDate
            }
            'Okta' {
                $AppDisplayName = "Abacus Okta"
                Write-Log -LogString "Creating new AzureAD App" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-AzureADApplication -DisplayName $AppDisplayName -OutVariable newMsolService
                Write-Log -LogString "Creating AzureAD App for Okta" -LogLevel Output -LogObject $O365_global_logobject
                Set-AzureADApplication -ObjectId $newMsolService.ObjectId `
                    -ReplyUrls "https://abacus.okta.com", "https://abacus.okta.com/oauth2/v1/authorize/callback"

                #Set App Password
                Write-Log -LogString "Setting a new App password" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-AzureADApplicationPasswordCredential -ObjectId $newmsolservice.ObjectId `
                    -EndDate $ExpirationDate `
                    -Value $Base64Key `
                    -CustomKeyIdentifier "OktaKey"
                #New-AzADAppCredential -ObjectId $test.objectid -Password $($Base64Key | convertto-securestring -AsPlainText -Force) -EndDate $ExpirationDate -StartDate $(Get-Date) <-- SecureApi

                #Create Array Containing permissions for the AppId
                $Perms = @()
                #$Perms += [PSCustomObject]@{Id = "00000003-0000-0000-c000-000000000000"; Type = "Role" }
                $Perms += [PSCustomObject]@{Id = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"; Type = "Scope" }

                <#
                {
                    "id":  "93a89ee2-24d7-4658-9aa7-6bd6b1404e6c",
                    "requiredResourceAccess":  [{
                        "resourceAppId":  "00000003-0000-0000-c000-000000000000",
                        "resourceAccess":  [{
                            "id":  "e1fe6dd8-ba31-4d61-89e7-88639da4683d",
                            "type":  "Scope"
                        }]
                    }]
                }
                #>

                #Create Permission Model used to apply permissons on the AppId object
                Write-Log -LogString "Creating permissions scope for the App" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                $Resource = New-Object Microsoft.Open.AzureAD.Model.RequiredResourceAccess
                $Perms | % {
                    $Resource.ResourceAccess += $(New-Object Microsoft.Open.AzureAD.Model.ResourceAccess("$($_.id)", "$($_.type)"))
                }

                #Set the Resource Type GUID
                $Resource.ResourceAppId = "00000003-0000-0000-c000-000000000000"

                #Apply the permissions on the AppID
                Write-Log -LogString "Setting the permissions on our App with the new scope" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                Set-AzureADApplication -ObjectId $newmsolservice.ObjectId -RequiredResourceAccess $Resource

                #Create a SPN for the new App
                Write-Log -LogString "Creating a service principal" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                New-MsolServicePrincipal -AppPrincipalId $newmsolservice.AppId `
                    -DisplayName $AppDisplayName `
                    -AccountEnabled:$true `
                    -TenantId $TenantId `
                    -Value $Base64Key `
                    -StartDate $(Get-Date) `
                    -EndDate $ExpirationDate
            }
            Default {
                Write-Log -LogString "Unkown AppType" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        #Create a secret on the secret server for the new AppID
        #Set App information
        $Description = "$($AppDisplayName) - $($AppType) API connection for $($CompanyName)"

        Try {
            $SecArgs = @{
                "Microsoft Azure Instance" = "Abacus Group LLC ($Office365Instance)"
                "AppID"                    = $($newMsolService.AppId)
                "Expiration Date"          = $ExpirationDate
                "Description"              = $Description
                "TenantID"                 = $TenantId
            }

            #Create the Secret on the secret sever for the new AppId
            Write-Log -LogString "Creating Secret for our new AppId" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Add-Secret -SecretName "$($TenantInfo.CompanyName) - $AppDisplayName - Microsoft AppId" `
                -Password $Base64Key `
                -ArgumentList $SecArgs `
                -SecretTemplate "Microsoft Azure AppId" `
                -FolderName "Microsoft Azure AppIds"
            Write-Log -LogString "AppID Secret Created" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
        Catch {
            Write-Log -LogString "There was an error trying to create the new secret for the AppId on the secret server" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
}