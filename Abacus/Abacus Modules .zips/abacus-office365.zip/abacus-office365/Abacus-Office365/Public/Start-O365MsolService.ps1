<#
.SYNOPSIS
This command is an Abacus specific wrapper around the default Connect-MsolService function included in the MSOnline module.

.DESCRIPTION
Before executing commands against an Office365 instance, a connection first needs to be established to an Azure Environment. This command is an Abacus wrapper around the default Connect-MsolService which allows for us to easily connect to the US or UK Azure Environments respectively under the context of Abacus' Partner Center Administrator for the respective Azure Region. Most commands within this command utilize this underlying connection and as such the Office365Instance variable is used across all of these commands for easy of use and integration. The "CompanyName" variable is labeled as such due to legacy functionality, but this is used specifically to pass Region codes (US, UK) from commands to help specify which environment to connect to if it is not known by the proceeding command.

.PARAMETER Office365Instance
A value specifying the Region in which to connect. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER ConnectToPartnerCenter
A flag which can be set if a connection to the PartnerCenter API is also needed. If set, this will establish a connection to the respective Partner Center.

.EXAMPLE
Start-O365MsolService -Office365Instance US

.EXAMPLE
Start-O365MsolService -Office365Instance UK

.NOTES
This command needs to be run to first establish an underlying connection for most other commands within this module.
#>

Function Start-O365MsolService {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [Switch]$ConnectToPartnerCenter = $False
    )
    Begin {
        #Set the connection string based on the desired Instance
        Switch ($Office365Instance) {
            "US" {
                [String]$SecretName = "srv-O365USProvisioner"
                [String]$AppId = "srv-O365USProvisioner Microsoft AppId"
            }
            "UK" {
                [String]$SecretName = "srv-O365UKProvisioner"
                [String]$AppId = "srv-O365UKProvisioner Microsoft AppId"
            }
            Default {
                Write-Log -LogString "Script encountered an unhandled error while trying to pick an O365 Instance" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }
        $SecretUser = Get-O365Credentials -SecretName $SecretName -SecretType RefreshToken
        $SecretAppId = Get-O365Credentials -SecretName $SecretName -SecretType MSAppID
        $RefreshToken = $($SecretUser.Data.Value)
    }
    Process {
        If (  $False -eq [String]::IsNullOrEmpty($RefreshToken)   ) {
            Write-Log -LogString "Now attempting to connect to Azure" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $TenantId = $SecretUser.TenantId
            $AppId = $SecretAppId | Select -ExpandProperty AppId
            $AppKey = $SecretAppId | Select -ExpandProperty Key

            $Credentials = New-Object PSCredential -ArgumentList $AppId, $("$AppKey" | ConvertTo-SecureString -AsPlainText -Force)

            Write-Log -LogString "Fetching our Microsoft Login Token..." -LogLevel Verbose -LogObject $O365_global_logobject
            $LoginToken = Get-AccessToken -AppId $AppId -RefreshToken $RefreshToken -Credentials $Credentials -TenantId $TenantId -Resource 'https://login.microsoftonline.com/'
            $global:o365Atoken = $LoginToken

            If ( $True -eq $ConnectToPartnerCenter ) {
                Write-Log -LogString "Fetching our Partner Center Login Token..." -LogLevel Verbose -LogObject $O365_global_logobject
                $PartnerToken = Get-AccessToken -AppId $AppId -RefreshToken $RefreshToken -Credentials $Credentials -TenantId $TenantId -Resource 'https://api.partnercenter.microsoft.com'
                $global:o365Ptoken = $PartnerToken
            }

            Write-Log -LogString "Updating our Refresh token for {$($SecretUser)}." -LogLevel Verbose -LogObject $O365_global_logobject
            Update-RefreshToken -NewRefreshToken $LoginToken.RefreshToken -ClientAdminSecret $SecretUser

            #Connect to O365
            Try {
                Write-Log -LogString "Connecting to Office365..." -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                Connect-MsolService -AccessToken $($LoginToken.AccessToken) -AzureEnvironment AzureCloud
                Write-Log -LogString "Connection to Office365 Established sucessfully" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
            Catch {
                Write-Log -LogString "There was an error trying to connect to the Office365 environment" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }

            #Connect to PartnerCenter
            If ( $True -eq $ConnectToPartnerCenter ) {
                Try {
                    Write-Log -LogString "Connecting to PartnerCenter..." -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                    Connect-PartnerCenter -AccessToken $($PartnerToken.AccessToken) -ApplicationId $AppId -Credential $Credentials -Environment GlobalCloud -TenantId $SecretUser.TenantId | Out-Null
                    Write-Log -LogString "Connection to PartnerCenter Established sucessfully" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
                Catch {
                    Write-Log -LogString "There was an error trying to connect to the PartnerCenter" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
        }
        Else {
            Write-Log -LogString "No refresh token was detected on the secret object." -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
}

