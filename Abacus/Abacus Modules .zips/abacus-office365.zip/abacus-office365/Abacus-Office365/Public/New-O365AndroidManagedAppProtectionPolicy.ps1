<#
.SYNOPSIS
A command for creating the base Android ManagedApp Protection Policy.

.DESCRIPTION
A command for creating the base Android ManagedApp Protection Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365AndroidManagedAppProtectionPolicy -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>
Function New-O365AndroidManagedAppProtectionPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{
    "@odata.type":  "#microsoft.graph.androidManagedAppProtection",
    "description":  "Android - Managed Apps (Auto)",
    "displayName":  "Android - Managed Apps",
    "dataBackupBlocked":  "True",
    "allowedInboundDataTransferSources":  "allApps",
    "allowedOutboundDataTransferDestinations":  "managedApps",
    "dataBackupBlocked":  "True",
    "allowedDataStorageLocations":  [
        "oneDriveForBusiness"
    ],
    "encryptAppData":  "True",
    "screenCaptureBlocked":true,
    "allowedOutboundClipboardSharingLevel":  "managedAppsWithPasteIn",
    "managedBrowserToOpenLinksRequired":  "False",
    "appActionIfDeviceComplianceRequired":  "block",
    "deviceComplianceRequired":  "True",
    "saveAsBlocked":  "True",
    "appActionIfAndroidDeviceManufacturerNotAllowed":  "block",
    "appActionIfAndroidSafetyNetDeviceAttestationFailed":  "block",
    "requiredAndroidSafetyNetAppsVerificationType":  "none",
    "appActionIfAndroidSafetyNetAppsVerificationFailed":  "block",
    "mobileThreatDefenseRemediationAction":  "block",
    "notificationRestriction":  "allow",
    "pinRequired":  "True",
    "maximumPinRetries":  5,
    "simplePinBlocked":  "False",
    "minimumPinLength":  4,
    "pinCharacterSet":  "numeric",
    "periodBeforePinReset":  "PT0S",
    "disableAppPinIfDevicePinIsSet":  "False",
    "appActionIfMaximumPinRetriesExceeded":  "block",
    "previousPinBlockCount":  0,
    "fingerprintBlocked":  "False",
    "periodOfflineBeforeAccessCheck":"PT720M",
    "periodOfflineBeforeWipeIsEnforced":"P90D",
    "periodOnlineBeforeAccessCheck":  "PT30M",
    "minimumWarningOsVersion":  "8.0"
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/androidManagedAppProtections" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop


            #
            $Applications = (Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" -Method Get).value
            $AndroidApplications = $Applications | ? { $_.appStoreUrl -match "^https://play.google.com/*" -and $_.displayName -notlike "*(Deprecated)*" }
            $JSON = @()
            $AppsArray = @()
            $MobileAppIdArray = @()
            $AndroidApplications | Select -expand packageId | % {
                $currentAndroidApp = $_
                $AppsArray += $( [PSCustomObject]@{"@odata.type" = "#microsoft.graph.androidMobileAppIdentifier"; "packageId" = $currentAndroidApp } )
            }

            $AppsArray | % {
                $currentPackage = $_
                $MobileAppIdArray += [PSCustomObject]@{"mobileAppIdentifier" = $currentPackage }
            }

            $JSON = [PSCustomObject]@{"apps" = $MobileAppIdArray } | ConvertTo-Json -Depth 3
            Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/androidManagedAppProtections/$($Results.id)/targetApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/androidManagedAppProtections/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}