

<#
.SYNOPSIS
A command used to increase the Recover Deleted Items retension in Office365 for all mailboxes within under a tenant.

.DESCRIPTION
A command used to increase the Recover Deleted Items retension in Office365 for all mailboxes within under a tenant.

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by the Connect-TenantExchange command which can be used to invoke commands against the Tenant's remote exchange environment.

.PARAMETER DaysToRetain
An integer matching the number of days in which the retension should be set to. Default is 30.

.EXAMPLE
Set-O365MBDeletedItemRetension -DaysToRetain 30

.NOTES
N/A
#>

Function Set-O365MBDeletedItemRetension {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
        ,
        [Int]$DaysToRetain = "30"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
        Import-PSSession $ExchangeSession -AllowClobber
    }
    Process {
        Write-Log -LogString "Attempting to set all mailbox retension to $($DaysToRetain)" -LogLevel Output -LogObject $O365_global_logobject
        Try {
            $Mailboxes = @()
            $Mailboxes = Get-Mailbox -ResultSize unlimited -Filter { (RecipientTypeDetails -eq 'UserMailbox') } -ErrorAction Stop
            $Mailboxes | Set-Mailbox -RetainDeletedItemsFor $($DaysToRetain) -ErrorAction Stop
        }
        Catch {
            $Mailboxes = @()
            Write-Log -LogString "There was an error increasing the Retension duration.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
    End {
        Write-Log -LogString "Set-O365MBDeletedItemRetension completed..." -LogLevel Output -LogObject $O365_global_logobject
    }
}