<#
.SYNOPSIS
A function to look for expiring admin accounts.

.DESCRIPTION
This function will look for Admin accounts within Tenant AzureAD instances in where the Token expiration date is within the range specified. If any matches are found, the function will return a list.

.PARAMETER Days
An integer value matching the number of days in which to use as the reference point of when an account will expire.

.PARAMETER Office365Instance
A value specifying the Region in which to enumerate a list of tenants to check against.

.EXAMPLE
Get-ExpiringTenantsAdminAccounts -Days 30 -Office365Instance US

.EXAMPLE
Get-ExpiringTenantsAdminAccounts -Days 10 -Office365Instance UK

.NOTES
If not supplied, the default value of days is set to 30.
#>

Function Get-ExpiringTenantsAdminAccounts {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [Int]$Days = "30"
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
    )

    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject
            Start-O365MsolService -Office365Instance $Office365Instance
        }

        $Results = @()

        $Tenants = Get-MSolPartnerContract | % {
            $_.tenantid.guid | % {
                Get-MsolUser -tenantId $_ -SearchString "admin@" | Select UserPrincipalName, StsRefreshTokensValidFrom, PasswordNeverExpires | ? { $_.PasswordNeverExpires -ne $True }
            }
        }
    }

    Process {

        $Tenants | % {
            $Company = $($_.UserPrincipalName)
            $TokenValidityDate = $($_.StsRefreshTokensValidFrom)
            $TokenExpireDate = ($TokenValidityDate).AddDays(90)
            $TodaysDate = Get-Date

            If (     (($TokenExpireDate -ge $TodaysDate) -and (($TokenExpireDate - $TodaysDate).totaldays -le $Days)) -or ($TokenExpireDate -le $TodaysDate)     ) {
                $Results += [PSCustomObject]@{Name = "$($Company)"; TokenGenerated = "$($TokenValidityDate)"; TokenExpiration = "$($TokenExpireDate)" }
            }
        }

        If ($Results -ne $null) {
            Write-Log -LogString "The following Office365 admin account will expire in <= $Days days or have already expired" -LogLevel Warning -LogObject $O365_global_logobject
            $Results
        }
        Else {
            Write-Log -LogString "No Office365 partner admin accounts are expiring in the next $Days days" -LogLevel Output -LogObject $O365_global_logobject
        }
    }
}