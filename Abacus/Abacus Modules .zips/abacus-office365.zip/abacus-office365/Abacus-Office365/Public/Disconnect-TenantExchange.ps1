<#
.SYNOPSIS
A function to Disconnect from a Tenant's Exchange after having run the Connect-TenantExchange function

.DESCRIPTION
This function is used to disconnect from a Tenant's Exchange as well as remove the PSSession as a clean up step.

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by Connect-TenantExchange which is used as a  reference for the disconnect command.

.EXAMPLE
Disconnect-TenantExchange

.NOTES
This function requires Connect-TenantExchange to have already been run so it can disconnect and remove the session.
#>
Function Disconnect-TenantExchange {
    [CmdletBinding()]
    Param(
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        Try {
            Get-PSSession -Name Office365Exchange -ErrorAction Stop | Out-Null
        }
        Catch {

        }
    }
    Process {
        Write-Log -LogString "Now disconnecting from Exchange PSSession" -LogLevel Output -LogObject $O365_global_logobject
        Remove-PSSession -Name "$TenantExchangeSession" -ErrorAction SilentlyContinue | Out-Null
    }
}