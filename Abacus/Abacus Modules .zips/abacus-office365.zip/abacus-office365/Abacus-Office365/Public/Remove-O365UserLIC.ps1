<#
.SYNOPSIS
A wrapper function to easily remove a license to a user within a specific Tenant environment

.DESCRIPTION
This function provides a convenient wrapper around base MSOnline functions for removing user licenses from a user within a Tenant's environment.

.PARAMETER UserPrincipalName
The UserPrincipalName of the account that will be targeted for a user license to be removed.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER LicenseType
The type of license to be removed from the account.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Remove-O365UserLIC -UserPrincipalName {UserPrincipalName} -TenantId {TenantId} -Office365Instance {US/UK} -LicenseType ENTERPRISEPACK

.NOTES
You can also use this function to remove different license types that are not included by default by changing the LicenseType parameter.
#>

Function Remove-O365UserLIC {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$UserPrincipalName
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet('ENTERPRISEPACK','STANDARDPACK','ENTERPRISEPREMIUM','DESKLESSPACK','AAD_PREMIUM','EMS')]
        [String]$LicenseType = "ENTERPRISEPACK"
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance = "US"
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "There was an error finding the Tenant based on the supplied TenantId" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        # Get User Info
        $TenantUser = (Get-MsolUser -UserPrincipalName $UserPrincipalName -TenantId $TenantInfo.TenantId -ErrorAction SilentlyContinue)
    }

    Process {
        # Does the user exist and can we find him/her?
        If ([Boolean]$TenantUser -eq $False) {
            Write-Log -LogString "No User was found" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        # Is the User Already Licensed
        If ([Boolean]$TenantUser.isLicensed -eq $False) {
            Write-Log -LogString "This user is already not licensed" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }

        # Get LIC
        $TenantLICs = Get-MsolAccountSku -TenantId $TenantInfo.tenantId | ? { $_.SkuPartNumber -eq $LicenseType } | Select -ExpandProperty AccountSkuId

        # Remove LIC
        Try {
            Write-Log -LogString "Attempting to remove the user license..." -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Set-MsolUserLicense -UserPrincipalName $UserPrincipalName -RemoveLicenses $TenantLICs -TenantId $TenantInfo.TenantId -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an error trying to remove a License on $UserPrincipalName under $($TenantInfo.CompanyName)" -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
        }
    }
}