<#
.SYNOPSIS
A wrapper function to easily remove additional licenses from an Office365 Tenant

.DESCRIPTION
This function is used to more easily remove one more licenses from an Office365 Tenant via the CLI through API calls to the PartnerCenter.

.PARAMETER LICName
The Microsoft License Name matching the desired license(s) that are to be removed to the Tenant's subscription.

.PARAMETER LICOfferId
The Microsoft OfferID matching the desired license(s) that are to be removed from the Tenant's subscription.

.PARAMETER Quantity
A integer value matching the number of licenses in which will be removed from the tenant's subscription.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Remove-O365TenantLIC -LICName {LICName} -Quantity 1 -TenantId {$TenantId} -Office365Instance US

.EXAMPLE
Remove-O365TenantLic -LICOfferId {LicOfferID} -Quantity 1 -TenantId {TenantId} -Office365Instance US

.NOTES
None
#>
Function Remove-O365TenantLIC {
    [CmdletBinding(DefaultParameterSetName = 'ByLicenseId')]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(ParameterSetName = 'ByLicenseId')]
        [String]$LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("Office 365 E1", "Office 365 E3", "Office 365 E5", "Office 365 F1", "Azure Active Directory Premium P1", "Enterprise Mobility + Security E3")]
        [Parameter(ParameterSetName = 'ByLicenseName')]
        [String]$LICName = 'Office 365 E3'
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [Int]$Quantity
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateSet("US", "UK")]
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$Office365Instance
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Debug -LogObject $O365_global_logobject
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject
            Start-O365MsolService -Office365Instance $Office365Instance -ConnectToPartnerCenter
        }

        Switch ($Office365Instance) {
            'US' {
                $CountryCode = 'US'
            }
            'UK' {
                $CountryCode = 'GB'
            }
        }

        # Check Partner Center Connection
        Try {
            Write-Log -LogString "Testing to see if we already have connection to the Partner Center" -LogLevel Output -LogObject $O365_global_logobject
            Get-PartnerLegalProfile -ErrorAction Stop | Out-Null
        }
        Catch {
            Write-Log -LogString "Connection to Partner Center is not started or has failed: `n $($_.Exception)" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        If ($Null -eq $TenantInfo) {
            Write-Log -LogString "There was an error finding the Tenant based on the supplied TenantId" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

        Switch ($PSCmdlet.ParameterSetName) {
            'ByLicenseId' {
                $LicenseType = $(Get-PartnerOffer -CountryCode $($CountryCode) -OfferId $LICOfferId)
                If (   $Null -eq $LicenseType   ) {
                    Write-Log -LogString "Not Matching LicenseType was found based on the provided license ID {$($LICOfferId)}. Please verify the ID and try again." -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            'ByLicenseName' {
                $LICOfferId = Get-O365LicIdFromLicName -LICName $LICName
                $LicenseType = $(Get-PartnerOffer -CountryCode $($CountryCode) -OfferId $LICOfferId)
                If (   $Null -eq $LicenseType   ) {
                    Write-Log -LogString "Not Matching LicenseType was found based on the provided license ID {$($LICOfferId)}. Please verify the ID and try again." -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
        }
    }
    Process {
        Write-Log -LogString "Gathering information for tenant {$($TenantInfo.CompanyName)}" -LogLevel Output -LogObject $O365_global_logobject
        $CustomerSubInfo = Get-O365TenantLIC -TenantId $TenantInfo.TenantId -Office365Instance $Office365Instance -OnlyActive | ? { ($_.OfferId -eq $LicenseType.OfferId) -and ($_.BillingCycle -eq 'Monthly') }

        $CurrentLicCount = 0
        $CustomerSubInfo | % {
            $CurrentLicCount += ($_.Quantity)
        }
        $DesiredLicCount = ($CurrentLicCount - $Quantity)
        If ($DesiredLicCount -lt 0) {
            Write-Log -LogString "Cannot decrement LIC count to a value less than zero. Cannot complete request." -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            $LicArray = @()
            $CustomerSubInfo | % {
                $LicArray += [PSCustomObject]@{SubscriptionId = $($_.SubscriptionId); Quantity = $($_.Quantity) }
            }
            $DesiredDecrementValue = $Quantity
            $TotalDecremented = 0
            $DesiredDecrementValue = 0
            $LicArrayToDecrease = $LicArray | Sort -Property Quantity | % {
                $Calculate = $True
                $DesiredDecrementValue = $Quantity - $TotalDecremented
                While ($Calculate -eq $True) {
                    If (   ($_.Quantity - $DesiredDecrementValue -ge 0)  ) {
                        $Calculate = $False
                        [PSCustomObject]@{SubscriptionId = $($_.SubscriptionId); QuantityToRemove = $DesiredDecrementValue }
                        $TotalDecremented += $DesiredDecrementValue
                    }
                    Else {
                        $DesiredDecrementValue = ($DesiredDecrementValue - 1)
                    }
                }
            }
            $LicArrayToDecrease = ForEach ($Lic in $LicArrayToDecrease) {
                $NewLicQuantity = ($LicArray | ? { $_.SubscriptionId -eq $Lic.SubscriptionId } | Select -Expand Quantity) - $Lic.QuantitytoRemove
                If ($NewLicQuantity -eq 0) {
                    $NewLicQuantity = "SuspendLic"
                }
                [PSCustomObject]@{SubscriptionId = $($Lic.SubscriptionId); QuantityToSet = $NewLicQuantity }
            }
            Write-Log -LogString "Attempting to decrease the {$($LicenseType.Name)} LIC from {$($CurrentLicCount)} by {$($Quantity)} to {$($DesiredLicCount)} for {$($TenantInfo.CompanyName)}" -LogLevel Output -LogObject $O365_global_logobject
            $LicArrayToDecrease | % {
                Try {
                    If ($_.QuantityToSet -eq 'SuspendLic') {
                        Set-PartnerCustomerSubscription -CustomerId $($TenantInfo.TenantId) -SubscriptionId $($_.SubscriptionId) -Status Suspended -ErrorAction Stop -ErrorVariable errSetSubLic
                    }
                    Else {
                        Set-PartnerCustomerSubscription -CustomerId $($TenantInfo.TenantId) -SubscriptionId $($_.SubscriptionId) -Quantity $_.QuantityToSet -ErrorAction Stop -ErrorVariable errSetSubLic
                    }
                }
                Catch {
                    Write-Log -LogString "There was an issue trying to decrement {$($LicenseType)} licenses.`n Exception: {$($errSetSubLic)}" -LogLevel Warning -LogObject $O365_global_logobject
                    Write-Log -LogString "$($_.Exception)" -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
            }
        }
    }
}