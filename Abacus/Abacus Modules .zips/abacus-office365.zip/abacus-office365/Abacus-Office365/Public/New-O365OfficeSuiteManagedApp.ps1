<#
.SYNOPSIS
A command for creating the base Office Suite Managed App.

.DESCRIPTION
A command for creating the base Office Suite Managed App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365OfficeSuiteManagedApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365OfficeSuiteManagedApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{
    "@odata.type":  "#microsoft.graph.officeSuiteApp",
    "version": 1,
    "description":  "Office Suite for Windows",
    "displayName":  "Office Suite - Windows",
    "publisher":  "Microsoft",
    "owner":  "Microsoft",
    "developer":  "Microsoft",
    "autoAcceptEula":  "True",
    "isFeatured": true,
    "productIds":  [
        "o365ProPlusRetail"
    ],
    "shouldUninstallOlderVersionsOfOffice":  true,
    "updateChannel":  "deferred",
    "updateVersion":"",
    "useSharedComputerActivation":false,
    "officePlatformArchitecture":  "x64",
    "excludedApps":  {
        "access": "False",
        "excel": "False",
        "groove": "True",
        "infoPath": "True",
        "lync": "False",
        "oneDrive": "False",
        "oneNote": "False",
        "outlook": "False",
        "powerPoint": "False",
        "publisher":  "False",
        "sharePointDesigner": "True",
        "teams": "False",
        "visio": "False",
        "word": "False"
    }
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}