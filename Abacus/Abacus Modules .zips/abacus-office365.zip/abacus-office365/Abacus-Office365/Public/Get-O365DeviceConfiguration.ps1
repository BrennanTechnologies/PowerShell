<#
.SYNOPSIS
A command for querying one or more Device Restriction Policies.

.DESCRIPTION
A command for querying one or more Device Restriction Policies.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER Name
The DisplayName of the configuration policy you are looking for. If left blank this will query all possible.

.EXAMPLE
Get-O365DeviceConfiguration -Headers $Headers

.EXAMPLE
Get-O365DeviceConfiguration -Headers $Headers -Name 'Windows 10 - RDP'

.NOTES
General notes
#>
Function Get-O365DeviceConfiguration {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$Name = $Null
    )
    Begin {
    }
    Process {
        Try {
            If (   $False -eq [String]::IsNullOrEmpty($Name)   ) {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations?`$filter=displayname eq '$($Name)'" `
                    -Method Get `
                    -ErrorAction Stop
            }
            Else {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                    -Method Get `
                    -ErrorAction Stop
            }
        }
        Catch {
            Write-Log -LogString "There was an error querying the endpoint for Device Configurations.`nException: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

    }
    End {
        Return $Results
    }
}