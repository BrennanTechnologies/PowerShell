<#
.SYNOPSIS
A command for creating the base iOS ManagedApp Protection Policy.

.DESCRIPTION
A command for creating the base iOS ManagedApp Protection Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365iOSManagedAppProtectionPolicy -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>
Function New-O365iOSManagedAppProtectionPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{
    "@odata.type":  "#microsoft.graph.iOSManagedAppProtection",
    "description":  "iOS/iPadOS - Managed Apps",
    "displayName":  "iOS/iPadOS - Managed Apps",
    "allowedInboundDataTransferSources": "allApps",
    "allowedOutboundDataTransferDestinations": "managedApps",
    "organizationalCredentialsRequired": "False",
    "allowedOutboundClipboardSharingLevel": "managedAppsWithPasteIn",
    "dataBackupBlocked": "True",
    "deviceComplianceRequired": "True",
    "saveAsBlocked": "True",
    "pinRequired": "True",
    "maximumPinRetries": 5,
    "simplePinBlocked": "False",
    "minimumPinLength": 4,
    "pinCharacterSet": "numeric",
    "periodBeforePinReset": "PT0S",
    "periodOnlineBeforeAccessCheck":"PT30M",
    "periodOfflineBeforeAccessCheck":"PT720M",
    "periodOfflineBeforeWipeIsEnforced":"P90D",
    "allowedDataStorageLocations":  [
        "oneDriveForBusiness"
    ],
    "contactSyncBlocked": "False",
    "printBlocked": "False",
    "fingerprintBlocked": "False",
    "disableAppPinIfDevicePinIsSet": "False",
    "minimumWarningOsVersion": "11.0.1",
    "appActionIfDeviceComplianceRequired": "block",
    "appActionIfMaximumPinRetriesExceeded": "block",
    "allowedOutboundClipboardSharingExceptionLength": 0,
    "notificationRestriction": "allow",
    "previousPinBlockCount": 0,
    "mobileThreatDefenseRemediationAction": "block",
    "isAssigned": "True",
    "appDataEncryptionType": "whenDeviceLocked",
    "faceIdBlocked": "False",
    "appActionIfIosDeviceModelNotAllowed": "block",
    "filterOpenInToOnlyManagedApps": "False",
    "disableProtectionOfManagedOutboundOpenInData": "False",
    "protectInboundDataFromUnknownSources": "False"
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/iosManagedAppProtections" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            #
            $Applications = (Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" -Method Get).value
            $iOSApplications = $Applications | ? { $_.appStoreUrl -match "^https://itunes.apple.com/*" -and $_.displayName -notlike "*(Deprecated)*" -and $_.bundleId -ne 'com.microsoft.groupies-daily' -and $_.bundleId -ne 'com.microsoft.o365smb.engagex' }
            $JSON = @()
            $AppsArray = @()
            $MobileAppIdArray = @()
            $iOSApplications | Select -expand bundleId | % {
                $currentiOSApp = $_
                $AppsArray += $( [PSCustomObject]@{"@odata.type" = "#microsoft.graph.iosMobileAppIdentifier"; "bundleId" = $currentiOSApp } )
            }

            $AppsArray | % {
                $currentPackage = $_
                $MobileAppIdArray += [PSCustomObject]@{"mobileAppIdentifier" = $currentPackage }
            }

            $JSON = [PSCustomObject]@{"apps" = $MobileAppIdArray } | ConvertTo-Json -Depth 3

            Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/iosManagedAppProtections/$($Results.id)/targetApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/iosManagedAppProtections/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}