<#
.SYNOPSIS
A command for creating the base Window 10 Device Restrictions Policy.

.DESCRIPTION
A command for creating the base Window 10 Device Restrictions Policy.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365Win10DeviceRestrictionsPolicy -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>

Function New-O365Win10DeviceRestrictionsPolicy {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{
    "@odata.type":  "#microsoft.graph.windows10GeneralConfiguration",
    "version":  "1",
    "description":  "Windows 10 - Device Restrictions",
    "displayName":  "Windows 10 - Device Restrictions",
    "cortanaBlocked":  "True",
    "lockScreenBlockCortana":  "False",
    "passwordBlockSimple":  "True",
    "passwordExpirationDays":  "90",
    "passwordMinimumCharacterSetCount":  "4",
    "passwordMinimumLength":  "8",
    "passwordMinutesOfInactivityBeforeScreenTimeout":  "15",
    "passwordPreviousPasswordBlockCount":  "24",
    "passwordRequired":  "True",
    "passwordRequiredType":  "alphanumeric",
    "passwordRequireWhenResumeFromIdleState":  "False",
    "passwordSignInFailureCountBeforeFactoryReset":  "11",
    "windowsSpotlightBlockConsumerSpecificFeatures":  "False",
    "windowsSpotlightBlocked":  "True",
    "windowsSpotlightBlockOnActionCenter":  "False",
    "windowsSpotlightBlockTailoredExperiences":  "False",
    "windowsSpotlightBlockThirdPartyNotifications":  "False",
    "windowsSpotlightBlockWelcomeExperience":  "False",
    "windowsSpotlightBlockWindowsTips":  "False",
    "windowsSpotlightConfigureOnLockScreen":  "notConfigured",
    "authenticationAllowSecondaryDevice":  "True",
    "authenticationWebSignIn":  "notConfigured",
    "inkWorkspaceBlockSuggestedApps":  "True"
}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If ($False -eq [String]::IsNullOrEmpty($TargetId)) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}