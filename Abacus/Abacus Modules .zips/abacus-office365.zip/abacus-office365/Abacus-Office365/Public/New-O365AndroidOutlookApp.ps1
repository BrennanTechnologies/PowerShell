<#
.SYNOPSIS
A command for creating the base Android Outlook App.

.DESCRIPTION
A command for creating the base Android Outlook App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365AndroidOutlookApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365AndroidOutlookApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
{"@odata.type":"#microsoft.graph.androidStoreApp","appStoreUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.outlook","categories":[{"displayName":"Productivity","id":"ed899483-3019-425e-a470-28e901b9790e"}],"description":"Microsoft Outlook","developer":"","displayName":"Microsoft Outlook","informationUrl":"https://play.google.com/store/apps/details?id=com.microsoft.office.outlook","isFeatured":true,"roleScopeTagIds":[],"largeIcon":{"type":"image/pngapplication/octet-stream","value":"iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAIAAACyr5FlAAAAA3NCSVQICAjb4U/gAAAgAElEQVR4nO19e7AkV3nf7zunu+d5Z+7eu3d3tdKutHquhGQJ87AQClA8giUEoYwNTmSwy4kdggPERWSiUBW7HCeEStk4SYWKwcEuAgaKKiOcGAK4bGNiG5BKwkIYSWilXfTY933Ou/t8X/44p3t6Xlf33p07d662f1pN3emeOX2m+9ff+b7f+c7XJCLIkGEY1E53IMP0IiNHhpHIyJFhJDJyZBiJjBwZRiIjR4aRyMiRYSQycmQYiYwcGUYiI0eGkcjIkWEkMnJkGImMHBlGIiNHhpHIyJFhJDJyZBiJjBwZRiIjR4aRyMiRYSQycmQYiYwcGUYiI0eGkcjIkWEkMnJkGImMHBlGIiNHhpHIyJFhJDJyZBiJjBwZRiIjR4aRyMiRYSQycmQYiYwcGUYiI0eGkfB2ugNbRGTMqbOrTzy7xqyBdSpX0bp7N/KVLbSw8W6s13ghR9cenp2rFonogjuwFexKcjx3ZuUjn3/0v/55DRWBCJA+d8m5HjyhfZd8nQ/L5lvAVrsx4i0RhGDoE2/b/4/vuKZUCAba2XbsPnIsrzbu+O0HHz4X6vIqIjOGu3pqocgE/i99iaOO+ac//SLf0xM+/u4jx7/7+P0Pn2zq9jIUDbsvX0AwoqMWq86/+Fznx6+fe/nNl034+LvMIa03G//tb1ZALdALnRkWRIoZxfCz3zg++YPvMnKcPl+DYkQRdshH2wEQQUW/+9enJn/kXUYOESAyO92LSUOJoBbuwHEnf8gLAUEQhrjYqi4Lw0STP+wuIwcAhNFFRw5mtDLL8bwQgC8yZsD+ap78YXcbOS5a7IQDnpEjw0jsNnJcNAHsNGC3kSPDBLH75PNdgfH6zALsSIC2C8kRtRDxGIcXYYiR8V5PBiHaQIvJz3BTy9TdSKnPGKC9AzrHbiOH8lG52ivp3JjaM5HMX1OdOVTlMd6agtkDgV/212kyfekpoQRBASAiiCJKNhqixmptbN3bMHYbOaBQqlBeJ7fZhaLD/sxssHdufPIJiXBxXz6Yya9vjRJjQb1/EPW/jQjF/Lhuh01g15ED0CA1trCfFEgJQcblJwiEAILQ8/kJSSxAAhBI4h8lqaQfgtgWd0L6223kIECJqM2fKqLeq092GzRApNTYXA7LCUWksAHbZkmgetyMZJRJboCxJCpuAbuNHACIN2k3CCSAID0Ukdj/RQFKEO+hfg5tDUIkaoMtUcr/oBRLUszYKexGchiiTZ2ylPNHSXIogRggUkIAIPH1EKgLHrKE0vf9RnqWfpv+4s5qfruQHBJtzMraiw4AUD3BAQiAc1uEABJFwjZRmYggRHQh5oPghpVNNdJHpmmQgncZOQo5hbDFod6YxY7PsAFIAUREIAIpkE4lGjLARF0nUCAXshpA4NreWhPTQAuLsZEjjMzfPXbmt//05OeOtwFvm1wo7Svv0IHSps9fHAYQoAlspNWU0MDTAEgYzAARKUjimshWL273kOufgvQHpocQaYyHHMzRb/3ho7/5LYPZHCr57futBJS2TjunM1ExT9WZaPE8N1okWsQIGEJCQqS7rusF/IoNZj9v8Ag7lUw9HnJ89AtP/OaDUlnwFDBmIXrcEMNSa6tS4B9YCJ89aRohmMEMUhAIhEjF+tQFIKWDb6WTO5O/0Y8xkOPYM4uffihERe1UOL5pEMxaW5dzeq4a1k6CI3AE0qQ0SMhpUlYI2eIlokFhZZNfnwaMYcr+xLP179ZNZUp+0MZAiky9rUsFRKFwJMxgFmGIiBXYZOvMeMFgDJaDIw+8C0+kEWhfog6iUKLQxrZCyg0IwiLqIufHOJJ9du0JJAAcsonERBAjzBAGRC627PYRuKgzwQSCKBQTionYGNiYVuIZs4ueIuMgx+49hwLhDkwEE4ENDENYwBCZ8phrMrioLQcgiCIxkRgjbERYILHZAC5MRH8B4CInB8AhOBITCRthBltyZMMKkJFDOAIbp4NJ7HBc9LSwGItCOs5TaZW0FSMIAY6HfgIU4FNV0xilNhKAI+FI2BCzCIsw2UJSGUXGN/F2wSkQwKoAoWDVoCm4Nv9bV+UrJS8IlFJotbndNvf8fXPlWAtFhRlFHl2g7OY8C2ER9+oIId3cn4scUzFlHwoaTb6lpF59tPgzt8/ffEUp8JVWRORUKBEA8t5IWPDXP1j54t8sfv1E64dNLhTUluuoOQvEBpxiBtwqkd0cg40NO0wOAVZDQZM//daF227Zc2QhP/RjdqIj5xOA19+85/U373nsmfqf/L/zv/bN5eaMrl7wXU4uK5gAESLl0j5o6wrpJpPVnrexVL7S5LCT5BBgtcF37fc/cvdlN1xe3tR3r7us9KtvL73qxdVbP3J8ZV5XvS2dOxEyoYRtbrcEWgAFkGFEEWkt2iO1FYddBKZlIjLjcloiAI0mUBlPcxvGTpJjdYU/8sqZD9x9xdZKKHoKP3Fd9dRHr3/X/3jqa2fDWX+TsgSRQMLayTNPBWfPeOI34eXh5aF9aF/Ig9K0pUUQxsgNt+3L7dEyjvUEBLRAaO5AsaudIQcByzX+8Ctn3v+OwxdYXHN/NfjMr1y58KHHlpVU9SYvpACktKe8HFGgySP4mrQHraE0SG/NcjCL58HTNmt5DPAAmXQNUnfcHcByR953tPD+tx/OecPP/tJauLQWPvyjRrtliKha8a47kN+7J1fODzlJe8v+8Q9dfeTDT6wQqpu+mpnjORI7QA4DYNF84N5DBX/IlWx0+C8eOPdfvrH09cdbyJNT6SKgLe+5tfyWl86+8aXzg9+6fF/+M29Z+Cf3nZHiTnhuL1BMmhwC1Nb4U3fvP7x3yOLPc6ud9/3PE599soU8VQ94qUWBYOBjP2x+7JHGh0807vmpQ4MDyFteuXD3d5Y/cz7c9OCSYQQmLZ+vMt54qf/6l+wZ3LVYi17zO8c+e6I1U1Y2+kgsvs3prAZUmlH3/tnS737x6cHBoBSod75xH5ZNRo1xYeJzK6G84ariJXv6zUbE8qmvnvz+UlQprOcEekB5Vv/rryx+5/HVwb2vuqEKT3V2sxdh84xkADui5U+UHAZAzbz1NfsGd33vidVf/dPFygY8Bg1gzvtnv//0YO3FQqB+/83zjfoOVGW8QHRJEPNjGjBRckQAQly1b4gMeu9XzmDPRn3JosIjRv72ByuDu64/VNhQSZ2pQcKJ9T4D+C/4UpOtFt/z2urg9pU2f/Wba9XcRjvjAzDy+LG1wV0H9uZv2u+v7AZ6bIQWFj7hwXa0ujJkJN1WTNbnaMutVxYHN//dE6uY9zYncHr0/ZPtWqtfN5wteS+f1VNe5XgkLcS9SuofBB7RVYKbX/Evv/Tlv2p1JieVTpYcHTk0bEx56FgdxU2aTY0vPNdZa/SXUcvnvbmi3qiyNXFTPZwW4v65TKPBnYIZrY7/YO2t7/zkP/+Vf//dR45NpreTJYfBpZUhykp7qYNNGo6qoh+djTqdft8z51M52HCdnsnal1HWIuZG3KWBf3ZX6RJv9mj5Uw+cevFN7/7EH3xxAh2eLDkC4oG71QCNrbmQLaGB4UMDZX/qlI5RBqNrJywJUmmKEu+NSxAJBCSyp+gVb7vul3/xk2cXt90FmRw5RICcGsxLMIKB+38DIMDw0Ht/qvyNdcaRhBbpBDThnrfuk2JLQ7i0Z00AvLVGa7s7Pzn5nAgwQ8Qcn5DfQjaGAHpIZYIIqIcyBUl+NrNsCE+72yROOkOKCvE7m3fUU8VWBACLrD20iDuO5vcPkYvGi8nOrbR40LMgoBhsekU6CzCjMcCqTii1cKdFMIHIMKuWHkTidMTUQghJ13MR2BJDILhCmIa5dq52aTX/invfvHTnm01o4KttdaonSA4CgJWmuXRgz+z+PDprtJlsnTWW1+33C7n+GfxWK1qqmw1XRdnw8TYMEes59G1NbYoNRpyrKmmWxEYDICgByBYNkUgkOPv47e96T+Unf1KuuPLhRtt0QsnZjKTt4scEySFAQI+fat1wRX9G4K3XlLF2GuXNVAM1eMUlQanQ3//levTtFbPRjMsxeycjwpHBcSThh9PLu4tzKX4FwEnNMpY8mzvv+3Tj6utXDDWeqQVVrxNGxpBW25gFNNloJU/3PzGkhveNl5cRyeZCFiO3XF4sBv39P3O+/ciZaHZnBIzkTfw64Fem3E/nqrq1VHaVrgiLe7WeqTEAMFNRCy8+eOaKG86djxafaZsQWtAJQzbbK4hNlBx+Tv3Hbw4PwH79zfO1tY3OttcBIrzo2pnBXY8928CGNbALR3rCLN7kXiXlVfT+ExGReOWlpYWtGWOJwgwRMEsUSr5IC5f5lb1ecyVcO91u11krgAQkxpjtnqKbKDnyBBC+d6I+uOvdr9s3V/aWN+BKEhDV+YO3zBw92K/EtyP5ha8u6uKEftTwGDXxI5EePqzZsGvqemjBdvl2136AGRzB8+mSI8HCZYGJ5OzTYX2VRWy9TAAgV4PoBUQOBaBIX39gcXDXgfncJ+7ai1XTfr5GlkNBTr3/LQcHdz305BqWzMzGR+Hhlkqe1xkZol50Bc3YPqQVC3G2QdLWgiUZU9gtupMoEojsPegfOBIQYflMtLrIRP058BwnQG0rJp7s46svfK924nRzcM9P3b7vP7x2trVqVgZl1BgrbTnoqwd++dCBPf1L3Rj4X185jXm9idtJYB+bQK6orIpL2KrU3xT/s8sUSECpjRQv5FWuzJwoQIEUKeWWRaXaFHcgkp6jEEB2NJld0IeuzefLqrZoVs6ZsCNDc58mwAxMPoe0qvCt8+Fn/vLsv33H4cG99/7M4esO5H/6vrPLLYOyzisX1hkgDAXL5ueuL3zoHZcevaw0+N2/eHDxY8fbxfwmThoJe6tnqDgbBSUyhqIcog6UT9qD8qAUSMU6lBWgei9Jl4bkvE0GADZcO+l11jpsrPXoWpP0W9hRgcGGTUfmj+5ZuKLoB6pZM401xjrVJp/ftI0HO5B9PlPWH/ra0p0/MXfLQExLwNv+wb7TL6p+/m/Pve8vl1vnI2h7m9Crry38p19ceNGRmZnCkGFjrRH9q/99Gh78zfSE2HjHHuRCOQwK5OdJ5+AFonxoD0qDlCIN51cO2KOuuoluWGKnQ5hPft+DboINGGARARjEApb4rYBFQnSWo/zB4CXvPFI6UOh0sHQ65A08FWIyyWI7QA4FYMH7pY+d+OKvXX3ZsBz0fXO5977p0ve+6dJ6hHrbBB7NrpsH1Irk7f/9yUeWo9m82uRJIwR5kBa7WpYUKY+UhtJQHkBQWuJF993rZY9BKWaklXCwgDytyFNguBpSLJYlEBuyAizNZVM9GNx09xXzN8xHTbOyaKKQ1caW2En3cNuInSneUiU8YOSeTx5fqq/3XLuSh30l/TzMCPmjf/z0/32mPbNpZlgIktLonM7n7Rr+ns922SBwYYZ0/VBbG4gFhmFEjIgRGIEBXPkPgZGoYerPhtfdtf+mn79m7rq52rnO6vnIRMPdi6FgYAITSDu2VrYa0OfOhPf/+mNf/cCVV11S2Foja43oXb/31H1PtsrlrSxcFABkAE5tEYiQMEQhreb3TYqkBxHnbcTGg5mYmUWxIIqdDGs5BKZlmHDgxpnLX3/IL3rtujn/TFup+GEeGwUlMzLbip1cSD3r07FIrv7Px/7wjvmffe2B3CYXI33z4aUPfOnU/eejSnmLq9wIcfEgRnphq3UyKAkJetwLQKzbiZTCBXDK7WSB6VoXsW6HkcZ5M3998chrL5m5tNyp88rpjjAo7rvIZp7jIckP2EbscAmGqkerCr/wf87dd//Ku163945b9viBXockArQ6/INnGh//k5O/96M2NGYLWxtNkhY59iitMAnnAoNEQEl8kp4rE/QMJZIMMdbZFLCBEZDYx9VKJFGHlaabfv5w9UgFTKtnOhzFBdbFxqV2EZckDwxdv9OTySPd+co+FQUU1X3L0X1/8Czw3G+8pvqKq0p7K36h6JXzOu9RO5JGh2vNqLYa/uC51rv/fAlLEfZ6+RzlLtS4CiSCGHCsYdnLrGKtisiaieTuhmBIwhbbjbHOxQwWiQQiUd2ogr78VXv33rKgtGqtRJ0mxzOphNg8OVqI2qAv8YKNVoaiqon2eC3Bb3x7Fd9YQU4dKKsfy9Nen5YjPNmWR+sGDUZAQV4VL1nveb4bhwh4tdW99e30hhKwe1yTGzviQJaSqJXRZzPiObR4i2Ex3DgX7ntJ5dCrD+QquXYtipqRxM8HdROwJFZrJ4EoSiZiCbJ+0CJygXfFhjAt5AAgQI6QyyvkIcC5SL625s6AIlQCosApHGNihujAL9x208qZJqoRKYFiF2gQAwSOiy05T9NJ5mQPz2wpIsx9JkTCKBRTORxc847Li/uK7bVw7bk2KFHUyFIj5of9iyBCRCJCiKkxgh6xJD+Gk7A+pogcaRBQGpIEOFYIdOAdfOPbqsud4985jbCtZjxSDCUwAiUghij3UaQmTUQgoMTDSBwOERiOllso567+R1fMHJlHJPVTLRMJJU+cFPsfWQ1d3FNZrJmKSRITBiMe+DKex5tuAFNKjkmAYAxHRlePXPbiG46e+fvnTj96Lqq3dUlBKwhBKZBx5R+AOF51bOCkVqmtpc8c1UJ/Jnf4zpv2vvQGArWXQtMRUiCyRgjCAgVismFy4m2AQNb5cIbD0ST2VodQZCKjysVMDoAIJpTmmslrufTW6xd+LDr90ImT3z2lqkQ+pWa37Dji7EcyuyosBAFDImPWwv23XbnwsqPB3Gy42oqa9qG19sv26yBF8bPkuteWEDsgbjQRgIRANrZFN2swgQ2cJzDzdlGTA3AXJ2yzLHfys+Uj//Al+19Wf/RLD7ZWW5QPtO915S8GAOmGKgALhxG3jL9QuubnXpubq5g2N07VrZ2Ih4b4AfXkfCWKrYYzDEKkiEUUSJzBsAONMyQEdPfEXeaL2eeYHMgVHGVBs24MuDi/52Xvvev8I8d/9K0f1p5a9uYLAOwd3xPBMsxyK394z/5bj1auPczNqHWuDQPSyTyuuPxg5ZacWDdT7HOx40TzhDSxjG8Jkczf9KpdsX88mfz6i5sc9l6MX5UiY9CsG587e2+8evaaw89957Hjn38Q+wsqsJGGm3TlDstK+5I33Vy9/gqdL7TPt7gjlHowrSOAQJQkl92FJWylUOkKsAIoQjdOEY4NTLwZXU2UhEDRRCbexkKO4SvPdgHY6goEIhJCvKosilBf7gRF/8gbXnbwthufuu+vTn3/FK+1EChE7M2Vqtft3/eqH9eBH611OitN0rbWsVg3FaSgxHqZJLH0aS+8jVCSqV4A9unXnDgYEj8tXVzUbF/cICXKRjoTUcHGQI4gL9BibM2dXQOB75FpQ6m4uHU6swtQ6LTYmJaX96792ddf8syZs0+eqS02C5V8MFfx91S5xdFyC4B9aL2IiIJyKjiDCQApF6OmJvhTjoQzHvHT0WPGpPkRK+tJ0AuGKKFwXCVO18UYyHHj1bN3zi1/ubmFGqA7BgF0Ke/XTpDSZCsVK8eMxO0jAgvCpjFtLh7Ye+TgQm2ptXKuGTWiztkWCUGBlAIDSggAxwGpGyksYcgajK5PEd/3EvuksRMSWwllHQ9r0CgxMmLHGQIEnYlIpGO4nnPVmXvuquDp9opQsg5nmkGK9Gw56Cz6tRNQnpAiK16mjUfq1DNLq2baDVOq5vYfLpfKvmmLiQQMYWYWMd2nSnYre7GV1F3GOYTEyampz8TzOUkSiWsF8VSP09lsiiGSlJOBTJNtwXgc0te89PCX3xPe+Udra76Psa3fJADw1RaL3vcjvnc9hXzgR0uFc99GLk/aV0rDJgPDZRo7dSElPRGBjbTqxvPV/JFK5ZLi2WOrrbXQfltIHKUctUSsE8IiZEcWiZ9xrYSFlBsxktuf4ITPtDKWUtEFKaMkEguo24yxPYznjtuvrr149RsPnXvuTF1BjXZRZfS79Bu7wtx869FTHz+2OLe1urOC7pMxbCyhtVahz+c9WaKZfeTnSWtoTcqDVoizbrqexwCiUKJQvEAfvHG+udRafrberEWer6AFRkgp6drirsztoloiIlEKwuSCXOugxtMsXRHEDkVJRokg5YMocpM4uyoTrFSq3Hn7WB/7IGHxj098/Mt/5Fe22KwoIlLwfNI++YH285QrUq6M3Cx5AXkeaZ+0htJE2toOF7+si6gjHJlcJbev5NfPN8+fqCsm5ZFTURWRiCh3TUnBXltrGWz+MMWaBhSJ2LAVBCG2HKJYNUU8RxzbNHGDz24JZbcFzNzpRKFRmD1Mpfxmz4Q11EQEUqQ1aU95PnkB+Xmdy1Mur4I8+QH5geUHaY+Ujs2GG1bW4Qgz2g3WGqWFUnmhtHhipbHUYRHtKXvJYYSUgJRNC7GWw6oUXWcyiW2dxpZ4pnCDjoCUDYmRhDwkMQu3GdNLDtgLrDRKZVXIp13E55tY6AqLRESKoDxSmnyftK+CHAV55efJD5SXI+2R50NrkIJSZBc4EVEsWa3fPWZwi5WmucurMwvRyslafbHjBUq0xAulxDr9JATl7nfLBSJb9j/hBxDLIYleKiRu0q7rnZCIgJOZu23EVJMDsOSo6CDY7HkgNygTKQUbr3q+0j75Afk5FeSUXyA/IC8g7ZHyoLTTNhONmmLVu+sL2JYTXcsZfxMJG9aBnjtSLe3tLJ+si7ExEJAYIBVfcon9VjvOSFdV7/E+Yj2kG+nG+UEQV85luzH95PBQquhg5GKl0bcPuVdFVsyAp0lbfuTIDyjIkRfA86E9kA1Y7HQZnKwpHD/RIxEw7RHdZWEwuewwYYANk4Jf8vddvad+vtlYabMRpeMeskAlc2oQJueHkBM14iyPZKolUUeSiTjEKtmECp9NNzlEQBrFsvKGk4NSFU4I3Vs7viD2bCsoBa1IeaQ90h55AXk+eTnyfNK+W/9oJ1KhrJkHCYnqrnNLB4/SPXzvxJiIQWSENBXm8vlqUDvTaK6F2lNWgY21L7g3EtuSRE/v/iw4xTQ1aR9HcCKAVWC3G9NNDgDKQ3FW+158C6UgAKDjKXEMMSFEICd9Kq2UQsIP7ZHnW3KQ8oU8Ig1oK0nFV2O4VSLEeyVZ2SLJ8UQgkXAkpDFzoFTcY9bONaO2AQmUQr8cTqmr3m3L+TsxTcGxTUlUkIkopNNPDoVckfwtCWEEQCkiGxxazwNKk9bWikB5blmsIiKKcyfgNGxrGuyBucsU6bKm//qk73+OIEZIq8r+YqcR1ZdabJh0t0kXf8SBCEkyEdOlANlDx3NtLgNIDTn0dmDKySFQHgoz2tPxDdtDkmRiCuix7z1vbFSgFIGglPNPtbJOKJw8qgXKLpftOgDOQHRHka6AmZpIcwdKRoye3pOEAsDP69lLy63ldrseMrNS8WDB6eA2TjUmiFsvE/um3fl9F6w4C7fNmHJyAEoj55EesnKJYjcteWuRcgkoVsF76mSQtr6nhlKkCKSB2LpIbC6kV4BMvALnmYo7pMtEHxr0dt1JEwJKcpWcX/Rbq+1O05CKkzqc90FCIuIm3eBm6NKZQSKxnxJHNRexCOZAGl5Anh6acS29nEg803hATxqx8hPZOi1WGRMipUisfgll7bZzAQVEYE5FKKmlTd1+cNdFTBTNlDhCSVIXAWJgjJCiQjUflExzpcMRE7lVEG4tJLlVLCRpEyVxAkAqauFJZKBPPzkIOoA/vAgcdUMUpBzTVBTY/ZQdqsmplVaiBsFOtjlLQVB2BaRjVq/pjt9Jz6sk3ocM+Vwyw2rBzAQiUqX5QtgIO42QI7HCvTjzFHMziVXsQeJZGIAYE8oTnHpyiLL6ZpKi3bt3WNJBVw2IHQIrQKrEsiSTrxTPaMWeC7vVzBst1Ee9XNnID3KkES/naV+HzbDdjJRKcjviRpP0H7dwwY0w6HpD246pJwcRrHyZ4oakfQ0ZZjoGeOQWp/YyJv64sxxxsNJt0360J151OVpxN7inIXQ/3716fY048YtdPOoXfb/gt2sdE5mYBvHREl87PRtjmzJZKGstg9KgbgY30HX+nLjRR4/k4iZsiePHHl81gbUjyVjQp130iyupQaOreKT6i27Vpq5igmQmxHm2knTMCICgFHBkwpYxoVE6XpcAFzfbgS9xQajL7+3FlJPD6lgapGLtGGm/MI7ukGyJv5TyU9N/x/t7tiTpvtLLB0rZAKF+dqGPGKlrlTgaKSvjJkRIer7SZaSQUkFJcajClrFyPcU5QrG+7mb+RWxrF320ks68S001dMP+9L2eWPBEukz/bb/qUiJcO7G1kZgaaTXF6QlJo+i22eNo0PBupI5DiLvR46D0NSIQKK2CkjLtyETiBHYhG+Am8zhxNvK2m46pJocIPO0K7wF9qU+CJMJMDyfSGziQc+xjo+7WhHRbSWawYpb0DRRuvEkrpP0XRUZ2I/nEQDd6Im3EKaJxN3TgKV9M27Bh65DC8TSmISPvbfvk21STgwWHZv1Dz5ERqO4Nnf6I9BgU9O3quZIST1LEDACQfJv6r2fSSE85qJQvs/3d8HKaWXFo2AqmRDb/1NqMA8X+sqhjx7ST48i83tOsrZQqRZEen2Dwkg2H9P7ZEwuk9q/TyMCOSXXDKmHK18TCIQu7/I7HI/o3Cy1P+evnIl04pnepCREppbxc8XeOrpxohC0hEiChiKT/Jbn9bouk3srA3mEt9DciwxpMbZlUN1iseKpzWikiwTOMNwSdtx+uRfDUNpNjei2HJYfS3qF9hU+vPv3BZxaeKlYvJ6PTubUpM596P3wE6n0r/dtU+ttJI4PWYHQjY+nG8EYEglDrp6FeHq1+8MqVmULR83y1lfqam0Bfmsl0IYqiZrO5uLi4ury0srr2Z8f1/WvFqDCXqsY0EfTPqVAPHbpqSj9HUuj1P5PYO/FFhn6p12Mtd1Zvr66+/KDMVcsz1T1zc3P5fNabNDcAAAFESURBVF7rbVyEOtXkYOYwDOv1+vLycq1WizoNmFDYiEvm3+n+TQbJGivlkQ78XHGmUqlUKuVyWWu9rcZjeocVAEop3/cLhYKIeJ7XaASdToeZk+WEk5AJdx42m4C01kEQFIvFcrlcKBS2mxmYcssBOJ8uiqJOp9Nut6MomsDjq6YQSimtte/7QRAEQTABZmD6yWHBvdgVfR4vnHuulNba/j2Jg+6iE72Lurp92L6nyA45VnbGM4zC9IpgGXYcGTkyjERGjgwjkZEjw0hk5MgwEhk5MoxERo4MI5GRI8NIZOTIMBIZOTKMREaODCORkSPDSGTkyDASGTkyjERGjgwjkZEjw0hk5MgwEhk5MoxERo4MI5GRI8NIZOTIMBIZOTKMREaODCORkSPDSGTkyDASGTkyjERGjgwjkZEjw0hk5MgwEv8frk2QxLa27fYAAAAASUVORK5CYII="},"minimumSupportedOperatingSystem":{"v8_0":true},"notes":"","owner":"","privacyInformationUrl":"","publisher":"Microsoft Corporation"}
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            $CatCounter = 0
            While ($CatCounter -le 10) {
                Try {
                    $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                    Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                    $CatCounter = 10
                    Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
                }
                Catch {
                    $CatCounter++
                    Sleep 2
                }
            }

            # Assignment
            $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
            Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
            $Results2 = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                -Method Post `
                -Body $JSON2 `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}