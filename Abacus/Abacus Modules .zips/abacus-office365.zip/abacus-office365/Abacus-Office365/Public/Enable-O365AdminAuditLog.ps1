<#
.SYNOPSIS
A wrapper function around the MSOnline 'Enable-OrganizationCustomization' and 'Set-AdminAuditLogConfig' commands

.DESCRIPTION
This function is used to Enable Organization Customization and Admin Auto Logs within a Tenant's Exchange environment. While the MSOnline module includes these functions, we have wrapped them to be more easily accessible by our automation when creating New Tenants as connecting to the Exchange environment is required.

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by the Connect-TenantExchange command which can be used to invoke commands against the Tenant's remote exchange environment.

.EXAMPLE
Enable-O365AdminAuditLog

.NOTES
This function requires Connect-TenantExchange to have already been run and have a connection established.
#>
Function Enable-O365AdminAuditLog {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
    }
    Process {
        #Set the Admin Log Audit
        Try {
            Write-Log -LogString "Attempting to enable Org customizations." -LogLevel Output -LogObject $O365_global_logobject
            Invoke-Command -Session $ExchangeSession -ScriptBlock {
                Enable-OrganizationCustomization -Confirm:$False
            } -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an error enabling org customizations.`n Exception: {$($_.Exception)}" -LogLevel Warning -LogObject $O365_global_logobject
        }

        Sleep 60

        Try {
            Write-Log -LogString "Attempting to enable admin audit logs." -LogLevel Output -LogObject $O365_global_logobject
            Invoke-Command -Session $ExchangeSession -ScriptBlock {
                Set-AdminAuditLogConfig -UnifiedAuditLogIngestionEnabled:$True -Force
            } -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an error enabling admin audit logs.`n Exception: {$($_.Exception)}" -LogLevel Warning -LogObject $O365_global_logobject
        }
    }
}