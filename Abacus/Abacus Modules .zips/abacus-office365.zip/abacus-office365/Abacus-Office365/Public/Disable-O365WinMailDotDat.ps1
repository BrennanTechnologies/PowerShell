<#
.SYNOPSIS
A command for disabling WinMail.dat.

.DESCRIPTION
A command for disabling WinMail.dat.

.PARAMETER TenantExchangeSession
The name of the PSSession that was created by the Connect-TenantExchange command which can be used to invoke commands against the Tenant's remote exchange environment.

.EXAMPLE
Disable-O365WinMailDotDat

.NOTES
This function requires Connect-TenantExchange to have already been run and have a connection established.
#>
Function Disable-O365WinMailDotDat {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
    }
    Process {
        # Set the Default RemoteDomain's TNEF setting to FALSE
        Try {
            Write-Log -LogString "Attempting to set the TNEF configuration on the Default Remote Domain to False to disable WinMail.dat" -LogLevel Output -LogObject $O365_global_logobject
            Invoke-Command -Session $ExchangeSession -ScriptBlock {
                Set-RemoteDomain -Identity Default -TNEFEnabled:$false
            } -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an issue setting the TNEF configuration to false for disabling WinMail.dat." -LogLevel Warning -LogObject $O365_global_logobject
            Write-Log -LogString "$($_.Exception)" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
    }
}