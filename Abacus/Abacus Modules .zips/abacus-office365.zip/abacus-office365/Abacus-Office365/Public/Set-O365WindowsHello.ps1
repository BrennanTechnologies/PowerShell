<#
.SYNOPSIS
A command for enabling or disabling Windows Hello for an O365 client.

.DESCRIPTION
A command for enabling or disabling Windows Hello for an O365 client.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER State
A string value specifying if Windows Hello should be Enabled or Disabled

.EXAMPLE
Set-O365WindowsHello -TenantId {Tenantid} -Office365Instance {US/UK} -State Enabled

.EXAMPLE
Set-O365WindowsHello -TenantId {Tenantid} -Office365Instance {US/UK} -State Disabled

.NOTES
General notes
#>

Function Set-O365WindowsHello {
    [CmdletBinding()]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("Enabled", "Disabled")]
        [Parameter(Mandatory)]
        [String]$State
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType MDMRefreshToken -ErrorAction Stop)
        $MDMRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($MDMRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning -LogObject $O365_global_logobject
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))
            $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $MDMRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel Error -LogObject $O365_global_logobject
            }

            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))


            # Action(s)
            $JSON = @"
            {
                "@odata.type":  "#microsoft.graph.deviceEnrollmentWindowsHelloForBusinessConfiguration",
                "state":  "$($State)"
            }
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceEnrollmentConfigurations/9157824d-e683-433f-b23b-a92f98f0fac2_DefaultWindowsHelloForBusiness" `
                -Method Patch `
                -Body $JSON `
                -ErrorAction Stop
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}