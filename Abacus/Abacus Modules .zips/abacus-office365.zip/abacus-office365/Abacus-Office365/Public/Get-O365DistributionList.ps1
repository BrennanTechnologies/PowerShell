﻿<#
.SYNOPSIS
A command to get one or all DistributionGroups for a given tenant via the Graph API

.DESCRIPTION
A command to get one or all DistributionGroups for a given tenant via the Graph API

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Displayname
If specified, the DisplayName matching the individual distribuitionList to return along with its respective membership information.

.PARAMETER EmailAddress
If specified, the e-mail address matching the individual distribuitionList to return along with its respective membership information.

.PARAMETER ReturnAll
A Boolean switch flag which, if specified, will return all distribution list and membership information for a particular tenant.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER FirstRun
This flag can be provided which will call the PartnerCenter function in order to generate a new Access Token for the application.

.PARAMETER TestOnly
An optional flag which can be provided to test the command's access to the API-- at this will run a basic query, this can be used to create/refresh an Access Token without needed to run a full query which can be taxing.

.EXAMPLE
Get-O365DistributionList -TenantID <TenantId> -DisplayName <DisplayName> -EmailAddress <EmailAddress> -Office365Instance US

.EXAMPLE
Get-O365DistributionList -TenantID <TenantId> -DisplayName <DisplayName> -EmailAddress <EmailAddress> -Office365Instance US -ReturnAll

.NOTES
This function supports pipeline with Get-O365TenantDistributionList
#>

Function Get-O365DistributionList {
    [CmdletBinding(DefaultParameterSetName = 'ReturnAll')]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [Parameter(Mandatory = $False, ParameterSetName = 'ByDisplayName')]
        [ValidateNotNull()]
        [String]$Displayname = ''
        ,
        [Parameter(Mandatory = $False, ParameterSetName = 'ByEmail')]
        [ValidateNotNull()]
        [String]$EmailAddress = ''
        ,
        [Parameter(Mandatory = $False, ParameterSetName = 'ReturnAll')]
        [ValidateNotNull()]
        [Switch]$ReturnAll = $True
        ,
        [ValidateNotNull()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [Switch]$FirstRun = $False
        ,
        [Switch]$TestOnly = $False
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAEXCHANGEAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAEXCHANGEAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance

        #Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }

        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType EXCHRefreshToken -ErrorAction Stop)
        $EXCHRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($EXCHRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning -LogObject $O365_global_logobject
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        $Credentials = $(New-Object PSCredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

        If (   $True -ne $FirstRun   ) {
            Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose -LogObject $O365_global_logobject
            If ($RefreshTokenStatus -eq $False) {
                Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
            Else {
                $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $EXCHRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
            }
        }
        Else {
            Write-Log -LogString "FirstRun flag detected, will prompt for consent." -LogLevel Verbose -LogObject $O365_global_logobject
            $ResponseToken = Get-AccessToken -AppId $AppId -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -PromptConsent -Resource https://graph.microsoft.com/
        }

        If ($Null -ne $ResponseToken) {
            Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
        }
        Else {
            Write-Log -LogString "We were unable to retrieve a response token. Value was empty." -LogLevel Error -LogObject $O365_global_logobject
        }
        $Headers = @{ }
        $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))
    }
    Process {
        Try {
            $ReturnObject = @()
            If ($True -eq $TestOnly) {
                $ReturnObject = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/me" -ContentType "application/json" -Headers $Headers -Method Get
                $TenantContainer.Status = "200"
                $TenantContainer.Data = $ReturnObject
            }
            Else {
                Switch ($PSCmdlet.ParameterSetName) {
                    'byDisplayName' {
                        $Groups = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/groups?`$top=999&filter=displayName eq '$($Displayname)'"  `
                            -ContentType "application/json" `
                            -Headers $Headers `
                            -Method Get
                        $Results = $Groups.Value | % {
                            [PSCustomObject]@{
                                DisplayName     = $($_.DisplayName);
                                Mail            = $($_.mail);
                                GroupType       = $(   If ($True -eq [Boolean]$($_.groupTypes -eq 'Unified')) { 'Unified' } Else { 'LegacyDistributionGroup' }   );
                                SecurityEnabled = $($_.SecurityEnabled) ;
                                'Members'       = $($_ | Select @{n = "Members"; Expression = { Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/$($_.id)/members" -Method Get -Headers $Headers | select -expand Value } } | Select -ExpandProperty Members) | Select '@odata.type', id, displayName, mail, userPrincipalName ;
                                id              = $($_.id)
                            }
                        }
                    }
                    'byEmail' {
                        $DirectoryObject = ConvertTo-AzureObjectId -AccessTokenHeaders $Headers -Object $EmailAddress
                        If ($DirectoryObject.Status -ne 200) {
                            Write-Log -LogString "There was an issue querying our DirectoryObject for `"$EmailAddress`" code `"$($DirectoryObject.Status)`" was returned." -LogLevel TerminatingError -LogObject $O365_global_logobject
                        }
                        Else {
                            $Results = $DirectoryObject.Data.Value | % {
                                [PSCustomObject]@{
                                    DisplayName     = $($_.DisplayName);
                                    Mail            = $($_.mail);
                                    GroupType       = $(   If ($True -eq [Boolean]$($_.groupTypes -eq 'Unified')) { 'Unified' }  Else { 'LegacyDistributionGroup' }   );
                                    SecurityEnabled = $($_.SecurityEnabled) ;
                                    'Members'       = $($_ | Select @{n = "Members"; Expression = { Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/$($_.id)/members" -Method Get -Headers $Headers | select -expand Value } } | Select -ExpandProperty Members) | Select '@odata.type', id, displayName, mail, userPrincipalName ;
                                    id              = $($_.id)
                                }
                            }
                        }
                    }
                    'ReturnAll' {
                        $Groups = Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/groups?`$top=999"  `
                            -ContentType "application/json" `
                            -Headers $Headers `
                            -Method Get
                        $Results = $Groups.Value | % {
                            [PSCustomObject]@{
                                DisplayName     = $($_.DisplayName);
                                Mail            = $($_.mail) ;
                                GroupType       = $(   If ($True -eq [Boolean]$($_.groupTypes -eq 'Unified')) { 'Unified' } Else { 'LegacyDistributionGroup' }   );
                                SecurityEnabled = $($_.SecurityEnabled) ;
                                'Members'       = $($_ | Select @{n = "Members"; Expression = { Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/$($_.id)/members" -Method Get -Headers $Headers | select -expand Value } } | Select -ExpandProperty Members) | Select '@odata.type', id, displayName, mail, userPrincipalName ;
                                id              = $($_.id)
                            }
                        }
                    }
                    Default {
                        Write-Log -LogString "Unhandled Exception" -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                }

                ForEach ($Result in $Results) {
                    If ($Result.Members.Count -le 1) {
                        $Result.Members = @($($Result.Members))
                    }
                }

                If ($Results.count -le 1) {
                    $Results = @($Results)
                }

                ForEach ($Result in $Results) {
                    If ($Result.GroupType -eq 'LegacyDistributionGroup') {
                        Switch ($Result.SecurityEnabled) {
                            "True" { $Result.GroupType = 'SecurityGroup' }
                        }
                    }

                    If ($Result.GroupType -eq 'SecurityGroup') {
                        If ($Null -ne $Result.Mail) {
                            $Result.GroupType = "MailEnabled$($Result.GroupType)"
                        }
                    }
                }

                $TenantContainer.Status = "200"
                $ReturnObject += $Results
                If ($Null -ne $ReturnObject) {
                    $TenantContainer.Data = $ReturnObject
                }
            }
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "401"
                    $TenantContainer.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "400"
                    $TenantContainer.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(404)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(503)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(504)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(?)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning -LogObject $O365_global_logobject
            $TenantContainer.Status = "ERR(?)"
            $TenantContainer.Data = "$_"
        }
    }
    End {
        Return $TenantContainer
    }
}