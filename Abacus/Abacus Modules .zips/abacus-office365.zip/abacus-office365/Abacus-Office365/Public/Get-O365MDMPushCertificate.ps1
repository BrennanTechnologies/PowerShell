<#
.SYNOPSIS
A function to grab an Azure Tenant's MDM Push Certificate information

.DESCRIPTION
This function connects to AzureAD with the supplied Tenant Id and attempts to grab the MDM Push Certificate information within the environment via the InTune API.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.PARAMETER ReturnAsJson
A Boolean switch flag which can be supplied to return the output of the following command as a JSON object instead of a PowerShell Object.

.PARAMETER FirstRun
This flag can be provided which will call the PartnerCenter function in order to generate a new Access Token for the application.

.PARAMETER TestOnly
An optional flag which can be provided to test the command's access to the API-- at this will run a basic query, this can be used to create/refresh an Access Token without needed to run a full query which can be taxing.

.EXAMPLE
Get-O365MDMPushCertificate -TenantId <TenantID> -Office365Instance US

.NOTES
Use the -ReturnAsJson switch option if you wish to get the result in the form of a JSON object rather than a PowerShell Object
#>

Function Get-O365MDMPushCertificate {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$TenantId
        ,
        [ValidateNotNull()]
        [ValidateSet("US", "UK", "DEV")]
        [Parameter(Mandatory)]
        [String]$Office365Instance
        ,
        [ValidateNotNull()]
        [Switch]$ReturnAsJson = $False
        ,
        [Switch]$FirstRun = $False
        ,
        [Switch]$TestOnly = $False
    )
    Begin {
        #Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                #Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAMDMAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance

        #Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType MDMRefreshToken -ErrorAction Stop)
        $MDMRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($MDMRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object pscredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

            If (   $True -ne $FirstRun   ) {
                Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose
                If ($RefreshTokenStatus -eq $False) {
                    Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError
                }
                Else {
                    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $MDMRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                }
            }
            Else {
                Write-Log -LogString "FirstRun flag detected, will prompt for consent." -LogLevel Verbose
                $ResponseToken = Get-AccessToken -AppId $AppId -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -PromptConsent -Resource https://graph.microsoft.com/
            }

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel TerminatingError
            }

            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))

            If ($True -eq $TestOnly) {
                $ReturnObject = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/me" -ContentType "application/json" -Headers $Headers -Method Get
            }
            Else {
                Write-Log -LogString "Attempting to obtain MDM Certificate information for Company `"$($TenantInfo.CompanyName)`"" -LogLevel Output -LineNumber $(Get-CurrentLineNumber)
                $ReturnObject = $(Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/devicemanagement/applePushNotificationCertificate" -ContentType "application/json" -Headers $Headers -Method Get -ErrorAction Stop)
                $ReturnObject = $($ReturnObject | Select -Property * -ExcludeProperty '@odata.context')
            }

            If ($Null -ne $ReturnObject) {
                $TenantContainer.Data = $ReturnObject
                $TenantContainer.Status = "200"
            }
            Else {
                $TenantContainer.Data = "NULL"
            }
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "401"
                    $TenantContainer.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "400"
                    $TenantContainer.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(404)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(503)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(504)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning
                    $TenantContainer.Status = "ERR(?)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning
            $TenantContainer.Status = "ERR(?)"
            $TenantContainer.Data = "$_"
        }
    }
    End {
        If ($True -eq $ReturnAsJson) {
            Write-Log -LogString "ReturnAsJson was selected, outputting results in JSON format." -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber)
            Return $($TenantContainer | ConvertTo-Json -Depth 5)
        }
        Else {
            Return $TenantContainer
        }
    }
}