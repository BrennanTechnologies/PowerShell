<#
.SYNOPSIS
A command for querying one or more Device Management Scripts.

.DESCRIPTION
A command for querying one or more Device Management Scripts.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER Name
The DisplayName of the device management scripts you are looking for. If left blank this will query all possible.

.EXAMPLE
Get-O365DeviceManagementScripts -Headers $Headers

.EXAMPLE
Get-O365DeviceManagementScripts -Headers $Headers -Name 'DisableFireWall-SYSTEM'

.NOTES
General notes
#>
Function Get-O365DeviceManagementScripts {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$Name = $Null
    )
    Begin {
    }
    Process {
        Try {
            If (   $False -eq [String]::IsNullOrEmpty($Name)   ) {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceManagementScripts?`$filter=displayname eq '$($Name)'" `
                    -Method Get `
                    -ErrorAction Stop
            }
            Else {
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceManagementScripts" `
                    -Method Get `
                    -ErrorAction Stop
            }
        }
        Catch {
            Write-Log -LogString "There was an error querying the endpoint for Device Configurations.`nException: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }

    }
    End {
        Return $Results
    }
}