﻿<#
.SYNOPSIS
A command for updating a refresh token on the secret object for a given ClientAdminSecret

.DESCRIPTION
A command for updating a refresh token on the secret object for a given ClientAdminSecret

.PARAMETER ClientAdminSecret
The SecretObject from the Secret server that points to the O365 Admin account for the client that will have its refreshtoken updated.

.PARAMETER NewRefreshToken
The new refresh token from Microsoft.

.EXAMPLE
Update-RefreshToken -ClientAdminSecret <ClientAdminSecretObject> -NewRefreshToken <NewRefreshTokenFromMicrosoft>

.NOTES
This command can update multiple types of refresh tokens based on whatever information is passed to it from the secret object.
#>

Function Update-RefreshToken {
    [cmdletbinding()]
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $ClientAdminSecret
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        $NewRefreshToken
    )
    Begin {
        If (   ($Null -ne $ClientAdminSecret.SecretId) -and ($ClientAdminSecret.Data.Name -like '*RefreshToken*') -and ($Null -ne $ClientAdminSecret.Data.Value)   ) {
            $ProceedWithUpdate = $True
        }
        Else {
            $ProceedWithUpdate = $False
        }
    }
    Process {
        If ($ProceedWithUpdate -eq $True) {
            Try {
                Write-Log -LogString "Updating $($ClientAdminSecret.Data.Name) in Secret for SecretName: `"$($ClientAdminSecret.SecretName)`" - SecretId: `"$($ClientAdminSecret.SecretId)`"" -LogLevel Output -LogObject $O365_global_logobject
                Update-Secret -SecretId $ClientAdminSecret.SecretId -ArgumentList @{$($ClientAdminSecret.Data.Name) = $NewRefreshToken } -Confirm:$False -ErrorAction Stop
                $ReturnStatus = $True
            }
            Catch {
                $ReturnStatus = $False
                Write-Log -LogString "There was an issue updating the RefreshToken on the SecretObject" -LogLevel Error -LogObject $O365_global_logobject
            }

        }
        Else {
            $ReturnStatus = $False
        }
    }
    End {
        Switch ($ReturnStatus) {
            $True {
                Write-Log -LogString "Refresh Token was updated sucessfully..." -LogLevel Output -LogObject $O365_global_logobject
            }
            $False {
                Write-Log -LogString "Failed to Update RefreshToken" -LogLevel Warning -LogObject $O365_global_logobject
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject
            }
        }
    }
}