<#
.SYNOPSIS
A command to remove a Named Location for Conditional Access policy usage.

.DESCRIPTION
A command to remove a Named Location for Conditional Access policy usage.

.PARAMETER ID
The ID of the namedLocation to be removed.

.PARAMETER Name
The displayName of the namedLocation to be removed.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Remove-O365NamedLocation -Name 'Test Location' -TenantId $TenantId -Office365Instance US

.NOTES
General notes
#>

Function Remove-O365NamedLocation {
    [CmdletBinding(DefaultParameterSetName = 'ByName')]
    Param (
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ById')]
        [String]$ID
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByName')]
        [String]$Name
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True)]
        [String]$TenantId
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory = $True)]
        [ValidateSet("US", "UK")]
        [String]$Office365Instance
    )
    Begin {
        # Check for MSOnline connection and attempt to start if not already established
        Try {
            Test-O365MsolService -Office365Instance $Office365Instance | Out-Null
        }
        Catch {
            Write-Log -LogString "Currently not connected to an Office365 environment" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Write-Log -LogString "Attempting to establish a conncetion to Office365" -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Start-O365MsolService -Office365Instance $Office365Instance
        }
        Switch ($Office365Instance) {
            'US' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAREPORTAPP(US)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the US instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            'UK' {
                # Get RoleAccount Credentials
                Try {
                    $Secret = $(Get-O365Credentials -SecretName 'ABAREPORTAPP(UK)' -SecretType MSAppID)
                    $AppId = $($Secret | Select -ExpandProperty AppId)
                    $Password = $($Secret | Select -ExpandProperty Key)
                }
                Catch {
                    Write-Log -LogString "There was an issue obtaining the credentials for the UK instance." -LogLevel TerminatingError -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception" -LogLevel Error -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            }
        }

        $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
        [Array]$Body = @()

        # Create CustomObject to contain device information
        $TenantContainer = [PSCustomObject]@{
            'CompanyName'           = "$($TenantInfo.CompanyName)"; `
                'TenantId'          = "$($TenantInfo.TenantId)"; `
                'Office365Instance' = "$($Office365Instance)"; `
                'Status'            = "NULL";
            'Data'                  = "NULL";
        }
    }
    Process {
        # Get Client Secret + Refresh Token
        $ClientAdminSecret = (Get-O365Credentials -SecretName $($TenantInfo.CompanyName) -SecretType REPORTRefreshToken -ErrorAction Stop)
        $REPORTRefreshToken = $ClientAdminSecret.Data.Value
        If ([String]::IsNullOrEmpty($REPORTRefreshToken)) {
            Write-Log -LogString "The Refresh Token value is empty..." -LogLevel Warning -LogObject $O365_global_logobject
            [Boolean]$RefreshTokenStatus = $False
        }
        Else {
            [Boolean]$RefreshTokenStatus = $True
        }

        Try {
            $Credentials = $(New-Object pscredential -ArgumentList $AppId, $($Password | ConvertTo-SecureString -AsPlainText -Force))

            If (   $True -ne $FirstRun   ) {
                Write-Log -LogString "FirstRun flag NOT detected. Attempting to get response token with refresh token..." -LogLevel Verbose -LogObject $O365_global_logobject
                If ($RefreshTokenStatus -eq $False) {
                    Write-Log -LogString "There is no existing refresh token for this app. Please run in -FirstRun mode to create a refresh token." -LogLevel TerminatingError -LogObject $O365_global_logobject
                }
                Else {
                    $ResponseToken = Get-AccessToken -AppId $AppId -RefreshToken $REPORTRefreshToken -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -Resource 'https://graph.microsoft.com/'
                }
            }
            Else {
                Write-Log -LogString "FirstRun flag detected, will prompt for consent." -LogLevel Verbose -LogObject $O365_global_logobject
                $ResponseToken = Get-AccessToken -AppId $AppId -Credentials $Credentials -TenantId $($TenantInfo.TenantId) -PromptConsent -Resource 'https://graph.microsoft.com/'
            }

            If ($Null -ne $ResponseToken) {
                Update-RefreshToken -ClientAdminSecret $ClientAdminSecret -NewRefreshToken $($ResponseToken.refreshtoken)
            }
            Else {
                Write-Log -LogString "Response token was empty." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }

            Write-Log -LogString "Attempting to get Conditional Access Policy information for company $($TenantInfo.CompanyName)" -LogLevel Output -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            $Headers = @{ }
            $Headers.Add('Authorization' , $($ResponseToken.AccessTokenType) + " " + $($ResponseToken.AccessToken))

            # If there is more than one rule with the same name, this will remove all of them.
            $ReturnObject = @()

            Switch ($PSCmdlet.ParameterSetName) {
                'ByName' {
                    $LocationToDelete = (Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/namedLocations?`$filter=displayName eq '$Name'" -ContentType "application/json" -Headers $Headers).value

                    If (  ($LocationToDelete | Measure).count -lt 1   )  {
                        Write-Log -LogString "No matching Named Location was found to be removed." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        $LocationToDelete | %{
                            Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/namedLocations/$($_.id)" -ContentType "application/json" -Headers $Headers -Method Delete
                        }
                    }
                }
                'ById' {
                    $LocationToDelete = (Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/namedLocations?`$filter=id eq '$ID'" -ContentType "application/json" -Headers $Headers).value

                    If (  ($LocationToDelete | Measure).count -lt 1   )  {
                        Write-Log -LogString "No matching Location ID was found to be removed." -LogLevel TerminatingError -LogObject $O365_global_logobject
                    }
                    Else {
                        Invoke-RestMethod -Uri "https://graph.microsoft.com/beta/conditionalAccess/namedLocations/$($LocationToDelete.id)" -ContentType "application/json" -Headers $Headers -Method Delete
                    }
                }
            }

            If ($Null -ne $ReturnObject) {
                $TenantContainer.Data = $ReturnObject
                $TenantContainer.Status = "200"
            }
            Else {
                $TenantContainer.Data = "NULL"
                $TenantContainer.Status = "200"
            }
        }
        Catch [System.Net.WebException] {
            $CurrentError = $_
            Switch ($_.Exception.Message) {
                "The remote server returned an error: (401) Unauthorized." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "401"
                    $TenantContainer.Data = "$($CurrentError.Exception.message) --> $($CurrentError.ErrorDetails.Message)"
                }
                "The remote server returned an error: (400) Bad Request." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "400"
                    $TenantContainer.Data = "Bad Request --> $($CurrentError.Exception.message)"
                }
                "Unhandled Error: The remote server returned an error: (404) Not Found." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(404)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (503) Server Unavailable." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(503)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                "The remote server returned an error: (504) Gateway Timeout." {
                    Write-Log -LogString "$($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(504)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
                Default {
                    Write-Log -LogString "Unhandled Error: $($CurrentError)" -LogLevel Warning -LogObject $O365_global_logobject
                    $TenantContainer.Status = "ERR(?)"
                    $TenantContainer.Data = "$($CurrentError.Exception.message)"
                }
            }
        }
        Catch {
            Write-Log -LogString "Unhandled Error: $($_)" -LogLevel Warning -LogObject $O365_global_logobject
            $TenantContainer.Status = "ERR(?)"
            $TenantContainer.Data = "$_"
        }
    }
    End {
        If ($True -eq $ReturnAsJson) {
            Write-Log -LogString "ReturnAsJson was selected, outputting results in JSON format." -LogLevel Verbose -LogObject $O365_global_logobject -LineNumber $(Get-CurrentLineNumber)
            Return $($TenantContainer | ConvertTo-Json -Depth 5)
        }
        Else {
            Return $TenantContainer
        }
    }
}
