<#
.SYNOPSIS
A converter of Abacus' specific terminology to Microsoft license offers.

.DESCRIPTION
A converter of Abacus' specific terminology to Microsoft license offers.

.PARAMETER AccountType
The Abacus specific identifier to be converted to obtain the associated LIC offer.

.EXAMPLE
Get-O365LicenseType -AccountType FlexHybrid

.EXAMPLE
Get-O365LicenseType -AccountType EmailOnly

.EXAMPLE
Get-O365LicenseType -AccountType ServiceAccount

.NOTES
General notes
#>

Function Get-O365LicenseType {
    [CmdletBinding()]
    Param (
        [ValidateNotNull()]
        [ValidateSet("FlexHybrid", "EmailOnly", "ServiceAccount")]
        [Parameter(Mandatory)]
        [String]$AccountType
    )
    Begin {
    }
    Process {
        Switch ($AccountType) {
            "FlexHybrid" {
                #E3 = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
                $LICOfferId = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
                $LIC = @{
                    'Fullname' = $(Get-PartnerOffer -CountryCode $($Office365Instance) -OfferId $LICOfferId | Select -ExpandProperty Name)
                    'code'     = "ENTERPRISEPACK"
                    'OfferId'  = '796B6B5F-613C-4E24-A17C-EBA730D49C02'
                }
            }
            "EmailOnly" {
                #E1 = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                $LICOfferId = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                $LIC = @{
                    'Fullname' = $(Get-PartnerOffer -CountryCode $($Office365Instance) -OfferId $LICOfferId | Select -ExpandProperty Name)
                    'code'     = "STANDARDPACK"
                    'OfferId'  = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                }
            }
            "ServiceAccount" {
                #E1 = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                $LICOfferId = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                $LIC = @{
                    'Fullname' = $(Get-PartnerOffer -CountryCode $($Office365Instance) -OfferId $LICOfferId | Select -ExpandProperty Name)
                    'code'     = "STANDARDPACK"
                    'OfferId'  = '91FD106F-4B2C-4938-95AC-F54F74E9A239'
                }
            }
            Default {
                Write-Log -LogString "Unhandled Exception." -LogLevel TerminatingError -LogObject $O365_global_logobject
            }
        }
        $ReturnObject = New-Object PSobject -Property $LIC
    }
    End {
        Return $ReturnObject
    }
}