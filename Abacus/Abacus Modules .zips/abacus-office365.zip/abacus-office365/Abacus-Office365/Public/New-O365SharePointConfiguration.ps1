<#
.SYNOPSIS
A command used to create the SharePoint Configuration in O365 for a tenant.

.DESCRIPTION
A command used to create the SharePoint Configuration in O365 for a tenant.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365SharePointConfiguration -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>
Function New-O365SharePointConfiguration {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
            {
                "description":  "Windows 10 - SharePoint",
                "displayName":  "Windows 10 - SharePoint",
                "roleScopeTagIds":  [

                                    ]
            }
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/groupPolicyConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop

            # Assignment
            If ($Null -ne $TargetId) {
                $JSON2 = @"
                {"assignments":[{"id":"","target":{"@odata.type":"#microsoft.graph.groupAssignmentTarget","groupId":"$($TargetId)"}}]}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                $AssignResults = Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/groupPolicyConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }


            #Settings
            $SettingsJson = @"
            [
{"enabled":true,"presentationValues":[{"@odata.type":"#microsoft.graph.groupPolicyPresentationValueText","value":"5","presentation@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('120400ba-f245-46c6-9f84-c91b1500d706')/presentations('03081a27-07d6-4982-b31d-0937259d64a0')"}],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('120400ba-f245-46c6-9f84-c91b1500d706')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('81c07ba0-7512-402d-b1f6-00856975cfab')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('a7df08c0-4e3e-40a0-bd4a-321579eb05ba')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('2516d030-870e-4501-a00c-1910892fa3fc')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('e79145d3-90ee-4095-bfb9-cd23a0acce4c')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('25a3cd1f-1a49-4bf7-8dab-2c19ad2eb53c')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('0d1269b6-bfd5-4938-87dd-d9c4fa6b0765')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('686f6f27-ca3e-49c1-a622-debf103e4c85')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('ba45be03-e632-408a-bc4d-f2df8f7caa37')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('73d52afc-3218-4933-8072-c33bf5d1bb84')"}
,
{"enabled":true,"presentationValues":[],"definition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/groupPolicyDefinitions('021a3a53-5c3b-4a52-9c21-cf04304bc496')"}
]
"@

            ForEach (   $Setting in $($SettingsJson | ConvertFrom-Json)   ) {
                $SettingResults = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/groupPolicyConfigurations('$($Results.id)')/definitionValues" `
                    -Method Post `
                    -Body $($Setting | ConvertTo-Json) `
                    -ErrorAction Stop
            }

            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}