<#
.SYNOPSIS
A command to create Mail connectors within a Tenant's O365 environment.

.DESCRIPTION
A command to create Mail connectors within a Tenant's O365 environment.

.PARAMETER TenantExchangeSession
The name of the PSSession to look for to import commands from.

.EXAMPLE
New-O365MailConnectors

.NOTES
Please ensure you are connected to a Tenant's Exchange environment before running this commad.
#>

Function New-O365MailConnectors {
    [CmdletBinding()]
    Param (
        [String]$TenantExchangeSession = "Office365Exchange"
    )
    Begin {
        $ExchangeSession = $(Get-PSSession -Name $TenantExchangeSession -ErrorAction SilentlyContinue)
        If ($ExchangeSession -eq $Null) {
            Write-Log -LogString "There is no active Office365 session. Please connect with the Connect-TenantExchange command" -LogLevel Warning -LogObject $O365_global_logobject
        }
        Import-PSSession $ExchangeSession -AllowClobber
    }
    Process {
        Try {
            New-InboundConnector -Name 'Inbound Email from Proofpoint' `
            -RequireTls:$True `
            -SenderDomains '*' `
            -ConnectorType Partner `
            -RestrictDomainsToIPAddresses:$False `
            -RestrictDomainsToCertificate:$False `
            -CloudServicesMailEnabled:$False `
            -TreatMessagesAsInternal:$False `
            -Enabled:$False

        New-OutboundConnector -Name 'Outbound Email to Proofpoint' `
            -ConnectorType Partner `
            -RecipientDomains '*' `
            -UseMXRecord:$False `
            -SmartHosts 'mailgwny01.accessabacus.com', 'mailgwny02.accessabacus.com', 'mailgwsf01.accessabacus.com', 'mailgwsf02.accessabacus.com' `
            -TlsSettings 'EncryptionOnly' `
            -AllAcceptedDomains:$False `
            -CloudServicesMailEnabled:$False `
            -TestMode:$False `
            -Enabled:$False

        #New-HostedConnectionFilterPolicy -Name 'Abacus Connection Filters' -IPAllowList '199.192.65.7', '199.192.65.8', '199.192.65.9', '199.192.67.8', '199.192.67.9'
        #Set-HostedConnectionFilterPolicy -Identity 'Default' -IPAllowList '199.192.65.7', '199.192.65.8', '199.192.65.9', '199.192.67.8', '199.192.67.9'
        }
        Catch {
            $Err = $($_.Exception)
        }
    }
    End {
        If ($Null -ne $Err) {
            Write-Log -LogString "Failing to create Mail connectors...`n Exception: {$($Err)}" -LogLevel TerminatingError -LogObject $O365_global_logobject
        }
        Else {
            Write-Log -LogString "New-O365MailConnectors completed..." -LogLevel Output -LogObject $O365_global_logobject
        }
    }
}