<#
.SYNOPSIS
A command for creating the base iOS Excel App.

.DESCRIPTION
A command for creating the base iOS PowerPoint App.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.EXAMPLE
New-O365iOSExcelApp -Headers $Headers

.NOTES
General notes
#>

Function New-O365iOSExcelApp {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
        $RetryCreate = 0
        $RetryCreateMax = 5
        $RetryAssign = 0
        $RetryAssignMax = 5
    }
    Process {
        # Action(s)
        While ($RetryCreate -le $RetryCreateMax) {
            Try {
                $JSON = @"
{
    "@odata.type":  "#microsoft.graph.iosStoreApp",
    "applicableDeviceType":  {
                                "iPad":  true,
                                "iPhoneAndIPod":  true
                            },
    "appStoreUrl":  "https://apps.apple.com/us/app/microsoft-excel/id586683407?uo=4",
    "bundleId":  "",
    "categories":  [{
                        "displayName":  "Productivity",
                        "id":  "ed899483-3019-425e-a470-28e901b9790e"
                }],
    "description":  "Microsoft Excel, the spreadsheet app, lets you create, view, edit, and share your files quickly and easily. Manage spreadsheets, tables and workbooks attached to email messages from your phone with this powerful productivity app from Microsoft.\n\nWork in data analysis, accounting, auditing, or other fields confidently with anyone, anywhere. With Excel, your Office moves with you. Quickly graph the most complex formulas, charts and tables with amazing features.\n\nBudget, review spreadsheets and run data analysis on the go. Customize tables and spreadsheets the way you want with robust formatting tools and great features. The productivity app lets you build your spreadsheet to meet your specific needs, for whatever you’re doing.\n\nGet the complete Microsoft Office experience when you sign in with your Office 365 subscription.",
    "developer":  "",
    "displayName":  "Microsoft Excel",
    "informationUrl":  "",
    "isFeatured":  true,
    "roleScopeTagIds":  [],
    "largeIcon":  {
        "type":  "image/jpeg",
        "value":  "/9j/4AAQSkZJRgABAQAASABIAAD/4QBoRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAABJKGAAcAAAAQAAAAUKABAAMAAAABAAEAAKACAAQAAAABAAACAKADAAQAAAABAAACAAAAAABBU0NJSQAAAG1hZ2UgMTlN/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAgACAAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAICAgICAgMCAgMEAwMDBAUEBAQEBQcFBQUFBQcIBwcHBwcHCAgICAgICAgKCgoKCgoLCwsLCw0NDQ0NDQ0NDQ3/2wBDAQICAgMDAwYDAwYNCQcJDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ3/3QAEACD/2gAMAwEAAhEDEQA/AP38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/0P38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/0f38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/0v38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/0/38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/1P38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoorOudY0mzl8i8vbeCQDOySVEbB9iQaCZSUVeTNGisf/AISLw/8A9BOz/wDAiP8A+Ko/4SLw/wD9BOz/APAiP/4qi6I9vT/mX3mxRWP/AMJF4f8A+gnZ/wDgRH/8VR/wkXh//oJ2f/gRH/8AFUXQe3p/zL7zYorH/wCEi8P/APQTs/8AwIj/APiqP+Ei8P8A/QTs/wDwIj/+Koug9vT/AJl95sUVj/8ACReH/wDoJ2f/AIER/wDxVH/CReH/APoJ2f8A4ER//FUXQe3p/wAy+82KKx/+Ei8P/wDQTs//AAIj/wDiqP8AhIvD/wD0E7P/AMCI/wD4qi6D29P+ZfebFFY//CReH/8AoJ2f/gRH/wDFUf8ACReH/wDoJ2f/AIER/wDxVF0Ht6f8y+82KKx/+Ei8P/8AQTs//AiP/wCKo/4SLw//ANBOz/8AAiP/AOKoug9vT/mX3mxRWN/wkXh//oJ2f/gRH/8AFVKNc0U8jULX/v8AJ/jRdB7el/MvvNSisz+29F/5/wC1/wC/yf40f23ov/P/AGv/AH+T/Gi6D6xS/mX3mnRWZ/bei/8AP/a/9/k/xo/tvRf+f+1/7/J/jRdB9YpfzL7zTorM/tvRf+f+1/7/ACf40f23ov8Az/2v/f5P8aLoPrFL+ZfeadFZn9t6L/z/ANr/AN/k/wAaP7b0X/n/ALX/AL/J/jRdB9YpfzL7zTorM/tvRf8An/tf+/yf40f23ov/AD/2v/f5P8aLoPrFL+ZfeadFZn9t6L/z/wBr/wB/k/xo/tvRf+f+1/7/ACf40XQfWKX8y+806KzP7b0X/n/tf+/yf40f23ov/P8A2v8A3+T/ABoug+sUv5l95p0VTt9R0+7cx2l1DM4GSsciuQPoCauUGkZKSvFhRRRQMKKKKACiiigAooooAKKKKACiiigD/9X9/KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApCcc0teT/HDxHdeFvhR4o1mxfy7mDTZ1hcdVkkHlqR7gtke9KTsrnPi8THD0J4ie0U2/RK58N/tE/tUa5qer3ngn4aXrWGl2btBdanbtie7kU4dYnHMcSnjcvzP1yF6/C9xLLeTNcXjtPM5JaSVi7sT3LNkk1EBgYpa8CrVlN3kfxln3EGNzfEyxOLm3fZdIrsl/Te7GeXH/AHR+Qo8uP+6PyFPorM8SyGeXH/dH5Cjy4/7o/IU+igLIZ5cf90fkKPLj/uj8hT6KAshnlx/3R+Qo8uP+6PyFPooCyGeXH/dH5Cjy4/7o/IU+igLIZ5cf90fkKPLj/uj8hT6KAshnlx/3R+Qo8uP+6PyFPooCyIzHHg/KPyFe12safZYflH+rTt/sivFz0Ne1Wv8Ax6w/9c0/9BFBxY1KyJfLT+6Pyo8tP7o/KnUUHBZDfLT+6Pyo8tP7o/KnUUBZDfLT+6Pyo8tP7o/KnUUBZDfLT+6Pyo8tP7o/KnUUBZDfLT+6Pyo8tP7o/KnUUBZDfLT+6Pyo8tP7o/KnUUBZDfLT+6Pyo8tP7o/KnUUBZE1pc3OnzrdWEsltMhBWSFjG6kdwykEV9tfAb9oHUdR1G38E+O7j7RJckR2GoycSNIfuxTHoxbor9SeDnINfD9Pjmlt5EuIGKSxMHRxwVZTkEe4IzWtKtKnK6PpuF+KsbkeMjiMNN8t/ej0kuqa79nuj9taK5zwjqz674Y0rWJBh72yt7hh6NLGrH9TXR176Z/cdKpGpBTjs9QooooLCiiigAooooAKKKKACiiigD//W/fyiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK+cv2oJ9vwa8Sx/3rUD/wAiJX0bXzJ+1ET/AMKi8RD/AKdh/wCjEqKvwP0PI4g/5FeJ/wCvc/8A0ln45UUUV88fxMFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACHoa9qtf+PWH/AK5p/wCgivFT0Ne1Wv8Ax6w/9c0/9BFM48bsieiiikeeFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIelLQelAM/XD4UzeZ4A8Pj00y0H/kJa9Iryv4RH/ihNB/7B1r/6KWvVK+jjsj/QDLv90pf4Y/kgooopnYFFFFABRRRQAUUUUAFFFFAH/9f9/KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAr5j/AGo/+SReIv8Ar2H/AKMSvpyvmP8Aaj/5JF4i/wCvYf8AoxKir8D9DyOIP+RXif8Ar3P/ANJZ+OdFFFfPH8TBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAh6GvarX/j1h/wCuaf8AoIrxU9DXtVr/AMesP/XNP/QRTOPG7InooopHnhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQelFB6UAz9Y/hF/wAiJoX/AGD7X/0Uteq15V8Iv+RE0L/sH2v/AKKWvVa+jjsj/QDLv90pf4Y/kgooopnYFFFFABRRRQAUUUUAFFFFAH//0P38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvmP8Aaj/5JF4i/wCvYf8AoxK+nK+Yv2pDj4ReIj/07D/0YlRV+B+h5HEH/IrxP/Xuf/pLPx0opu8f5NG8f5NfP2Z/Ew6im7x/k0bx/k0WYDqKbvH+TRvH+TRZgOopu8f5NG8f5NFmA6im7x/k0bhRZgOopu6l3CkAtFJkUtABRRRQAh6GvarX/j1h/wCuaf8AoIrxU9DXtVr/AMesP/XNP/QRTOPG7InooopHnhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQelFB6UAz9Y/hF/wAiJoX/AGD7X/0Uteq15V8Iv+RE0L/sH2v/AKKWvVa+jjsj/QDLv90pf4Y/kgooopnYFFFFABRRRQAUUUUAFFFFAH//0f38ooooAKKKKACiiigAqG4uILSCS6upEhhhUvJJIwVERRkszHAAA5JPAqavyd/bq+OeqX3iJvgz4euWg0zT0il1lomwbm4kUOkDEdY40Ksy9GY8/drGvWVKHMzwOJeIKOT4GWMrK72S7t7L9X5H0p43/bo+C3hS9k03R2vvEs0TFXk02JRbZHUCaV0D/VAyn1rzv/h4t4D/AOhR1r/v7bf/AByvyV4FNJ9K8eWYVm9D8Hr+KGe1JuUJRiuyiv1uz9az/wAFF/AX/Qo61/39tv8A45Sf8PGPAf8A0KOtf9/bb/45X5J0Uv7QrdzP/iJef/8AP1f+Ax/yP1s/4eMeA/8AoUda/wC/tt/8co/4eMeA/wDoUda/7+23/wAcr8k6Qmj+0K3cf/ES8/8A+fq/8Bj/AJH62/8ADxjwF/0KOtf9/bb/AOOUn/DxnwF/0KOtf9/bb/4uvyQJ9aaW9KPr9buH/ES8+/5+r/wGP+R+uH/DxrwD/wBCjrX/AH9tv/i68l+L/wC2t4P+JPgfVPCuneG9Vs57+IRpLPLAY1IZWyQrE9u1fnPSE4pPH1mrNmWI8Qs7r0Z0KtRcsk0/dWzVn0Ov/wCElj/54v8A99CkPieIf8sX/MVx5OaSuf2kj4T2EOx2P/CURf8APB/zFH/CURf88H/MVx1NLUe0kH1eHY7L/hKIv+eL/mKT/hKYf+eD/mK4wn1ppb0o9pIr6tT7HaHxVCP+WD/mKP8AhK4f+eD/AJiuIJxTSc0e0kP6tT7HbnxZAP8Alg/5ij/hLYP+eEn5iuHope0kNYWn2PQIPFVlI2JVeLPcjI/SujhuI5kEkTB1bkEcivHM4rY0XU5LK5WMk+VIcEehPQ1UKutmZVcFG14HqQYGng4qnHJuGRVlcntWrR5ko2JqKRQfSnYPoaVmSNPQ17Va/wDHrD/1zT/0EV4sQcHg17Vag/ZYf+uaf+gig4sbsiailwaMGkcAlFLg0YNACUUuDRg0AJRS4NGDQAlFLg0YNACUUuDRg0AJRS4NGDQAlB6UuDSEHFAM/WP4Rf8AIiaF/wBg+1/9FLXqteVfCL/kRNC/7B9r/wCilr1Wvo47I/0Ay7/dKX+GP5IKKKKZ2BRRRQAUUUUAFFFFABRRRQB//9L9/KKKKACiiigAooooAK/nd+P1zLdfG7x3NMxZjr9+uT/dSUqo/AAAV/RFX86vx2/5LV46/wCxh1H/ANHtXmZn8C9T8i8Xv9yw6/vP8jymiijNeMfggUhOKQt6UwnFAxxNMJ9KQnNJQOwZozimlvSm0FJCk0lFGcUAFITimk5ppNBSQ4nNMLelITmmFvSgY4n1ppPpTaKB2CiikJxSuUoi00tTS3rTCc0WKHFqjcnaT7GgnFMY/KfoaZSRj2uoXZiXM8vT++3+NaSX15/z8S/99t/jXK2MmYl+lbcTdDVyPSxFJJvQ1lvLzj/SJf8Avtv8ak+2Xn/PxL/323+NUFqapuzi5V2LBvLzB/0iX/vtv8a95tru7+zQ/v5f9Wn8bf3R718+noa97tv+PaH/AK5p/wCgirps8rM4q0S99ru/+e8v/fbUfa7v/nvL/wB9tVeitbs8iyLH2u7/AOe8v/fbUfa7v/nvL/321V6KLsLIsfa7v/nvL/321H2u7/57y/8AfbVXoouwsix9ru/+e8v/AH21H2u7/wCe8v8A321V6KLsLIsfa7v/AJ7y/wDfbUfa7v8A57y/99tVeii7CyLH2u7/AOe8v/fbUfa7v/nvL/321V6KLsLIsfa7v/nvL/321H2u7/57y/8AfbVXoouwsix9ru/+e8v/AH21Ibu7wf38vT++3+NQUh6GlcOVH7l/BUk/Djw0Sck6VZZJ/wCuKV69XkHwU/5Jv4a/7BVl/wCiUr1+vo47I/ubL/8Adaf+FfkFFFFM6wooooAKKKKACiiigAooooA//9P9/KKKKACiiigAooooAK/nU+Ov/JafHX/Yw6j/AOj3r+iuv50vjsf+L1eO/wDsYdR/9HtXmZn8C9T8j8Xf9yof4n+R5UW9KaT600t6U2vGPwT0FJpKQnFNJzQUkOJppOaSvRPBnwl+JPxEtLi/8D+HrzWre0lEM72oRvLkI3BWBYEZByOMH86ai27I3oYerWn7OjFyl2Su/uR53RXup/Zi/aC7eA9X/wC+E/8Ai6af2Yf2gz/zIer/APfCf/F1fsan8r+471keY/8AQPP/AMBl/keFFvSmE4rq/GXgXxl8PtTj0bxtpF1o17NCLiOG6XazxMSodcEgjcpHB6iuRJ9ahpp2Zw1KM6UnTqJprdPRi5NNJxTSc0lIgUnNJRXrnhv4C/Gbxhott4j8MeD9T1HTLwM1vdQxr5cqqxUldzAkbgRnGOKai3olc6cPhK1eXLRg5Psk3+R5HSE4r3g/swftC9vAWr/98J/8XVW7/Zo+PljbTXt54H1WGC3jaWWWRY1REQFmZiXwAAMk+lV7Gp2Z2/2LmCV/YT/8Bl/keHlqYW9KbnPNNLelQeckOzimE0lFBSQU1/uN9DQW9Kjc/K30NBaicTp7/ulPtXRQHiuV04/ulNdNbnitZns4yPvM01qeq6VYrI8l7iHoa97tv+PaH/rmn/oIrwQ9DXvdt/x7Q/8AXNP/AEEVpTPKzTaJNRRRWh44UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAH7lfBT/km/hr/sFWX/AKJSvX68g+Cn/JN/DX/YKsv/AESlev19HHZH9y5f/utP/CvyCiiimdYUUUUAFFFFABRRRQAUUUUAf//U/fyiiigAooooAKKKKACv5zvjv/yWvx3/ANjDqP8A6Pav6Ma/nM+PBx8a/Hf/AGMOo/8Ao9q8zM/gR+R+Ln+5Yf8AxP8AI8qppb0ptFeMfg4UUE4phNA0hxOK+j/2XPjXL8F/ibbX9/Ky+HtY2WOrp/CsTN+7uMf3oGOfXYWHevmwmmk5q4TcJKUdzty/G1sFiIYrDu0ou6/rs9n5H9R8UsU8STwuskcih0dTlWVhkEEcEEdKkr4G/YU+OP8Awm/gt/hl4guN+teF4l+yM7Ze50zO1OvVoCRGf9kp719819LSqKpBTR/WWTZrSzLB08ZR2ktuz6r5M+JP25fg+fiB8Lz4x0iDzNa8Ib7sbBl5bBsfaY+OTsAEo/3SB1r8QuvNf1KTQxXETwToskcilHRhlWVhggg9QR1r+eT9pL4Sy/Bv4sar4YhjZdJum+36S56NZzklUB7mFg0Z/wB0HvXl5lRs1VXzPyTxSyDkqwzWktJe7L16P5rT5LueDUUhOKYW9a8o/IUj1L4OfDPU/i/8RtH8B6buRb2XfeTqM/Z7OL5p5fqF4X1cqO9f0a6HoumeG9GsfD+iwLbWGm28drbQoMKkUShVH4AfjXxB+wf8F/8AhB/h/J8Rtbt9ms+LEV7cOMPBpinMQ56GY/vD6rs9K+9K9/AUOSHM92f0Z4d8P/UMv+s1V+8q2fpHov1fr5BX5u/t9/Hf/hHdAj+DXhu4xqWtxCfWHjPzQWBPyQkjo1wRyP8AnmD2cV9v/FX4j6H8JvAWreO9fb9xp0JMUIOHuLh/lihT/akcgewyegNfzieM/F+uePvFWqeMvEkxn1LV7l7mdv4VLfdRR2RFAVR2UAVOPxHJHkW7ObxG4j+p4T6hRf7yotfKPX79vS5zWaSkJAppOa8M/AkhxNNJzTScU0nNBSQpb0pjn5Wz6GkLelMc/K30NBSWpwun/wCqWuot+grl9P8A9UtdRB0FbTPZxm7NNOgqxVdOgqxWJ48txD0Ne923/HtD/wBc0/8AQRXgh6Gve7b/AI9of+uaf+gitKZ5OabRJqKKK0PHCiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA/cr4Kf8k38Nf9gqy/9EpXr9eQfBT/AJJv4a/7BVl/6JSvX6+jjsj+5cv/AN1p/wCFfkFFFFM6wooooAKKKKACiiigAooooA//1f38ooooAKKKKACiiigAr+cv48f8ls8d/wDYw6j/AOj2r+jSv5yfjwf+L2eO/wDsYdR/9HtXm5n8C9T8k8W/9yof4n+R5TTS3pSE5phb0rxT8ISHE+tMJpCfWmE5oGOJxTSSaSigpI7v4Z/EHW/hZ450nx1oDH7Tpk4dos4WeBvllhb/AGZEJX2OD1Ar+jXwV4v0Tx94U0vxl4dmE+natbJcwt3AYfMjDs6NlWHZgRX8x9fo/wDsCfHH+wten+DXiG4xYay7XOjPIeIr3GZIBnoJ1G5R/fUgcvXoZfiOWfI9n+Z+m+G3EX1LF/UKz/d1Hp5S6fft62P15r4t/bg+Dx+I3wrfxTpMHma34Q8y+i2DLy2RA+1RccnCgSAeqYHWvtKmSRxyxtFKodHBVlYZBB4IIPUGvZq01OLg+p+5Zrl1LH4Spg620lb07P5PU/lk3Z5Fe/fs0fB2b41fFXTvDlxGx0ayIv8AWJB0FpEw/d57NM2Ix7EntS/tPfCR/gz8WtU8PWsRTR74/wBpaQ3b7JOx/dg9zC4aP6AHvX60fsbfBgfCf4UW1/qkOzxB4nEeo35YYeKJlzb259PLRssP77NXhYfDOVXkl03P594X4Tq4nOXhMVH3aTvP5PRf9vP8Ls+soIIbWCO2tkWKKJFSNEG1VRRgAAcAAcAVLRXyR+2H8dh8G/htJY6LOE8T+JBJZ6aFPz28eMTXWO3lq2EP/PRl9DXu1JqEXJn9CZjj6OBw08VXdoxV/wDJLzeyPz6/bk+O/wDwsfx2Ph/4fuN/h7wpM8cjIcpdalysr8cMsIzGnvvI4Ir4VLU0sSSzEkk5JJyST3PrTS3pXzVWo6knOR/LObZlVzDFzxlfeT+5dF8kOJxTCc0hOKYTWZ544nFNJJpKQnFK5SiLTHPyt9DQTmo3PykexoLW5xen/wCqWuog6CuX0/8A1S11EHQVvM9bGbs006CrFV06CrFYnjS3EPQ173bf8e0P/XNP/QRXgh6Gve7b/j2h/wCuaf8AoIrSmeTmm0SaiiitDxwooooAKKKKACiiigAooooAKKKKACiiigApD0NLSHoaAP3K+Cn/ACTfw1/2CrL/ANEpXr9eQfBT/km/hr/sFWX/AKJSvX6+jjsj+5cv/wB1p/4V+QUUUUzrCiiigAooooAKKKKACiiigD//1v38ooooAKKKKACiiigAr+cb48nHxs8ef9jFqX/o9q/o5r+cL49HHxu8e/8AYxal/wCj2rzMz+Bep+S+LX+5UP8AE/yPKCaaW9KQnNJXjH4TYKKKQnFK5SiLSE00tUZNFih5ap7G/vdMvrfU9Ome2u7SVJ4Jozh45YmDI6nsVYAiqZOKaTmmVG6d0f0W/s6fGSy+Nvwy0/xSGRNVtx9j1e3Xjyr2IDcQOySAiRPZsdQa92r8A/2R/jg3wY+J0A1Wcp4b8QmOx1UE/JCSf3Nzj/pkx+Y/882b2r9+lZXUOhDKwyCOQQe4r6LCV/awu90f05wXxCs1y9SqP95DSX6P5/nc8J+M3wG8NfGbU/B+pa5tVvC+rLeyArn7TaYzJbN/svIkZPsD617wAAMCiiuhQSba6n0tLCUadWdaEbSna772Vl9yMvW9Z0zw7o97r+tXCWlhp0ElzczyHCxxRKWZj9AK/nN+PXxf1P42fEnUvGt5vjsyfs2l2zn/AI9rGIny1x03Nku/+2x7Yr71/wCCg/x2aNIfgZ4buCGkEV5r7ocfIcPb2p/3uJXHpsHcivyjJrx8wxHNL2a2R+KeJHEX1jELLaD9yHxecu3/AG7+d+wufWmlvSm5zRXmn5gkFGcU0t6U0nFItIUnNNJxTS1Rk0WGkPLVGx+U/Q0U1/uN9DTLSOS0/wD1S11EHQVy+nkeUtdPbkYHNbTPTxm7NROgqxVZCMCrORWJ40lqIehr3u2/49of+uaf+givBCRg171bEfZoef8Almn/AKCK0pnk5ptEnopMj1oyPWtDxxaKTI9aMj1oAWikyPWjI9aAFopMj1oyPWgBaKTI9aMj1oAWikyPWjI9aAFopMj1oyPWgBaQ9DRketISMHmgD9y/gp/yTfw1/wBgqy/9EpXr9eQfBT/km/hr/sE2X/olK9fr6OOyP7ly/wD3Wn/hX5BRRRTOsKKKKACiiigAooooAKKKKAP/1/38ooooAKKKKACiiigAr+cH49f8lu8e/wDYxal/6Pav6Pq/nA+PX/JbvHv/AGMWpf8Ao9q8zNH7kT8n8WVfB0P8T/I8mozimlqYWrxT8LHlqjLelNJppb0p2GkOzTS3pTaKCkgozimlvSui8IeE9c8d+KNM8H+G4Dc6nq1wltbx9tzdWY9kRcsx7KCaEm3ZGtOlKclCCu3okfUv7GnwEPxf+II8Qa/b7/C3hiSO4uw4+S7u/vQ23uvG+Qf3QAfvCv3eACgADAHAArzL4P8Awu0P4O/D/S/AuhAMtnHvubjGHuruTmWZvdm6DsoC9BXp1fR4WgqULdep/TnCXD0cpwKpP+JLWT8+3otvvfUKK+RfiV+1HoXgL9oDwn8JJpYvsV+jJrVy2P8ARLi8CixUtkbfmGZM9FkU19dVtGpGTaXQ9vC5hh8TOpToyu4Plfk7X/4Hqmuh+bP7f/wG/wCEj8PR/Gfw1b7tS0OIQ6yka/NPp4PyzEDq1uT8x/55k9kFfjrX9VF3a219azWN7Ek9vcRtFLFIAyPG4KsrA8EEHBHpX87/AO1B8Ebn4G/E670O3RzoGpbr7RZjyDbM3zQlu7wMdh7ldrfxV5OY4ez9rHrufkHiRw77Kqs0oL3ZaS8n0fz6+fqfOpb0ppPrTS1MLV5Z+V2HFqYWpuc0Uy0gopCaYW9aVykhxb0qKRvkb6H+VBaonPyt9D/KguK1PJLInYtb8BOBWBZfcWt+DoK9Vn6ZiOpfUnFTZPqahXpUtZnA9xcn1r0WMny05/hH8q85r0WP/Vp/uj+VYV+h85xBtD5/oSZPqaMn1NJRXMfMi5PqaMn1NJRQAuT6mjJ9TSUUALk+poyfU0lFAC5PqaMn1NJRQAuT6mjJ9TSUUALk+poyfU0lFAC5PqaRidp5PSikb7p+lAM/o/8AgJ/ySjwj/wBgTTv/AEnjr2qvFfgJ/wAko8I/9gTTv/SeOvaq+qh8KP67wX+70/RfkFFFFUdIUUUUAFFFFABRRRQAUUUUAf/Q/fyiiigAooooAKKKKACv5vPj23/F7/Hv/Yxal/6Pav6Q6/m4+Phx8cPH3/Yxal/6PavMzP4In5R4sf7lQ/xP8jycnNNJxTSTSV4x+GKIpOaSkyBTSc0FpDicU0nNNJxTSc0FJClgK/Y79gj4Bf8ACK+HW+Mfii226trsPl6RHIvzW2nt1lwej3BAI7iMD+8RXwh+yf8AAib44fEiKHUomPhnQyl5rEmCFkGf3VsD/emYHPcIGPXFf0DQww20MdvbosUUShERAFVVUYAAHAAHAFepl+Hu/ay+R+teG3Dftan9q4he7HSHm+r+Wy879iWvPfir8RdG+FHgDWfHuuEGDS7dnjizhp52+WGFf9qSQhfbOegr0Kvxi/4KCfGz/hKvGVv8I9Cn3aZ4Zfz9SKH5ZtSdeEOOot42x/vuw6rXoYmt7Km5dT9K4ozuOV5fPEfaekf8T/y3fofBXirxPrPjPxLqfi7xBOZ9S1a6kvLiTOP3khzhfRVGFUdgAO1fvV+yD8aR8Y/hLZy6nP5niDw/s03VQT88jIv7m4P/AF2jAJP98P6V/PmT619NfsmfGlvgx8XLG/1CYx6Bre3TdXBPypFIw8uc+8EmGJ/uFx3rxcHiHCrdvR7n4lwZxBLL8zU60vcqaS+e0vk9/Js/oar5y/ag+B9r8c/hhd6Hboi69pu6+0WdsDbcovMRbsk6/I3YHa38Ir6MVldQ6EMrDII5BBpa+gnBSi4y2P6ExuDpYuhPDV1eMlZ/1+R/KXd2t1Y3U1jfRPb3NtI8M0Mg2vHJGSrKwPIKsCCPWq9fpV/wUE+An/CN+II/jV4at9uma3KsGtJGPlgvyPknIHRbgDDH/noMnl6/NMt6V8zWpOnNwZ/MWc5RVy7GTwlXps+66P8ArroLkCmlqaWqMtWR5qQ8tUZakJzSUykgpr/cb6GlJAqKRvkb6H+VFy4x1PKrL7i1vwdBWBZfcWt+DoK9Rn6TiOpfXpUtRL0qWszz3uFeix/6tP8AdH8q86r0WP8A1af7o/lWFfofOcQbQ+f6D6KKK5j5kKKKKACiiigAooooAKKKKACiiigAooooAKRvun6UtI33T9KAZ/R/8BP+SUeEf+wJp3/pPHXtVeK/AT/klHhH/sCad/6Tx17VX1UPhR/XeC/3en6L8goooqjpCiiigAooooAKKKKACiiigD//0f38ooooAKKKKACiiigAr+bb4+/8lw8ff9jFqX/o96/pJr+bT4+n/i+Hj7/sY9S/9HtXmZn8ET8p8Vl/sdD/ABP8jyamlvSm5ppb0rxj8QURxNNJ9KaT600t6UDFJxWlomi6t4l1mx8PaFbPeajqVxHa2sEfLSSysFVR+J5PQDk8VlV+sv8AwT9+AP2W2b45+Kbb97cLJb+HopBykRys13g935jjP93cejA1tQourNQR7nD2SVc0xsMLDRbt9l1f6LzsfcHwA+DmlfA/4b6f4Ostkt8w+06pdqMG5vZAPMbPXYuAiDsqjvmva6KK+kjFRXKj+ocLhaWGoxoUVaMVZI8Q/aH+L1l8E/hZq3jOQo2oFfsmlQN/y2vpgREMd1TBkf8A2VNfzhX+oXmqX1xqeozPcXd3M8880hy8ksrFndj3LMSTX2R+3H8bv+FofFJ/C+i3HmeH/CDSWcBQ5Se+JxczccEKQIlPopI+9XxPnNeDjq3tKllsj8A47z3+0MwdKm/3dPReb6v9F5LzHFqaeeveikJxXHc+JSP3k/Ya+Nf/AAs/4VJ4X1m48zxB4QEdjOXOXnsiCLWb1J2qY2PqmT96vtmv5tf2cfjFc/BL4r6T4wZ2/suVvsWrxL/y0sZyA5x3aIgSL7rjua/pCtLu2v7SG+spVnt7mNJYZUO5HjcBlZSOoIIINe/ga/tKdnuj+h+Bc8+v5eqVR/vKej810f3aeqOf8a+D9C8f+FNU8GeJYBc6bq9s9tcJ3CuOGU9nRsMp7MAa/mq+Lnw0134QfEDV/AHiAFptOl/cT4wt1av80M6+zpjPo2V6g1/T7Xwf+3Z8Aj8UPh//AMJ74ctvM8S+E4pJdsa5ku9O+9NDxyzR8yRj/eUctSx2H9pDmW6MeO+Hvr+E+s0V+8p6+seq/VfNdT8KCc0lICCMjpSFq8C5+CKIuQKaWphaoy1M0UR5NRO3ytj0NGc01/uN9DRctbnmVl9xa34Ogrn7H/VrXQQdBXqM/RMR1L69KlqJelS1mee9wr0WP/Vp/uj+VedV6LH/AKtP90fyrCv0PnOINofP9B9FFFcx8yFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFI33T9KWkb7p+lAM/o/wDgJ/ySjwj/ANgTTv8A0njr2qvFfgJ/ySjwj/2BNO/9J469qr6qHwo/rvBf7vT9F+QUUUVR0hRRRQAUUUUAFFFFABRRRQB//9L9/KKKKACiiigAooooAK/mx+Px/wCL4+P/APsY9S/9HtX9J1fzXfH84+OXj/8A7GPUv/R7V5mZ/BE/K/FX/c6H+J/keSE00t6UhOaSvGufiCQUZxTS3pTSfWkUkKTnjtXuNh+0z8fNKsbfTNN8capbWlpEkEEETRqkUUahURRs4VVAAHpXhRamFvSqjKS2djqw+Kr0G3Qm437Nr8j6AP7VX7RX/Q/6x/33H/8AEVFJ+1N+0TLG0T+P9Y2uCpxIgODweQgI/CvAqKv20/5mdf8Aa+P/AOf8/wDwKX+YpJYlmJJJySeSSe5pM4ppb0phasjhSHFqYWphamk5osUKWr2vRP2kfjx4b0iz0DQvHGrWen2EK29tbpIpSKJBhUXcpOFHAGeBxXiVITiqU3H4WdOHxFag3KjNxb7Nr8j6C/4as/aN/wCig6x/33H/APEU0/tXftG/9FB1j/vuP/43Xz4WqMn1qva1P5n952rNsf8A8/5/+BS/zJ7i4luZ5LmY7pJXaR2wBlmJJOAABknoOKrk0ham1FzhFJzSUhOKYWpasB5OKhdvlb6GkJ9ajdvlbHof5UJFxjqed2P+rWugg6Cufsf9WtdBB0Feqz9CxHUvr0qWol6VLWZ573CvRY/9Wn+6P5V51Xosf+rT/dH8qwr9D5ziDaHz/QfRRRXMfMhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSN90/SlpG+6fpQDP6P/gJ/wAko8I/9gTTv/SeOvaq8V+An/JKPCP/AGBNO/8ASeOvaq+qh8KP67wX+70/RfkFFFFUdIUUUUAFFFFABRRRQAUUUUAf/9P9/KKKKACiiigAooooAK/ms+P/APyXLx//ANjHqX/o96/pTr+bD9oi3mtfjx8QIJlKsPEWoNg/3XlZlP0KkEV5mafBH1PyzxTX+x0H/ef5HjpNNJzTSajLV4tj8SsPLVGWpCc0lMpRDrRSE4ppalctIUtTS3rTC1MLUWKsOLUwmkoplJBRnFNLVGWNItRHlqjJppamk5plpClvSm0U0tSv2GOphamFqYWosUoji1MLelITmkzihsoKa5+U/Q0FqhkfCMewBJ/KjUuMdTg7H/VrXQQdBXP2X3FroIOgr1WffYjqX16VLUS9KlrM897hXosf+rT/AHR/KvOq9Bjmh8tP3ifdH8Q9Kwr9D53P4tqFvP8AQnoqPzof+eif99Cjzof+eif99CuezPm/Zy7ElFR+dD/z0T/voUedD/z0T/voUWYezl2JKKj86H/non/fQo86H/non/fQosw9nLsSUVH50P8Az0T/AL6FHnQ/89E/76FFmHs5diSio/Oh/wCeif8AfQo86H/non/fQosw9nLsSUVH50P/AD0T/voUedD/AM9E/wC+hRZh7OXYkoqPzof+eif99Cjzof8Anon/AH0KLMPZy7ElI33T9KZ50P8Az0T/AL6FNaeHaf3idP7wosxOnLsf0ifAT/klHhH/ALAmnf8ApPHXtVeKfAQg/CfwgR0Oh6d/6Tx17XX1MPhR/XOC/wB3p+i/IKKKKo6QooooAKKKKACiiigAooooA//U/fyiiigAooooAKKKKACvx7/4KA/ALVtP8St8b/Ddq1xpWoxxRa2sSkm1uYlEaXDADiKRAqs3RXXn7wr9hKhuba3vLeW0u4kngmRo5IpFDo6MMMrKcggjgg8Gsa9FVYcrPE4gyOlmuDeFqu3VPs11/R+R/KUTmkr92fHv/BP74F+L7+XU9EGoeFZ5mLPFpkqm1yepWGZJAn0Qqo9K80/4dm/D3/oc9d/79Wv/AMbrx5ZfWWx+MVvDrOITcYRjJd1JfrZn445xTC1fsh/w7M+Hn/Q567/35tf/AI3Sf8Oyvh4f+Zz13/v1a/8Axup/s+t2IXh9nX/Ptf8AgS/zPxtLUwtX7Jn/AIJk/Dw/8zprv/fm1/8AjdJ/w7I+Hn/Q6a7/AN+bX/43R/Z9bsV/xD/Ov+fa/wDAl/mfjVnNFfsr/wAOyPh5/wBDprv/AH5tf/jdIf8AgmP8PD/zOmu/9+rX/wCN0fUK3Ya8P85/59r/AMCX+Z+NRaoy1fswf+CYvw7P/M6a9/35tf8A43Xgf7Rv7Efg/wCCvwj8SfEXRfEuq6leaJafaIra7igWGRt6JhjGoYDDZ4o+oVlrYcuAs4jFylTVl/eX+Z+cBNMJzXk3/Cf6x/z42/8A309J/wAJ/rP/AD5W/wD303+NZ/VanY4P9Wcf/KvvR6zSE4ryb/hPtZ/58rf/AL6b/GkPj3WD/wAuUH/fT/40vqlTqH+rGP8A5V96PVi1MJ9a8r/4TzV/+fKD/vp/8aT/AITrV/8Anyg/76an9Uqdilwzjv5V96PUiaSvLv8AhOtX/wCfKD/vpqafHOrn/lyg/wC+n/xo+qVR/wCrWO/lX3o9RLUwtXmH/Cb6sf8Alzg/76b/ABpw8aaqf+XSD82/xpLCVCv9W8cvsr70elE+tYGuaisEJs4zmaYYwP4VPUn+lco/iXWbldkaxQZ7qCzfhuOB+VRW0TFzLIxd2OWZjkk/WtaeGad5nZgshnTmqmJa06LX7zYtVwAPStuEYArLt1rXiHFbyPSrsuL0qWoh0qWoOF7hRRRQIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACmt90/SnUjfdP0oA/qB/Z8/wCSQeC/+wBpn/pNHXuFeH/s+f8AJIPBf/YA0z/0mjr3Cvbjsj92w/8ACj6IKKKKZsFFFFABRRRQAUUUUAFFFFAH/9X9/KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAr4q/buXd+zN49X103/2tHX2rXxj+3Ku/9m3x0vrpw/8ARsdTP4Wc2MdsPUfk/wAj+YD7P7UfZ/at/wCze1H2b2rzeY/MfrCMD7P7UfZ/at/7N7UfZvajmD6wjA+z+1H2f2rf+ze1H2b2o5g+sIwPs/tR9n9q3/s3tR9m9qOYPrCMD7OfSpkt/atoWvrUq22KOYl4gzYoPatWCLFTJb+1Xooals5Kta4+FMVpIKhjTFW1FZNnn1JXH1JTB1p9I5wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkb7p+lLSN90/SgD+oH9nz/AJJB4L/7AGmf+k0de4V4f+z5/wAkg8F/9gDTP/SaOvcK9uOyP3bD/wAKPogooopmwUUUUAFFFFABRRRQAUUUUAf/1v38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvjf8AbdXd+zn43X107/2rHX2RXx3+2uM/s7+Nh/1D/wD2rHUz+FnJj3/stX/C/wAmfza/ZxR9nFanl0eXXj8x+Me1Zl/ZxR9nFanl0eXRzB7VmX9nFH2cVqeXR5dHMHtWZf2cUfZxWp5dHl0cwe1Zl/Z6cIK0vLpdlHMDqsorDVhY8VYCU7ApXM3UuMVakopQM0jJsVfWnUUUCCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKRvun6UtI33T9KAP6gf2fP8AkkHgv/sAaZ/6TR17hXh/7Pn/ACSDwX/2ANM/9Jo69wr247I/dsP/AAo+iCiiimbBRRRQAUUUUAFFFFABRRRQB//X/fyiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK+Pf21Rn9nnxqP+of8A+1Y6+wq+Pv21P+TevGn/AGD/AP2rHUz+FnJmH+61f8MvyZ/Odto206ivFPw4bto206igBu2jbTqKAG7aNtOooAbto206igBu2l2ilooATApaKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkb7p+lLSN90/SgD+oH9nz/kkHgv/ALAGmf8ApNHXuFeH/s+f8kg8F/8AYA0z/wBJo69wr247I/dsP/Cj6IKKKKZsFFFFABRRRQAUUUUAFFFFAH//0P38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvmL9qfw7d+K/gt4v0HT0MlzdaXceSg6tJGvmKB7krge9fTtcH4sg821dT3FJq6sZ1qaqU5U5bNNfefyljkUV92ftJ/st63oniC+8YfDuya9028kee506BczW0jHLtEg+/Ex52r8y9ACOnwvcQzWkrQXcbwSocMkqlGUjsQQCK8edNwdmfiuPy6vg6rpVl6Po/QjopvmJ/eH50eYn94fnUHCOopvmJ/eH50eYn94fnQA6im+Yn94fnR5if3h+dADqKb5if3h+dHmJ/eH50AOopvmJ/eH50eYn94fnQA6im+Yn94fnR5if3h+dADqKb5if3h+dHmJ/eH50AOopvmJ/eH50eYn94fnQA6im+Yn94fnR5if3h+dADqKb5if3h+dHmJ/eH50AOopvmJ/eH50eYn94fnQA6im+Yn94fnR5if3h+dADqKb5if3h+dHmJ/eH50AOopvmJ/eH50eYn94fnQA6im+Yn94fnR5if3h+dADqmt7W4vriKytIzLPcOsUUajJeSQhVUD1JIFPsbO81O4S0023lu55CFSKBGkdiewVQSa/R39lL9l7VLLxFZfEL4iWvkS2bCXTtNk5dJR92ecDgFeqJ1B5bBAFaU6bm7I9HLMsrY2qqdNadX0SP12+EejSeHPAegeH5jufTNNs7Nj6tBCkZ/Va9UrmPDsfl2qL6AV09ewj9pjFRSiugUUUUFBRRRQAUUUUAFFFFABRRRQB//0f38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACsPV7T7RCw68VuUx0DDBoA+a/EWgEyMSmRXmV54O0m6lMt3YwTP/ekiV2/MgmvsDUNFhugfl61yU/hBGYkLQJpPRnzB/wgvh//AKBtr/4Dx/8AxNH/AAgvh/8A6Btr/wCA8f8A8TX0t/why/3aP+EOX+6aLIXJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dNFkHJHsfNP/CC+H/+gba/+A8f/wATR/wgvh//AKBtr/4Dx/8AxNfS3/CHL/dNH/CHL/dosg5I9j560/wfplpLvs7OGBjwTFEqEj3KgV654Y0EqytswK7e28JRqwJWuwsdKitVAAoGkloi3p9v5MSr6Vo01V2inUDCiiigAooooAKKKKACiiigAooooA//0v38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAxmm7V9KdRQA3YvpRsX0p1FADdi+lGxfSnUUAN2L6UbF9KdRQA3YvpRsX0p1FADdi+lGxfSnUUAN2L6UbF9KdRQA3YvpRsX0p1FADdi+lGxfSnUUAN2L6UbF9KdRQA3YvpRsX0p1FADdi+lGxfSnUUAN2L6UbF9KdRQA3YvpRsX0p1FADdi+lGxfSnUUAN2L6UbF9KdRQAm1fSloooAKKKKACiiigAooooAKKKKACiiigAooooA//0/38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/1P38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/1f38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/1v38ooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/2Q=="
        },
    "minimumSupportedOperatingSystem":  {"v8_0":  true},
    "notes":  "",
    "owner":  "",
    "privacyInformationUrl":  "",
    "publisher":  "Microsoft Corporation"
}
"@
                Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
                $Results = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" `
                    -Method Post `
                    -Body $JSON `
                    -ErrorAction Stop
                Write-Log -LogString "App created succesfully..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
                Break
            }
            Catch {
                Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
                $ResultContainer.Status = "FAILED"
                $ResultContainer.Data = $_.Exception
                $RetryCreate++
                Sleep 2
            }
        }


        $CatCounter = 0
        While ($CatCounter -le 10) {
            Try {
                $CategoryBody = '{"@odata.id":"https://graph.microsoft.com/beta/deviceAppManagement/mobileAppCategories/ed899483-3019-425e-a470-28e901b9790e"}'
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/categories/`$ref" -Method Post -Body $CategoryBody -ErrorAction Stop
                $CatCounter = 10
                Write-Log -LogString "Category Set" -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Green
            }
            Catch {
                $CatCounter++
                Sleep 2
            }
        }

        While ($RetryAssign -le $RetryAssignMax) {
            # Assignment
            Try {
                $JSON2 = @"
{
    "mobileAppAssignments":  [{
        "@odata.type":  "#microsoft.graph.mobileAppAssignment",
        "target":  {
            "@odata.type":  "#microsoft.graph.allLicensedUsersAssignmentTarget"
        },
        "intent":  "Available",
        "settings":  null
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                $Results2 = Invoke-RestMethod -ContentType "application/json" `
                    -Headers $Headers `
                    -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($Results.id)/assign" `
                    -Method Post `
                    -Body $JSON2 `
                    -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
                $ResultContainer.Data = "NULL"
                Write-Log -LogString "App assigned succesfully..." -LogLevel Output -LogObject $O365_global_logobject -ForegroundColor Magenta
                Break
            }
            Catch {
                Write-Log -LogString "There was an error Assigning the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
                $ResultContainer.Status = "FAILED"
                $ResultContainer.Data = $_.Exception
                $RetryAssign++
                Sleep 2
            }
        }
    }
    End {
        Return $ResultContainer
    }
}