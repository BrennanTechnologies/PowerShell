<#
.SYNOPSIS
A command for creating the base Win10 Bitlocker Profile.

.DESCRIPTION
A command for creating the base Win10 Bitlocker Profile.

.PARAMETER Headers
The authorization headers needed to be able to execute the commands against Microsoft's graphAPI.

.PARAMETER TargetId
The ObjectID matching DynamicGroupAll (or another desired assignment target)

.EXAMPLE
New-O365Win10BitlockerProfile -Headers $Headers -TargetId $TargetId

.NOTES
General notes
#>
Function New-O365Win10BitlockerProfile {
    Param (
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [Hashtable]$Headers
        ,
        [Parameter(Mandatory = $False)]
        [ValidateNotNullOrEmpty()]
        [String]$TargetId
    )
    Begin {
        $ResultContainer = [PSCustomObject]@{
            'Status' = "NULL";
            'Data'   = "NULL";
        }
    }
    Process {
        Try {
            # Action(s)
            $JSON = @"
            {
                "id":  "00000000-0000-0000-0000-000000000000",
                "displayName":  "Windows 10 - Bitlocker (OPTIONAL)",
                "description":  "Windows 10 - Bitlocker (OPTIONAL)",
                "roleScopeTagIds":  [

                                    ],
                "@odata.type":  "#microsoft.graph.windows10EndpointProtectionConfiguration",
                "bitLockerRecoveryPasswordRotation":  "enabledForAzureAd",
                "bitLockerPrebootRecoveryMsgURLOption":  "default",
                "bitLockerEncryptDevice":  true,
                "bitLockerSyntheticSystemDrivePolicybitLockerDriveRecovery":  true,
                "applicationGuardAllowPrintToPDF":  false,
                "applicationGuardAllowPrintToXPS":  false,
                "applicationGuardAllowPrintToLocalPrinters":  false,
                "applicationGuardAllowPrintToNetworkPrinters":  false,
                "bitLockerFixedDrivePolicy":  {
                                                  "requireEncryptionForWriteAccess":  false,
                                                  "recoveryOptions":  null,
                                                  "encryptionMethod":  "xtsAes128"
                                              },
                "bitLockerRemovableDrivePolicy":  {
                                                      "requireEncryptionForWriteAccess":  false,
                                                      "encryptionMethod":  "aesCbc128"
                                                  },
                "bitLockerSystemDrivePolicy":  {
                                                   "startupAuthenticationRequired":  true,
                                                   "startupAuthenticationTpmUsage":  "allowed",
                                                   "startupAuthenticationTpmPinUsage":  "allowed",
                                                   "startupAuthenticationTpmKeyUsage":  "allowed",
                                                   "startupAuthenticationTpmPinAndKeyUsage":  "allowed",
                                                   "startupAuthenticationBlockWithoutTpmChip":  false,
                                                   "minimumPinLength":  6,
                                                   "recoveryOptions":  {
                                                                           "recoveryPasswordUsage":  "allowed",
                                                                           "recoveryKeyUsage":  "allowed",
                                                                           "enableRecoveryInformationSaveToStore":  true,
                                                                           "recoveryInformationToStore":  "passwordAndKey",
                                                                           "enableBitLockerAfterRecoveryInformationToStore":  true
                                                                       },
                                                   "prebootRecoveryEnableMessageAndUrl":  true,
                                                   "prebootRecoveryMessage":  null,
                                                   "prebootRecoveryUrl":  null,
                                                   "encryptionMethod":  "xtsAes128"
                                               },
                "firewallProfileDomain":  null,
                "firewallProfilePrivate":  null,
                "firewallProfilePublic":  null,
                "deviceGuardEnableVirtualizationBasedSecurity":  false,
                "deviceGuardEnableSecureBootWithDMA":  false,
                "userRightsAccessCredentialManagerAsTrustedCaller":  {
                                                                         "state":  "notConfigured"
                                                                     },
                "userRightsLocalLogOn":  {
                                             "state":  "notConfigured"
                                         },
                "userRightsAllowAccessFromNetwork":  {
                                                         "state":  "notConfigured"
                                                     },
                "userRightsActAsPartOfTheOperatingSystem":  {
                                                                "state":  "notConfigured"
                                                            },
                "userRightsBlockAccessFromNetwork":  {
                                                         "state":  "notConfigured"
                                                     },
                "userRightsDenyLocalLogOn":  {
                                                 "state":  "notConfigured"
                                             },
                "userRightsBackupData":  {
                                             "state":  "notConfigured"
                                         },
                "userRightsChangeSystemTime":  {
                                                   "state":  "notConfigured"
                                               },
                "userRightsCreateGlobalObjects":  {
                                                      "state":  "notConfigured"
                                                  },
                "userRightsCreatePageFile":  {
                                                 "state":  "notConfigured"
                                             },
                "userRightsCreatePermanentSharedObjects":  {
                                                               "state":  "notConfigured"
                                                           },
                "userRightsCreateSymbolicLinks":  {
                                                      "state":  "notConfigured"
                                                  },
                "userRightsCreateToken":  {
                                              "state":  "notConfigured"
                                          },
                "userRightsDebugPrograms":  {
                                                "state":  "notConfigured"
                                            },
                "userRightsRemoteDesktopServicesLogOn":  {
                                                             "state":  "notConfigured"
                                                         },
                "userRightsDelegation":  {
                                             "state":  "notConfigured"
                                         },
                "userRightsGenerateSecurityAudits":  {
                                                         "state":  "notConfigured"
                                                     },
                "userRightsImpersonateClient":  {
                                                    "state":  "notConfigured"
                                                },
                "userRightsIncreaseSchedulingPriority":  {
                                                             "state":  "notConfigured"
                                                         },
                "userRightsLoadUnloadDrivers":  {
                                                    "state":  "notConfigured"
                                                },
                "userRightsLockMemory":  {
                                             "state":  "notConfigured"
                                         },
                "userRightsManageAuditingAndSecurityLogs":  {
                                                                "state":  "notConfigured"
                                                            },
                "userRightsManageVolumes":  {
                                                "state":  "notConfigured"
                                            },
                "userRightsModifyFirmwareEnvironment":  {
                                                            "state":  "notConfigured"
                                                        },
                "userRightsModifyObjectLabels":  {
                                                     "state":  "notConfigured"
                                                 },
                "userRightsProfileSingleProcess":  {
                                                       "state":  "notConfigured"
                                                   },
                "userRightsRemoteShutdown":  {
                                                 "state":  "notConfigured"
                                             },
                "userRightsRestoreData":  {
                                              "state":  "notConfigured"
                                          },
                "userRightsTakeOwnership":  {
                                                "state":  "notConfigured"
                                            }
            }
"@
            Write-Log -LogString $JSON -LogLevel Verbose -LogObject $O365_global_logobject
            $Results = Invoke-RestMethod -ContentType "application/json" `
                -Headers $Headers `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations" `
                -Method Post `
                -Body $JSON `
                -ErrorAction Stop
            # Assignment
            If (   $False -eq [String]::IsNullOrEmpty($TargetId)   ) {
                $JSON2 = @"
{
    "assignments":[{
        "target":  {
            "groupId":"$($TargetId)",
            "@odata.type":"#microsoft.graph.groupAssignmentTarget"
        }
    }]
}
"@
                Write-Log -LogString $JSON2 -LogLevel Verbose -LogObject $O365_global_logobject
                Invoke-RestMethod -ContentType "application/json" -Headers $Headers -Uri "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Results.id)/assign" -Method Post -Body $JSON2 -ErrorAction Stop
                $ResultContainer.Status = "SUCCESS"
            }
            $ResultContainer.Status = "SUCCESS"
        }
        Catch {
            Write-Log -LogString "There was an error creating the policy.`nException: {$($_.Exception)}" -LogLevel Error -LogObject $O365_global_logobject
            $ResultContainer.Status = "FAILED"
            $ResultContainer.Data = $_.Exception
        }
    }
    End {
        Return $ResultContainer
    }
}