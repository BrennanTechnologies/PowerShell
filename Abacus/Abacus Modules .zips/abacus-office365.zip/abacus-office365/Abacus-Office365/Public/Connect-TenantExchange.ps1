<#
.SYNOPSIS
A function used to connect to a Tenant's Exchange environment.

.DESCRIPTION
In the scenario where an administrator may need to execute commands directly within a Tenant's Exchange environment, this command will establish a PSSession to their environment which can then be imported to the local console.

.PARAMETER TenantId
The Microsoft provided unique identifier of the Client Tenant being referenced.

.PARAMETER CompanyName
A company name matching what is listed in the tenant list in which a connection to that tenant's exchange environment wil be made.

.PARAMETER Office365Instance
A value specifying the Region in which a client lives. These values are respective to where Abacus has it's Partner Accounts.

.EXAMPLE
Connect-TenantExchange -CompanyName 'Eze Vonage (DEV)'

.EXAMPLE
Connect-TenantExchange -TenantId <TenantId>

.NOTES
Only one Tenant Exchange PSSession can be established at any given time.
Before connecting to another Tenant's Exchange, disconnect from the environment by using the Disconnect-TenantExchange function.
You can connect to an exchange environment by using either the company name or tenantId.
#>

Function Connect-TenantExchange {
    [CmdletBinding(DefaultParameterSetName = 'ByTenantId')]
    Param (
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByTenantId')]
        [String]$TenantId = $Null
        ,
        [ValidateNotNull()]
        [Parameter(Mandatory = $True, ParameterSetName = 'ByCompanyName')]
        [String]$CompanyName = $Null
        ,
        [ValidateNotNullorEmpty()]
        [ValidateSet("US", "UK")]
        [Parameter(Mandatory=$True)]
        [String]$Office365Instance
    )
    Begin {
        Try {
            Switch ($PSCmdlet.ParameterSetName) {
                'ByTenantId' {
                    $TenantInfo = Get-O365TenantInfo -TenantId $TenantId -Office365Instance $Office365Instance
                    $CompanyName = $TenantInfo.CompanyName
                }
                'ByCompanyName' {
                    $TenantInfo = Get-O365TenantInfo -CompanyName $CompanyName -Office365Instance $Office365Instance
                    $CompanyName = $TenantInfo.CompanyName
                }
                Default {
                    Write-Log -Logstring "No valid identifier supplied. Unhandled Exception" -LogLevel TerminatingError  -LogObject $O365_global_logobject
                }
            }
        }
        Catch {
            Write-Log -Logstring "Failed to get tenant information based on the supplied query method." -LogLevel TerminatingError  -LogObject $O365_global_logobject
        }

        $ConnectionStatus = $(Get-PSSession -Name "Office365Exchange" -ErrorAction SilentlyContinue)
        If ($Null -ne $ConnectionStatus) {
            Write-Log -LogString "There is already an active Office365 session open. Please disconnect this session with the Disconnect-TenantExchange command before opening a new one." -LogLevel Warning -LogObject $O365_global_logobject
        }
        Else {
            Write-Log -LogString "Now getting Office365 Creds for $CompanyName" -LogLevel Verbose -LogObject $O365_global_logobject
            $Credentials = Get-O365Credentials -SecretName $CompanyName -SecretType O365Login
        }
    }

    Process {
        Write-Log -LogString "Now connecting to $CompanyName`'s Office365 Exchange using $($Credentials.UserName)" -LogLevel Output -LogObject $O365_global_logobject
        $TenantExchangeSession = New-PSSession -ConfigurationName Microsoft.Exchange `
            -Name "Office365Exchange" `
            -ConnectionUri https://outlook.office365.com/powershell-liveid/ `
            -Credential $Credentials `
            -Authentication  Basic `
            -AllowRedirection

        Import-PSSession $(Get-PSSession -Name "Office365Exchange") -AllowClobber -ErrorAction SilentlyContinue | Out-Null
    }
}