﻿
#Get public and private function definition files.
$Public  = @( Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue )
if(Test-Path "$PSScriptRoot\Private\"){
	$Private = @( Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue )
}else{
	$Private = @()
}

#Dot source the files
Foreach($import in @($Public + $Private))
{
    Try
    {
        #Write-Host "$import"
        . $import.fullname | Out-Null
    }
    Catch
    {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Export-ModuleMember -Function $Public.Basename

try {
    $script_name = "Abacus-Onboarding"
    $logname = "Operations.log"
    $audit_logroot = "\\service02.corp\DFS\SHARES\PSAuditLogs\"
    $log_logroot = "C:\ProgramData\PSlogs"

    $audit_logpath = Join-Path $(Join-Path $audit_logRoot $script_name) $logname
    $log_logpath = Join-Path $(Join-Path $log_logroot $script_name) $logname

    Write-Host $audit_logpath
    Write-Host $log_logpath

    $Onboarding_global_logobject = Start-Log -LogPath $log_logpath -ScriptName $script_name -Audit True -AuditLogPath $audit_logpath -Global False -IgnoreLogging
}catch{
    throw "Failed to initiate log $($Onboarding_global_logobject | Out-String) `n($_.exception)"
}