﻿#collect users via UM mailbox
Function Get-ABAUMUsers {

    Param(
        [String]$ClientCode
        ,
        [PSCredential]$Credential
    )
    

    $Session = New-PSSession -ConfigurationName Microsoft.Exchange `
                             -ConnectionUri http://nysrv2-mbxny01.service02.corp/PowerShell/ `
                             -Authentication Kerberos `
                             -Credential $Credential

    Import-PSSession $Session -DisableNameChecking -AllowClobber



    $ad_ou = Get-ADOrganizationalUnit -Server "service02.corp" `
                                      -SearchBase "ou=Reseller - Abacus Group(ZZZ),ou=Customers,dc=service02,dc=corp" `
                                      -Filter * | ? DistinguishedName -like "*($ClientCode)*" | ? name -eq "User Structure"
    
    if($null -eq $ad_ou){
        throw "Failed to query for OU"
    }

    $um = Get-UMMailbox -OrganizationalUnit $ad_ou.DistinguishedName `
                        -ResultSize Unlimited | ? {$_.UMEnabled -eq $True}

    return $um.name
}