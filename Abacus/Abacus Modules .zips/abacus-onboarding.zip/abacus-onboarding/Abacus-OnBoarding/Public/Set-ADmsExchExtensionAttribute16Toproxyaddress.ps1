﻿Function Set-ADmsExchExtensionAttribute16Toproxyaddress {
<#
    .SYNOPSIS
    Sets all active directory user objects per client Extension attribute 16 to proxy adderss value

    .DESCRIPTION
    Sets all active directory user objects per client Extension attribute 16 to proxy adderss value

    .PARAMETER Client_Code 
    Specify target client Client code

    .PARAMETER TargetDC
    Specify a target DC default: nysrv2-dc02.service02.corp

    .PARAMETER whatif
    simulates a what if condition

    .EXAMPLE 
    Set-ADmsExchExtensionAttribute16Toproxyaddress -Client_Code "TST" -whatif 

    .NOTES
    requires access to service02 domain
#>

    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Code
        ,
        [String]$TargetDC = "nysrv2-dc02.service02.corp"
        ,
        [switch]$whatif
    )

    try{
        $OU =  Get-ADOrganizationalUnit -Server $TargetDC -Filter * | ? DistinguishedName -Like "*($Client_Code)*" | ? name -EQ "User Structure"
    }catch{
    
        throw "Failed to Query for OU`n$($_.exception)"
    }

    if(!$OU){
        throw "unable to find OU"
    }

    $AllUsers = Get-ADUser -Server $TargetDC -SearchBase $OU.DistinguishedName -Filter * -Properties proxyaddresses | Sort name 
    
    foreach ($user in $AllUsers){
        
        $proxyaddressarray = @()
        $proxyaddressarray = $user.proxyaddresses

        [Array]$newproxyaddressarray=@()
        ForEach ($paddress in $proxyaddressarray) {
            if(   ( $true -eq ($paddress -notlike "*service02.corp*") ) -or ( $true -eq($paddress -match "^EUM.*") )   ) {
                $newproxyaddressarray+=$paddress
            }
        }

        $proxyaddress = ($user.proxyaddresses -match "mail.onmicrosoft.com$")
        
        If($proxyaddress) {
            $proxyaddress = $proxyaddress.replace("smtp:","")
            If ($whatif) {
                Write-Host -ForegroundColor Green "attempting to set $($user.name) msExchExtensionAttribute16 to $proxyaddress"
                Set-ADUser $user -add @{msExchExtensionAttribute16 =$proxyaddress} -Server $TargetDC -WhatIf 

                Write-Host -ForegroundColor Cyan "attempting to set $($user.name) ProxyAddresses to:"
                Write-Host -ForegroundColor Cyan "$($newproxyaddressarray | ConvertTo-Json -Depth 5)"
                Set-ADUser $user -replace @{proxyaddresses = $newproxyaddressarray} -Server $TargetDC -WhatIf 
            } 
            Else {
                    Write-Host -ForegroundColor Green "attempting to set $($user.name) msExchExtensionAttribute16 to $proxyaddress"
                    Set-ADUser $user -add @{msExchExtensionAttribute16 =$proxyaddress} -Server $TargetDC

                    Write-Host -ForegroundColor Cyan "attempting to set $($user.name) ProxyAddresses to:"
                    Write-Host -ForegroundColor Cyan "$($newproxyaddressarray | ConvertTo-Json -Depth 5)"
                    Set-ADUser $user -replace @{proxyaddresses = $newproxyaddressarray} -Server $TargetDC
            }
        }
        Else{
            Write-Warning "Proxyaddress not found for $($user.name)"
        }   
    }

    Write-Host "Set-ADmsExchExtensionAttribute16Toproxyaddress: END"
}

