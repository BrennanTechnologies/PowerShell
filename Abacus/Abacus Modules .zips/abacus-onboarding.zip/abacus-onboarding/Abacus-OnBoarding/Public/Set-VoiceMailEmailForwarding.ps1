﻿Function Set-VoiceMailEmailForwarding{
    <#
    .SYNOPSIS
    Sets Voicemail forwarding to a contact object in Panel user.

    .DESCRIPTION
    Sets Voicemail forwarding to a contact object in Panel user.

    .PARAMETER VM_Client_Fullname
    Specify your target voicemail client fullname 

    .PARAMETER VM_Users
    Specify your target voicemail users

    .EXAMPLE
    Set-VoiceMailEmailForwarding -VM_Users @{"user1","user2"} -VM_Client_fullname "Voicemail - ezevonage" 

    .NOTES

    #>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $VM_Users
        ,
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $VM_Client_FullName
        
    )

    Begin{
   
        $vm_customer = Get-CPSMCustomer -Client_FullName $VM_Client_FullName -ErrorAction SilentlyContinue

        if($null -eq $vm_customer){
            Write-Log -LogLevel TerminatingError -logstring "$VM_Client_FullName not found"
        }

        Write-Host "Target Customer - $VM_Client_Fullname"
    }
    Process{
        foreach($user in $VM_Users){
 
            $cpsm_user = Get-CPSMUser -Client_FullName $VM_Client_Fullname -Name $User
            if($null -ne $cpsm_user){
                Write-host "Setting Email Forwarding for $($cpsm_user.name) with contact $($cpsm_user.fullname)"
                try{
                    Set-CPSMUserHEEmailForwarding -Client_FullName $VM_Client_Fullname -Name $cpsm_user.Name -Contact_DisplayName $cpsm_user.fullname -ErrorAction Continue
                }catch{
                    Write-Warning "Failed to create forwarding rule"
                }
            }else{
                Write-Warning "unable to find cpsm voicemail object"
            }
        }
    }
}