Function New-vCommanderCustomer {
    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Fullname
        ,
        [Parameter(Mandatory=$true)]
        [Site]$Site
        ,
        [ValidateSet("Proactive MSP","Eze Castle Software","Eze White Label","Trader Tools")]
        [String]$HostingProvider
        ,
        [Parameter(Mandatory=$true)]
        [String]$VLANID
        ,
        [Parameter(Mandatory=$true)]
        [String]$ClientCode
    )

    Begin {
        #Connect to vcmd
        Connect-vCmdServer
        [string]$manager = "vcommanderenterpriseadmins@management.corp"
        [string]$usergroup = "vcommandersupportadmins@management.corp"

    }

    Process{
        write-log -logstring "Checking for existing org:$Client_fullName"
        try{
            $existing_org = Get-OrganizationByName -name $Client_fullName
        }catch{
            $existing_org = $null
        }

        if(!$existing_org){
            Write-Log "No existing org found"

            #Creating organization users
            try{
                Write-Log -logstring "Generating members"
                $Members = @()
                Write-Log -logstring "Assigning manager role to : $manager"
                $user1DTO = New-vCmdOrganizationUser -userId $manager -manager -portalRole "Manager"
                $Members += $user1DTO

                foreach ($user in $usergroup){
                    if($usergroup -ne "") {
                        Write-Log -logstring "assigning Delegated Admin role to : $usergroup"
                        $user2DTO = New-vCmdOrganizationUser -userId $usergroup -portalRole "Delegated Admin"
                        $Members += $user2DTO
                    }
                }
            }catch{
                throw "generating oraganization users failed`n$($_.exception)"
            }

            #Create an organization
            try{
                Write-Log -logstring "Creating organization object"

                $org = New-vCmdOrg -name $Client_fullName -OrganizationMembers $Members

            }catch{
                throw "Failed to create org`n$($_.exception)"
            }

            if($org){
                Write-Log "Organization $($org.Organization.name) sucessfully created"
            }else{
                Write-Log -LogLevel TerminatingError -LogString "no org created"
            }
        }else{
            Write-Log -LogLevel Warning "Organization already exists: $existing_org"
        }
    }
}