﻿Function Get-HumanUsers{
    Param(
        $ClientCode
    )

    $ad_ou = Get-ADOrganizationalUnit -Server "service02.corp" `
                                      -SearchBase "ou=Reseller - Abacus Group(ZZZ),ou=Customers,dc=service02,dc=corp" `
                                      -Filter * | ? DistinguishedName -like "*($ClientCode)*" | ? name -eq "User Structure"
    
    $users = Get-ADUser -Filter * -SearchBase $ou.DistinguishedName -Properties Mail | ? mail -ne $null


    #filters
    $users = $users | ? Name -notLike "conf-$ClientCode-*"
    $users = $users | ? Name -ne "agadmin_$ClientCode"
    $users = $users | ? Name -ne "agtestuser_$ClientCode"

    return $users.name

}
