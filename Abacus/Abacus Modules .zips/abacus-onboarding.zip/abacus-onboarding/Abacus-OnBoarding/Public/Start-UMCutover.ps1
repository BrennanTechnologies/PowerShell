Function Start-UMCutover {
<#
.SYNOPSIS
Cuts over unified messaging plans from source customer to voice mail customer

.DESCRIPTION
Removes UM from userplan on source customer - adds UM on voicemail plan in voicemail customer. Adds voicemail extension to VM customer side

.PARAMETER Source_Client_Fullname
Specify your source panel customer fullname

.PARAMETER VM_Client_Fullname
Specify your target voicemail client fullname 

.PARAMETER VM_Users
Specify your target voicemail users

.PARAMETER UMData
Allows you to take the what if report and cutover using that meta data

.PARAMETER whatif
Creates a report of migration values

.EXAMPLE
$cutover_users = Start-UMCutover -Source_Client_Fullname "Abacus group llc" -VM_Client_Fullname "Voicemail - Abacus Group LLC" -VM_Users bchen_abavm -whatif
or
$target = Start-UMCutover -Source_Client_Fullname $Source_Customer -VM_Client_Fullname $Voicemail_Customer -VM_Users "user_ABAVM" -whatif 

Start-UMCutover -UMData $target

.NOTES

#>   
    Param(
        [Parameter(Mandatory=$true,ParameterSetName='ByUsers')]
        $Source_Client_Fullname
        ,
        [Parameter(Mandatory=$true,ParameterSetName='ByUsers')]
        $VM_Client_Fullname
        ,
        [Parameter(Mandatory=$True,ParameterSetName='ByUsers')]
        $VM_Users
        ,
        [Parameter(Mandatory=$True,ParameterSetName='ByUMData')]
        $UMData
        ,
        [switch]$whatif
    )

    Begin{
        if($PSCmdlet.ParameterSetName -eq "ByUsers"){
            $src_customer = Get-CPSMCustomer -Client_FullName $Source_Client_Fullname
            $VM_customer = Get-CPSMCustomer -Client_FullName $VM_Client_Fullname

            if($null -eq $src_customer){
                Write-Log -LogLevel TerminatingError -LogString "unable to find source customer"
            }

            if($null -eq $VM_customer){
                Write-Log -LogLevel TerminatingError -LogString "unable to find voicemail customer"
            }

            $results = @()
        }
    }

    Process{
        Foreach($user in $VM_Users){
            #Write-Log -LogString "Gathering information for $user"
            try{
                $vm_user = Get-CPSMUser -Client_FullName $VM_Client_Fullname -Name $user -ErrorAction SilentlyContinue
            }Catch{
                
            }

            if($null -eq $vm_user){
                Write-Log -LogLevel Warning -LogString "Voicemail user not found $user"
               
            }else{

                try{
                    $username = $vm_user.name.split("_")[0]
                    $constructed_src_user = $username+"_"+$($src_customer.name)
                    $src_user = $src_customer | Get-CPSMUser -Name $constructed_src_user -ErrorAction SilentlyContinue
                }catch{
                    Write-Log -LogLevel Warning -LogString "Unable to find to query user $constructed_src_user"
                }

                if($null -ne $src_user){
                    $VM_userplan = Get-CPSMUserHEUserPlan -Client_FullName $VM_customer.fullname -Name $VM_user.name -ErrorAction SilentlyContinue
                    if($null -eq $VM_userplan){
                        Write-Log -LogLevel Warning -LogString "$($VM_user.name) hosted exchange user plan not found"
                
                    }else{
                        $VM_userplan_features = Convert-CPSMUserPlan -User_Plan $VM_userplan
                        if($VM_userplan_features.UM -eq $true){
                            Write-Log -LogLevel Warning -LogString "$($VM_user.name) already has UM provisioned"
                        }else{
                            try{
                                $extension = Get-CPSMUserHEExtension -Client_FullName $src_customer.fullname -Name $src_user.name
                                $src_userplan = Get-CPSMUserHEUserPlan -Client_FullName $src_customer.fullname -Name $src_user.name
                                $src_userplan_features = Convert-CPSMUserPlan -User_Plan $src_userplan
                                $new_src_userplan = Get-CPSMUserPlan -Client_FullName $src_customer.fullname -Archiving:$($src_userplan_features.Archive) -Site $($src_userplan_features.Site)
                                $new_vm_userPlan = Get-CPSMUserPlan -Client_FullName $VM_customer.fullname -Site $($src_userplan_features.Site) -Unified_Messaging

                                $object = [PSCustomObject]@{
                                    SourceCustomer = $src_customer.fullname
                                    FullName = $src_user.fullname
                                    SourceName = $src_user.name
                                    CurrentUserPlan = $src_userplan
                                    NewUserPlan = $new_src_userplan.fullname
                                    Extension = $extension
                                    VoicemailCustomer = $VM_customer.fullname
                                    VoicemailName = $vm_user.name
                                    VoicemailPlan = $new_vm_userPlan.FullName
                                }

                                $results +=$object
                            }Catch{
                                Write-Log -LogLevel Warning -LogString "failed to query src information for $user"
                            }
                            
                        }
                    }
                }else {
                    Write-Log -LogLevel Warning -LogString "Unable to find source user for $user"
                }
            }
            Remove-Variable object,extension,src_user,src_userplan,vm_user,username,src_userplan_features,new_src_userplan -ErrorAction SilentlyContinue
        }
    }

    End{
        if($whatif -eq $true){
            return $results

        }else{
            Write-Log -LogString "Starting Cutover"

            if($PSCmdlet.ParameterSetName -eq "ByUMData"){
                $results = $UMData
            }

            foreach($target in $results){
                Write-Log -LogString "----------------------------------------"
                Write-Log -ForegroundColor Cyan -LogString "Target user: $($target.FullName)"
                
                #set src user 
                #Set-CPSMUserHEExtension -Client_FullName $src_customer.fullname -ClientCode $ClientCode -Name $HE_User.name -UM_Mailbox_Extension 1
                $src_ex_check = Get-CPSMUserHEUserPlan -Client_FullName $target.SourceCustomer -Name $target.SourceName 

                if($src_ex_check -ne $($target.NewUserPlan)){
                    Write-Log -LogString "Setting $($target.SourceName)   Userplan to $($target.NewUserPlan)" -ForegroundColor Cyan
                    Set-CPSMUserHEUserPlan -Client_FullName $target.SourceCustomer -Name $target.SourceName -HE_User_Plan_Name $target.NewUserPlan
                }else{
                    Write-Log -LogLevel Warning -LogString "$($target.SourceName) is already set to user plan: $($target.NewUserPlan)"
                }
                
                Write-Log -LogString "Setting $($target.VoicemailName) userplan to $($target.VoicemailPlan)`nSetting extension $($target.Extension)" -ForegroundColor Cyan
                
                
                #set VM_user
                #$VM_ex_check = Get-CPSMUserHEUserPlan -Client_FullName $target.VoicemailCustomer -Name $target.VoicemailName
                #Set-CPSMUserHEExtension -Client_FullName $target.VoicemailCustomer -Name $target.VoicemailName -UM_Mailbox_Extension $target.Extension
                #if($VM_ex_check -ne $($target.VoicemailPlan)){
                Set-CPSMUserHEUserPlan -Client_FullName $target.VoicemailCustomer -Name $target.VoicemailName -HE_User_Plan_Name $target.VoicemailPlan -UM_Mailbox_Extension $target.Extension
                #}else{
                #Write-Log -LogLevel Warning -LogString "$($target.SourceName) is already set to user plan: $($target.VoicemailPlan)"
                #}

                Write-Log -LogString "----------------------------------------"
            } 
        }
    }
}