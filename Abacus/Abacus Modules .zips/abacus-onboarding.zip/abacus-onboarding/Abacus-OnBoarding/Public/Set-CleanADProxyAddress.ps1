﻿Function Set-CleanADProxyAddress {
<#
    .SYNOPSIS
    Ensures that the target AD user's Proxy address property does not contain *service02.corp unless containing EUM

    .DESCRIPTION
    Ensures that the target AD user's Proxy address property does not contain *service02.corp unless containing EUM

    .PARAMETER Client_Code 
    Specify target client Client code

    .PARAMETER TargetDC
    Specify a target DC default: nysrv2-dc02.service02.corp

    .PARAMETER whatif
    simulates a what if condition

    .EXAMPLE 
    Set-CleanADProxyAddress -Client_Code "TST" -user user1 -whatif

    .NOTES
    requires access to service02 domain
#>
   
 
    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Code
        ,
        [Parameter(Mandatory=$true)]
        [String]$User
        ,
        [String]$TargetDC = "nysrv2-dc02.service02.corp"
        ,
        [switch]$whatif
    )
    Begin{
         try{
            $OU = Get-ADOrganizationalUnit -Server $TargetDC -Filter * | ? DistinguishedName -Like "*($Client_Code)*" | ? name -EQ "User Structure"
        }catch{
            throw "Failed to Query for OU`n$($_.exception)"
        }

        if(!$OU){
            throw "unable to find OU"
        }
    }
   
    Process{

        $user_obj = Get-ADUser -Server $TargetDC -SearchBase $OU.DistinguishedName -Filter * -Properties proxyaddresses | ? Name -eq $User
        
        $proxyaddressarray = @()
        $proxyaddressarray = $user_obj.proxyaddresses

        [Array]$newproxyaddressarray=@()
        ForEach ($paddress in $proxyaddressarray) {
            if(   ( $true -eq ($paddress -notlike "*service02.corp*") ) -or ( $true -eq ($paddress -match "^EUM.*") )   ) {
                $newproxyaddressarray+=$paddress
            }
        }


        If($user_obj) {
            if($null -ne $newproxyaddressarray){
                If ($whatif) {
                    Write-Host -ForegroundColor Cyan "attempting to set $($user.name) ProxyAddresses to:"
                    Write-Host -ForegroundColor Cyan "$($newproxyaddressarray | ConvertTo-Json -Depth 5)"
                    Set-ADUser $user_obj -replace @{proxyaddresses = $newproxyaddressarray} -Server $TargetDC -WhatIf 
                } 
                Else {
                    Write-Host -ForegroundColor Cyan "attempting to set $($user.name) ProxyAddresses to:"
                    Write-Host -ForegroundColor Cyan "$($newproxyaddressarray | ConvertTo-Json -Depth 5)"
                    Set-ADUser $user_obj -replace @{proxyaddresses = $newproxyaddressarray} -Server $TargetDC
                }
            
            }else{
            
                Write-Warning "No valid proxy addresses found"
            }
            
        }
        Else{
            Write-Warning "User not found for $($user.name)"
        }   
    }

    END{
        #Write-Host "Set-ADProxyAddresses: FIN"
    }
}