﻿Function Get-LegacyExchangeDN{

<#
    .SYNOPSIS
    Grab the Distribution group for the specified client based on the ClientCode provided.

    .DESCRIPTION
    Grab the Distribution group for the specified client based on the ClientCode provided.

    .PARAMETER Client_Code 
    Specify target client Client code

    .PARAMETER TargetDC
    Specify a target DC default: nysrv2-dc02.service02.corp

    .PARAMETER whatif
    simulates a what if condition

    .EXAMPLE 
    Get-LegacyExchangeDN -Client_Code "TST"

    .NOTES
    requires access to service02 domain
#>
   
    Param(
        [Parameter(Mandatory=$true)]
        [String]$clientCode
        ,
        [Parameter(Mandatory=$true)]
        [String]$targetdc = "nysrv2-dc02.service02.corp"
    
    )
    try{
        $DistributionGroupOU = Get-ADOrganizationalUnit -Server $TargetDC -Filter {Name -eq 'Distribution Groups' } | ?{ $_.DistinguishedName -Like "*($Client_Code)*" }
    }catch{
        throw "Failed to Query for OU`n$($_.exception)"
    }
    
    If ($Null -eq $DistributionGroupOU)  {
        Throw "The DistributionGroupOU could not be verified."
    }

    # Grab the Distribution Groups for the client based on the OU specified above.
    $DistributionGroups = Get-ADGroup -Searchbase $DistributionGroupOU -Properties DisplayName,msExchRecipientDisplayType,GroupType,legacyExchangeDN -Filter * | ?{$Null -ne $_.msExchRecipientDisplayType}

    If ($Null -eq $DistributionGroups)  {
        # If no groups where found, throw and error and stop.
        Throw "No Distribution Groups where found for $($Client_Code)"
    }

    return $DistributionGroups 

}
       