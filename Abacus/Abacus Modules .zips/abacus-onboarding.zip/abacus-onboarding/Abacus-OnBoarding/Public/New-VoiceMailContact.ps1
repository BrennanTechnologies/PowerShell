﻿Function New-VoiceMailContact {
<#
    .SYNOPSIS
    Creates a new voicemail Contact 

    .DESCRIPTION
    Uses the source customer to create a contact in the voicemail customer

    .PARAMETER apiUrl 
    The url path where the requests are targeting - Default: https://panel.accessabacus.com/cortexapi/default.

    .PARAMETER QA
    If switch is specified it changes the APIURL to "https://cpsm.accessabacus.com/cortexapi/default.aspx"

    .PARAMETER Source_Usernames
    Array of usernames to be modeled after to create contact

    .PARAMETER Source_Client_FullName
    Choose Source Client Fullname 

    .PARAMETER VM_Client_FullName
    Target Voicemail customer - default to $VM_Client_FullName = "VOICEMAIL - $($src_customer.fullname)"

    .PARAMETER Credential
    Credentials used to authenticate against panel. If left blank then it will use your runtimeCredentials

    .EXAMPLE 
    New-VoiceMailContact -Source_Client_FullName test_client -Source_Usernames @{"user1","user2"} -VM_Client_fullname "Voicemail - test_client" -credential $credential 

    .NOTES
    you need Credentials to access panel to run this command.

#>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [String[]]$Source_Usernames
        ,
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [String]$Source_Client_FullName
        ,
        [String]$VM_Client_FullName
        ,
        [PSCredential]$Credential
    )

    Begin{

        $src_customer = Get-CPSMCustomer -Client_FullName $Source_Client_FullName `
                                         -Credential $credential `
                                         -ErrorAction SilentlyContinue
        
        if($null -eq $src_customer){
            throw "$Source_Client_FullName not found"
        }

        if([String]::IsNullOrEmpty($VM_Client_FullName)){
            $VM_Client_FullName = "VOICEMAIL - $($src_customer.fullname)"
        }

        $vm_customer = Get-CPSMCustomer -Client_FullName $VM_Client_FullName `
                                        -Credential $credential `
                                        -ErrorAction SilentlyContinue

        if($null -eq $vm_customer){
            throw "$VM_Client_FullName not found"
        }
    }

    Process{
        
        foreach($source_username in $Source_Usernames){
            try{
                $expanded_Source_user = Get-CPSMUser -Credential $credential `
                                                     -Client_FullName $($src_customer.fullname) `
                                                     -Name $($source_username)
               
            }catch{
                 Write-Warning "failed to query for source user $source_username"
            
            }
            

            if($Null -eq $expanded_Source_user){

                Write-Warning "User:$($Source_User.name) not found"

            }elseif($expanded_Source_user.status -ne "Provisioned"){

                Write-Warning "$($expanded_Source_user.fullname) is not a provisioned user"
        
            }else{
                
                $Contact_firstname    = $expanded_Source_user.Firstname
                $Contact_Lastname     = $expanded_Source_user.lastname
                $Contact_Displayname = $expanded_Source_user.fullname
                $Contact_PrimaryEmail = $expanded_Source_user.addresses.address | ? primary -eq "True" | select -ExpandProperty '#text'
                
                try {
                    New-CPSMContact -Client_FullName $($vm_customer.fullname) `
                                    -First_name $Contact_firstname `
                                    -Last_name $Contact_Lastname `
                                    -Displayname $Contact_Displayname `
                                    -Email $Contact_PrimaryEmail `
                                    -Credential $credential `
                                    -HideFromAddressLists
                }catch{
                    Write-Warning "failed to create contact $Source_Username"
                }
                
            }
   

        }
    }

    End{
    
    }
   

}
