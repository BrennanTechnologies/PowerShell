﻿Function New-VoicemailCustomer {
<#
    .SYNOPSIS
    Creates a Voicemail customer and agadmin account in customer

    .DESCRIPTION
    Creates a Voicemail customer and agadmin account in customer

    .PARAMETER Source_Client_FullName
    Choose Source Client Fullname

    .PARAMETER SourceType
    Choose Source Client Fullname

    .PARAMETER PrimaryDomain
    Specify Client primary domain. by default "<clientcodeVM>.accessabacus.com"

    .PARAMETER Parent_client
    Specify Parent client in OU structure. by default = "Reseller - Abacus Group"

    .PARAMETER ContactName
    Specify Contact name. by default = "agadmin"

    .PARAMETER ContactEmail
    specify contact email. by default "contactname@primaryDomain"

    .PARAMETER Credential
    Credentials used to authenticate against panel. If left blank then it will use your runtimeCredentials

    .PARAMETER whatif
    Will not run the command and display the generated commands.

    .EXAMPLE
    New-VoicemailCustomer -Source_Client_Fullname "ezevonage" -SourceType Portal

    .NOTES
    you need Credentials to access panel to run this command. This needs to be run from a machine with portal certs
#>

    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $Source_Client_FullName
        ,
        [Parameter(Mandatory=$true)]
        [ValidateSet("Panel","Portal")]
        $SourceType
        ,
        [String]$PrimaryDomain
        ,
        [string]$Parent_client = "Reseller - Abacus Group"
        ,
        [String]$ContactName = "agadmin"
        ,
        [String]$ContactEmail
        ,
        [PSCredential]$Credential
        ,
        [Switch]$whatif
    )

    Begin{

        if($null -eq $Credential){
            if($null -eq $Global:CPSM_Credential){
                Set-CPSMCredential
            }
            $Credential = $Global:CPSM_Credential
        }


        Switch ($SourceType){
            "Panel" {
                $customer = Get-CPSMCustomer -Client_FullName $Source_Client_FullName -Credential $credential -ErrorAction SilentlyContinue

                if($null -eq $customer){
                    Write-log -LogLevel TerminatingError -LogString "$Source_Client_FullName not found"
                }

                $vm_client_fullname = "VOICEMAIL - $($customer.fullname)"
                $vm_name = "$($customer.name)VM"

            }
            "Portal" {

                $Customer = Get-PortalTenant -name $Source_Client_FullName

                if($customer -eq $null){
                    Write-log -LogLevel TerminatingError -LogString "$Source_Client_FullName not found"
                }
                $pattern = '[^a-zA-Z\s]'
                $rm_punc = $($customer.name) -replace $pattern,""
                $vm_client_fullname = "VOICEMAIL - $rm_punc"
                $vm_name = "$($customer.ClientCode)VM"

            }

            Default {
                Write-Log -LogLevel TerminatingError -LogString "Unhandled exception"
            }

        }

        if([string]::IsNullOrEmpty($PrimaryDomain)){
            $vm_primaryDomain = "$($vm_name).accessabacus.com".ToLower()
        }

        $vm_Parent_client = $Parent_client
        $vm_contactname = $ContactName
        if([String]::IsNullOrEmpty($vm_ContactEmail)){
            $vm_ContactEmail = "$vm_contactname@$($vm_primaryDomain)"
        }

    }
    Process{
        $params = @{
            Client_FullName = $vm_client_fullname
            Name            = $vm_name
            primaryDomain   = $vm_primaryDomain
            Parent_client   = $vm_Parent_client
            ContactName     = $vm_contactname
            ContactEmail    = $vm_ContactEmail
            Credential      =  $credential
        }

        if($whatif -eq $true){
            write-host -ForegroundColor Green $($params | out-string)
        }else{
            try{
                $results = New-CPSMCustomer @params
            }catch{
                throw "Failed to create Voicemail customer:$vm_client_fullname`n$($_.exception)"
            }

            $vm_customer = Get-CPSMCustomer -Client_FullName $vm_client_fullname -Credential $credential

            sleep 10
            #adding Hosted exchange

            Add-CPSMCustomerService -Client_FullName $vm_customer.fullname -Service_name HE -Credential $Credential

            sleep 10
            #creating agadmin account

            $spaceless_Source_client_fullname = $Source_Client_FullName.Replace(" ","")

            $VM_user_Name         = "agadmin"
            $VM_user_username     = "agadmin"
            $VM_user_firstname    = "agadmin"
            $VM_user_Lastname     = "VM-$($spaceless_Source_client_fullname)"
            $VM_user_FullName     = "$VM_user_firstname $VM_user_Lastname"
            $VM_user_PrimaryEmail = $VM_user_username+"@"+$($vm_customer.name.ToLower())+".accessabacus.com"
            $VM_user_UPN          = $VM_user_username+"@"+$($vm_customer.name.ToLower())+".service02.corp"
            try{
                New-CPSMUser -Client_FullName $($vm_customer.fullname) `
                            -User_FullName $VM_user_FullName `
                            -First_name $VM_user_firstname `
                            -Last_name $VM_user_Lastname `
                            -Type Hosted `
                            -Name $VM_user_Name `
                            -CPSM_UPN $VM_user_UPN `
                            -Primary_Email $VM_user_PrimaryEmail `
                            -Credential $credential
            }catch{
                throw "Failed to create Voicemail customer agadmin account on :$vm_client_fullname`n$($_.exception)"
            }
        }
    }
}