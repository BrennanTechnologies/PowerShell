﻿Function Set-VoiceMailFowarding {
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [String]$Source_Usernames
        ,
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [String]$Source_Client_FullName
        ,
        [String]$VM_Client_FullName
        ,
        [PSCredential]$Credential
    )
    

    Begin {
        
        $customer = Get-CPSMCustomer -Client_FullName $Source_Client_FullName -Credential $credential -ErrorAction SilentlyContinue

        if($customer -eq $null){
            throw "$Source_Client_FullName not found"
        }
    }

    Process{

        Foreach($Source_Username in $Source_Usernames){
            $username = $user.name 

            $usernameonly = $username.Split("_")[0]
            $clientcode = $username.Split("_")[1]+"VM"
            Write-host "Adding HE to $usernameonly on $VM_Client_Fullname"
            $cpsm_user = Get-CPSMUser -Username $usernameonly -Client_FullName $VM_Client_Fullname -Credential $credential
            $target_primary_email = $cpsm_user.addresses.address | ? primary -eq "true" | select -ExpandProperty '#text'
    
            if([String]::IsNullOrEmpty($target_primary_email)){
                Write-Warning "No primary email found"
            }else{
                $target_mailbox = Get-Mailbox -Identity $target_primary_email
            }
    

            if($($target_mailbox | measure).count -gt 1){
                throw "GTFO! NO! You are targetting more than 1 mailbox"
            }elseif($null -eq $target_primary_email){
                Write-Warning "target mailbox not found"
            }else{
        
                $target_mailbox | Set-Mailbox -DeliverToMailboxAndForward $true -ForwardingAddress $forwarding_address
    
            }
    
        }
        
    }

    



}
