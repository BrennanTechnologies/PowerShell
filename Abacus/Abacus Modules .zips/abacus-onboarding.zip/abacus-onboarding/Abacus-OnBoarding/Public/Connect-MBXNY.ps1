﻿<#
.SYNOPSIS
A wrapper command that can be used to connect to the on-prem Exchange environment.

.DESCRIPTION
This command creates a remote PSSession to the on-prem Exchange environment in order to invoke commands against the environment.

.PARAMETER Credentials
A PSCredential object containing administrative credentials to the remote Exchange environment.

.EXAMPLE
Connect-MBXNY

.EXAMPLE
Connect-MBXNY -Credentials $CredentialObject

.NOTES
N/A
#>

Function Connect-MBXNY {
    Param(
     [PSCredential]$Credentials
    )

    if($null -eq $Credentials){
        $Credentials = Get-Credential
    }


$Session = New-PSSession -ConfigurationName Microsoft.Exchange `
                         -ConnectionUri http://nysrv2-mbxny01.service02.corp/PowerShell/ `
                         -Authentication Kerberos `
                         -Credential $credentials

Import-PSSession $Session -DisableNameChecking -AllowClobber


}

