﻿<#
.SYNOPSIS
A wrapper command that can be used to connect to a tenant's exchange environment.

.DESCRIPTION
This command creates a remote PSSession to an O365 Exchange environment and returns the session object to the calling command to invoke commands against the remote environment.

.PARAMETER Credentials
A PSCredential object containing administrative credentials to the remote Exchange environment.

.EXAMPLE
Connect-ABAEXO

.EXAMPLE
Connect-ABAEXO -Credentials $CredentialObject

.NOTES
As scope matters, the created PSSession is not imported here, but rather passed off to the calling command to be imported there.
#>
Function Connect-ABAEXO {
    Param(
     [PSCredential]$Credentials
    )

    Import-Module MSOnline -ErrorAction Stop -Force

    if($null -eq $Credentials){
        $Credentials = Get-Credential
    }

    If (   $True -eq [Boolean]$(Get-PSSession -Name 'O365Session' -ErrorAction SilentlyContinue)   ) {
        Try {
            Write-Log -LogString "An existing PSSession exists to O365. Closing to remake..." -LogLevel Output -ForegroundColor Yellow -LogObject $Onboarding_global_logobject
            Get-PSSession -Name 'O365Session' | Remove-PSSession -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an issue closing out our existing connections." -LogLevel TerminatingError -ForegroundColor Yellow -LogObject $Onboarding_global_logobject
        }
    }

    Connect-MsolService -Credential $Credentials -ErrorAction Stop
    $msoExchangeURL = "https://ps.outlook.com/powershell/"
    $Session = New-PSSession -ConfigurationName Microsoft.Exchange `
                             -ConnectionUri $msoExchangeURL `
                             -Credential $Credentials `
                             -Authentication Basic `
                             -AllowRedirection `
                             -Name O365Session `
                             -ErrorAction Stop

    Try {
        Write-Log -LogString "Attempting to load EXO* commands from O365 PSSession." -LogLevel Output -LogObject $Onboarding_global_logobject
        Return $($Session)
        #Import-PSSession $Session -prefix EXO -AllowClobber -ErrorAction Stop
    }
    Catch {
        Write-Log -LogString "There was an issue loading the commands from the PSSession.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
    }
}