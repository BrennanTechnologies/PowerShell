<#
.SYNOPSIS
This function is used to convert On-Prem DistributionGroups to in Cloud only DistributionGroups

.DESCRIPTION
This function is used to convert On-Prem DistributionGroups to in Cloud only DistributionGroups

.PARAMETER Credentials
The UserName/Password contained within a PSCredential object for the Office365 instance you are looking to connect to.

.PARAMETER Client_Code
The three Letter internal ClientCode given to the Tenant

.PARAMETER TargetDC
The FQDN of the domain or a specific domain controller in which to query the OU and Groups from.

.PARAMETER RemoveOnPremGroup
A Boolean value for whether or not we want to remove the On-Prem group. Usually used during testing.

.PARAMETER Date
A date value (generally matching the date when the script is run) which is used during folder creation to export data too before any migration takes place.

.EXAMPLE
Convert-DistributionGroupToCloudOnly -Client_Code <3LetterClientCode> -TargetDC <FQDNDomainName or DomainController>

.EXAMPLE
Convert-DistributionGroupToCloudOnly -Client_Code <3LetterClientCode> -TargetDC <FQDNDomainName or DomainController> -RemoveOnPremGroups -RemoveOnPremContacts

.NOTES
N/A
#>
Function Convert-DistributionGroupToCloudOnly {
    [CmdletBinding()]
    Param
    (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory = $True)]
        [PSCredential]$Credentials = $(Get-Credential)
        ,
        [Parameter(Mandatory = $True)]
        [String]$Client_Code = 'TST'
        ,
        [Parameter(Mandatory = $True)]
        [String]$TargetDC = 'service02.corp'
        ,
        [Switch]$RemoveOnPremGroups = $True
        ,
        [Switch]$RemoveOnPremContacts = $True
        ,
        $Date = $(Get-Date -Format 'MM-dd-yyyy_H-mm-ss')
    )
    Begin {
        $ReturnObject = @()
        $DistroMembership = @()
        $DLsToConvert = @()
        $ContactsToConvert = @()
        $OverlappingContacts = @()
        $PreExportObject = @()
        $PreCloudExportObject = @()
        $ObjectIdList = @()

        # Load the Active Directory PSModule.
        Try {
            Write-Log -LogString "Importing Active Directory PS Module" -LogLevel Output -LogObject $Onboarding_global_logobject
            Import-Module ActiveDirectory -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an error importing the Active Directory Module" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
        }


        
        # Load the MSOnline PSModule
        Try {
            Write-Log -LogString "Importing MSOnline PSModule" -LogLevel Output -LogObject $Onboarding_global_logobject
            Import-Module MSOnline -ErrorAction Stop -Force
        }
        Catch {
            Write-Log -LogString "There was an issue importing the MSOnline module.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
        }



        # Attempt to connect to Office365 environment with provided credentials.
        Try {
            Write-Log -LogString "Attempting to connect to the client's Office365 environment via PSSession." -LogLevel Output -LogObject $Onboarding_global_logobject
            Import-PSSession -Session $(Connect-ABAEXO -Credentials $Credentials -Force) -prefix EXO -AllowClobber -ErrorAction Stop 
            
        }
        Catch {
            Write-Log -LogString "There was an issue connecting to the client's O365 environment.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
        }


        Try {
            Write-Log -LogString "Attempting to enumerate the Client's On-Prem DistributionGroups and Contacts." -LogLevel Output -LogObject $Onboarding_global_logobject
            # Grab the GroupOU for the specified client based on the ClientCode provided.
            $DistributionGroupOU = Get-ADOrganizationalUnit -Server $TargetDC -Filter { Name -eq 'Distribution Groups' } | ? { $_.DistinguishedName -Like "*($Client_Code)*" }
            $ContactOU = Get-ADOrganizationalUnit -Server $TargetDC -Filter { Name -eq 'Contacts' } | ? { $_.DistinguishedName -Like "*($Client_Code)*" }
            If ($Null -eq $DistributionGroupOU) {
                Write-Log -LogString "The DistributionGroupOU could not be verified." -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
            }
            If ($Null -eq $ContactOU) {
                Write-Log -LogString "The ContactOU could not be verified." -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
            }



            # Grab the Distribution Groups for the client based on the OU specified above.
            $DistributionGroups = Get-ADGroup -Server $TargetDC -Searchbase $DistributionGroupOU -Properties * -Filter * | ? { $Null -ne $_.msExchRecipientDisplayType }
            $Contacts = Get-ADObject -Server $TargetDC -Searchbase $ContactOU -Properties * -Filter { ObjectClass -eq 'contact' }
        }
        Catch {
            Write-Log -LogString "There was an issue enumerating the Client's OnPrem DistributionGroups and Contacts.`n Exception {$($_.Exception)}" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
        }
        
        

        Write-Log -LogString "A total of {$($DistributionGroups.Count)} On-Prem DistributionGroups were detected..." -LogLevel Output -LogObject $Onboarding_global_logobject
        Write-Log -LogString "A total of {$($Contacts.Count)} On-Prem contacts were detected..." -LogLevel Output -LogObject $Onboarding_global_logobject



        # Create a folder matching the ClientCode and Todays date for pre-execution data export 
        $ExportLocation = "\\service02.corp\dfs\shares\PSAuditLogs\Abacus-OnBoarding\$($Client_Code)\$($Date)\"
        If (   $False -eq (Test-Path -LiteralPath $ExportLocation)   ) {
            Try {
                New-Item -Path $ExportLocation -ItemType Directory -Force -ErrorAction Stop
            }
            Catch {
                Write-Log -LogString "There was an issue creating our data export directory {$($ExportLocation)}.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $Onboarding_global_logobject
            }
        }



        # Gather On-Prem DistributionList Information
        ForEach ($DistributionGroup in $DistributionGroups) {
            $PropertyObject = [PSCustomObject]@{ }
            $DistributionGroup | gm | ? { $_.MemberType -eq 'Property' -or $_.MemberType -eq 'NoteProperty' } | % {
                $PropertyToAdd = $Null
                $PropertyToAdd = $_
                $PropertyObject | Add-Member -MemberType NoteProperty -Name $PropertyToAdd.name -Value $DistributionGroup.$($PropertyToAdd.Name)
            }
            $PropertyObject.Sid = $PropertyObject.Sid.Value
            #$PropertyObject | Add-Member -MemberType NoteProperty -Name 'members' -Value $($DistributionGroup | Get-ADGroupMember | Select name, DistinguishedName, SamAccountName, SID)
            $PreExportObject += $PropertyObject
        }



        # Gather Cloud DistributionList Information
        Try {
            $CloudDLS = Get-EXODistributionGroup
            ForEach ($CloudDL in $CloudDLS) {
                $PropertyObject = [PSCustomObject]@{ }
                $CloudDL | Get-Member | ? { $_.MemberType -eq 'Property' -or $_.MemberType -eq 'NoteProperty' } | % {
                    $PropertyToAdd = $Null
                    $PropertyToAdd = $_
                    $PropertyObject | Add-Member -MemberType NoteProperty -Name $PropertyToAdd.name -Value $CloudDL.$($PropertyToAdd.Name)
                }
                $PropertyObject | Add-Member -MemberType NoteProperty -Name 'members' -Value $(Get-EXODistributionGroupMember -Identity $CloudDL.Guid.Guid | Select *)
                $PreCloudExportObject += $PropertyObject
            }

            # Gather Contact Info
            $CloudContacts = Get-EXOContact
        }
        Catch {
            Write-Log -LogString "There was an error querying O365 for DL information" -LogLevel TerminatingError
        }
        

        Write-Log -LogString "A total of {$($CloudDLS.Count)} Cloud DistributionGroups were detected..." -LogLevel Output -LogObject $Onboarding_global_logobject
        Write-Log -LogString "A total of {$($CloudContacts.Count)} Cloud contacts were detected..." -LogLevel Output -LogObject $Onboarding_global_logobject


        # Perform Data Export
        Try {
            $ExportDate = $(Get-Date -format 'MM-dd-yyyy,h-mm-ss')
            Write-Log -LogString "Exporting PreCheck results for {$($Client_Code)} to location {$($ExportLocation)}" -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
            $PreExportObject | ConvertTo-Json -Depth 3 | Out-File -LiteralPath "$ExportLocation\OnPremDLs_$($ExportDate).Json" -ErrorAction Stop
            $Contacts | ConvertTo-Json | Out-File -LiteralPath "$ExportLocation\OnPremContacts_$($ExportDate).Json" -ErrorAction Stop
            $PreCloudExportObject | ConvertTo-Json -Depth 3 | Out-File -LiteralPath "$ExportLocation\CloudDLs_$($ExportDate).Json" -ErrorAction Stop
            $CloudContacts | ConvertTo-Json | Out-File -LiteralPath "$ExportLocation\CloudContacts_$($ExportDate).Json" -ErrorAction Stop
        }
        Catch {
            Write-Log -LogString "There was an issue exporting our pre-execution data and therefore script will not continue.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -ForegroundColor Green -LogObject $Onboarding_global_logobject
        }
    } # End Begin
    Process {
        #################################################
        ##### Actions items will be performed below #####
        #################################################

        # Enumerate list of DistributionGroups within O365 to convert and remove them from O365 if tests pass
        ForEach ($DistributionGroup in $DistributionGroups) {
            Write-Log -LogString "Checking if group {$($DistributionGroup.Name)} exists in Office365" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
            $GroupToConvert = $Null
            $GroupToConvert = $CloudDLs | ? { $_.Identity -eq $DistributionGroup.Name }

            # If More than one group is found with the same name, assume snowflake and do not perform any action.
            If ($GroupToConvert.count -gt 1) {
                Write-Log -LogString "More than one DistributionGroup was found with this DisplayName" -LogLevel Warning -LogObject $Onboarding_global_logobject
                $ReturnObject += [PSCustomObject]@{
                    ObjectName = "$($DistributionGroup.DisplayName)";
                    ObjectType = "DistributionGroup"; ConversionStatus = "FAILED";
                    Message = "More than one DG exists with this name."
                }
            }
            ElseIf ($GroupToConvert.count -eq 0) {
                # If no group is found with the same name, assume snowflake and do not perform any action.
                Write-Log -LogString "Could not find a matching DistributionGroup by the DisplayName `"$($DistributionGroup.DisplayName)`" in Office365" -LogLevel Warning -LogObject $Onboarding_global_logobject
                $ReturnObject += [PSCustomObject]@{
                    ObjectName       = "$($DistributionGroup.DisplayName)";
                    ObjectType       = "DistributionGroup";
                    ConversionStatus = "FAILED";
                    Message          = "No DG exists with this name."
                }
            }
            Else {
                # If only one group is found with a matching name, assume that the group is good to be converted.
                Write-Log -LogString "Evaluating removal of {$($GroupToConvert.Name)} from Azure" -LogLevel Output -LogObject $Onboarding_global_logobject
                $ObjectId = (Get-MsolGroup | ? { $_.Displayname -eq $($GroupToConvert.DisplayName) }).ObjectId.Guid
                If ($ObjectId.count -eq 1) {
                    $ObjectIdList += [PSCustomObject]@{'ObjectId' = $ObjectId; 'ObjectType' = 'Group' }
                    Write-Log -LogString "Removing objectId {$($ObjectId)}" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
                    Remove-MsolGroup -ObjectId $($ObjectId) -ErrorAction Stop -ErrorVariable err -Force
                    Write-Log -LogString "Adding {$($GroupToConvert.Name)} to our list of DistributionGroups to Convert" -LogLevel Output -LogObject $Onboarding_global_logobject
                    $DLsToConvert += $GroupToConvert
                }
                ElseIf ($ObjectId.count -gt 1) {
                    Write-Log -LogString "More than one ObjectId {$($ObjectId.count)} for group {$($GroupToConvert.DisplayName)} was returned by Azure so this group will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                    $ReturnObject += [PSCustomObject]@{
                        ObjectName       = "$($GroupToConvert.DisplayName)";
                        ObjectType       = "DistributionGroup";
                        ConversionStatus = "FAILED";
                        Message          = "More than one Azure object ID {$($ObjectId.count)} were found."
                    }
                }
                ElseIf ($ObjectId.count -eq 0) {
                    Write-Log -LogString "No ObjectId for group {$($GroupToConvert.DisplayName)} was returned by Azure so this group will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                    $ReturnObject += [PSCustomObject]@{
                        ObjectName       = "$($GroupToConvert.DisplayName)";
                        ObjectType       = "DistributionGroup";
                        ConversionStatus = "FAILED";
                        Message          = "No Azure object ID was found."
                    }
                }
                Else {
                    Write-Log -LogString "There was an unexpected error with obtaining an ObjectId for the group {$($GroupToConvert.DisplayName)} so this group will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                    $ReturnObject += [PSCustomObject]@{
                        ObjectName       = "$($GroupToConvert.DisplayName)";
                        ObjectType       = "DistributionGroup";
                        ConversionStatus = "FAILED";
                        Message          = "Unknown error with Azure object ID detection."
                    }
                }
            }
        } # End ForEach



        # Enumerate list of Contacts within O365 to convert and remove them from O365 if tests pass
        $DuplicateContacts = $Contacts | Group -Property Displayname
        If ( $True -eq ($DuplicateContacts.Count -notcontains 1) ) {
            ForEach ($i in $DuplicateContacts) {
                If ( $True -eq ($i.count -gt 1) ) {
                    Write-Log -LogString "Duplicate contacts named {$($i.Name)} were detected, {$($i.Count)} in total, removing these from the list to be converted." -LogLevel Output -ForegroundColor Yellow -LogObject $Onboarding_global_logobject
                    $ReturnObject += [PSCustomObject]@{ObjectName = "$($i.Name)"; ObjectType = "Contact"; ConversionStatus = "FAILED"; Message = "Multiple contacts {$($i.Count)} matching this DisplayName were found." }
                    $Contacts = $Contacts | ? { $_.DisplayName -ne $i.Name }
                }
            }
        }

        # Verify Match and ensure only one Azure AD Object exists before removing
        If ($CloudContacts.Count -ne 0) {
            ForEach ($Contact in $Contacts) {
                If ($CloudContacts.Displayname -contains $Contact.DisplayName) {
                    $Match = $CloudContacts[$($CloudContacts.DisplayName.IndexOf($Contact.DisplayName))]
                    Write-Log -LogString "Contact overlap detected, OnPrem {$($Contact.DisplayName)} and Cloud {$($Match.DisplayName)} from O365" -LogLevel Output -LogObject $Onboarding_global_logobject

                    $ObjectId = (Get-MsolContact | ? { $_.Displayname -eq $($Match.DisplayName) }).ObjectId.Guid
                    If ($ObjectId.count -eq 1) {
                        $ObjectIdList += [PSCustomObject]@{'ObjectId' = $ObjectId; 'ObjectType' = 'Contact' }
                        Write-Log -LogString "Removing objectId {$($ObjectId)}" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
                        Remove-MsolContact -ObjectId $ObjectId -Force
                        
                        Write-Log -LogString "Adding {$($Match.Name)} to our list of Contacts to Convert" -LogLevel Output -LogObject $Onboarding_global_logobject
                        $ContactsToConvert += [PSCustomObject]@{OnPremContact = $Contact; O365Contact = $Match }
                    }
                    ElseIf ($ObjectId.count -gt 1) {
                        Write-Log -LogString "More than one ObjectId {$($ObjectId.count)} for contact {$($Match.DisplayName)} was returned by Azure so this contact will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                        $ReturnObject += [PSCustomObject]@{
                            ObjectName       = "$($Match.DisplayName)";
                            ObjectType       = "Contact";
                            ConversionStatus = "FAILED";
                            Message          = "More than one Azure object ID {$($ObjectId.count)} were found."
                        }
                    }
                    ElseIf ($ObjectId.count -eq 0) {
                        Write-Log -LogString "No ObjectId for contact {$($Match.DisplayName)} was returned by Azure so this contact will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                        $ReturnObject += [PSCustomObject]@{
                            ObjectName       = "$($Match.DisplayName)";
                            ObjectType       = "Contact";
                            ConversionStatus = "FAILED";
                            Message          = "No Azure object ID was found."
                        }
                    }
                    Else {
                        Write-Log -LogString "There was an unexpected error with obtaining an ObjectId for the contact {$($Match.DisplayName)} so this contact will be skipped." -LogLevel Warning -LogObject $Onboarding_global_logobject
                        $ReturnObject += [PSCustomObject]@{
                            ObjectName       = "$($Match.DisplayName)";
                            ObjectType       = "Contact";
                            ConversionStatus = "FAILED";
                            Message          = "Unknown error with Azure object ID detection."
                        }
                    }
                }
                Else {
                    Write-Log -LogString "Could not find a matching Contact for OnPrem contact {$($Contact.DisplayName)}" -LogLevel Output -ForegroundColor Yellow -LogObject $Onboarding_global_logobject
                }
            }
        }
        

        # Remove Overlapping Contacts from on prem
        If ($True -eq $RemoveOnPremContacts) {
            If ($ContactsToConvert.Count -ne 0) {
                ForEach ($Contact in $ContactsToConvert) {
                    Try {
                        Write-Log -LogString "Removing On-Prem Contact {$($Contact.OnPremContact.DistinguishedName)}" -LogLevel Output -LogObject $Onboarding_global_logobject
                        Remove-ADObject -Identity $($Contact.OnPremContact) -Server $TargetDC -Confirm:$False -ErrorAction Stop
                    }
                    Catch {
                        Write-Log -LogString "There was an error removing the On-Prem Contact {$($Contact.OnPremContact)}" -LogLevel Warning -LogObject $Onboarding_global_logobject
                    }
                }
            }
        }

        Write-Log -LogString "Performing a check on all ObjectIds to ensure elements are completely removed." -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
        While ($ObjectIdList.Count -ne 0) {
            Write-Log -LogString "There are a total of {$($ObjectIdList.Count)} ObjectIds remaning to be verified." -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject

            ForEach ($Id in $ObjectIdList) {

                If ($Id.ObjectType -eq 'Group') {
                    $IdCheck = [Boolean]$(Get-MsolGroup -ObjectId $($Id.ObjectId) -ErrorAction SilentlyContinue)
                }
                ElseIf ($Id.ObjectType -eq 'Contact') {
                    $IdCheck = [Boolean]$(Get-MsolContact -ObjectId $($Id.ObjectId) -ErrorAction SilentlyContinue)
                }
                Else {
                    Write-Log -LogString "ObjectId {$($Id.ObjectId)} has an unknown objectType of type {$($id.ObjectType)}, removing from the list..." -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
                    $ObjectIdList = $ObjectIdList | ? { $_ -ne $($Id.ObjectId) }
                }                

                If ($False -eq $IdCheck) {
                    Write-Log -LogString "ObjectId {$($Id.ObjectId)} confirmed sucessfully removed." -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
                    $ObjectIdList = $ObjectIdList | ? { $_.ObjectId -ne $($Id.ObjectId) }
                }
            }
            Sleep 2
        }

        
        Write-Log -LogString "Performing a check on all Exchange Objects to ensure elements are completely removed." -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
        $CloudExchangeObjectsToWaitFor = @()
        $CloudExchangeObjectsToWaitFor += $DlsToConvert | Select Name, DisplayName, RecipientType, id
        $CloudExchangeObjectsToWaitFor += $ContactsToConvert.O365Contact | Select Name, DisplayName, RecipientType, id

        While ($CloudExchangeObjectsToWaitFor.id.Count -ne 0) {
            Write-Log -LogString "There are a total of {$($CloudExchangeObjectsToWaitFor.id.Count)} Exchange Objects remaning to be verified." -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject

            ForEach ($Object in $CloudExchangeObjectsToWaitFor) {
                Switch -Regex ($Object.'RecipientType') {
                    '.*DistributionGroup.*' {
                        #Write-Log -LogString "DistributionList Detected" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
                        $ExchangeCheck = [Boolean]$(Get-EXODistributionGroup -Identity $Object.Id -ErrorAction SilentlyContinue)

                        If ($False -eq $ExchangeCheck) {
                            Write-Log -LogString "ExchangeObject {$($Object.Id)} confirmed sucessfully removed." -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
                            $CloudExchangeObjectsToWaitFor = $CloudExchangeObjectsToWaitFor | ? { $_.Id -ne $($Object.Id) }
                        }
                    }
                    'MailContact' {
                        #Write-Log -LogString "Contact Type Detected" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
                        $ExchangeCheck = [Boolean]$(Get-EXOMailContact -Identity $Object.Id -ErrorAction SilentlyContinue)

                        If ($False -eq $ExchangeCheck) {
                            Write-Log -LogString "ExchangeObject {$($Object.Id)} confirmed sucessfully removed." -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
                            $CloudExchangeObjectsToWaitFor = $CloudExchangeObjectsToWaitFor | ? { $_.Id -ne $($Object.Id) }
                        }
                    }
                    Default {
                        Write-Log -LogString "Unknown Object Type Detected... Removing from list" -LogLevel Output -ForegroundColor Magenta -LogObject $Onboarding_global_logobject
                        Write-Log -LogString "ExchangeObject {$($Object.Id)} confirmed sucessfully removed." -LogLevel Output -ForegroundColor Green -LogObject $Onboarding_global_logobject
                        $CloudExchangeObjectsToWaitFor = $CloudExchangeObjectsToWaitFor | ? { $_.Id -ne $($Object.Id) }
                        
                    }
                }
            }
            Sleep 2
        }
        
        
        #################################################################################################################################################

        # ReCreate DLs
        ForEach ($DL in $DlsToConvert) {
            Write-Log -LogString "Now attempting to recreate DistributionGroup: {$($DL.Name)} with DisplayName: {$($DL.DisplayName)}" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject

            Try {
                $NewCloudDistributionGroup = New-EXODistributionGroup -Name "$($DL.Name)" `
                    -DisplayName "$($DL.DisplayName)" `
                    -PrimarySmtpAddress "$($DL.PrimarySmtpAddress)" `
                    -RequireSenderAuthenticationEnabled:$False `
                    -Notes "DistributionGroup migrated from On-Prem to Cloud Only."
                Start-Sleep 15
                $NewCloudDistro = Get-EXODistributionGroup -Identity $($DL.DisplayName)
                $NewCloudDistroID = [String]$NewCloudDistributionGroup.guid
                Set-EXODistributionGroup -Identity $($DL.DisplayName) -EmailAddresses $Dl.EmailAddresses                       
                        
                # Apply the AcceptMessagesOnlyFrom array values to new group
                Write-Log -LogString "Adding ACCEPTMESSAGES to DistributionGroup." -LogLevel Output -LogObject $Onboarding_global_logobject
                Set-ExoDistributionGroup -Identity $NewCloudDistroID `
                    -AcceptMessagesOnlyFrom $DL.AcceptMessagesOnlyFrom `
                    -AcceptMessagesOnlyFromDLMembers $DL.AcceptMessagesOnlyFromDLMembers `
                    -ErrorAction Continue
                        
                Write-Log -LogString "Adding REJECTMESSAGES to DistributionGroup." -LogLevel Output -LogObject $Onboarding_global_logobject
                Set-ExoDistributionGroup -Identity $NewCloudDistroID `
                    -RejectMessagesFrom $DL.RejectMessagesFrom `
                    -RejectMessagesFromDLMembers $DL.RejectMessagesFromDLMembers `
                    -ErrorAction Continue
                        
                # Delete OnPrem group 
                If ($True -eq $RemoveOnPremGroups) {
                    Write-Log -LogString "Removing `"$($DL.DisplayName)`" On-Prem AD group" -LogLevel Output -LogObject $Onboarding_global_logobject
                    Remove-ADGroup -Server $TargetDC -Identity $($PreExportObject | ? { $_.DisplayName -eq $DL.DisplayName }).sid -Confirm:$False
                }

                $ReturnObject += [PSCustomObject]@{
                    ObjectName = "$($DL.DisplayName)";
                    ObjectType = "DistributionGroup";
                    ConversionStatus = "CONVERTED"; Message = ""
                }
            }
            Catch {
                $err
                Write-Log -LogString "There was an issue attempting to convert the following group, `"$($DL.DisplayName)`"" -LogLevel Warning -LogObject $Onboarding_global_logobject
                $ReturnObject += [PSCustomObject]@{
                    ObjectName = "$($DL.DisplayName)";
                    ObjectType = "DistributionGroup";
                    ConversionStatus = "FAILED"; Message = "$($err)"
                }
            }
        }

        ForEach ($Contact in $ContactsToConvert) {
            Try {
                New-EXOMailContact -DisplayName $Contact.O365Contact.DisplayName `
                    -Name $Contact.O365Contact.Name `
                    -LastName $Contact.O365Contact.LastName `
                    -FirstName $Contact.O365Contact.FirstName `
                    -Initials $Contact.O365Contact.Initials `
                    -ExternalEmailAddress $($Contact.O365Contact.WindowsEmailAddress -replace '@.*', '' -replace '_at_', '@') `
                    -ErrorVariable err `
                    -ErrorAction Stop | Out-Null
                $ReturnObject += [PSCustomObject]@{ObjectName = "$($Contact.O365Contact.DisplayName)"; ObjectType = "Contact"; ConversionStatus = "CONVERTED"; Message = "" }
            }
            Catch {
                Write-Log -LogString "There was an error converting the contact {$($Contact.O365Contact.Name)}.`n Exception: $($_.Exception)" -LogLevel Warning -LogObject $Onboarding_global_logobject
                $ReturnObject += [PSCustomObject]@{ObjectName = "$($Contact.O365Contact.DisplayName)"; ObjectType = "Contact"; ConversionStatus = "FAILED"; Message = "$($_.Exception.message)" }
            }
        }
        
        
        #Adding Membership back to groups
        ForEach ($DL in $DLsToConvert) {
            $OldDLInfo = $PreCloudExportObject | ? { $_.DisplayName -eq $DL.DisplayName }
            If ($Null -ne $OldDLInfo.members) {
                ForEach ($Member in $OldDLInfo.members) {
                    Write-Log -LogString "Re-adding memeber {$($Member.Name)} to DistributionGroup {$($DL.Name)}" -LogLevel Output -ForegroundColor Cyan -LogObject $Onboarding_global_logobject
                    Try {
                        Add-EXODistributionGroupMember -Identity $($DL.Id) -Member $($Member.Name) -ErrorAction Stop
                    }
                    Catch {
                        Write-Log -LogString "There was an issue re-adding memeber {$($Member.Name)} to DistributionGroup {$($DL.Name)}. Exception {$($_.Exception.Message)}" -LogLevel Warning -LogObject $Onboarding_global_logobject
                    }
                }
            }
            Else {
                Write-Log -LogString "There was no previous membership information for group {$($DL.Name)} so no members will be added." -LogLevel Output -ForegroundColor Magenta -LogObject $Onboarding_global_logobject
            }
        }
    } # Process
    End {
        Get-PSSession -Name 'O365Session' | Remove-PSSession
        Write-Log -LogString "Please allow a few minutes before the changes populate in Office365 as there is a delay when it appears in the GUI." -LogLevel Output -ForegroundColor Yellow -LogObject $Onboarding_global_logobject
        Return $ReturnObject | Format-Table -AutoSize
    }
}