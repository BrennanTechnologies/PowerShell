﻿Function Set-ADmsExchExtensionAttribute16 {
<#
    .SYNOPSIS
    Sets active directory user object Extension attribute 16

    .DESCRIPTION
    Sets active directory user object Extension attribute 16

    .PARAMETER Client_Code 
    Specify target client Client code

    .PARAMETER User
    Specify target user sam account name

    .PARAMETER value
    Specify the value of attribute

    .PARAMETER TargetDC
    Specify a target DC default: nysrv2-dc02.service02.corp

    .PARAMETER whatif
    simulates a what if condition

    .EXAMPLE 
    Set-ADmsExchExtensionAttribute16 -Client_Code TST -user user1 -whatif

    .NOTES
    You require access to query active directory objects

#>

    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Code
        ,
        [Parameter(Mandatory=$true)]
        [String]$User
        ,
        [Parameter(Mandatory=$true)]
        [String]$value
        ,
        [String]$TargetDC = "nysrv2-dc02.service02.corp"
        ,
        [switch]$whatif
    )
    Begin{
         try{
            $OU = Get-ADOrganizationalUnit -Server $TargetDC -Filter * | ? DistinguishedName -Like "*($Client_Code)*" | ? name -EQ "User Structure"
        }catch{
            throw "Failed to Query for OU`n$($_.exception)"
        }

        if(!$OU){
            throw "unable to find OU"
        }
    }
   
    Process{

        $user_obj = Get-ADUser -Server $TargetDC -SearchBase $OU.DistinguishedName -Filter * -Properties proxyaddresses | ? Name -eq $User
                
        If($user_obj) {
            If ($whatif) {
                Write-Host -ForegroundColor Green "attempting to set $($user.name) msExchExtensionAttribute16 to $value"
                Set-ADUser $user -add @{msExchExtensionAttribute16 =$value} -Server $TargetDC -WhatIf
            } 
            Else {
                Write-Host -ForegroundColor Green "attempting to set $($user.name) msExchExtensionAttribute16 to $value"
                Set-ADUser $user -add @{msExchExtensionAttribute16 =$value} -Server $TargetDC
            }
        }
        Else{
            Write-Warning "User not found for $user"
        }   
    }
    
    END{
        #Write-Host "Set-ADmsExchExtensionAttribute16: FIN"
    }
}
