﻿Function New-VoiceMailUser {
<#
    .SYNOPSIS
    Creates a new voicemail Contact 

    .DESCRIPTION
    Uses the source customer to create a contact in the voicemail customer

    .PARAMETER apiUrl 
    The url path where the requests are targeting - Default: https://panel.accessabacus.com/cortexapi/default.

    .PARAMETER QA
    If switch is specified it changes the APIURL to "https://cpsm.accessabacus.com/cortexapi/default.aspx"

    .PARAMETER Source_Usernames
    Array of usernames to be modeled after to create contact

    .PARAMETER Source_Client_FullName
    Choose Source Client Fullname 

    .PARAMETER VM_Client_FullName
    Target Voicemail customer - default to $VM_Client_FullName = "VOICEMAIL - $($src_customer.fullname)"

    .PARAMETER Credential
    Credentials used to authenticate against panel. If left blank then it will use your runtimeCredentials

    .EXAMPLE 
    New-VoiceMailUser -Source_Client_FullName "ezevoange" -Source_Usernames @{"user1","user2"} -VM_Client_fullname "Voicemail - ezevonage" -credential $credential 

    .NOTES
    you need Credentials to access panel to run this command.
#>

    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $Source_Usernames
        ,
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        $Source_Client_FullName
        ,
        $VM_Client_FullName
        ,
        [PSCredential]$Credential
    )

    Begin{
        
        if($null -eq $Credential){
            if($null -eq $Global:CPSM_Credential){
                Set-CPSMCredential
            }
            
            $Credential = $Global:CPSM_Credential
        }

        $src_customer = Get-CPSMCustomer -Client_FullName $Source_Client_FullName `
                                         -Credential $credential `
                                         -ErrorAction SilentlyContinue
        
        if($null -eq $src_customer){
            throw "$Source_Client_FullName not found"
        }

        if([String]::IsNullOrEmpty($VM_Client_FullName)){
            $VM_Client_FullName = "VOICEMAIL - $($src_customer.fullname)"
        }

        $vm_customer = Get-CPSMCustomer -Client_FullName $VM_Client_FullName `
                                        -Credential $credential `
                                        -ErrorAction SilentlyContinue

        if($null -eq $vm_customer){
            throw "$VM_Client_FullName not found"
        }
    }

    Process{
        
        foreach($source_username in $Source_Usernames){

            $expanded_Source_user = Get-CPSMUser -Credential $credential `
                                                 -Client_FullName $($src_customer.fullname) `
                                                 -Name $($source_username)

            if($Null -eq $expanded_Source_user){

                Write-Warning "User:$($Source_User.name) not found"

            }elseif($expanded_Source_user.status -ne "Provisioned"){

                Write-Warning "$($expanded_Source_user.fullname) is not a provisioned user"
        
            }else{
                $VM_Name         = $expanded_Source_user.name + "VM"
                $VM_username     = $expanded_Source_user.name.Split("_")[0]
                $VM_firstname    = $expanded_Source_user.Firstname
                $VM_Lastname     = $expanded_Source_user.lastname
                $VM_FullName     = $expanded_Source_user.fullname
                $VM_PrimaryEmail = $VM_username+"@"+$($vm_customer.name.ToLower())+".accessabacus.com"
                $VM_UPN          = $VM_username+"@"+$($vm_customer.name.ToLower())+".service02.corp"
                Write-Log -LogString "Creating user $VM_Name"
                New-CPSMUser -Client_FullName $($vm_customer.fullname) `
                             -User_FullName $VM_FullName `
                             -First_name $VM_firstname `
                             -Last_name $VM_Lastname `
                             -Type Hosted `
                             -Name $vm_name `
                             -CPSM_UPN $VM_UPN `
                             -Primary_Email $VM_PrimaryEmail `
                             -Credential $credential
                
                
                #get source use plan site

                $src_userplan = Get-CPSMUserHEUserPlan -Client_FullName $Source_Client_FullName -Name $source_username

                if($null -ne $src_userplan){
                    $src_userplan_features = Convert-CPSMUserPlan -User_Plan $src_userplan
                    $he_user_plan_name = Get-CPSMUserPlan -Client_FullName $VM_Client_FullName -Site $($src_userplan_features.site)

                    #provision the user plan
                    Write-host "Adding HE to $VM_Name with user plan $($he_user_plan_name.fullname)"
                    Add-CPSMUserHE -Client_FullName $VM_Client_FullName `
                                   -Name $VM_Name `
                                   -HE_User_Plan_Name $($he_user_plan_name.fullname)

                }else{
                    Write-Log -LogLevel Warning -LogString "Hosted exchange not found in $source_username`n unable to provision HE on $VM_Name"
                }
            }
        }
    }

    End{
    
    }
   

}
