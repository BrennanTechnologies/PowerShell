Function New-VMwareCustomer {
    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Fullname
        ,
        [Parameter(Mandatory=$true)]
        [Site]$Site
        ,
        [ValidateSet("Proactive MSP","Eze Castle Software","Eze White Label","Trader Tools","Client VMs")]
        [String]$HostingProvider
        ,
        [Parameter(Mandatory=$true)]
        [String]$VLANID
        ,
        [Parameter(Mandatory=$true)]
        [String]$ClientCode
    )
    Begin{
        #Connect
        if($(Test-ABAVIServer -site $Site) -eq $false ){
            Connect-ABAVIServer -site $site
        }

        $vcenter = "$($site)mgmtvc01.management.corp"
        $VDSwitch = "ClientNetworks"
    }
    Process {
        #default hosting provider
        if([String]::IsNullOrEmpty($HostingProvider)){
            $HostingProvider = "Client VMs"
        }

        #Determine The folder Location
        Try{
            New-ABACustomerFolder -vCenterServer $vcenter -OrgName $Client_Fullname -location $HostingProvider
        }Catch{
            Write-Log -LogLevel TerminatingError -LogString "Failed to Create VM Folder`n$($_.exception)"
        }

        Try{
            New-ABAvPortGroups -vCenterServer $vcenter -VLANID $VLANID -ClientCode $ClientCode -VDSwitch $VDSwitch
        }Catch{
            Write-Log -LogLevel TerminatingError -LogString "Failed to Portgroup`n$($_.exception)"
        }
    }
}
