﻿Function Set-ADProxyAddressToEmail {
    Param(
        [Parameter(Mandatory=$true)]
        [String]$Client_Code
        ,
        [Parameter(Mandatory=$true)]
        [String]$TargetDC
        ,
        [switch]$whatif
    )

    try{
        $OU =  Get-ADOrganizationalUnit -Server $TargetDC -Filter * | ? DistinguishedName -Like "*($Client_Code)*" | ? name -EQ "User Structure"
    }catch{
    
        throw "Failed to Query for OU`n$($_.exception)"
    }
    
    if($null -eq $OU){
        throw "No OU Found"
    }


    try{
        $AllUsers = Get-ADUser -Server $TargetDC -SearchBase $OU.DistinguishedName -Filter * -Properties emailaddress | Sort name 
    }Catch{
        throw "Failed to query User`n$($_.exception)"
    }
    

    if($null -eq $AllUsers){
        throw "No users found in target User structure OU OU"
    }

 
    if ($whatif) {
        $Allusers | %{set-aduser $_ -add @{proxyaddresses="SMTP:$($_.emailaddress)"; targetaddress="SMTP:$($_.emailaddress)"} -WhatIf} 
    } else {
        $Allusers | %{set-aduser $_ -add @{proxyaddresses="SMTP:$($_.emailaddress)"; targetaddress="SMTP:$($_.emailaddress)"} }
    }

    Write-Host "Set-ADProxyAddressToEmail: END"

}

