Function Sync-ADproxyaddress {
    Param(
        [String]$Client_Domain
        ,
        [String]$Username
        ,
        [String]$Client_Code
        ,
        [Microsoft.ActiveDirectory.Management.ADUser]$aduser_object
        ,
        [switch]$whatif
    )
    if($aduser_object){
        [regex]$rx='(?:.*?)DC=(.*)'
        $DN=$aduser_object.DistinguishedName
    
        $Client_Domain = $rx.Replace($DN,'$1') -replace ',DC=','.'

        $username = $aduser_object.samaccountname
    }

    $user = get-aduser -Server $Client_domain -Identity $username -Properties proxyaddresses

    $service02_user = $user.SamAccountName + "_$client_code"

    try{
        $service02_user_object = Get-ADUser -Server Service02 -Identity $service02_user -Properties proxyaddresses
    }catch{
        Write-Warning "unable to find $service02_user"
    }

    if($service02_user_object){
        write-host -ForegroundColor Yellow "Existing service02 account found: $($service02_user_object | select name, @{name="proxyaddresses";E={$_ | select -ExpandProperty proxyaddresses }} | out-string) "

        $all_client_local_user_proxy_addresses = $user.proxyaddresses
        write-host -ForegroundColor Green "$($all_client_local_user_proxy_addresses.count) proxy addresses found"
        $all_client_local_user_proxy_addresses| %{
            write-host -ForegroundColor Gray "ProxyAddress:$_"
            $match_for_existing = $service02_user_object.proxyaddresses -match "^$_$"
            #append it to service02 account
            #Write-Host "Match:$match_for_existing"
            if([string]::IsNullOrEmpty($match_for_existing)){

                if($whatif -eq $true){
                    Write-Host "Whatif: Target service02 User:$($service02_user_object.name)`n"
                }else{
                    Set-ADUser -Server service02.corp -Identity $service02_user_object.name -Add @{Proxyaddresses="$_"}
                } 
            
            }else{
                Write-warning "Proxy Address already exists in service02 account"
                Write-Host "`r"
            }
        } 
    }

    Write-Host "Sync-ADproxyaddress: END"
}