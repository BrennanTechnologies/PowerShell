$ModuleName = $(Split-Path -Path $PSScriptRoot -Leaf)
Write-Host -ForegroundColor Magenta "Loading Module $($ModuleName) from {$PSScriptRoot\$($ModuleName)}"
Import-Module $PSScriptRoot\$($ModuleName)