﻿<#
.SYNOPSIS
Sets a Secret Server object's field. Particularly used for when creating new Secret Server Objects.


.DESCRIPTION
Sets a Secret Server object's field. Particularly used for when creating new Secret Server Objects.

.PARAMETER ssObject
The Secret Server Object.

.PARAMETER ssFieldName
The Secret Server Field Name.

.PARAMETER ssValue
The Secret Server value.

.EXAMPLE
SetSSField [SS Object] "Domain" "ezevonage.corp"

.NOTES
LEGACY
#>

Function SetSSField ($ssObject, $ssFieldName, $ssValue) {
    $Found = $False

    # Loop through all items in the object
    # If the field name matches the given field name, set the value accordingly
    Foreach ($Item in ($ssObject.Secret.Items)) {
        If ($Item.FieldDisplayName -eq $ssFieldName) {
            $Item.Value = $ssValue
            $Found = $True
        }
    }

    If(!($Found)) {
        Return $False
    }
    Else {
        Return $True
    }
}