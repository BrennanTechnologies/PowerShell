<#
.SYNOPSIS
This command can be used to add a new secret to the Thycotic Secret server.

.DESCRIPTION
This command can be used to add a new secret to the Thycotic Secret server.

.PARAMETER SecretName
The desired name of the Secret that will be created.

.PARAMETER FolderName
The name of the Folder on the Secret Server where this secret will placed upon creation.

.PARAMETER SecretTemplate
The name of the Secret Template in which will be used as a reference for creating the new secret. The new secret will be of the same type as what is specified here.

.PARAMETER Password
The desired value that will be included in the secret's password field.

.PARAMETER ArgumentList
Any additional arguments that should be added or set on the secret object.

.EXAMPLE
Add-Secret -SecretName "Test Secret" -FolderName 'Test Folder' -SecretTemplate 'Office365 Account' -Password $(New-SecurePassword) -ArgumentList @{Domain= "onmicrosoft.com";UserName = "admin@$OnMicrosoftDomainName";Notes="O365 Admin account for Test Company";TenantId="1234-5678";}

.NOTES
General notes
#>
Function Add-Secret {
    [cmdletbinding()]
    Param(
        [ValidateNotNull()]
        [Parameter(Mandatory)]
        [String]$SecretName
        ,
        [ValidateNotNull()]
        [String]$Password
        ,
        [ValidateNotNull()]
        [Hashtable]$ArgumentList
    )
    DynamicParam {

        #Parameter Details - Secret Templates
        $ParameterName_SecretTemplate = 'SecretTemplate'
        $RunTimeDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]

        $ParamAttribute = New-Object System.Management.Automation.ParameterAttribute
        $ParamAttribute.Mandatory = $true
        $ParamAttribute.Position = 2

        $AttributeCollection.Add($ParamAttribute)

        #Parameter Validation Items
        $secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
        $secretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
        $ValidateItems = $secretWS.GetSecretTemplates() | Select -ExpandProperty SecretTemplates | Select -ExpandProperty Name
        $ValidateSetAttribute = New-Object System.Management.Automation.ValidateSetAttribute($ValidateItems)

        #Add Validated Set to an Collection Array
        $AttributeCollection.Add($ValidateSetAttribute)

        #Create the Runtime Param with the Collection Array
        $RunTimeParam = New-Object System.Management.Automation.RuntimeDefinedParameter($ParameterName_SecretTemplate, [string], $AttributeCollection)
        $RunTimeDictionary.Add($ParameterName_SecretTemplate, $RunTimeParam)


        ### ###

        #Parameter Details - Secret Templates
        $ParameterName_FolderName = 'FolderName'
        #$RunTimeDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]

        $ParamAttribute = New-Object System.Management.Automation.ParameterAttribute
        $ParamAttribute.Mandatory = $true
        $ParamAttribute.Position = 3

        $AttributeCollection.Add($ParamAttribute)

        #Parameter Validation Items
        #$secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
        #$secretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
        $ValidateItems = $Secretws.SearchFolders('') | Select -ExpandProperty Folders | Select -ExpandProperty Name
        $ValidateSetAttribute = New-Object System.Management.Automation.ValidateSetAttribute($ValidateItems)

        #Add Validated Set to an Collection Array
        $AttributeCollection.Add($ValidateSetAttribute)

        #Create the Runtime Param with the Collection Array
        $RunTimeParam = New-Object System.Management.Automation.RuntimeDefinedParameter($ParameterName_FolderName, [string], $AttributeCollection)
        $RunTimeDictionary.Add($ParameterName_FolderName, $RunTimeParam)

        #Return Parameter Dictionary
        Return $RunTimeDictionary

    }

    Begin {
        $SecretTemplateName = $PSBoundParameters[$ParameterName_SecretTemplate]
        $FolderName = $PSBoundParameters[$ParameterName_FolderName]

        $SecretTemplate = $secretWS.GetSecretTemplates() | Select -ExpandProperty SecretTemplates | ? {$_.Name -eq $SecretTemplateName}
        $SecretFolderId = $secretWS.SearchFolders($FolderName) | Select -ExpandProperty Folders | Select -ExpandProperty Id
        $SecretItemFields = @()
        $SecretItemValues = @()

        #Generate a password if none is provided
        If (   ($Password -eq $null) -or ($Password -eq "")   ) {

            Try {
                $Password = New-SecurePassword
            }

            Catch {
                Write-Warning "Failed to make connection to thes secrets server."
                Exit
            }
        }
    }

    Process {
        #$SecretItemFields = ((221, "Domain"), (224, "Username"), (223, "Password"), (222, "Notes"))
        $SecretTemplate.Fields | % {
            $SecretItemFields += [PSCustomObject]@{Name = "$($_.DisplayName)"; Id = "$($_.Id)"; Value = ""; IsPassword = "$($_.IsPassword)"}
        }

        #Populate SecretItemFields with either a Splatted argument list or a Read-Host
        $SecretItemFields | % {
            If ($_.IsPassword -eq "True") {
                $_.Value = $Password
            }
            Else {
                $currentProperty = $_.Name
                If (     [Boolean]$ArgumentList.$currentProperty -eq $true     ) {
                    $_.Value = $ArgumentList.$currentProperty
                }
                else {
                    #Set blank value
                    $_.Value = ""
                }
            }
        }

        # Original SecretItemValue command: $SecretItemValues = ($Domain,$UserName,$Password, "")
        $SecretItemFields | % {
            $SecretItemValues += $($_.Value)
        }

        Try {
            $secretWS.AddSecret($SecretTemplate.ID, $SecretName, $SecretItemFields.Id, $SecretItemValues, $SecretFolderId)
            Write-Host -Foregroundcolor Cyan "The Secret $SecretName been created."
            Write-Host -Foregroundcolor Cyan "SecretId: $($SecretTemplate.ID)"
            Write-Host -Foregroundcolor Cyan "SecretName: $($SecretName)"
            $SecretItemFields | % {
                If ($_.IsPassword -eq $true) {
                    Write-Host -Foregroundcolor Cyan "Password: ******"
                }
                Else {
                    Write-Host -Foregroundcolor Cyan "$_"
                }

            }

            Write-Host -Foregroundcolor Cyan "SecretFolderId: $SecretFolderId"
        }
        Catch {
            Write-Warning "There was an error trying to create the new password."
        }

    }

}