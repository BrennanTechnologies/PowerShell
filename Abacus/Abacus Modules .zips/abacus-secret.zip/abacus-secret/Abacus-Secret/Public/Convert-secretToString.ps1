<#
.SYNOPSIS
The following will convert a Secret Object to a username and password string.

.DESCRIPTION
This command converts a SecretObject into a string which is outputted to the console containing the username and password.

.PARAMETER secretObject
The SecretObject retrieved from the Secret Server.

.PARAMETER secretServer
The URI of the secret server.

.EXAMPLE
$SecretObject | Convert-secretToString

.NOTES
N/A
#>

Function Convert-secretToString {
    [cmdletbinding()]
    Param(
        [parameter(ValueFromPipeline,Mandatory=$True,Position=1)]
        [System.Object]$secretObject,
        $secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
    )

        Write-Verbose "Input : $secretObject"
        Write-Verbose "Input Count: $($secretObject.count)"
        if($secretObject.count -ne 1){
            throw "select only one secret"
        }

        Try {
            $secretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
            $wsResult = $secretWS.GetSecret($secretObject.SecretID, $false, $null)
            Write-Verbose "wsResult: $wsResult"
        }
        Catch{
            Throw "failed to make connection"
        }

        #Store the Secret object
        $SecretItem = $($wsResult.Secret.Items)

        #If the Secret contains a username store it, we will return it later
        If (   ($($SecretItem.FieldDisplayName) -Contains 'UserName') -eq $True   ) {
            Write-Verbose "UserName detected in secret"
            $UserName = $($SecretItem | ?{ $_.FieldDisplayName -eq 'UserName'}).Value
        }
        Else {
            Write-Verbose "UserName not detected in secret"
            $UserName = $null
        }

        #Store whichever field contains the Secret password
        $Password = ($SecretItem | ?{$_.IsPassword -eq $True}).Value

        #If the Secret contains a username, return it along with the password, otherwise only return the password
        If (   ($UserName -ne $null) -and ($UserName -ne "")   ) {
            Write-Verbose "Username: $UserName"
            Write-Verbose "Password: $Password"
            $creds = @{
                'username' = $username
                'password' = $Password
            }
        }
        Else {
            Write-Verbose "Password: $Password"
            $creds = $Password
        }

        return $creds
    }