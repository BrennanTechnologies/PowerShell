﻿<#
.SYNOPSIS
Checks for errors in a given Secret Server object.

.DESCRIPTION
Checks for errors in a given Secret Server object.

.PARAMETER ssResult
Result from the Secret Server

.EXAMPLE
GetSSError [Secret Server Object]

.NOTES
Legacy
#>

Function GetSSError ($ssResult) {

    # Checks for a null result, or an error thrown from the Secret Server
    If ($ssResult -eq $Null) {
        Return $True
    }
    Elseif($ssResult.Errors.Length -gt 0){
        # Return $ssResult.Errors[0]
        Return $True
    }
    Else {
        Return $False
    }

}
