<#
.SYNOPSIS
This command returns all attributes of a secretObject.

.DESCRIPTION
This command takes in a raw secretObject and outputs all of the SecretObject's attributes.

.PARAMETER SecretId
The SecretId of the SecretObject to query for its attributes.

.PARAMETER secretServer
The URI of the Secret Server.

.EXAMPLE
Get-SecretAttributes -SecretId 240

.EXAMPLE
$SecretObject | Get-SecretAttributes

.NOTES
N/A
#>
Function Get-SecretAttributes {
    [CmdletBinding()]
    Param(
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [int]$SecretId
        ,
        [ValidateNotNullOrEmpty()]
        [String]$secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
    )
    Begin {
        Try {
            $secretWS = New-WebServiceProxy -Uri $secretServer -UseDefaultCredential
        }
        Catch {
            Write-Log -LogString "Get-SecretAttributes: Failed to connect to to secret server." -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }
    }
    Process {
        If ($SecretId) {
            Write-Log -LogString "Fetching attributes for secret object $SecretId" -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
            $secretObject = $($secretWS.GetSecret($SecretId, $null, $null))
            $Secret = $secretObject.Secret.Items
            Write-Log -LogString "Attributes feteched for secret object $($secretObject.Secret.Name) - $($secretObject.Secret.Id)" -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }
        Else {
            Write-Log -LogString "Get-SecretAttributes: Unhandled Exception" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }

        Write-Log -LogString "Returning Attributes on '$($secretObject.Secret.Name)' - '$($secretObject.Secret.Id)'" -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        Return $Secret
    }
}