<#
.SYNOPSIS
A command to update a SecretObject on the secret Server.

.DESCRIPTION
This command can be used to update a SecretObject's password and/or other attributes.

.PARAMETER SecretId
The Id of the SecretObject being targeted for updating.

.PARAMETER ArgumentList
The list of arguments (hash table) to be updated for the desired SecretObject.

.PARAMETER Confirm
A Boolean value if a confirmation prompt should be presented before updating the SecretObject.

.PARAMETER secretServer
The Secret Server URI.

.EXAMPLE
Update-Secret -SecretId <SecretId> -ArgumentList @{Password="$(New-SecurePassword)";Notes="This is a new Note";TenantId="1234-5678";}

.NOTES
N/A
#>

Function Update-Secret {
    [cmdletbinding()]
    Param(
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [String]$SecretId
        ,
        [ValidateNotNullorEmpty()]
        [Parameter(Mandatory)]
        [Hashtable]$ArgumentList
        ,
        [ValidateNotNull()]
        [Boolean]$Confirm = $True
        ,
        [ValidateNotNull()]
        [String]$secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
    )
    Begin {
        $NewSecretObj = @{ }
        $SecretDiffObj = @{ }
        $SecretAttributes = @()
    }
    Process {
        If (   [String]::IsNullOrEmpty($SecretId) -eq $True   ) {
            Write-Log -LogString "SecretId cannot be set to a null value" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }

        Try {
            Write-Log -LogString "Connecting to the secret server..." -LogLevel Verbose -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
            $SecretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
        }
        Catch {
            Write-Log -LogString "Could not connect to the secret server" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }

        $Secret = $SecretWS.GetSecret($SecretId, $null, $null)
        If ($Null -eq $Secret) {
            Write-Log -LogString "Secret object was not detected" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        }
        $SecretAttributes += $($Secret.Secret.Items)


        $DetectedAttributes = Compare-Object -ReferenceObject $($SecretAttributes.FieldName) -DifferenceObject $($ArgumentList.Keys) -IncludeEqual -ExcludeDifferent | Select -ExpandProperty InputObject

        $DetectedAttributes | % {
            $AttributeToUpdate = $_
            # Store Values for Diff
            If ($AttributeToUpdate -like '*Password*') {
                $SecretDiffObj.Add("$AttributeToUpdate", $(   $($Secret.Secret.Items | ? { $_.FieldName -eq $AttributeToUpdate } | Select -Expand Value) -replace '(\w|\W)', '*'    ))
            }
            Else {
                $SecretDiffObj.Add("$AttributeToUpdate", $($Secret.Secret.Items | ? { $_.FieldName -eq $AttributeToUpdate } | Select -Expand Value    )   )
            }

            # Make change to the local object's properties
            If (   $Secret.Secret.Items.FieldName -eq $($AttributeToUpdate)   ) {
                $($Secret.Secret.Items | ? { $_.FieldName -eq $AttributeToUpdate }).Value = $ArgumentList.$AttributeToUpdate
            }
        }

        $DetectedAttributes | % {
            $AttributeToCheck = $_
            # Store Values for Diff
            If ($AttributeToCheck -like '*Password*') {
                $NewSecretObj.Add($AttributeToCheck, $(   $($Secret.Secret.Items | ? { $_.FieldName -eq $AttributeToCheck } | Select -Expand Value) -replace '(\w|\W)', '*'   ))
            }
            Else {
                $NewSecretObj.Add($AttributeToCheck, $($Secret.Secret.Items | ? { $_.FieldName -eq $AttributeToCheck } | Select -Expand Value))
            }
        }

        Write-Log -LogString "Secret Name: $($Secret.Secret.Name)" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
        Write-Log -LogString "Secret Id: $($SecretId)" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject


        Write-Log -LogString "`n`nBefore <===" -LogLevel Output -LogObject $SecretLogObject
        Write-Log -LogString "$($SecretDiffObj | ConvertTo-Json)" -LogLevel Output -LogObject $SecretLogObject
        Write-Log -LogString "Before <===`n`n" -LogLevel Output -LogObject $SecretLogObject

        Write-Log -LogString "After ===>" -LogLevel Output -LogObject $SecretLogObject
        Write-Log -LogString "$($NewSecretObj | ConvertTo-Json)" -LogLevel Output -LogObject $SecretLogObject
        Write-Log -LogString "After ===>" -LogLevel Output -LogObject $SecretLogObject

        If ($Confirm -eq $True) {
            While ($Answer -ne "y" -and $Answer -ne "n") {
                $Answer = Read-Host -Prompt "Do you wish to continue with these changes? y/n"
            }
            Switch ($Answer) {
                'y' {
                    Try {
                        Write-Log -LogString "Updating Secret..." -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                        $SecretWS.UpdateSecret($Secret.Secret) | Out-Null
                        Write-Log -LogString "Secret updated sucessfully" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                    }
                    Catch {
                        Write-Log -LogString "There was an error updating the secret" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                    }
                }
                'n' {
                    Write-Log -LogString "Aborting... No changes have been made." -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                }
                Default {
                    Write-Log -LogString "Unhandled Exception" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                }
            }
        }
        Else {
            Try {
                Write-Log -LogString "Updating Secret..." -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
                $SecretWS.UpdateSecret($Secret.Secret) | Out-Null
                Write-Log -LogString "Secret updated sucessfully" -LogLevel Output -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
            }
            Catch {
                Write-Log -LogString "There was an erorr updating the secret" -LogLevel TerminatingError -LineNumber $(Get-CurrentLineNumber) -LogObject $SecretLogObject
            }
        }
    }
}