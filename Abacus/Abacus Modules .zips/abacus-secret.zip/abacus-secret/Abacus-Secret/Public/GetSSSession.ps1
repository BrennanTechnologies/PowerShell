﻿<#
.SYNOPSIS
Establishes a Secret Server connection.

.DESCRIPTION
Establishes a Secret Server connection.

.EXAMPLE
GetSSSession

.NOTES
LEGACY
#>

Function GetSSSession () {
    $ssURI = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"

    Try {
        $ssSession = New-WebServiceProxy -URI $ssURI -UseDefaultCredential -ErrorAction Stop
    }
    Catch {
        Return $False
    }

    Return $ssSession
}