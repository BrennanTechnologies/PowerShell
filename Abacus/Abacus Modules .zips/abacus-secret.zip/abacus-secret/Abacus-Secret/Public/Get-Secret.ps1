<#
.SYNOPSIS
A command to query Secret Server for one or more secretObjects.

.DESCRIPTION
This command queries the Secret Server for one or more secretObjects based on multiple parameters.

.PARAMETER SecretName
The name of the SecretObject you are querying for.

.PARAMETER SecretId
The SecretId of the SecretObject you are querying for.

.PARAMETER SecretTypeID
The Id of the SecretType you are querying for.

.PARAMETER FolderId
The Id of the Folder in which the SecretObject you are querying for is located in.

.PARAMETER secretServer
The URI of the SecretServer.

.EXAMPLE
Get-Secret -SecretName TestSecret

.EXAMPLE
Get-Secret -SecretId 120

.EXAMPLE
Get-Secret -SecretName GenericSecret -SecretTypeID 2 -FolderId 4

.NOTES
General notes
#>

Function Get-Secret {
[cmdletbinding()]
Param(
    [parameter(ValueFromPipeline,Position=1)]
    [String]$SecretName,
    [int]$SecretId,
    [int]$SecretTypeID,
    [int]$FolderId,
    [String]$secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx"
)
try {
    $secretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
    Write-Verbose $secretWS
}catch{
    throw "failed to make connection"
}

    $secretObjects = $($secretWS.SearchSecrets($SecretName, $null, $null)).SecretSummaries
    Write-Verbose "Total secret objects Queried by name: $($secretObjects.count)"

    if($SecretTypeID){
        Write-Verbose "filtering SecretTypeID: $SecretTypeID"
        $secretObjects = $secretObjects | ? {$_.SecretTypeID -match $SecretTypeID}
        Write-Verbose "Total secret objects after filter: $($secretObjects.count)"
    }

    if($FolderId){
        Write-Verbose "filtering FolderId: $FolderId"
        $secretObjects = $secretObjects | ? {$_.FolderId -match $FolderId}
        Write-Verbose "Total secret objects after filter: $($secretObjects.count)"
    }

    if($SecretId){
        Write-Verbose "filtering SecretId: $SecretId"
        $secretObjects = $secretObjects | ? {$_.SecretId -eq $SecretId}
        Write-Verbose "Total secret objects after filter: $($secretObjects.count)"
    }


    return $secretObjects

}