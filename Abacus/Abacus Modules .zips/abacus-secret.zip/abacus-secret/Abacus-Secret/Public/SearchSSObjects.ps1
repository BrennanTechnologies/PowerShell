﻿<#
.SYNOPSIS
Returns Secret Server object(s) based on search string.

.DESCRIPTION
Returns Secret Server object(s) based on search string.

.PARAMETER ssSession
The Secret Server session.

.PARAMETER searchString
The search string to use against the Secret Server.

.EXAMPLE
SearchSSObjects $ssSession "abacus agadmin"

.NOTES
LEGACY
#>

Function SearchSSObjects ($ssSession, $searchString) {

    # Get Secret Server objects based on our search string
    $ssObjects = $ssSession.SearchSecrets($searchString, $null, $null) | Foreach { $_.SecretSummaries }

    # Check for errors
    $Err = GetSSError $ssObjects

    If (!($Err)) {
        Return $ssObjects
    }
    Else {
        Return $False
    }
}