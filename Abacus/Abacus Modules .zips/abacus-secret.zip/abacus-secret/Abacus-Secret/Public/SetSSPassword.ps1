﻿<#
.SYNOPSIS
Sets the password for a given Secret Server Object.

.DESCRIPTION
Sets the password for a given Secret Server Object.

.PARAMETER ssSession
The Secret Server session.

.PARAMETER ssObject
The Secret Server SecretObject.

.PARAMETER Password
The desired password to be set.

.EXAMPLE
SetSSPassword $ssSession [Secret Server Object] "newpassword"

.NOTES
LEGACY
#>

Function SetSSPassword ($ssSession, $ssObject, $Password) {

    $ssResult = GetSSObject $ssSession $ssObject

    # Loop through each item in the object to find the Password field
    Foreach ($Item in $ssResult.Secret.Items) {
        If ($Item.FieldDisplayName -eq "Password") {
            $Item.Value = $Password
            $ssResult = $ssSession.UpdateSecret($ssResult.Secret)

            # Check for errors
            If (GetSSError $ssResult) {
                Return $False
            }
            Else {
                Return $True
            }
        }
    }

    Return $False
}