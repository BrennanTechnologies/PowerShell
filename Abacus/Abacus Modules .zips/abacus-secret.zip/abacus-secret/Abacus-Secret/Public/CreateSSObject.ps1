﻿<#
.SYNOPSIS
A legacy method for creating Secret Object.

.DESCRIPTION
A legacy method for creating Secret Object.

.PARAMETER ssSession
Secret Server Sessions.

.PARAMETER Template
Secret Server template.

.PARAMETER Folder
Secret Server folder.

.PARAMETER Domain
Domain name for the secret object.

.PARAMETER Username
A username for the secret object.

.PARAMETER Password
Password for the secret object.

.EXAMPLE
CreateSSObject [SS Session Object] [SS Template Object] [SS Folder Object] "ezevonage.corp" "account" "password123"

.NOTES
Legacy.
#>

Function CreateSSObject ($ssSession, $Template, $Folder, $Domain, $Username, $Password) {

    # Initialize new secret
    $ssObject = $ssSession.GetNewSecret($Template.Id, $Folder.Id)

    # Set all relevant properties of new secret object
    If (GetSSError $ssObject) {
        Return $False
    }
    Else {

        # Secret name
        $ssObject.Secret.Name = "$Domain - $Username"

        # Secret fields (Domain, Username, Password, etc...)
        SetSSField $ssObject "Domain" $Domain
        SetSSField $ssObject "Username" $Username
        SetSSField $ssObject "Password" $Password

        # Commit new secret
        $ssResult = $ssSession.AddNewSecret($ssObject.Secret)

        # Check for any errors
        If (GetSSError $ssResult) {
           Return $False
        }
        Else {
           Return $True
        }
    }

}