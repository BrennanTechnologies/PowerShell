<#
.SYNOPSIS
This command is used to generate a new random password.

.DESCRIPTION
This command is used to generate a new random secure password with a desired character limit.

.PARAMETER PasswordLength
The number of characters (length) that the new password should be.

.EXAMPLE
New-SecurePassword

.EXAMPLE
New-SecurePassword -PasswordLength 12

.NOTES
N/A
#>

Function New-SecurePassword {
    [cmdletbinding()]
    Param(
        [Int]$PasswordLength = 15
    )
    Begin {
        [String]$generatedPwd = ""
    }
    Process {
        While (   ($generatedPwd.Length -lt $PasswordLength)   ) {
            #$Numbers = [Char]($(get-random -Minimum 48 -Maximum 57))
            #$UpperCaseChars = [Char]($(get-random -Minimum 65 -Maximum 90))
            #$LowerCaseChars = [Char]($(get-random -Minimum 97 -Maximum 122))
            $generatedPwd += Get-Random $(Get-Random '!','@','#','$','%','^','&','*','(',')','_' -Minimum 1),`
                                        $([Char]$(Get-Random -Minimum 48 -Maximum 57)),`
                                        $([Char]$(Get-Random -Minimum 65 -Maximum 90)),`
                                        $([Char]$(Get-Random -Minimum 97 -Maximum 122)) -Minimum 1
        }
        $PadPassword = [Boolean]$(Get-Random -Maximum 2 -Minimum 0)
        While ($True -eq $PadPassword) {
            $PadPassword = [Boolean]$(Get-Random -Maximum 2 -Minimum 0)
            If (   ($generatedPwd.Length -lt $PasswordLength)   ) {
                If ($True -eq $PadPassword){
                    $generatedPwd += Get-Random $(Get-Random '!','@','#','$','%','^','&','*','(',')','_' -Minimum 1),`
                                                $([Char]$(Get-Random -Minimum 48 -Maximum 57)),`
                                                $([Char]$(Get-Random -Minimum 65 -Maximum 90)),`
                                                $([Char]$(Get-Random -Minimum 97 -Maximum 122)) -Minimum 1
                }
            }
        }
    }
    End {
        Return $($generatedPwd)
    }
}