﻿<#
.SYNOPSIS
Returns Secret Server object properties based on a given object.

.DESCRIPTION
Returns Secret Server object properties based on a given object.

.PARAMETER ssSession
The Session to the Secret Server.

.PARAMETER ssObject
The Secret Server Object.

.EXAMPLE
GetSSObject $ssSession [Secret Server Object]

.NOTES
LEGACY
#>

Function GetSSObject ($ssSession, $ssObject) {
    $ssObject = $ssSession.GetSecret($ssObject.SecretID, $False, $Null)

    # Check for errors
    If (GetSSError $ssObject) {
        Return $False
    }
    Else {
        Return $ssObject
    }
}
