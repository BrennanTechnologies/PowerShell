﻿<#
.SYNOPSIS
Returns Secret Server template object based on a given template type.


.DESCRIPTION
Returns Secret Server template object based on a given template type.

.PARAMETER ssSession
The Secret Server Session.

.PARAMETER ssTemplateType
The Secret Server Secret template.

.EXAMPLE
GetSSTemplate $ssSession "Active Directory Account"

.NOTES
LEGACY
#>

Function GetSSTemplate ($ssSession, $ssTemplateType) {

    # Gets a list of all template objects from Secret Server
    $ssTemplates = $ssSession.GetSecretTemplates()

    # Loop through all templates and select the one that matches our given template string.
    # Ex. "RPC - Active Directory Account"
    If (GetSSError $ssTemplates) {
        Return $False
    }
    Else {
        Foreach ($ssTemplate in ($ssTemplates | Select-Object -ExpandProperty SecretTemplates)) {
            If ($ssTemplate.Name -eq $ssTemplateType) {
                Return $ssTemplate
            }
        }

        Return $False
    }
}