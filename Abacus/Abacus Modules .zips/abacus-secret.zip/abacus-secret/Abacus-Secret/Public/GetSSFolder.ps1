﻿<#
.SYNOPSIS
Returns Secret Server folder object based on a given folder name.

.DESCRIPTION
Returns Secret Server folder object based on a given folder name.

.PARAMETER ssSession
The Secret Server Session.

.PARAMETER folderName
The Secret Server folder name.

.EXAMPLE
GetSSTemplate $ssSession "Client Agadmin Accounts"

.NOTES
LEGACY
#>

Function GetSSFolder ($ssSession, $folderName) {

    # Searches for a folder object by name
    $ssFolder = $ssSession.SearchFolders($folderName)

    # Will only return the first result we find
    If (GetSSError $ssFolder) {
        Return $False
    }
    Else {
        Return $ssFolder.Folders[0]
    }
}