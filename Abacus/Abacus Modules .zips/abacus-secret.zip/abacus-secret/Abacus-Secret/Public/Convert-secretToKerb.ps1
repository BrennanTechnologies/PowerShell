
<#
.SYNOPSIS
A command to convert a secret object to a PSCredential Object.

.DESCRIPTION
This command can be used to convert a secret Object to a PSCredential object for PowerShell credential passing.

.PARAMETER secretObject
The raw SecretObject obtained from the secret server.

.PARAMETER secretServer
The URI of the secret server to query.

.PARAMETER domain
The domain associated with the username contained within the secret object.

.PARAMETER prefix
A switch parameter to supply if '\' should be included to match the domain\username.

.EXAMPLE
$SecretObject | Convert-SecretToKerb

.NOTES
N/A
#>

Function Convert-secretToKerb {
    [cmdletbinding()]
    Param(
        [parameter(ValueFromPipeline, Mandatory = $True, Position = 1)]
        [System.Object]$secretObject,
        $secretServer = "https://secret.accessabacus.com/ss/winauthwebservices/sswinauthwebservice.asmx",
        [String]$domain,
        [switch]$prefix
    )

    Write-Log -LogString "Domain: $domain" -LogLevel Verbose -LogObject $SecretLogObject
    Write-Log -LogString "Prexfix: $prefix" -LogLevel Verbose -LogObject $SecretLogObject
    Write-Log -LogString "Input : $secretObject" -LogLevel Verbose -LogObject $SecretLogObject
    Write-Log -LogString "Input Count: $($secretObject.count)" -LogLevel Verbose -LogObject $SecretLogObject
    if ($secretObject.count -lt 1) {
        Write-Log -LogString "SecretObject count cannot be less than 1. Count: {$($secretObject.count)} " -LogLevel TerminatingError -LogObject $SecretLogObject
    }
    elseif ($secretObject.count -gt 1) {
        Write-Log -LogString "SecretObject count cannot be greater than 1. Count: {$($secretObject.count)}" -LogLevel TerminatingError -LogObject $SecretLogObject
    }

    try {
        $secretWS = New-WebServiceProxy -uri $secretServer -UseDefaultCredential
        $wsResult = $secretWS.GetSecret($secretObject.SecretID, $false, $null)
        Write-Log -LogString "wsResult: {$wsResult}" -LogLevel Verbose -LogObject $SecretLogObject
    }
    catch {
        Write-Log -LogString "Failed to make a connection to the secrect server.`n Exception: {$($_.Exception)}" -LogLevel TerminatingError -LogObject $SecretLogObject
    }

    $username = $($wsResult.Secret.Items |? {$_.FieldDisplayName -eq "Username"}).value
    if ($domain) {
        if ($prefix) {
            $username = $domain + "\" + $username
        }
        else {
            $username = $username + "@" + $domain
        }

    }
    Write-Log -LogString "Username: $username" -LogLevel Verbose -LogObject $SecretLogObject
    $Password = ConvertTo-SecureString -String $($wsResult.Secret.Items |? {$_.FieldDisplayName -eq "Password"}).value -AsPlainText -Force
    Write-Verbose "Password: $Password"

    $Creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username, $Password

    return $Creds

}