## SQL Query Examples

Example: **Select**  
` $Query = [string]"Select * FROM [dbo].[$Table]" `

Example: **Insert**  
` $Query = [string]"INSERT INTO [dbo].[$Table] ([FName],[LName]) VALUES ('$FName','$LName')" `

Example: **Update**  
` $Query = [string]" UPDATE [dbo].[$Table] SET [LName] = '$NewLName' WHERE ID ='$ID' " `

Example: **Delete**  
` $Query = [string]" DELETE FROM [dbo].[$Table] WHERE ID = '$ID' " `

