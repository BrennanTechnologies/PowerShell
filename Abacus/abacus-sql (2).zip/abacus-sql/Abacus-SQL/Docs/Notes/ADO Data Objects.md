## ADO Data Objects

|      Data Object     |  Notes                                                                                                                |
|----------------------|---------------------------------------------------------------------------------------------------------------------- |
| DataSet              | Contains one or more DataTable objects based on the resultset of the Command executed in the DataAdapter Fill method. |
| DataSet Object       | The container for a number of DataTable objects.  This is the object the  DataAdapter’s Fill method populates.        |
| DataTable Object     | Allows you to examine data through collections of rows and columns.  The DataSet contains one or more DataTable objects based on the resultset of the Command executed in the |
| DataRow Object       | Provides access to the DataTable’s Rows collection.                                                                   |
| DataColumn Object    | Corresponds to a column in your table.                                                                                |
| Constraint Object    | Defines and enforces column constraints.                                                                              |
| DataRelation Object  | Defines the relations between DataTables in the DataSet object.                                                       |
| DataView Object      | Allows you to examine DataTable data in different ways.                                                               |


