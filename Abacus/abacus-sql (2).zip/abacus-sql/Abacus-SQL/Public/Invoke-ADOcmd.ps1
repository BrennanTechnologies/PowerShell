<#
.SYNOPSIS
Invoke a .NET ADO Database Connection & Runs a SQL Query.

.DESCRIPTION
Invoke a .NET ADO Database Connection & Runs a SQL Query.

.PARAMETER ServerInstance
A string that specifies the name of an instance of the Database Engine.

.PARAMETER Database
Specifies the name of a database. This cmdlet connects to this database in the instance that is specified in the ServerInstance parameter.

.PARAMETER Query
Specifies the SQL query that this cmdlet will run. 

Example 1:  Select  
    $Query = [string]"Select * FROM [dbo].[$Table]"

Example 2:  Insert  
    $Query = [string]"INSERT INTO [dbo].[$Table] ([FName],[LName]) VALUES ('$FName','$LName')"

Example 3:  Update  
    $Query = [string]" UPDATE [dbo].[$Table] SET [LName] = '$NewLName' WHERE ID ='$ID' "

Example 4:  Delete  
    $Query = [string]" DELETE FROM [dbo].[$Table] WHERE ID = '$ID' "

.EXAMPLE
Invoke-ADOcmd -ServerInstance $ServerInstance -Database $Database -Query $Query

.PARAMETER Quiet
Suppress console output.

.OUTPUTS
ExitCode: 
    Success = $True
    Error   = $False

.NOTES

#>

function Invoke-ADOcmd {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [string]$ServerInstance = "nymgmtdodb01.management.corp\MSSQLSERVER,1433"
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Database
        ,
        [Parameter(Mandatory = $True)]
        [ValidateNotNullOrEmpty()]
        [string]$Query
        ,
        [Parameter(Mandatory = $False)]
        [switch]$Quiet
        )
    Begin {    
        ### Create Database Connection String
        ###----------------------------------
        $ConnectionString = "Data Source=$ServerInstance;Initial Catalog=$Database;Integrated Security=true;"
        ### Open DB Connection
        ###----------------------------------
        $Connection = New-Object System.Data.SqlClient.SqlConnection
        $Connection.ConnectionString = $ConnectionString
        $Connection.Open()
        ### SQL Command
        ###----------------------------------
        $SQLCommand = New-Object System.Data.SqlClient.SqlCommand
        $SQLCommand.Connection = $Connection
        $SQLCommand.CommandText = $Query
        # Create Exit Code Object 
        ###----------------------------------
        $Status = [PSCustomObject]@{
            ServerInstance  = $ServerInstance
            Database        = $Database
            ExitCode        = $null
        }

        # Set Query Type
        ###----------------------------------
        if((($Query.ToUpper()).Trim()).StartsWith("SELECT")){
            $DateReader = $True
        }
        else{
            $DateReader = $False
        }
    }
    Process {
        if($DateReader){
            ### Execute "Select" SQL Queries
            ###----------------------------------
            try {
                $DataReader = $SQLCommand.ExecuteReader()
                $DataTable = New-Object 'System.Data.DataTable'
                $DataTable.Load($DataReader)
                $Status.ExitCode = $True
            } 
            catch {
                Write-Warning -Message ("ERROR EXECUTING SQL: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message) 
                $Status.ExitCode = $False
                return $Status.ExitCode
            }
            return $DataTable
        }
        else {
            ### Execute All Other SQL Queries
            ###----------------------------------
            try {
                $SQLCommand.ExecuteNonQuery() | Out-Null
                $Status.ExitCode = $True
            } 
            catch {
                Write-Warning -Message ("ERROR EXECUTING SQL: " + $((Get-PSCallStack)[0].Command) + "`n`r" + $global:Error[0].Exception.Message) 
                $Status.ExitCode = $False
            }
            if(-Not $Quiet){
                return $Status
            }
        }
    }
    End {
        ### Close DB Connection
        ###----------------------------------
        $Connection.Close()
    }
}
