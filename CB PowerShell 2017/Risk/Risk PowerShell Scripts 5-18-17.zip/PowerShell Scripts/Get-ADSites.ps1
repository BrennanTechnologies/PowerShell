﻿$Sites = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Sites 

foreach ($Site in $Sites)
{
     Write-Host $Site.Name -ForegroundColor Yellow
     $Site.Servers #.Name
}