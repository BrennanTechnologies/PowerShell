﻿        cls

        $Path = "\\col-file01\Shared\2016 Budget"
        $Path = "\\col-file01\Shared\2016"
        $Path = "S:\2016 Budget"
        $AllFiles = Get-ChildItem -path $Path -recurse -File 
        #$AllFiles = Get-ChildItem -path \\col-file01\Shared\2016 -recurse -File 

        $AllFiles
