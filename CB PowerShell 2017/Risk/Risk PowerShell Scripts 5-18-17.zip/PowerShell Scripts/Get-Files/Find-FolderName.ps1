﻿  cls

############################
# Set Path to Search
############################
$Path = "\\col-file01\shared"
#$Path = "\\col-file01\Shared\Worksmart"
#$Path = "\\col-file01\Shared\1-Chicago\_WorkSmart Training Folder"
#$Path = "\\col-file01\Shared\CBrennan"
#$Path = "\\col-file01\Shared\Catawba College\"
#$Path = "\\col-file01\Shared\1-Chicago\1-Chicago D&O\"
#$Path = "\\col-file01\Shared\NNJ\document"
$Path = "\\col-file01\Shared\"

  write-host "Recursing Folders in: $Path" -foregroundcolor Yellow
  $RootFolders = 
  get-childitem $Path -Directory -Recurse | Where-Object {$_.name -like "Alexander"}

      