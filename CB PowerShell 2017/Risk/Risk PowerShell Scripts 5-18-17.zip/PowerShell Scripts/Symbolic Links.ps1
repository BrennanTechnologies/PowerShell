﻿# Create Test Folder
Set-Location c:\Foo\SlTest
mkdir C:\Foo\SlTest
#
# Now a subfolder
mkdir C:\Foo\SlTest\Real
#
# And a real doc
1..10 | Out-File c:\Foo\SlTest\Real\foo.txt
#
# Now create a symbolic link
New-Item -ItemType SymbolicLink -Name .\virtual -Target .\real   
#
# And a symlink for a file
New-Item -ItemType SymbolicLink -Name .\SYMfoo.txt  -Target .\real\foo.txt
#
# You can also create a hard link
New-Item -ItemType HardLink     -Name .\hard.txt  -Target .\real\foo.txt