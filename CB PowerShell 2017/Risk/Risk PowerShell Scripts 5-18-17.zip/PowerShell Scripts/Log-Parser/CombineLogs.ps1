﻿cls

$Server = "col-dc01"
$LogPath = "\\" + $Server + "\C$\Windows\System32\winevt\Logs"

$LogParser = "\\col-file01\Users\cbrennan\LogParser\LogParser.exe"


$LogSource = "\\col-dc01\C$\windows\System32\Winevt\logs\*"

$LogDestination = "\\col-file01\e$\users\cbrennan\eventlogs\combined.evt"



#LogParser.exe -i:iisw3c "select * into combinedLogFile.log from *.log order by date, time" -o:w3c

#LogParser -I:EVT "select * into E:\logs\merged.log from E:\logs\WEB35\*, E:\logs\WEB36\*, E:\logs\WEB37\*" -o:csv


$Args = "-i:EVT 'select * into '\\col-file01\e$\users\cbrennan\eventlogs\combined.evt' from \\col-dc01\C$\windows\System32\Winevt\logs\*' #-o:csv"

#start-process -filepath $LogParser -ArgumentList $Args -NoNewWindow

$LogPath = "c:\windows\system32\winevt\logs\*"

c:\LogParser\LogParser.exe -i:evt "Select * from \\col-file01\Security" -o:CSV

#“SELECT * FROM \\col-file01\Security” -o:CSV -q:ON -stats:OFF >> c:\temp\Events.csv