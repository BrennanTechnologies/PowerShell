﻿#Get-WmiObject Win32_MappedLogicalDisk -computer 10.2.5.78 | select name, providername

psexec \\10.2.5.78 cmd


net use n: \\file01\shared /persistent:yes
#new-pssession -ComputerName 10.2.5.78
