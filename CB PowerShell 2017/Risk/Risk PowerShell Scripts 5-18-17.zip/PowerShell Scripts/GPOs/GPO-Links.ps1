﻿cls
Import-Module grouppolicy


#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies"


$AllOUs =  Get-ADOrganizationalUnit -Filter * -Properties * #-SearchBase $Domain -SearchScope Subtree
$AllOSs
exit

Write-Host "`nLinked GPOs`n"
$AllGPOs = Get-GPO -All $Domain 

ForEach ($GPO in $AllGPOs) 
{
    $GPOID   = $GPO.ID
    $xml = [xml](Get-GPOReport -domain $Domain -guid $GPOID -ReportType xml)

    If ($xml.GPO.LinksTo)
    {
        If ($xml.GPO.Computer.ExtensionData -or $xml.GPO.User.ExtensionData) 
        {
            $gpo.DisplayName
        }
    }
 }

