﻿cls
Import-Module GroupPolicy

$Report = @()
#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies.com"
$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "GPOReport.html"


### Get All Domain GPOs
$AllGPOs = Get-GPO -All $Domain
$AllGPOsCount  = $AllGPOs.count #226


###################################################
### GET OU's
###################################################

### Get All Domain OU's
$AllOUs =  Get-ADOrganizationalUnit -Filter * -Properties *

#$AllOUs

### Select All OU's with Linked GPO's & Expand multivalue field.
#------------->>>>>>>

$LinkedOUs = $AllOUs | select Name, DistinguishedName, @{
    name='LinkedGroupPolicyObjects'
    expression={$_.LinkedGroupPolicyObjects -join ','}
}

### Export Link OU Report
$LinkedOUs | export-csv u:\temp\1.LinkedOUs.csv

#------------->>>>>>>




#$LinkedOUs = Get-ADOrganizationalUnit -Filter * -Properties * | select -ExpandProperty LinkedGroupPolicyObjects 

#(Get-Process)[-1] | Select-Object Name,@{
#name='Threads'
#expression={$_.threads.id -join ','}

$LinkedOUsCount = $LinkedOUs.count #259

### Joint both arrays
foreach ($LinkedOU in $LinkedOUs)
{
    $LinkedGPOID = $LinkedOU.Split('{').Split('}')[1]
    
    #---> $OUName = $AllOUs | Where { -eq }
    
    foreach ($GPO in $AllGPOs)
    {
        ### Link on Key Field
        if ($GPO.Id -eq $LinkedGPOID)
        {
                
            #write-host "Link worked" -ForegroundColor Green
            #$GPO.Id
            #$GPO.DisplayName
            
            # output a new object with the join result
            New-Object PSObject -Property @{
                
                OUName        = $OU.Name;
                GPOId       = $GPO.Id;
                LinkedGPOID = $LinkedGPOID
                GPOName     = $GPO.DisplayName;
            };
    
        $Report   += $PSObject  

        }
    }
}


$Report
$Report.count






###############################################

###$LinkedGPOs = Get-ADOrganizationalUnit -Filter 'Name -like "*lab*"' | select -ExpandProperty LinkedGroupPolicyObjects 



#$OUs = Get-ADOrganizationalUnit -filter * -Properties * #name,distinguishedName,gpLink,gPOptions 
#$OUs | Get-Member

#LinkedGroupPolicyObjects 

################

#Get-ADOrganizationalUnit -filter * -Properties name,distinguishedName,gpLink,gPOptions | Select-Object -Property *,@{label = 'FriendlyGPODisplayName' expression = {$_.LinkedGroupPolicyObjects | ForEach-Object {([adsi]"LDAP://$_").displayName -join ''}


<#
Get-ADOrganizationalUnit -filter {name -like "*test*"} -Properties name,distinguishedName,gpLink,gPOptions |Select-Object -Property *,@{
label = 'FriendlyGPODisplayName'
expression = {$_.LinkedGroupPolicyObjects | ForEach-Object {([adsi]"LDAP://$_").displayName -join ''}
#>
