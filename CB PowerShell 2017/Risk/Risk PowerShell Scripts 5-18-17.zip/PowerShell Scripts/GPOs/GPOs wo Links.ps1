﻿cls
Import-Module GroupPolicy

$Report = @()
#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies.com"
$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "GPOReport.html"


##################################
### Get ALL Domain GPOs
##################################

#$AllGPOs = Get-GPO -All $Domain
#$AllGPOCount = $AllGPOs.count


$GPONoLinks = @()

Get-GPO -All | 
 
    %{ 
       If ( $_ | Get-GPOReport -ReportType XML | Select-String -NotMatch "<LinksTo>" )
        {


        Write-Host $_.DisplayName -ForegroundColor Green
        $GPONoLinks += $_.DisplayName
        
        }
    }

    $GPONoLinks
    $GPONoLinks.count 
    $GPONoLinks | Export-CSV "U:\temp\GPONoLinks.csv" -NoTypeInformation

    #>