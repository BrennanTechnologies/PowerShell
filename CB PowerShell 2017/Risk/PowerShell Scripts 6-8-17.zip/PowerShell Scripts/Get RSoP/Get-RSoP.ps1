﻿$ComputerName = $env:computername
$ReportDate = Get-Date -Format ddmmyyyy
$RSopReportPath = "\\col-dc01\shared\RSopReports\"
$RSopReportFile = $RSopReportPath + $ComputerName +"_RSopReport_" + $Date


#######################################
### Get GPOs
#######################################
$ScriptBlock ="c:\windows\system32\GPResult.exe /r /z /scope USER,COMPUTER /X $RSoPReportFile"
start-process $ScriptBlock

#######################################
### Get Shares
#######################################
$ScriptBlock = "net use"
start process $ScriptBlock


#######################################
### Get Printers
#######################################


### Get Installed Printers
$Printers = Get-WMIObject -Class Win32_Printer -Computer $ComputerName -Property * 

### Select Printer Properties
$PrinterS = $PrinterS | Select-Object -Property Name,Default,PortName,ServerName,Shared,ShareName

### Display Pre-Installed Printers
write-host "Logging All Printers Found for: " $ComputerName -ForegroundColor Yellow
$Printers | ft -auto

### Write Log File
$ReportFile = $ReportPath + $ComputerName + "_Pre-Installed Printers_" + $ReportDate + ".txt"
$Printers | Export-Csv $ReportFile -notype  # Export for Excel
#$Printers | Out-File $ReportFile -force # Export for Text



<#
cls
Import-Module GroupPolicy


$Domain = "DewittStern.com"
#$Domain = "Risk-Strategies.com"

$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "RSOP.html"

### Get-GPResultantSetofPolicy -Path <string> -ReportType {<Xml> | <Html>} [-Computer <string>] [-User <string>] [<CommonParameters>]




get-gpresultantsetofpolicy -reporttype html -path $ReportFile -user risk\cbrennan

#>