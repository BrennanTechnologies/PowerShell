﻿function Get-Script-Directory
{
    $scriptInvocation = (Get-Variable MyInvocation -Scope 1).Value
    return Split-Path $scriptInvocation.MyCommand.Path
}

$ScriptPath = Get-Script-Directory
write-host "Path:" $ScriptPath