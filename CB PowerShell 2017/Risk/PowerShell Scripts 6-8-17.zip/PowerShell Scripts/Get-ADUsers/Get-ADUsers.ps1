﻿cls
Import-Module GroupPolicy

$Report = @()
#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies.com"

$Report = @()

$Users = Get-ADUser  -Filter 'enabled -eq $true' -Properties samAccountName, Name, CanonicalName , scriptpath, homedrive, homedirectory  
$Users | Get-Member

foreach ($User in $Users)
{

    $hash = [ordered]@{            

        AD_Domain             = $Domain
        AD_CanonicalName      = $User.CanonicalName  
        AD_samAccountName     = $User.samAccountName            
        AD_Name               = $User.Name            
        AD_scriptpath         = $User.scriptpath            
        AD_homedrive          = $User.homedrive   
        AD_homedirectory      = $User.homedirectory  
    }                           

    $PSObject =  New-Object PSObject -Property $hash
    $Report   += $PSObject
            
}

$Users | ft samAccountName, Name, scriptpath, homedrive, homedirectory  
$Users.Count


function Write-Report()
 {
     ############################
    # Export & Show the File
    ############################
    function Get-Script-Directory
    {
        $scriptInvocation = (Get-Variable MyInvocation -Scope 1).Value
        return Split-Path $scriptInvocation.MyCommand.Path
    }
    #$ScriptPath = Get-Script-Directory
        
    $ScriptPath = "U:\Reports\"

    $ReportPath = $ScriptPath +"\Reports\"
    

    # Create the Log Folder.
    $ReportPath = $ScriptPath + "\Reports\" 
    if(!(Test-Path -Path $ReportPath)) {New-Item -ItemType directory -Path $ReportPath | out-null}

    $ReportDate = Get-Date -Format ddmmyyyy
    $ReportFile = $ReportPath + "Report_$ReportDate.csv"

    $Report | Export-Csv -Path $ReportFile -NoTypeInformation 
    start-process notepad.exe $ReportFile
}

Write-Report 