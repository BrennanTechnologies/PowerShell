﻿cls
Import-Module GroupPolicy

$Report = @()
#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies.com"
$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "GPOReport.html"


##################################
### Get ALL Domain GPOs
##################################

Write-Host "Getting All GPOs in $Domain`t" -ForegroundColor Magenta

$AllGPOs = @()
$AllGPOs = Get-GPO -All $Domain
$AllGPOCount = $AllGPOs.count
Write-Host "Count of All GPO's: " $AllGPOCount -ForegroundColor Magenta

##################################
### Generate HTML Report
##################################

# Get-GPOReport -All -ReportType html -Path $ReportFile
# Start-Process $ReportFile

#$AppliedGPOs = $AllGPOs | Where {}


$xml = $null

##################################
### Get GPO Properties
##################################
foreach ($GPO in $AllGPOs)
{
    $GPOID   = $GPO.ID
    $GPOName = $GPO.DisplayName
    #$GPOName = "RAN Logon Script"
    
    Write-Host "Generating XML Report for:  " -ForegroundColor Yellow -nonewline
    Write-Host "$GPOName" -ForegroundColor White
    
    ### Reference:
    ### https://blogs.technet.microsoft.com/heyscriptingguy/2013/02/07/use-powershell-to-generate-and-parse-a-group-policy-object-report/

    #######################################
    ### Get XML Report for each GPO
    #######################################

    ### Generate XML Report
    $xml = [xml](Get-GPOReport -domain $Domain -guid $GPOID -ReportType xml)

    ### Ref: <http://www.joseph-streeter.com/?p=1158>
    ###
    ### XML Document Properties
    #$xml.DocumentElement
    #$xml.GPO
    write-host "Domain: " $Domain
    write-host "Name: " $xml.GPO.Name
    write-host "Test: " $xml.GPO.GPOstatus
    write-host "GPO User Enabled: " $xml.GPO.User.Enabled
    write-host "GPO User ExtentionData: " $xml.GPO.User.ExtensionData
    write-host "GPO Comp Enabled: " $xml.GPO.Computer.Enabled
    write-host "GPO Comp ExtentionData: " $xml.GPO.Comp.ExtensionData
    write-host "GPO LinksTo Enabled: " $xml.GPO.LinksTo.Enabled # SOMName

#--------------------->
    
    write-host "GPO LinksTo: "
    #$LinksTo = 
    $xml.GPO.LinksTo
    $xml.GPO.Computer.Enabled
    #write-host "GPO LinksTo: "  $LinksTo  #SOM Name
    
#--------------------->
 
        
    #$xml.GPO.Computer.ExtensionData
    #write-host "GPO CreatedTime: " $xml.GPO.CreatedTime
    #write-host "Owner: " $xml.GPO.SecurityDescriptor.Owner.Name
   


}


<####################
Write-Host "`nUnlinked GPOs`n"
$allGPOs = Get-GPO -All | sort DisplayName
ForEach ($gpo in $allGPOs) {
    $xml = [xml](Get-GPOReport $gpo.Id xml)
    If (!$xml.GPO.LinksTo) {
        $gpo.DisplayName
        }
    }

Write-Host "`nGPOs with no settings`n"
$allGPOs = Get-GPO -All | sort DisplayName
ForEach ($gpo in $allGPOs) {
    $xml = [xml](Get-GPOReport $gpo.Id xml)
    If ($xml.GPO.LinksTo) {
        If (!$xml.GPO.Computer.ExtensionData -and !$xml.GPO.User.ExtensionData) {
            $gpo.DisplayName
            }
        }
    }

##################>


##################################
<#
# GPO Status	Enabled
# Links
#Computer Configuration (Enabled) No settings defined.

$GPONoLinks = @()

Write-Host "Generating XML Report" -ForegroundColor Magenta

$XML= Get-GPO -ALL | Get-GPOReport -ReportType XML
$XML.Contains("Linksto")


foreach ($a in $XML)
{
    $a #.DocumentElement.Computer    
}

exit



Get-GPO -All | 
 
    %{ 
       If ( $_ | Get-GPOReport -ReportType XML | Select-String -NotMatch "<LinksTo>" )
        {


        Write-Host $_.DisplayName -ForegroundColor Green
        $GPONoLinks += $_.DisplayName
        
        }
    }

    $GPONoLinks
    $GPONoLinks.count 
    $GPONoLinks | Export-CSV "U:\temp\GPONoLinks.csv" -NoTypeInformation

    #>