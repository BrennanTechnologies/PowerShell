﻿cls
Import-Module GroupPolicy


$Domain = "DewittStern.com"
#$Domain = "Risk-Strategies.com"

$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "GPOReport.html"

Get-GPOReport -All -ReportType XML -Path $ReportFile

$GPOReport= Get-Content -Path $ReportFile
$GPOReport.Trustee

