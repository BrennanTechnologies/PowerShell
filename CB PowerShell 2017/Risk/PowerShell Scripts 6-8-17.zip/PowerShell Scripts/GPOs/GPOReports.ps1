﻿cls
Import-Module GroupPolicy


$Domain = "DewittStern.com"
#$Domain = "Risk-Strategies.com"

$ReportDir = "u:\temp\GPOReports\"

#Export GPO’s to one HTML report
#Get-GPOReport -All -ReportType html -Path $ReportDir"AllGPOs.html"

# Export each GPO to it’s own HTML report:
#Get-GPO -All | %{$_.displayname}
#Get-GPO -All | %{Get-GPOReport -name $_.displayname -ReportType html -path ($ReportDir+"GPO_"+$_.displayname+".html")}



# Find Gpo’s that don’t apply to no one, and those that apply find out to who’m:
$reportFile = $ReportDir + "GPOApplyToPermissions.csv"
Set-Content -Path $reportFile -Value ("GPO Name,User/Group,Denied")

$AllGPOs = Get-GPO -All

foreach ($GPO in $AllGPOs)
{


#write-host "Status:" $GPO.GpoStatus
#write-host "Type:" $GPO.GetType()


#$GPO.GpoStatus
#$GPO.GetType()

$a = $GPO.GetSecurityInfo()
write-host "Permission:" $a.permission


#    $GPO

#    $GPOName = $GPO.displayName 
#    write-host $GPOName -ForegroundColor Cyan
    
#    [int]$counter = 0
    
#    $Security = $GPO.GetSecurityInfo()

    #$security 
#    $security | where{ $_.Permission -eq "GpoApply"}


    #foreach ()
    #{

    #}
}

<#
Get-GPO -All | %{
    $gpoName = $_.displayName 
    [int]$counter = 0
    $security = $_.GetSecurityInfo()
    $security | where{ $_.Permission -eq "GpoApply" } | %{

        add-Content -Path $reportFile -Value ($gpoName + "," + $_.trustee.name+","+$_.denied)
        $counter += 1
    }

    if ($counter -eq 0)
    {
        add-Content -Path $reportFile -Value ($gpoName + ",NOT APPLIED")
    }
}

#>