﻿cls

#Get-GPO -all | Get-GPOReport -ReportType XML

Get-GPO -all | Get-GPOReport -ReportType HTML -Path U:\temp\GPOReport.html 