﻿cls

Import-Module GroupPolicy
Import-Module ActiveDirectory

$Domain = "DewittStern.com"
#$Domain = "Risk-Strategies.com"

#Get-GPOReport -All -ReportType XML -Path u:\temp\GPO.xml

$GPOs  = @()
$GPOs += Get-GPO $Domain -All


foreach ($GPO in $GPOs)
{
    #$GPName = get-gpo -Name $GPO.DisplayName 
    $GPO.DisplayName
    
}

$GPOs.Count
 
#$GPOs | Get-Member
#$GPOs

#$GPOs = Get-GPO -properties * -Domain $Domain -All 

#$GPOs | get-member


#$GPOs | export-csv u:\temp\GPOinfo.csv -NoTypeInformatio

#$GPOs = Get-GPO -Domain $Domain -All 
#$OUs  = Get-ADOrganizationalUnit -Properties * -Filter * <#-SearchBase $Domain -SearchScope Subtree#>  #| select -ExpandProperty LinkedGroupPolicyObjects
#$OUs.Count
#
#cls
#Get-ADOrganizationalUnit -Properties * -Filter * | select -property name,LinkedGroupPolicyObjects -ExpandProperty LinkedGroupPolicyObjects | ft



<#
foreach($OU in $OUs)
{
    $Link = $Ou.LinkedGroupPolicyObjects

    $LinkedOUs = $OU | where-object ($OU.LinkedGroupPolicyObjects -ne $null ) #select -ExpandProperty LinkedGroupPolicyObjects
    
    $LinkedOUs

}

#>


<#
$LinkedGPOs = Get-ADOrganizationalUnit -Filter 'Name -like "*lab*"' | select -ExpandProperty LinkedGroupPolicyObjects            


$GUIDRegex = "{[a-zA-Z0-9]{8}[-][a-zA-Z0-9]{4}[-][a-zA-Z0-9]{4}[-][a-zA-Z0-9]{4}[-][a-zA-Z0-9]{12}}"            
            
foreach($LinkedGPO in $LinkedGPOs) {            
    $result = [Regex]::Match($LinkedGPO,$GUIDRegex);            
    if($result.Success) {            
        $GPOGuid = $result.Value.TrimStart("{").TrimEnd("}")            
        Get-GPO -Guid $GPOGuid            
    }            
            
}

#>


########################################
### Un-Linked GPO's

########################################
### Query GPOs linked to OUs Powershell
########################################
<#
$DNs = Get-Content c:\temp\listofDNsofOUs.txt
ForEach ($DN In $DNs) {
	Get-GPInheritance -Target $DN |
		Select-Object -ExpandProperty GPOLinks |
		Select-Object @{n='DN'; e={$DN}}, DisplayName, GpoId, Enforced, Order |
		Sort-Object -Property Order
} | Export-Csv -NoTypeInformation -Path C:\Temp\GPOLinks.csv

#>