﻿cls
Import-Module ActiveDirectory

$Domain ="Risk-Strategies.com"




$GPOs = @()
$GPOs += "Default Domain Policy"
$GPOs += "DSG-General Policy"
$GPOs += "DSG-Win 7 Policy"
#$GPOs += "DSG-NY - General Policy"
#$GPOs += "DSG-CH - General Policy"
#$GPOs += "DSG-GD - General Policy"
#$GPOs += ""
#$GPOs += ""
#$GPOs += ""
#$GPOs += ""


foreach ($GPO in $GPOs)
{
    $Report = "U:\PowerShell Scripts\GPOs\GPO Reports\" + $GPO + ".html"

    Write-Host "Writing Report: "  -ForegroundColor Green -NoNewLine
    Write-Host $GPO -ForegroundColor White
    #$GPO = Get-GPO -domain $Domain  -Name $GPOName
    Get-GPOReport -name $GPO -ReportType html -Path $Report
}


