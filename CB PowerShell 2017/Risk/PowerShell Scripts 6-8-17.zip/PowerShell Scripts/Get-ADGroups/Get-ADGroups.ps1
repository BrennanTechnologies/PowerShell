﻿cls

<#

-2147483646 ~ Global Security Group
-2147483644 ~ Local Security Group
-2147483643 ~ BuiltIn Group
-2147483640 ~ Universal Security Group

2 ~ Global Distribution Group
4 ~ Local Distribution Group
8 ~ Universal Distribution Group

#>

$Report = @()

$Domain = "Risk-Strategies.com"

$Groups = Get-ADGroup -Properties *  -Filter * #-Filter 'GroupCategory -eq "Security"' # -and GroupScope -ne "DomainLocal"' -SearchBase "DC=AppNC"

foreach ($Group in $Groups)
{
    write-host "Group Name: " $Group.Name -ForegroundColor Magenta
    write-host "Recursing Group Members" -ForegroundColor Green
    
    $Members = Get-ADGroupMember -Identity $Group -Recursive
    $MemberCount = $Members.Count
    
    foreach ($Member in $Members)
    {
        #write-host $Group.Name $Member -ForegroundColor Green
       $hash = [ordered]@{            

        #Domain             = $Domain
        GroupName          = $Group.Name
        MemberCount        = $MemberCount
        GroupMember        = $Member.Name
        CanonicalName      = $Group.CanonicalName
        Description        = $Group.Description
        DistinguishedName  = $Group.DistinguishedName
        GroupCategory      = $Group.GroupCategory
        GroupScope         = $Group.GroupScope
        #groupType          = $Group.groupType
        ManagedBy          = $Group.ManagedBy
        #MemberOf           = $Group.MemberOf
        #Memmbers           = $Group.Members
        #SamAccountName     = $Group.SamAccountName
        #sAMAccountType     = $Group.sAMAccountType
        whenChanged        = $Group.whenChanged
        whenCreated        = $Group.whenCreated 
        
    }                           
    $PSObject =  New-Object PSObject -Property $hash
    $Report   += $PSObject
    }
}

 function Write-Report()
 {
     ############################
    # Export & Show the File
    ############################
    
    function Get-Script-Directory
    {
        $scriptInvocation = (Get-Variable MyInvocation -Scope 1).Value
        return Split-Path $scriptInvocation.MyCommand.Path
    }
    $ScriptPath = Get-Script-Directory
    
    $ReportPath = $ScriptPath +"\Reports\"
    $ReportPath = "u:\reports\"

    # Create the Log Folder.
    $ReportPath = $ScriptPath + "\Reports\" 
    if(!(Test-Path -Path $ReportPath)) {New-Item -ItemType directory -Path $ReportPath | out-null}

    $ReportDate = Get-Date -Format ddmmyyyy
    $ReportFile = $ReportPath + "Report_$ReportDate.csv"

    $Report | Export-Csv -Path $ReportFile -NoTypeInformation 
    start-process notepad.exe $ReportFile
}

Write-Report