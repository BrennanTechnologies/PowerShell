﻿cls

$User = "LPowell"

ForEach ($Group in Get-DistributionGroup) 
{ 
   ForEach ($Member in Get-DistributionGroupMember -identity $Group | Where { $_.Name –eq $User }) 
   { 
      $Group.name 
   } 
}

<#
Get-ADUser $user |
  Get-ADPrincipalGroupMembership |
    select -Expand Distinguishedname |
      Get-DistributionGroup -EA 0

#>