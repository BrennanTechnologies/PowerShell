﻿cls
import-module ActiveDirectory




$Script:LogFile = Join-Path -Path $Env:TEMP -ChildPath "NanoServerImageGenerator.log"
$Script:TargetLogPath = $Script:LogFile

$Report = @()

$script:Domains  = @()
$script:Domains += "risk-strategies.com"
$script:Domains += "dewittstern.com"


function Get-ComputerData
{
    ############################
    # Convert LastLogonTime
    ############################
            
    ### Filter computers that never logged on.
    if ($Computer.lastlogontimestamp -gt 0)
    {
        $logindatetime = $Computer.lastlogontimestamp
        $lastlogintime = [datetime]::FromFileTime($logindatetime) 
    }
    else 
    {
        $usertime = "<Never>"
    }

    ############################
    # Build Hash Table
    ############################

    $hash = [ordered]@{            

        Domain             = $Domain
        Ping               = $Ping                  
        Name               = $Computer.name            
        CanonicalName      = $Computer.CanonicalName            
        Description        = $Computer.Description            
        DisplayName        = $Computer.DisplayName            
        DistinguishedName  = $Computer.DistinguishedName            
        DNSHostName        = $Computer.DNSHostName            
        IPv4Address        = $Computer.Login            
        OperatingSystem    = $Computer.OperatingSystem   
        whenCreated        = $Computer.whenCreated   
        whenChanged        = $Computer.whenChanged
        lastlogintime      = $lastlogintime
    }                           

    $PSObject =  New-Object PSObject -Property $hash
    $Report   += $PSObject   
}



foreach ($Domain in $Domains)
{
    $Domain = Get-ADDomain -Identity $Domain
    $Domain = $Domain.DistinguishedName
    
    $SearchBase = "OU=Servers,DC=risk-strategies,DC=com"

    write-host "Getting computers for domain: $Domain " -ForegroundColor Yellow -NoNewline
    write-host $Domain -ForegroundColor Cyan

    #$Computers = Get-ADComputer -Filter * -Properties * -SearchBase $Domain -SearchScope SubTree
    $Computers = Get-ADComputer -Filter {OperatingSystem -Like 'Windows Server*'} -Property *  -SearchBase $SearchBase -SearchScope SubTree

    foreach ($Computer in $Computers)
    {
        ############################
        # Ping each Computer name
        ############################

        write-host "Pinging . . . $computer" -ForegroundColor cyan
        $Ping = Test-Connection  $Computer.name -BufferSize 16 -Count 1 -quiet -ErrorAction SilentlyContinue


        if($Ping)
        {
            $Ping = $Ping.IPV4Address.IPAddressToString
            Get-ComputerData
        }
        else
        {
            $Ping = "Not Available"
        }
        write-host Ping Result: $Computer.name $Ping" -foregroundcolor yellow
    }
} 
 






############################
# Export & Show the File
############################
$script:ScriptPath  = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)
$ReportPath = $ScriptPath +"\Reports\"
    
# Create the Log Folder.
$ReportPath = $ScriptPath + "\Logs" 
if(!(Test-Path -Path $ReportPath)) {New-Item -ItemType directory -Path $ReportPath | out-null}

$ReportDate = Get-Date -Format ddmmyyyy
$ReportFile = $ReportPath + "Report_$ReportDate.txt"

$Report | Export-Csv -Path $ReportFile -NoTypeInformation 
start-process $ReportFile
