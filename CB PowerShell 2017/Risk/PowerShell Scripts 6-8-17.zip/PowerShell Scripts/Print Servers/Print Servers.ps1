﻿Import-Module ActiveDirectory
cls

### Get ALl Print Servers
#$PrintServers = Get-ADObject -LDAPFilter "(&(&(&(uncName=*)(objectCategory=printQueue))))" -properties *|Sort-Object -Unique -Property servername |select servername
#$PrintServers

### Get All DC's
#$DCs = [system.directoryservices.activedirectory.Forest]::GetCurrentForest().domains | %{$_.DomainControllers.name}
#$DCs


## Get Users Last Computer Logon

#RDaddario


#$Users = Get-ADUser -Properties * -Filter 'SamAccountName -eq "RDaddario"'
#$Users

#$Computers = Get-ADComputer -Properties * -Filter * #-Properties Name

#foreach ($Computer in $Computers)
#{
    $ComputerName = $Computer.Name
    $ComputerName
    $ComputerName = "oba-daddarior"

    #$lastevent = get-winevent -FilterHashtable @{LogName="security"; ID=4624} -computername $Computer | select -first 1
    #$lastevent

    $Log = "security"
    #$Computer ="LocalHost"
    $ID = "4624" 
    $Objlog = New-Object system.diagnostics.eventLog($Log, $Computer.Name)
    $Objlog.get_entries() | Where-object { $_.eventID -eq $id} #| select -first 1


#}




Get-Printer -ComputerName $ComputerName | Select Name,PortName

$Printers = Get-Printer -ComputerName $ComputerName

foreach ($Printer in $Printers)
{
    $Printer.Name
    $Printer.PortName 
}


