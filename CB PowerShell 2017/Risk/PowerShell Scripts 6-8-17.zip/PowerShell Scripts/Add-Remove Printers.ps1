﻿cls

### Get local computer name
$ComputerName = $env:computername
$ReportDate = Get-Date -Format ddmmyyyy
#$ReportPath = "C:\temp"
$ReportPath = "\\col-file01\Shared\PrinterReplacements\"
$ImportFile = "\\col-file01\Shared\PrinterReplacements\MIA_Printer_Info.csv"

#######################################
### Get All Pre-Installled Printers
#######################################

### Show installed Printers
#Get-WMIObject -Class Win32_Printer -Computer $Computer -Property * | Select -Property Name,Caption,Default,Description,PortName,ServerName,Shared,ShareName | ft -auto

### Get Installed Printers
$Printers = Get-WMIObject -Class Win32_Printer -Computer $ComputerName -Property * 

### Select Printer Properties
$PrinterS = $PrinterS | Select-Object -Property Name,Default,PortName,ServerName,Shared,ShareName


#######################################
### Log Pre-Installled Printers
#######################################

### Display Pre-Installed Printers
write-host "Logging Printers Found for: " $ComputerName -ForegroundColor Yellow
$Printers | ft -auto

### Write Log File
$ReportFile = $ReportPath + $ComputerName + "_Pre-Installed Printers_" + $ReportDate + ".txt"
$Printers | Export-Csv $ReportFile -notype  # Export for Excel
#$Printers | Out-File $ReportFile -force # Export for Text

#######################################
### Remove Shared Printers
#######################################

### Filter Shared Printers only
$SharedPrinters = $Printers | Where {$_.Shared -eq $True}
write-host  "Shared Printers:" -ForegroundColor Magenta
$SharedPrinters | ft -AutoSize

foreach ($Printer in $SharedPrinters)
{
    # --------------------------------------
    # Remove the Printer
    # --------------------------------------
    Write-host "Removing Printer" $Printer.Name $Printer.PortName  -ForegroundColor Yellow
    # Log printer to file
    $OutFile = $ReportPath + $ComputerName + "_Removed Printers_" + $ReportDate + ".txt"
    $OutString = $Printer.Name + $Printer.PortName
    $OutString | Out-File $OutFile -Append -Force
    #remove-printer $Printer.Name
}


#######################################
### Add Printers
#######################################

### Import CSV File
$NewPrinters = Import-Csv $ImportFile

foreach ($NewPrinter in $NewPrinters)
{
    # --------------------------------------
    # Add Printers
    # --------------------------------------
    write-host "Adding Printer: " $NewPrinter.'Name' $NewPrinter.'IP Address'
    # Log new printer to file
    $OutFile = $ReportPath + $ComputerName + "_Added Printers_" + $ReportDate + ".txt"
    #$OutString = $NewPrinter.'Name' + $NewPrinter.'IP Address'
    #$OutString | Out-File $OutFile -Append -Force

    #add-printer -name $NewPrinter.'Name' -drivername <driver name> -port $NewPrinter.'IP Address'
    $PrintServer = "col-DC01"
    $PrinterString = "\\" + $PrintServer + "\" + $NewPrinter.'Name'
    write-host "Adding Printer: " $PrinterString
    "Adding Printer: " + $PrinterString  | Out-File $OutFile -Append -Force

    #Add-Printer -ConnectionName $PrinterString
    #Add-Printer -ConnectionName \\printServer\printerName
}







<#


add-printer -name <name> -drivername <driver name> -port <port name>

remove-printer "Downstairs Printer"

Get-WMIObject -Class Win32_Printer -ComputerName $ComputerName

Name                        MemberType    Definition                                                                                                                         
----                        ----------    ----------                                                                                                                         
PSComputerName              AliasProperty PSComputerName = __SERVER                                                                                                          
CancelAllJobs               Method        System.Management.ManagementBaseObject CancelAllJobs()                                                                             
GetSecurityDescriptor       Method        System.Management.ManagementBaseObject GetSecurityDescriptor()                                                                     
Pause                       Method        System.Management.ManagementBaseObject Pause()                                                                                     
PrintTestPage               Method        System.Management.ManagementBaseObject PrintTestPage()                                                                             
RenamePrinter               Method        System.Management.ManagementBaseObject RenamePrinter(System.String NewPrinterName)                                                 
Reset                       Method        System.Management.ManagementBaseObject Reset()                                                                                     
Resume                      Method        System.Management.ManagementBaseObject Resume()                                                                                    
SetDefaultPrinter           Method        System.Management.ManagementBaseObject SetDefaultPrinter()                                                                         
SetPowerState               Method        System.Management.ManagementBaseObject SetPowerState(System.UInt16 PowerState, System.String Time)                                 
SetSecurityDescriptor       Method        System.Management.ManagementBaseObject SetSecurityDescriptor(System.Management.ManagementObject#Win32_SecurityDescriptor Descrip...
Attributes                  Property      uint32 Attributes {get;set;}                                                                                                       
Availability                Property      uint16 Availability {get;set;}                                                                                                     
AvailableJobSheets          Property      string[] AvailableJobSheets {get;set;}                                                                                             
AveragePagesPerMinute       Property      uint32 AveragePagesPerMinute {get;set;}                                                                                            
Capabilities                Property      uint16[] Capabilities {get;set;}                                                                                                   
CapabilityDescriptions      Property      string[] CapabilityDescriptions {get;set;}                                                                                         
Caption                     Property      string Caption {get;set;}                                                                                                          
CharSetsSupported           Property      string[] CharSetsSupported {get;set;}                                                                                              
Comment                     Property      string Comment {get;set;}                                                                                                          
ConfigManagerErrorCode      Property      uint32 ConfigManagerErrorCode {get;set;}                                                                                           
ConfigManagerUserConfig     Property      bool ConfigManagerUserConfig {get;set;}                                                                                            
CreationClassName           Property      string CreationClassName {get;set;}                                                                                                
CurrentCapabilities         Property      uint16[] CurrentCapabilities {get;set;}                                                                                            
CurrentCharSet              Property      string CurrentCharSet {get;set;}                                                                                                   
CurrentLanguage             Property      uint16 CurrentLanguage {get;set;}                                                                                                  
CurrentMimeType             Property      string CurrentMimeType {get;set;}                                                                                                  
CurrentNaturalLanguage      Property      string CurrentNaturalLanguage {get;set;}                                                                                           
CurrentPaperType            Property      string CurrentPaperType {get;set;}                                                                                                 
Default                     Property      bool Default {get;set;}                                                                                                            
DefaultCapabilities         Property      uint16[] DefaultCapabilities {get;set;}                                                                                            
DefaultCopies               Property      uint32 DefaultCopies {get;set;}                                                                                                    
DefaultLanguage             Property      uint16 DefaultLanguage {get;set;}                                                                                                  
DefaultMimeType             Property      string DefaultMimeType {get;set;}                                                                                                  
DefaultNumberUp             Property      uint32 DefaultNumberUp {get;set;}                                                                                                  
DefaultPaperType            Property      string DefaultPaperType {get;set;}                                                                                                 
DefaultPriority             Property      uint32 DefaultPriority {get;set;}                                                                                                  
Description                 Property      string Description {get;set;}                                                                                                      
DetectedErrorState          Property      uint16 DetectedErrorState {get;set;}                                                                                               
DeviceID                    Property      string DeviceID {get;set;}                                                                                                         
Direct                      Property      bool Direct {get;set;}                                                                                                             
DoCompleteFirst             Property      bool DoCompleteFirst {get;set;}                                                                                                    
DriverName                  Property      string DriverName {get;set;}                                                                                                       
EnableBIDI                  Property      bool EnableBIDI {get;set;}                                                                                                         
EnableDevQueryPrint         Property      bool EnableDevQueryPrint {get;set;}                                                                                                
ErrorCleared                Property      bool ErrorCleared {get;set;}                                                                                                       
ErrorDescription            Property      string ErrorDescription {get;set;}                                                                                                 
ErrorInformation            Property      string[] ErrorInformation {get;set;}                                                                                               
ExtendedDetectedErrorState  Property      uint16 ExtendedDetectedErrorState {get;set;}                                                                                       
ExtendedPrinterStatus       Property      uint16 ExtendedPrinterStatus {get;set;}                                                                                            
Hidden                      Property      bool Hidden {get;set;}                                                                                                             
HorizontalResolution        Property      uint32 HorizontalResolution {get;set;}                                                                                             
InstallDate                 Property      string InstallDate {get;set;}                                                                                                      
JobCountSinceLastReset      Property      uint32 JobCountSinceLastReset {get;set;}                                                                                           
KeepPrintedJobs             Property      bool KeepPrintedJobs {get;set;}                                                                                                    
LanguagesSupported          Property      uint16[] LanguagesSupported {get;set;}                                                                                             
LastErrorCode               Property      uint32 LastErrorCode {get;set;}                                                                                                    
Local                       Property      bool Local {get;set;}                                                                                                              
Location                    Property      string Location {get;set;}                                                                                                         
MarkingTechnology           Property      uint16 MarkingTechnology {get;set;}                                                                                                
MaxCopies                   Property      uint32 MaxCopies {get;set;}                                                                                                        
MaxNumberUp                 Property      uint32 MaxNumberUp {get;set;}                                                                                                      
MaxSizeSupported            Property      uint32 MaxSizeSupported {get;set;}                                                                                                 
MimeTypesSupported          Property      string[] MimeTypesSupported {get;set;}                                                                                             
Name                        Property      string Name {get;set;}                                                                                                             
NaturalLanguagesSupported   Property      string[] NaturalLanguagesSupported {get;set;}                                                                                      
Network                     Property      bool Network {get;set;}                                                                                                            
PaperSizesSupported         Property      uint16[] PaperSizesSupported {get;set;}                                                                                            
PaperTypesAvailable         Property      string[] PaperTypesAvailable {get;set;}                                                                                            
Parameters                  Property      string Parameters {get;set;}                                                                                                       
PNPDeviceID                 Property      string PNPDeviceID {get;set;}                                                                                                      
PortName                    Property      string PortName {get;set;}                                                                                                         
PowerManagementCapabilities Property      uint16[] PowerManagementCapabilities {get;set;}                                                                                    
PowerManagementSupported    Property      bool PowerManagementSupported {get;set;}                                                                                           
PrinterPaperNames           Property      string[] PrinterPaperNames {get;set;}                                                                                              
PrinterState                Property      uint32 PrinterState {get;set;}                                                                                                     
PrinterStatus               Property      uint16 PrinterStatus {get;set;}                                                                                                    
PrintJobDataType            Property      string PrintJobDataType {get;set;}                                                                                                 
PrintProcessor              Property      string PrintProcessor {get;set;}                                                                                                   
Priority                    Property      uint32 Priority {get;set;}                                                                                                         
Published                   Property      bool Published {get;set;}                                                                                                          
Queued                      Property      bool Queued {get;set;}                                                                                                             
RawOnly                     Property      bool RawOnly {get;set;}                                                                                                            
SeparatorFile               Property      string SeparatorFile {get;set;}                                                                                                    
ServerName                  Property      string ServerName {get;set;}                                                                                                       
Shared                      Property      bool Shared {get;set;}                                                                                                             
ShareName                   Property      string ShareName {get;set;}                                                                                                        
SpoolEnabled                Property      bool SpoolEnabled {get;set;}                                                                                                       
StartTime                   Property      string StartTime {get;set;}                                                                                                        
Status                      Property      string Status {get;set;}                                                                                                           
StatusInfo                  Property      uint16 StatusInfo {get;set;}                                                                                                       
SystemCreationClassName     Property      string SystemCreationClassName {get;set;}                                                                                          
SystemName                  Property      string SystemName {get;set;}                                                                                                       
TimeOfLastReset             Property      string TimeOfLastReset {get;set;}                                                                                                  
UntilTime                   Property      string UntilTime {get;set;}                                                                                                        
VerticalResolution          Property      uint32 VerticalResolution {get;set;}                                                                                               
WorkOffline                 Property      bool WorkOffline {get;set;}                                                                                                        
__CLASS                     Property      string __CLASS {get;set;}                                                                                                          
__DERIVATION                Property      string[] __DERIVATION {get;set;}                                                                                                   
__DYNASTY                   Property      string __DYNASTY {get;set;}                                                                                                        
__GENUS                     Property      int __GENUS {get;set;}                                                                                                             
__NAMESPACE                 Property      string __NAMESPACE {get;set;}                                                                                                      
__PATH                      Property      string __PATH {get;set;}                                                                                                           
__PROPERTY_COUNT            Property      int __PROPERTY_COUNT {get;set;}                                                                                                    
__RELPATH                   Property      string __RELPATH {get;set;}                                                                                                        
__SERVER                    Property      string __SERVER {get;set;}                                                                                                         
__SUPERCLASS                Property


Name	Model	IP Address
MIA-Admin-BL	Canon Imagerunner Advance C5540i	10.128.8.228
MIA-Admin-CL	Canon Imagerunner Advance C5540i	10.128.8.228
MIA-Commercial-BL	Canon Imagerunner Advance C5540i	10.128.8.229
MIA-Commercial-CL	Canon Imagerunner Advance C5540i	10.128.8.229
MIA-Mailroom-BL	Canon Imagerunner Advance C5540i	10.128.8.230
MIA-Mailroom-CL	Canon Imagerunner Advance C5540i	10.128.8.230
MIA-Main-BL	Canon Imagerunner Advance C5550i	10.128.8.227
MIA-Main-CL	Canon Imagerunner Advance C5550i	10.128.8.227
MIA-Personal-BL	Xerox Phaser 3600	10.128.8.231

 


#>