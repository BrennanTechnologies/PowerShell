﻿### Unlock AD Accounts
cls

Import-Module activedirectory




############################
# Convert Time
############################
            
if ($User.lockoutTime -gt 0)
{
    $time = $User.lockoutTime
    $time = [datetime]::FromFileTime($time) 
}
else 
{
    $time = "<Never>"
}


$Users = Search-ADAccount –LockedOut
#Search-ADAccount -LockedOut | Unlock-ADAccount

#$Users = @("csung", "syu")
#$Users = @("lockout_test")

write-host "Count: " $Users.Count



foreach ($User in $Users)
{
    $User = Get-Aduser $User -Properties *
  
    ############################
    # Convert Time
    ############################
    function Convert-Time ($time)
    {        
        if ($User.lockoutTime -gt 0)
        {
            $time = $User.lockoutTime
            $time = [datetime]::FromFileTime($time) 
        }
        else 
        {
            $time = "<Never>"
        }
    }
  
    #$user | Get-Member
    write-host "Name: " $User.name
    write-host "distinguishedname: " $User.distinguishedname
    write-host "Lockout Time: " $Time       #$User.lockoutTime
    write-host "Locked: " $User.LockedOut
    write-host "LockedOut: " $User.whenCreated
    write-host "pwdLastSet: " $User.pwdLastSet
    write-host "badPasswordTime: " $User.badPasswordTime

    #(Get-Aduser $User -Properties LockedOut).LockedOut
    
    #Unlock-ADAccount -Identity $User
}