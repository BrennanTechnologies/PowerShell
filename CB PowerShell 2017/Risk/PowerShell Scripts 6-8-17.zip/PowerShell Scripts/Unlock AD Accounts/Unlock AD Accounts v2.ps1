﻿### Unlock AD Accounts
cls

Import-Module activedirectory


############################
# Convert Time
############################
function Convert-Time ($Time)
{        
    if ($Time -gt 0)
    {
        $Time = [datetime]::FromFileTime($Time) 
        #$Time
    }
    else 
    {
        $Time = "<Never>"
    }
}


#$Users = Search-ADAccount –LockedOut
#Search-ADAccount -LockedOut | Unlock-ADAccount

#$Users = @("lockout_test")
$Users = @("csung", "syu", "oren", "RSchultheis")


write-host "Count: " $Users.Count



foreach ($User in $Users)
{
    $User = Get-Aduser $User -Properties *
  
    #$user | Get-Member
   # write-host "Name: " $User.name
    #write-host "distinguishedname: " $User.distinguishedname
    
    #$lockoutTime = Convert-Time $User.lockoutTime
    #write-host "Lockout Time: " $lockoutTime
    
    #write-host "Lockout Time: " $lockoutTime
    
    #write-host "whenCreated: "$User.whenCreated
    
    #$pwdLastSet = Convert-Time ($User.pwdLastSet)
    #write-host "pwdLastSet: " $pwdLastSet

    #(Get-Aduser $User -Properties LockedOut).LockedOut
    

    
    if ($User.LockedOut)
    {
        write-host "Locked: " $User.name "=" $User.LockedOut
        Unlock-ADAccount -Identity $User
    }
    else
    {
     write-host "Locked: " $User.name "=" $User.LockedOut
     Write-Host "No users locked"
    }
    
}