﻿Import-Module ActiveDirectory

cls

$Domain ="Risk-Strategies.com"

#$DCs = Get-ADDomainController -Server $Domain -Filter *

Get-ADDomainController -DomainName $Domain -Discover

$DCs
