﻿cls
Import-Module GroupPolicy

$Report = @()
#$Domain = "DewittStern.com"
$Domain = "Risk-Strategies.com"
$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "GPOReport.html"


##################################
### Get ALL Domain GPOs
##################################

Write-Host "Getting All GPOs in $Domain`t" -ForegroundColor Magenta

$AllGPOs = Get-GPO -All $Domain
$AllGPOCount = $AllGPOs.count
Write-Host "Count of All GPO's: " $AllGPOCount -ForegroundColor Magenta


$xml = $null

##################################
### Get GPO Properties
##################################
foreach ($GPO in $AllGPOs)
{
    $GPOID   = $GPO.ID
    $GPOName = $GPO.DisplayName
    $GPOName = "RAN Logon Script"
    
    Write-Host "Generating XML Report for:  " -ForegroundColor Yellow -nonewline
    Write-Host "$GPOName" -ForegroundColor White
    
    ### Reference:
    ### https://blogs.technet.microsoft.com/heyscriptingguy/2013/02/07/use-powershell-to-generate-and-parse-a-group-policy-object-report/

    #######################################
    ### Get XML Report for each GPO
    #######################################

    $xml = [xml](Get-GPOReport -GUID $GPOID -ReportType xml)

    #$xml.DocumentElement
    write-host "Name: " $xml.DocumentElement.Name
    #write-host "LinksTo: " $xml.GPO.LinksTo
    #write-host "Computer: " $xml.DocumentElement.Computer  
    #write-host "User: " $xml.GPO.User
    
    ### Ref:
    ### From <http://www.joseph-streeter.com/?p=1158> 

    $Computer = $xml.DocumentElement.Computer
    $User = $xml.DocumentElement.User
    #$Computer
    #$User
    
    $xml.GPO.User
    $xml.GPO.CreatedTime

    $xml.DocumentElement.SecurityDescriptor.Owner

    $xml.DocumentElement.User
    $xml.GPO.LinksTo # SOMName


    #write-host "User: " $xml.GPO.Computer.ExtensionData
    #write-host "User: " $xml.GPO.User.ExtensionData
     


}


<####################
Write-Host "`nUnlinked GPOs`n"
$allGPOs = Get-GPO -All | sort DisplayName
ForEach ($gpo in $allGPOs) {
    $xml = [xml](Get-GPOReport $gpo.Id xml)
    If (!$xml.GPO.LinksTo) {
        $gpo.DisplayName
        }
    }

Write-Host "`nGPOs with no settings`n"
$allGPOs = Get-GPO -All | sort DisplayName
ForEach ($gpo in $allGPOs) {
    $xml = [xml](Get-GPOReport $gpo.Id xml)
    If ($xml.GPO.LinksTo) {
        If (!$xml.GPO.Computer.ExtensionData -and !$xml.GPO.User.ExtensionData) {
            $gpo.DisplayName
            }
        }
    }

##################>


##################################
<#
# GPO Status	Enabled
# Links
#Computer Configuration (Enabled) No settings defined.

$GPONoLinks = @()

Write-Host "Generating XML Report" -ForegroundColor Magenta

$XML= Get-GPO -ALL | Get-GPOReport -ReportType XML
$XML.Contains("Linksto")


foreach ($a in $XML)
{
    $a #.DocumentElement.Computer    
}

exit



Get-GPO -All | 
 
    %{ 
       If ( $_ | Get-GPOReport -ReportType XML | Select-String -NotMatch "<LinksTo>" )
        {


        Write-Host $_.DisplayName -ForegroundColor Green
        $GPONoLinks += $_.DisplayName
        
        }
    }

    $GPONoLinks
    $GPONoLinks.count 
    $GPONoLinks | Export-CSV "U:\temp\GPONoLinks.csv" -NoTypeInformation

    #>