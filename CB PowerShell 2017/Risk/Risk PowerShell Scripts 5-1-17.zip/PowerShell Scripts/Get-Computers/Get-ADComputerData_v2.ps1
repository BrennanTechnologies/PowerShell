﻿cls
import-module ActiveDirectory

$Report = @()

$script:Domains  = @()
$script:Domains += "risk-strategies.com"
$script:Domains += "dewittstern.com"


function Get-ComputerData
{
    ############################
    # Convert LastLogonTime
    ############################
            
    ### ConvertLast lastlogontimestamp.
    if ($Computer.lastlogontimestamp -gt 0)
    {
        $logindatetime = $Computer.lastlogontimestamp
        $lastlogintime = [datetime]::FromFileTime($logindatetime) 
    }
    else 
    {
        $usertime = "<Never>"
    }

    ############################
    # Build Hash Table
    ############################
    
    write-host "OS: $Computer.OperatingSystem" -ForegroundColor green


    $hash = [ordered]@{            

        Domain             = $Domain
        Ping               = $Ping                  
        Name               = $Computer.name            
        CanonicalName      = $Computer.CanonicalName            
        #Description        = $Computer.Description            
        #DisplayName        = $Computer.DisplayName            
        DistinguishedName  = $Computer.DistinguishedName            
        DNSHostName        = $Computer.DNSHostName            
        IPv4Address        = $Computer.Login            
        OperatingSystem    = $Computer.OperatingSystem   
        whenCreated        = $Computer.whenCreated   
        whenChanged        = $Computer.whenChanged
        lastlogintime      = $lastlogintime
    }                           

    $PSObject =  New-Object PSObject -Property $hash
    $Report   += $PSObject
}


foreach ($Domain in $Domains)
{
    $Domain = Get-ADDomain -Identity $Domain
    $Domain = $Domain.DistinguishedName
    
    $SearchBase = "OU=Servers,DC=risk-strategies,DC=com"
    $SearchBase = $Domain

    write-host "Getting computers for domain: $Domain " -ForegroundColor magenta 

    #$Computers = Get-ADComputer -Filter * -Properties * -SearchBase $Domain -SearchScope SubTree
    $Computers = Get-ADComputer -Filter {OperatingSystem -Like 'Windows Server*'} -Property *  -SearchBase $SearchBase -SearchScope SubTree

    foreach ($Computer in $Computers)
    {

        ############################
        # Make WMI Calls
        ############################

        #Get-WmiObject -List
        #Get-WmiObject -computername $Computer.Name Win32_Computersystem | Select-Object *
        $OS = Get-WmiObject -computername $Computer.Name Win32_operatingSystem | Select-Object Caption
        if ($OS)
        {
            $OS = $OS.Caption
        }
        else
        {
            $OSS = "RPC Unavailable"
        }
        
        
        
        ############################
        # Ping each Computer name
        ############################

        write-host "Pinging . . . $computer.name" -ForegroundColor cyan
        $Ping = Test-Connection  $Computer.Name -BufferSize 16 -Count 1 -quiet -ErrorAction SilentlyContinue
        
        if($Ping)
        {
            $PingResult = "Sucess"

        }
        else
        {
            $PingResult = "Not Available"
        }
        write-host "Ping Result: $Computer.name $PingResult" -foregroundcolor yellow


        ############################
        # Convert LastLogonTime
        ############################
            
        ### ConvertLast lastlogontimestamp.
        if ($Computer.lastlogontimestamp -gt 0)
        {
            $logindatetime = $Computer.lastlogontimestamp
            $lastlogintime = [datetime]::FromFileTime($logindatetime) 
        }
        else 
        {
            $usertime = "<Never>"
        }

        ############################
        # Build Hash Table
        ############################

        $hash = [ordered]@{            

            Domain                = $Domain
            Ping                  = $Ping                  
            Name                  = $Computer.name 
            PingResult            = $PingResult    
            WMI_OS                = $OS
            AD_CanonicalName      = $Computer.CanonicalName            
            #AD_Description        = $Computer.Description            
            #AD_DisplayName        = $Computer.DisplayName            
            AD_DistinguishedName  = $Computer.DistinguishedName            
            AD_DNSHostName        = $Computer.DNSHostName            
            #AD_IPv4Address        = $Computer.IPv4Address.ToString()            
            AD_OperatingSystem    = $Computer.OperatingSystem   
            AD_whenCreated        = $Computer.whenCreated   
            AD_whenChanged        = $Computer.whenChanged
            AD_lastlogintime      = $lastlogintime
        }                           

        $PSObject =  New-Object PSObject -Property $hash
        $Report   += $PSObject
    }
} 


 function Write-Report()
 {
     ############################
    # Export & Show the File
    ############################
    $script:ScriptPath  = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)
    $ReportPath = $ScriptPath +"\Reports\"
    
    # Create the Log Folder.
    $ReportPath = $ScriptPath + "\Reports\" 
    if(!(Test-Path -Path $ReportPath)) {New-Item -ItemType directory -Path $ReportPath | out-null}

    $ReportDate = Get-Date -Format ddmmyyyy
    $ReportFile = $ReportPath + "Report_$ReportDate.csv"

    $Report | Export-Csv -Path $ReportFile -NoTypeInformation 
    start-process notepad.exe $ReportFile
}

Write-Report 