﻿cls

$Server = "col-dc01"
$LogPath = "\\" + $Server + "\C$\Windows\System32\winevt\Logs"

$LogParserPath = "\\col-file01\Users\cbrennan\LogParser\LogParser.exe"

#$SecurityEventLogs = 

#$Files = get-childitem $LogPath
#write-host "Name" $files.Name
#write-host "FullName" $files.FullName
#write-host "ext" $files.Extention
#exit

$EVTFiles = get-childitem $LogPath  | where {($_.extension -eq ".evtx" -and $_.Name -like "*Archive-Security*") -or ($_.extension -eq ".evtx" -and $_.Name -eq "Security.evtx")}



foreach ($EVTFile in $EVTFiles)

{



}

function Parse-Logs()
{
    
    
    <#
    $ScriptBlock = 
    {
        
    }
    #>

    #dir $LogPath
    #Start-Process -FilePath $LogParserPath -NoNewWindow -Wait

}

Parse-Logs



