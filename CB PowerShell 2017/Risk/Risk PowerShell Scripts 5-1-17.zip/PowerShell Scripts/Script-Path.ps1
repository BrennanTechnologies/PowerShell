﻿#$script:ScriptPath  = $PSScriptRoot # Requires PS 3.0
#$script:ScriptPath  = split-path -parent $MyInvocation.MyCommand.Definition # Required for PS 2.0
$script:ScriptPath  = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)


$script:ScriptPath