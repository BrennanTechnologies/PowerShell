﻿cls
Import-Module ActiveDirectory


# Get the PDC from the Domain
#$DomainName ="Risk-Strategies.com"
#$Domain ="DewittStern.com"


$ADForest = Get-ADForest
$ADForestDomains = $ADForest.Domains


#$Domain = Get-ADDomain -Identity $DomainName  #| Select-Object -Property pdcemulator
#write-host $Domain.Name -ForegroundColor Cyan

ForEach ($Domain in $ADForestDomains)
 {
    #$DomainDCs = 
    #Get-ADDomainController -filter * -server $Domain
    $DCs = [system.directoryservices.activedirectory.Forest]::GetCurrentForest().domains | %{$_.DomainControllers.name}
    #$DomainDCs
}

   <#
$DCs = Get-ADDomainController -Filter * -server $Domain.Name
$DCs

##$DomainControllers
##exit

foreach ($DC in $DomainControllers)
{
    $DC
}
#>
exit