﻿cls
Import-Module GroupPolicy


$Domain = "DewittStern.com"
#$Domain = "Risk-Strategies.com"

$ReportDir = "u:\temp\GPOReports\"
$ReportFile = $ReportDir + "RSOP.html"

### Get-GPResultantSetofPolicy -Path <string> -ReportType {<Xml> | <Html>} [-Computer <string>] [-User <string>] [<CommonParameters>]




get-gpresultantsetofpolicy -reporttype html -path $ReportFile -user risk\cbrennan