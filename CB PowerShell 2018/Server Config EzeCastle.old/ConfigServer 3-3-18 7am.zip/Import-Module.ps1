﻿cls
#Import-Module

$Parameters = @{
    FeatureName = "GPMC"
    ModuleName  = "GroupPolicy"
}

#Get-WindowsFeature -name $Parameters.FeatureName

### Check if Feature is Installed

$InstallState = Get-WindowsFeature -name $Parameters.FeatureName
#$InstallState | Get-Member

$InstallState = $InstallState.InstallState
write-host "State" $InstallState.InstallState

if ($InstallState -eq "Available") 
{
    write-host "Feature Not Installed."
    Get-WindowsFeature -name $Parameters.FeatureName

    ### Install Feature
    $Status = "Installing Feature: " + $Parameters.FeatureName
    write-host $Status
    #Add-WindowsFeature -name $Parameters.FeatureName
}
else
{
    $Status = "Featrue Installed: " + $Parameters.FeatureName
    write-host $Status
}    

## Verify Feature id installed
write-host "`n`nVerifying Feature"
$Verify = Get-WindowsFeature -name $Parameters.FeatureName
write-host "Name: " $Verify.Name 
write-host "Installed: " $Verify.Installed

if($Verify.Installed -eq $false)
 {
    write-host "Feature Install Failed Verifictions"
 }
else
{
    write-host "Feature Install Verified Successfully"    
}
exit

Get-Module -ListAvailable | where {$_.name -like '*Active*'}

        
Get-Module -ListAvailable -Name GroupPolicy
Get-Module -ListAvailable -Name $Parameters.ModuleName

## Check for Module
if (Get-Module -ListAvailable -Name $Parameters.ModuleName)
{
}

### Import Module
Import-Module -command $Parameters.ModuleName

## Test Module
Get-Command -Module$Parameters.ModuleName

