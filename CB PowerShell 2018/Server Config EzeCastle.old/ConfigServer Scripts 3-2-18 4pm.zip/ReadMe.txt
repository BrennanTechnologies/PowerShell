
This script requires one parameter 


Require Parameter File

c:\script\

The example file I am using is:
Parameters.txt


I purposelt wrote thhis script using ONLY PowerShell 3.0 commandlets with 2012 R2 server.

Usually I write scripts to check the OS Version and then execute each command using the appropriate methods

i.e.
netsh
Wmi
etc.


About this Script
This script uses my custom fuction libraries and a function template tht I created ...

Features 

Transcript Log

Advanced Custom Logging

Error Handling

Conditional logic to test if settings are currrently set

