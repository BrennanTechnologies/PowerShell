﻿cls


### Get Current PageFile Loction
$CurrentPageFileLocation =  Get-WmiObject -Class Win32_PageFileUsage  -ComputerName $env:computername 
$CurrentPageFileLocation.Name


### Disable Automatic PageFile Settings

#$computersys = Get-WmiObject Win32_ComputerSystem -EnableAllPrivileges
#$computersys.AutomaticManagedPagefile = $False
#$computersys.Put()


### Delete Current PageFile
$pagefile = Get_WmiObject -Query "Select * From Win32_PageFileSetting Where Name='c:\\pagefile.sys'"
$pagefile.Delete()

### Create New PageFile
Set-WMIInstance -class Win32_PageFileSetting -Arguments @{name="d:\pagefile.sys";InitialSize  
Win32_PageFileSetting -Arguments @{name="d:\pagefile.sys";InitialSize = 4096;MaximumSize =4096}

Set-WMIInstance -class Win32_PageFileSetting -Arguments @{name="d:\pagefile.sys";InitialSize = 4096;MaximumSize = 4096}