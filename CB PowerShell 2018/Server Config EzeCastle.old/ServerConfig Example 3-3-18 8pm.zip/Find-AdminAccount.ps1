﻿cls

### Find the Current Local Administrator Account
### The Administrator account is the only account that has a SID that ends with “-500”
Add-Type -AssemblyName System.DirectoryServices.AccountManagement
$PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
$UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
$Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
$Searcher.QueryFilter = $UserPrincipal
$Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}

$CurrentAdminName = $Account.Name