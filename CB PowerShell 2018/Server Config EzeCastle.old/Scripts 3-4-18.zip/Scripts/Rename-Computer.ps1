﻿Param($CurrentComputerName = $env:ComputerName)

cls
$NewComputerName = "Server02"

### CheckCurrent Computer Name
if($env:ComputerName -eq $NewComputerName)
{
    ### Names are the Same
    write-host "Computer Names are the same"
}
elseif($env:ComputerName -ne $NewComputerName)
{
    ### Rename Computer
    write-host "Renaming Computer"
    Rename-Computer –computername $CurrentComputerName –newname $NewComputerName

    ### Verify Computer Name
    write-Host "The computer is now named: $env:ComputerName"
}






