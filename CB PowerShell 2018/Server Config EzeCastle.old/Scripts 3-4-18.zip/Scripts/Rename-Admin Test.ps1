﻿cls
$NewAdminName = "Local Admin"

function Get-CurrentAdmin
{
    ### Find the Current Local Administrator Account
    ### The Administrator account is the only account that has a SID that ends with “-500”
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
    $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
    $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
    $Searcher.QueryFilter = $UserPrincipal
    $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
    $script:CurrentAdminName = $Account.Name
    Write-Log "The current Local Administrator Account is: $CurrentAdminName"
}

function Rename-Admin
{
    ### Get the Current Local Admin Account
    $User= Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | Where {$_.Name -eq $CurrentAdminName}

    ### Rename the Current Local Admin Account
    write-host "Renaming $CurrentAdminName to $NewAdminName "
    $user.Rename($NewAdminName) | Out-Null
}

function Check-CurrentAdmin
{
    ### Check if Local Admin is already renamed

    if($CurrentAdminName -eq $NewAdminName)
    {
        write-host "CurrentAdminName is the same as NewAdminName"
        write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
    }
    elseif($CurrentAdminName -ne $NewAdminName)
    {
        write-host "Renaming Local Admin Account"
        write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
        Rename-Admin
    }
}

function Verify-NewAdmin
{
    write-host "Verifying new Admin Account Name"
    Get-CurrentAdmin
}

Get-CurrentAdmin
Check-CurrentAdmin
Verify-NewAdmin
