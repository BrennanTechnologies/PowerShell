﻿cls

$ScriptPath = "c:\scripts\"
$ScriptFile = "Parameters.csv"

#$FullPath = $ScriptPath  + $ScriptFile
#$FullPath # /d domai /n name


powershell -noexit -executionpolicy bypass c:\scripts\C:\Scripts\Server_Configuration_Script_v2.ps1 c:\scripts\parameters.csv