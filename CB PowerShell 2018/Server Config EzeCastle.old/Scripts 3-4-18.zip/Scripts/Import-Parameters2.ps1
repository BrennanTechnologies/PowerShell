﻿cls

$ParameterFile = "p.csv"
$ParametersFilePath =  $ScriptPath + "\" + $ParameterFile

### Check for File
write-log "Checking for Parameter File: $ParameterFile"

### Check if Parameter File Exits
if(-not (Test-Path $ParametersFilePath))
{
    write-host "Parameter File Missing: $ParameterFile"
}
else
{
write-log "Importing File Exists: $ParameterFile" Blue
}

###########################
### Initialize Parameters
###########################

### Import from CSV file
$Parameters = Import-CSV -path $ParametersFilePath 

foreach ($Parameter in $Parameters)
{

    Set-Variable -name $Parameter.Name -value $Parameter.Value
    Get-Variable -name $Parameter.Name
}

