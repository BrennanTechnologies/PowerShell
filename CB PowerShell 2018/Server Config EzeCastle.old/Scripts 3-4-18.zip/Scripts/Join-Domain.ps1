﻿cls
$ADDomain = "Lab.net"

Param([String]$User = "Administrator")

### Check if Domain is reachable
if (Test-Connection $ADDomain)
{
    write-host-"Adding computer to Domain $ADDomain"
    Join-Domain
}
elseif(-not (Test-Connection $ADDomain))
{
    write-host-"The Domain $ADDomain is not reachable"
}

function Join-Domain
{
    write-host "Addding computer to domain $ADDomain"
    $Password = Read-Host -Prompt "Enter password for $ADDomain\$User" -AsSecureString 
    $UserName = "$ADDomain\$user" 
    $credential = New-Object System.Management.Automation.PSCredential($UserName,$Password) 

    try
    {
        Add-Computer -DomainName $ADDomain -Credential $Credential #-restart –force
    }

    catch
    {
        $error[0]
    }
}



