﻿cls
### Create New Page File
### ---------------------------------
$InitialSize = "3000"
$MaximumSize = "4000"
$PageFileLocation = "C:"

# Disable Auto Manage PageFile
$ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
if($ComputerSystem.AutomaticManagedPagefile -eq "True")
{
    $ComputerSystem = Set-CimInstance -Property @{ AutomaticManagedPageFile = $False }
}

write-host "AutomaticManagedPagefile : " $ComputerSystem.AutomaticManagedPagefile 


# Remove PageFile
$PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
write-host "BeforePageFile:" $PageFile.MaximumSize

$PageFile | Remove-CimInstance        

$PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
write-host "AfterPageFile:" $PageFile 

    
Write-Host "Creating New Page File: PageFileLocation: $PageFileLocation InitialSize: $InitialSize MaximumSize: $MaximumSize " 

# New PageFile
$PageFileName = $PageFileLocation + "\pagefile.sys"
New-CimInstance -ClassName Win32_PageFileSetting -Property  @{ Name= $PageFileName } | Out-Null
Get-CimInstance -ClassName Win32_PageFileSetting | Set-CimInstance -Property @{InitialSize = $InitialSize; MaximumSize = $MaximumSize;}


$NewPageFile = Get-CimInstance -ClassName Win32_PageFileSetting
write-host "Name:" $NewPageFile.Name
write-host "InitialSize:" $NewPageFile.InitialSize
write-host "MaximumSize:" $NewPageFile.MaximumSize