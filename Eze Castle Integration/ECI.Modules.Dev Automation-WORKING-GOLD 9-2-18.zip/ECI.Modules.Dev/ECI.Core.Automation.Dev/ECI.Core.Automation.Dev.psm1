##################################
### ECI.Core.Automation.Dev.psm1
##################################

### --------------------------------------------------
### Configure Desired State
### --------------------------------------------------
function Configure-DesiredState
{
    Param(
    [Parameter(Mandatory = $True)][int]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$FunctionName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$DesiredState,
    [Parameter(Mandatory = $True)][scriptblock]$GetCurrentState,
    [Parameter(Mandatory = $True)][scriptblock]$SetDesiredState,
    [Parameter(Mandatory = $True)][ValidateSet("Report","Configure")][string]$ConfigurationMode,
    [Parameter(Mandatory = $True)][ValidateSet($True, $False)][string]$AbortTrigger
    )

    ##################################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##################################################
    function Get-CurrentState
    {
        Try-Catch -Scriptblock { Invoke-Command $GetCurrentState } -Quiet
    }

    ##################################################
    ### COMPARE-CURRENT/DESIRED STATE:
    ##################################################
    function Compare-DesiredState
    {
        $global:Compare = ($CurrentState -eq $DesiredState)
        Write-ConfigReport "COMPARE: $Compare - FUNCTION: $FunctionName CURRENTSTATE: $CurrentState DESIREDSTATE: $DesiredState"
        if($Compare -eq $True)
        {
            ### CURRENT STATE = DESIRED STATE: True
            ### --------------------------------------
            Write-ConfigReport "The Current-State Matches the Desired-State. Not Running Configuration!"
        }
        elseif($Compare -eq $False)
        {
            ### CURRENT STATE = DESIRED STATE: False
            ### --------------------------------------
            Write-ConfigReport "The Current-State Does Not Match the Desired-State. Running Configuration!"
        }
    }

    ##################################################
    ### SET DESIRED-STATE:
    ##################################################
    function Set-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-ConfigReport "Running in Configure Mode. Changing Configuration!"
                [ScriptBlock]$DesiredStateConfiguration = {Invoke-Command $SetDesiredState}
                Try-Catch $DesiredStateConfiguration
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-ConfigReport "Running in Report Mode. Reporting Data Only!"
            }
        }
    }
        
    ##################################################
    ### VERIFY DESIRED STATE:
    ##################################################
    function Verify-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            ### VERIFY: Current State
            ### -----------------------------------------------------
            Get-CurrentState
            $global:VerifyState = $CurrentState

            ### COMPARE: Verify State - Desired State
            ### ----------------------------------------------------- 
            $global:Verify = ($VerifyState -eq $DesiredState) ### <-- True/False
            Write-ConfigReport "COMPARE - VERIFY: $Verify VERIFYSTATE: $VerifyState DESIREDSTATE: $DesiredState"

            ### VERIFY = TRUE
            ### -----------------------------------------------------        
            if($Verify -eq $True)
            {
                ### ABORT = FALSE
                ### --------------------
                $global:Abort = $False
            }
        
            ###  VERIFY = FALSE
            ### -----------------------------------------------------
            elseif($Verify -eq $False)
            {
                ### Increment Verify Error Counter
                $global:VerifyErrorCount ++

                if ($AbortTrigger -eq $True)
                {
                    ### ABORT TRIGGER = TRUE
                    ### --------------------
                    $global:Abort = $True
                }
                elseif($AbortTrigger -eq $False)
                {
                    ### ABORT TRIGGER = FALSE
                    ### --------------------
                    $global:Abort = $False
                }
            }
        }
    }

    ##################################################
    ### REPORT:
    ##################################################
    function Report-DesiredState
    {    
         ### Update Config Log
        ###-------------------------------------
        Write-Host "UPDATING SERVER CONFIG LOGS - ServerID: $ServerID  HostName: $HostName  FunctionName: $FunctionName Verify: $Verify Abort: $Abort" -ForegroundColor Cyan
        Write-ConfigLog -ServerID $ServerID -HostName $HostName -FunctionName $FunctionName -Verify $Verify -Abort $Abort

        ### Update Desired State
        ###-------------------------------------
        Write-Host "UPDATING SERVER DESIRED STATE - ServerID: $ServerID HostName: $HostName PropertyName: $PropertyName CurrentState: $CurrentState DesiredState: $DesiredState Verify: $Verify Abort: $Abort" -ForegroundColor Cyan
        Write-DesiredState -ServerID $ServerID -HostName $HostName -PropertyName $PropertyName -CurrentState $CurrentState -DesiredState $DesiredState -Verify $Verify -Abort $Abort
        
        ### Update Current State
        ###-------------------------------------
        Write-Host "UPDATING SERVER CURRENT STATE - ServerID: $ServerID HostName: $HostName PropertyName: $PropertyName CurrentState: $CurrentState" -ForegroundColor Cyan
        Write-CurrentState -ServerID $ServerID -HostName $HostName -PropertyName $PropertyName -CurrentState $CurrentState


    #Write-ServerConfigLogSQL -VM $VM -FunctionName $FunctionName -Verify $Verify -Abort $Abort        
        
        

        ### Write Config Log
        ###-------------------------------        
        #Write-Host "UPDATING CURRENT STATE - VM: $VM -PropertyName: $PropertyName VerifyState: $VerifyState" -ForegroundColor Cyan
        #Write-Host "PropertyName: $PropertyName"
 
        #Update-CurrentState -ServerID $ServerID -PropertyName $PropertyName -VerifyState $VerifyState

        ### Old -delete me?
        ###-------------------------------        
        #Write-Host "REPORT: SQL - VM: $VM  FUNCTION: $FunctionName VERIFIED: $Verify ABORT: $Abort" -ForegroundColor Yellow
        #Write-Config "REPORT: COOKIE - VM: $VM FUNCTION: $FunctionName VERIFY: $Verify ABORT: $Abort"
        #Write-Cookie $VM $FunctionName $Verify $Abort


        ### IF ABORT = TRUE
        ### --------------------
        if($Abort -eq $True)
        {
            ### Send Alert and Exit the Script
            ### -------------------------------------------------------------------------------------
            Write-ConfigReport "ABORTTRIGGER: " $AbortTrigger "`t`tABORT: " $Abort "`nExiting Script!!!!"
            Write-Host "Starting Sleep!" -ForegroundColor Red
            Start-Sleep -Seconds 1000
            #Send-Alert
            #Exit
        }
    }

    ############################################################################
    ### CONFIGURE DESIRED STATE
    ############################################################################
    &{
        BEGIN
        {   }

        PROCESS
        {
            Get-CurrentState
            Compare-DesiredState
            if($Compare -eq $False){Set-DesiredState}
            Verify-DesiredState
            Report-DesiredState
        }

        END
        {   }   
    }
}

function List-AllParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Server  Parameters
    ###----------------------------------------------------------------
    Write-Host `n('-' * 50)`n "Server Parameters  : "                        -ForegroundColor Gray
    Write-Host "ServerID                   : " $ServerID                     -ForegroundColor Gray

    ### Server Request Parameters
    ###----------------------------------------------------------------
    Write-Host `n('-' * 50)`n "ServerRequest Parameters  : "                  -ForegroundColor Gray
    Write-Host "RequestID                  : " $RequestID                     -ForegroundColor Gray
    Write-Host "RequestDateTime            : " $RequestDateTime               -ForegroundColor Gray
    Write-Host "HostName                   : " $HostName                      -ForegroundColor Gray
    Write-Host "ServerRole                 : " $ServerRole                    -ForegroundColor Gray
    Write-Host "IPv4Address                : " $IPv4Address                   -ForegroundColor Gray
    Write-Host "SubnetMask                 : " $SubnetMask                    -ForegroundColor Gray
    Write-Host "DefaultGateway             : " $DefaultGateway                -ForegroundColor Gray
    Write-Host "InstanceLocation           : " $InstanceLocation              -ForegroundColor Gray
    Write-Host "BackupRecovery             : " $BackupRecovery                -ForegroundColor Gray
    Write-Host "DisasterRecovery           : " $DisasterRecovery              -ForegroundColor Gray 

    ### VM Parameters
    ###----------------------------------------------------------------
    Write-Host "VM Parameters              : " `n('-' * 50)`n -ForegroundColor Gray
    Write-Host "VMParameterID              : " $VMParameterID -ForegroundColor Gray
    Write-Host "vCPUCount                  : " $vCPUCount -ForegroundColor Gray
    Write-Host "vMemorySizeGB              : " $vMemorySizeGB -ForegroundColor Gray
    Write-Host "OSVolumeGB                 : " $OSVolumeGB -ForegroundColor Gray
    Write-Host "SwapVolumeGB               : " $SwapVolumeGB -ForegroundColor Gray
    Write-Host "DataVolumeGB               : " $DataVolumeGB -ForegroundColor Gray
    Write-Host "LogVolumeGB                : " $LogVolumeGB -ForegroundColor Gray
    Write-Host "SysVolumeGB                : " $SysVolumeGB -ForegroundColor Gray

    ### OS Parameters
    ###----------------------------------------------------------------
    Write-Host "OS Parameters              : " `n('-' * 50)`n -ForegroundColor Gray
    Write-Host "NetworkInterfacename       : " $NetworkInterfacename -ForegroundColor Gray
    Write-Host "LocalAdministrator         : " $LocalAdministrator -ForegroundColor Gray
    Write-Host "CDROMLetter                : " $CDROMLetter -ForegroundColor Gray
    Write-Host "IPv6Preference             : " $IPv6Preference -ForegroundColor Gray
    Write-Host "WindowsFirewallPreference  : " $WindowsFirewallPreference -ForegroundColor Gray
    Write-Host "IEESCPreference            : " $InternetExplorerESCPreference -ForegroundColor Gray
    Write-Host "RemoteDesktopPreference    : " $RemoteDesktopPreference -ForegroundColor Gray
    Write-Host "RDPResetrictionsPreference : " $RDPResetrictionsPreference -ForegroundColor Gray
    Write-Host "SwapFileBufferSizeMB       : " $SwapFileBufferSizeMB -ForegroundColor Gray
    Write-Host "SwapFileLocation           : " $SwapFileLocation -ForegroundColor Gray
    Write-Host "SwapFileMemoryThreshholdGB : " $SwapFileMemoryThreshholdGB -ForegroundColor Gray
    Write-Host "SwapFileMultiplier         : " $SwapFileMultiplier -ForegroundColor Gray
    Write-Host  `n('-' * 50)`n -ForegroundColor Gray
}

### --------------------------------------------------
### VMWare Functions
### --------------------------------------------------
function Import-VMWareModules
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VMModules = "VMware.VimAutomation.*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
    
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -InvalidCertificateAction ignore -Confirm:$false | Out-Null
}

function Get-ECI.vCenter
{
    Param([Parameter(Mandatory = $True)][string]$InstanceLocation)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    switch ( $InstanceLocation )
    {
        "Lab" { $ECIvCenter = "ecilab-bosvcsa01.ecilab.corp" }
        "BOS" { $ECIvCenter = "bosvc.eci.cloud"      }
        "QTS" { $ECIvCenter = "cloud-qtsvc.eci.corp" }
        "SAC" { $ECIvCenter = "sacvc.eci.cloud"      }
        "LHC" { $ECIvCenter = "lhcvc.eci.cloud"      }
        "LD5" { $ECIvCenter = "ld5vc.eci.cloud"      }
        "HK"  { $ECIvCenter = "hkvc.eci.cloud"       }
        "SG"  { $ECIvCenter = "sgvc.eci.cloud"       }
    }

    $global:ECIvCenter = $ECIvCenter
    Write-Host "Instance Location  : " $InstanceLocation -ForegroundColor Yellow
    Write-Host "vCenter            : " $ECIvCenter -ForegroundColor Yellow
    Return $global:ECIVCenter
}

function Connect-ECI.VIServer
{
    Param([Parameter(Mandatory = $True)][string]$InstanceLocation)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Show/Hide VMWare Module Progress Bar
    $global:ProgressPreference = "Continue" ### "SilentlyContinue"

    write-host "InstanceLocation: " $InstanceLocation -ForegroundColor Gray

    $ECIvCenter = Get-ECI.vCenter -InstanceLocation $InstanceLocation



    if($global:DefaultVIServers.Count -gt 0)
    {
        Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
        #Disconnect-VIServer -Server $global:DefaultVIServers -confirm:$false
    }
    else 
    {
        Write-Host "Connecting New Session to VI Server: "  $ECIvCenter -ForegroundColor Gray
        #$VISession = Connect-VIServer -Server $ECIvCenter  -User ezebos\cbrennan -Password Tolkien43741
        $VISession = Connect-VIServer -Server $ECIvCenter  -User sdesimone_admin@ecilab.corp -Password cH3r0k33!B #| Out-Null
        $global:vCenterUUID = $VISession.InstanceUuid
        Write-Host "vCenterUUID   : " $vCenterUUID -ForegroundColor Magenta
    }
    

<#
    Write-Host "ECIvCenter    : " $ECIvCenter -ForegroundColor Magenta
    Write-Host "VISession     : " $VISession -ForegroundColor Magenta
    Write-Host "vCenterUUID   : " $vCenterUUID -ForegroundColor Magenta
#>
    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
    }

function Get-VMwareModuleVersion
{
    Write-Host "Getting VMWare Module Versions." -ForegroundColor Yellow

    Get-Module -Name VMware.PowerCLI | Select-Object -Property Name,Version
    Get-Module -Name VMware.* | Select-Object -Property Name,Version
}


### --------------------------------------------------
### Log Files
### --------------------------------------------------


### Delete Server Logs
### --------------------------------------------------
function Delete-ServerLogs
{
    Param(
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $False)][switch]$RuninGuest
    )
    ### Delete Log Path
    ###---------------------------
    if($RuninGuest)
    {
        $VMLogPath = "C:\SCripts\VMAutomation\" + $HostName + "\"
    }
    elseif(!($RuninGuest))
    {
        $VMLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\"
    }
    
    if(Test-Path -Path $VMLogPath)
    {
        Remove-Item -Path $VMLogPath -Include * -Recurse -Force -Confirm:$false 
    }
}

### Write Server Config Log
### --------------------------------------------------
function Write-ConfigLog
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$FunctionName,
    [Parameter(Mandatory = $True)][string]$Verify,
    [Parameter(Mandatory = $True)][string]$Abort,
    [Parameter(Mandatory = $False)][switch]$RuninGuest
    )

    function Create-ConfigLogFile
    {
        $ConfigLogName = "ConfigLog"

        ### Set Log Path
        ###---------------------------
        if($RuninGuest)
        {
            $script:ConfigLogPath = "C:\SCripts\VMAutomation\" + $HostName + "\"
        }
        elseif(!($RuninGuest))
        {
            $script:ConfigLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\"
        }
    
        ### Create Log Folder
        if(-NOT(Test-Path -Path $ConfigLogPath)) {(New-Item -ItemType directory -Path $ConfigLogPath -Force | Out-Null)}
    
        ### Set Log File Name
        ###---------------------------
        $script:ConfigLog = $ConfigLogPath + $ConfigLogName + "_" + $HostName + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"

        ### Delete Existing Log File
#        if(Test-Path -Path $ServerConfigLog){(Remove-Item -Path $ServerConfigLog -Force | Out-Null)}

        if(-NOT(Test-Path -Path $ConfigLog)) {(New-Item -ItemType file -Path $ConfigLog -Force | Out-Null)}
    }
    ### Create new log file if the log File variable doesnt exist 
    ###------------------------------------------------------------
    if (((Get-Variable 'ConfigLog' -Scope Global -ErrorAction 'Ignore')) -eq $Null)    #same as: (if(-NOT($LogFile)))
    {
        Create-ConfigLogFile
    }  
    else
    {
        $script:ConfigLog = $ConfigLog
    }

    $LogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "FunctionName=" + $FunctionName + "," +  "Verify=" + $Verify + "," +  "Abort=" + $Abort
    $LogEntry | Out-File -FilePath $ConfigLog -Append -Force
}

### Write Server Config Logs to SQL
### --------------------------------------------------
function Write-ConfigLog-SQL
{
    $VMLogName = "ConfigLog"

    ### Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $script:ConfigLog = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\" + "ConfigLog" + "_" + $HostName + ".txt"
    Write-Host "Writing ConfigLogFile to SQL: " $ConfigLog
    $ConfigLog = Get-Content -Path $ConfigLog
    
    foreach ($Record in $ConfigLog)
    {
        $Keys = $Null
        $Values = $Null

        foreach($Column in ($Record.split(",")))
        {
          $Key = $Column.split("=")[0]
          $Value =  "'" + $Column.split("=")[1] + "'"
          $Keys = $Keys + $Key + ","
          $Values = $Values + $Value + ","
        }
        $Keys = $Keys.Substring(0,$Keys.Length-1)
        $Values = $Values.Substring(0,$Values.Length-1)

        $Query = "INSERT INTO ServerConfigLog($Keys) VALUES ($Values)"
        
        ### Show Results
        ###------------------------
        Write-Host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

### Write Server Desired State
### --------------------------------------------------
function Write-DesiredState
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$CurrentState,
    [Parameter(Mandatory = $True)][string]$DesiredState,
    [Parameter(Mandatory = $True)][string]$Verify,
    [Parameter(Mandatory = $True)][string]$Abort,
    [Parameter(Mandatory = $False)][switch]$RuninGuest
    )

    function Create-DesiredStateFile
    {
        ### Set Log Path
        ###---------------------------
        $DesiredStateLogName = "DesiredStateLog"

        ### Set Log Path
        ###---------------------------
        if($RuninGuest)
        {
            $script:DesiredStateLogPath = "C:\SCripts\VMAutomation\" + $HostName + "\"
        }
        elseif(!($RuninGuest))
        {
            $script:DesiredStateLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\"
        }
    
        ### Create Log Folder
        if(-NOT(Test-Path -Path $DesiredStateLogPath)) {(New-Item -ItemType directory -Path $DesiredStateLogPath -Force | Out-Null)}
    
        ### Set Log File Name
        ###---------------------------
        $script:DesiredStateLog = $DesiredStateLogPath + $DesiredStateLogName + "_" + $HostName + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"

        ### Delete Existing Log File
#        if(Test-Path -Path $DesiredStateLog){(Remove-Item -Path $DesiredStateLog -Force | Out-Null)}

        if(-NOT(Test-Path -Path $DesiredStateLog)) {(New-Item -ItemType file -Path $DesiredStateLog -Force | Out-Null)}
    }

    ### Create new log file if the log File variable doesnt exist 
    ###------------------------------------------------------------
    if (((Get-Variable 'DesiredStateLog' -Scope Global -ErrorAction 'Ignore')) -eq $Null)    #same as: (if(-NOT($LogFile)))
    {
        Create-DesiredStateFile
    }  
    else
    {
        $script:DesiredStateLog = $DesiredStateLog
    }

    $LogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "PropertyName=" + $PropertyName + "," +  "CurrentState=" + $CurrentState + "," +  "DesiredState=" + $DesiredState + "," +  "Verify=" + $Verify + "," +  "Abort=" + $Abort
    $LogEntry | Out-File -FilePath $DesiredStateLog -Append -Force
}

### Write Server Desired State to SQL
### --------------------------------------------------
function Write-DesiredState-SQL
{
    $VMLogName = "DesiredState"

    ### Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $script:DesiredStateLog = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\" + "DesiredStateLog" + "_" + $HostName + ".txt"
    Write-Host "Writing DesiredStateLog to SQL: " $DesiredStateLog
    $DesiredStateLog = Get-Content -Path $DesiredStateLog
    
    foreach ($Record in $DesiredStateLog)
    {
        $Keys = $Null
        $Values = $Null

        foreach($Column in ($Record.split(",")))
        {
          $Key = $Column.split("=")[0]
          $Value =  "'" + $Column.split("=")[1] + "'"
          $Keys = $Keys + $Key + ","
          $Values = $Values + $Value + ","
        }
        $Keys = $Keys.Substring(0,$Keys.Length-1)
        $Values = $Values.Substring(0,$Values.Length-1)

        $Query = "INSERT INTO ServerDesiredState($Keys) VALUES ($Values)"
        
        ### Show Results
        ###------------------------        
        write-host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

### Write Server Desired State
### --------------------------------------------------
function Write-CurrentState
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$CurrentState
    )

    function Create-CurrentStateFile
    {
        ### Set Log Path
        ###---------------------------
        $CurrentStateName = "CurrentStateLog"

        ### Set Log Path
        ###---------------------------
        if($RuninGuest)
        {
            $script:CurrentStateLogPath = "C:\SCripts\VMAutomation\" + $HostName + "\"
        }
        elseif(!($RuninGuest))
        {
            $script:CurrentStateLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\"
        }
    
        ### Create Log Folder
        if(-NOT(Test-Path -Path $CurrentStateLogPath)) {(New-Item -ItemType directory -Path $CurrentStateLogPath -Force | Out-Null)}
    
        ### Set Log File Name
        ###---------------------------
        $script:CurrentStateLog = $CurrentStateLogPath + $CurrentStateName + "_" + $HostName + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"

        ### Delete Existing Log File
#        if(Test-Path -Path $DesiredStateLog){(Remove-Item -Path $DesiredStateLog -Force | Out-Null)}

        if(-NOT(Test-Path -Path $CurrentStateLog)) {(New-Item -ItemType file -Path $CurrentStateLog -Force | Out-Null)}
    }
    ### Create new log file if the log File variable doesnt exist 
    ###------------------------------------------------------------
    if (((Get-Variable 'DesiredStateLog' -Scope Global -ErrorAction 'Ignore')) -eq $Null)    #same as: (if(-NOT($LogFile)))
    {
        Create-CurrentStateFile
    }  
    else
    {
        $script:CurrentStateLog = $CurrentStateLog
    }

    $LogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "PropertyName=" + $PropertyName + "," +  "CurrentState=" + $CurrentState
    $LogEntry | Out-File -FilePath $CurrentStateLog -Append -Force
}

### Write Server Desired State to SQL
### --------------------------------------------------
function Write-CurrentState-SQL
{
    #Param([Parameter(Mandatory = $True)][string]$ServerID)

    $CurrentStateLogName = "CurrentStateLog"

    ### Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $script:CurrentStateLog = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $HostName + "\" + $CurrentStateLogName + "_" + $HostName + ".txt"
    Write-Host "Writing CurrentStateLog to SQL: " $CurrentStateLog
    $CurrentStateLog = Get-Content -Path $CurrentStateLog
    
    foreach ($Record in $CurrentStateLog)
    {
        $Keys = $Null
        $Values = $Null

        $ServerID     = ($Record.split(","))[0].split("=")[1]
        $HostName     = ($Record.split(","))[1].split("=")[1]
        $PropertyName = ($Record.split(","))[2].split("=")[1]
        $CurrentState = ($Record.split(","))[3].split("=")[1]
        
        $CurrentStateDateTime = "'" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "'"

### Remove me!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#$ServerID = 621


        if($CurrentState -eq "False"){$CurrentState = 0}
        if($CurrentState -eq "True"){$CurrentState = 1}
        else {$CurrentState = "'" + $CurrentState + "'"}

        #Write-Host "------------------------------------------"
        #Write-Host "ServerID      : " $ServerID
        #Write-Host "HostName      : " $HostName
        #Write-Host "PropertyName  : " $PropertyName
        #Write-Host "CurrentState  : " $CurrentState

        $Query = "UPDATE ServerCurrentState SET $PropertyName = $CurrentState, CurrentStateDateTime =  $CurrentStateDateTime WHERE ServerID = $ServerID"
        ###UPDATE ServerCurrentState SET column1 = value1, column2 = value2...., columnN = valueN WHERE [condition];

        ### Show Results
        ###------------------------        
        write-host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

############################################################################

### Show OS Parameters
### --------------------------------------------------
function Show-OSParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "`nOS Parameters:" `n("-" * 50)
    Write-Host "Step                : " $Step
    Write-Host "VM                  : " $VM
    Write-Host "ServerID            : " $ServerID
    Write-Host "ServerRole          : " $ServerRole
    Write-Host "HostName            : " $HostName
    Write-Host "ClientDomain        : " $ClientDomain
    Write-Host "IPv4Address         : " $IPv4Address
    Write-Host "SubnetPrefixLength  : " $SubnetPrefixLength
    Write-Host "DefaultGateway      : " $DefaultGateway
    Write-Host "PrimaryDNS          : " $PrimaryDNS
    Write-Host "SecondaryDNS        : " $SecondaryDNS
    

    Write-Host "BuildVersion: " $BuildVersion
    Write-Host "CDROMLetter: " $CDROMLetter
    Write-Host "InternetExplorerESCPreference: " $InternetExplorerESCPreference
    Write-Host "IPv6Preference: " $IPv6Preference
    Write-Host "LocalAdministrator: " $LocalAdministrator
    Write-Host "NetworkInterfaceName: " $NetworkInterfaceName
    Write-Host "RDPResetrictionsPreference: " $RDPResetrictionsPreference
    Write-Host "RemoteDesktopPreference: " $RemoteDesktopPreference
    Write-Host "SwapFileBufferSizeMB: " $SwapFileBufferSizeMB
    Write-Host "SwapFileLocation: " $SwapFileLocation
    Write-Host "SwapFileMemoryThreshholdGB: " $SwapFileMemoryThreshholdGB
    Write-Host "SwapFileMultiplier: " $SwapFileMultiplier
    Write-Host "WindowsFirewallPreference: " $WindowsFirewallPreference
}


### --------------------------------------------------

##################################################################################

###--------------------------------------------------------------------
###--------------------------------------------------------------------

function Write-ConfigReport 
{
    Param(
    [Parameter(Mandatory = $True, Position = 0)] [string]$Message,
    [Parameter(Mandatory = $False, Position = 1)] [string]$String,
    [Parameter(Mandatory = $False, Position = 2)] [string]$String2,
    [Parameter(Mandatory = $False, Position = 3)] [string]$String3,
    [Parameter(Mandatory = $False, Position = 4)] [string]$String4,
    [Parameter(Mandatory = $False, Position = 5)] [string]$String5,
    [Parameter(Mandatory = $False, Position = 6)] [string]$String6
    )
        function Start-ConfigReport 
    {
        ### Create Timestamp
        $TimeStamp  = Get-Date -format "MM-dd-yyyy_hh_mm_ss"

        ### Create Log Folder
        #$ConfigReportPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $VM + "\"
        $global:ConfigReportPath = "C:\Scripts\Logs\ConfigReport\"
        if(-NOT(Test-Path -Path $ConfigReportPath)) {(New-Item -ItemType directory -Path $ConfigReportPath -Force | Out-Null) }
       
        ### Create Log File
        $global:ConfigReportFile = $ConfigReportPath + "ConfigReport" + "_" + $TimeStamp + ".log"
        
        if(-NOT(Test-Path -Path $ConfigReportFile)) {(New-Item -ItemType file -Path $ConfigReportFile -Force | Out-Null) }
    }

    if (((Get-Variable 'ConfigReportFile' -Scope Global -ErrorAction 'Ignore')) -eq $Null) #if (-NOT($LogFile))
    {
        Start-ConfigReport
    }     

    ### Write the Message to the Config Report.
    $Message = $Message + $String + $String2 + $String3 + $String4 + $String5 + $String6
    Write-Host $Message
    $Message | Out-File -filepath $ConfigReportFile -append   # Write the Log File Emtry
}

function Write-ServerBuildTag #-redo
{
    Write-Host "Writing ServerBuildTag:"`n("-" * 50)

    ### Create Server Build Tag
    $ServerBuildTagPath = "C:\Scripts\VMAutomation\ServerBuildTag_" + $VM + "_" + $(get-date -f MM-dd-yyyy_HH_mm_ss) + ".txt"
   
    $ServerBuildTag     = [ordered]@{
        VMGuestName     = (Get-WmiObject Win32_ComputerSystem).Name
        VMGuestOS       = [environment]::OSVersion.Version
        VMGuestDomain   = (Get-WmiObject Win32_ComputerSystem).Domain
        BuildDate       = $(get-date)
        Engineer        = "CBrennan - (cbrennan@eci.com)"

    }
    $ServerBuildTag | Out-File -FilePath $ServerBuildTagPath -Force

    ### Get Module Meta Data
    $Modules = Get-Module | Where-Object {($_.Name -like "ECI.Core.*")}
    foreach($Module in $Modules)
    {
        $ModuleData = [ordered]@{
            Module        = $Module
            ModuleVersion = $Module.Version
        }
        $ModuleData | Out-File -FilePath $ServerBuildTagPath -Append
    
        Write-Host "Module: " $Module
        Write-Host "ModuleVersion: " $Module.Version   
    }

    ### Get Parameters
    Write-Host "Soft Parameters:" 
    $SoftParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $SoftParameters | FT
    
    Write-Host "Hard Parameters:" 
    $HardParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $HardParameters | FT
    
    Write-Host "Windows Features Installed:" 
    ("Windows Features:") | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | FT
}
###--------------------------------------------------------------------
###--------------------------------------------------------------------

###################################################


function Throw-AbortError
{
    Write-Host "Abort Error Triggered!" -ForegroundColor Red
    
    ###--------------------------------------------
    ### Write to Database
    ###--------------------------------------------
    
    $Database = "AzureSQL"
    $Table = "AbortError"

    Write-SQLData -Database $Database -Table $Table

    ###--------------------------------------------
    ### Send Email
    ###--------------------------------------------

    ### Manually Overide Email Parameters
    $SMTPServer = "owablu.ecilab.net"
    $To         = "cbrennan@eci.com"
    $From       = "cbrennan@eci.com"
    $Subject    = ""
    $Message    = ""

    ### Email Parameters
    $EmailParams = 
    @{
        From       = $From
        To         = $To 
        #CC        = $CC
        SMTPServer = $SMTPServer
     }
    #Send-MailMessage -SmtpServer owablu.ecilab.net -To sdesimone@eci.com -From wwilson@geemoneymgmt.com -Subject "hi"
    Send-MailMessage @EmailParams -Body ($Message | Out-String) -BodyAsHtml -Subject $Subject
}

### Open SQL Server Connection - SQL
### --------------------------------------------------
function Open-SQLConnection
{    
    [OutputType([bool])]
    Param([Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)]$ConnectionString)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    try
    {
        $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $Connection.Open();
        $Connection.Close();

        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $True;
    }
    catch
    {
        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $False;
        $Abort = $True
        Invoke-AbortError
    }
}

### Test SQL Server Connectivity - SQL
### --------------------------------------------------
function Test-SQLConnection
{    
    [OutputType([bool])]
    Param([Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)]$ConnectionString)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $SQLConnectionString   = "server=ECILAB-BOSDEV01\SQLEXPRESS;database=ServerConfiguration-Dev-Lab;trusted_connection=true;"
    $AzureConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $CWConnectionString   = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    try
    {
        $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $Connection.Open();
        $Connection.Close();

        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $True;
    }
    catch
    {
        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $False;
        $Abort = $True
        Invoke-AbortError
    }
}

### Get VM Parameters - SQL
### --------------------------------------------------
function Get-SQLData
{
    PARAM(
        [Parameter(Mandatory = $True)] [string]$DataSetName,
        [Parameter(Mandatory = $True)] [string]$ConnectionString,
        [Parameter(Mandatory = $True)] [string]$Query
    )

    BEGIN 
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = $ConnectionString 
        $Connection.Open()    

        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
    }
    
    PROCESS
    {
        ### Datatable
        #$Datatable = $DataSetName
        $Datatable = New-Object System.Data.DataTable
        $Datatable.Load($Reader)

        ### Get Columns from the  Datatable
        ###---------------------------------
        $Columns = $Datatable | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name} | Sort-Object -Property Name

        $global:Parameters = @()
        foreach($Column in $Columns)
        {
            ### Create Variables from Datatable
            Set-Variable -Name $Column -Value $Datatable.$Column -Scope global
            
            ### Build Parameter Set from Datatable
            $Parameters += Get-Variable -Name $Column 
            
            ### Build All Parameters Set
            $global:AllParameters += Get-Variable -Name $Column 
        }
        Write-Host "Getting Data Set: " $DataSetName -foregroundcolor yellow
        $Parameters | FT

<#
        $(($DataSetName) = "TEST") # $Parameters | Get-Member 
        
        #$DataSetName
        $ServerRequestParameters

<#
        ### Create Hash Table of Parameters
        ### ---------------------------------
        [array]$DataSetName = $DataSetName
        #$DataSetName = $Null
        $DataSetName = @{}
        #$DataSetName = @()

        foreach($Parameter in $Parameters)
        {
            $DataSetName.Add($Parameter.Name,$Parameter.Value)
        }
        #$ParameterSet
        $DataSetName
#>
       #Write-Host "ServerRequestParameters" -ForegroundColor Magenta        
        
        #$message = "Time: $($directory.CreationTime)"
        
        #$($DataSetName) = $Null

<#        
        $(($DataSetName) = @{})
        
        
        foreach($Parameter in $Parameters)
        {
            $(($DataSetName).Add($Parameter.Name,$Parameter.Value))
        }
        
        $(($DataSetName))
        $ServerRequestParameters
#>

    }
    
    END 
    {
        ### Close Database Connection
        $Connection.Close()
    }
}

### Build-ParameterHashTable from $AllParameters created by Get-SQL Data function          <-- delete me????
### --------------------------------------------------
function Build-ParameterHashTable-old #<-- delete me????
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Building Parameter Hash Table:" -ForegroundColor Yellow
    
   
    $global:ParameterHashTable = $Null
    $ParameterHashTable = @{}
    foreach($Parameter in ($AllParameters) | Sort-Object)
    {
        #Write-Host "Parameter Name: " $Parameter.Name
        #Write-Host "Parameter Value: " $Parameter.Value
        $ParameterHashTable.Add($Parameter.Name,$Parameter.Value)
    }
    #$ParameterHashTable | FT
}

### Generate-ParameterList                               <-- delete me????
### --------------------------------------------------
function Generate-ParameterList-delete # <-- delete me????
{
    foreach($Parameter in $AllParameters)
    {
        $String = '[Parameter(Mandatory = $True)][string]$'
        $Name = $Parameter.name
        $ParameterString = $string + $Name + ","
        $ParameterString
    }
}


### Get Build Version - SQL
### --------------------------------------------------
function Get-ECI.BuildVersion
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "BuildVersion"
    $ConnectionString =  "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionBuildVersions WHERE Production = '$True'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query   
}

### Get Server Request Parameters - SQL
### --------------------------------------------------
function Get-ECI.ServerRequest
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerRequest"
    #$ConnectionString = "server=ECILAB-BOSDEV01\SQLEXPRESS;database=ServerConfiguration-Dev-Lab;trusted_connection=true;"
    $ConnectionString = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    $Query = �SELECT * FROM ServerRequest WHERE RequestID = '$RequestID'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query   

    Write-Host "RequestId  : $RequestId" -ForegroundColor Yellow
    Write-Host "GPID       : $GPID" -ForegroundColor Yellow
    Write-Host "CWID       : $CWID" -ForegroundColor Yellow
    Write-Host "HostName   : $HostName" -ForegroundColor Yellow
}

### Get Server Role - SQL
### --------------------------------------------------
function Get-ECI.ServerRole
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerRole"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionServerRoles WHERE ServerRole = '$RequestServerRole' AND BuildVersion = '$BuildVersion'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Get VMWare Template - SQL
### --------------------------------------------------
function Get-ECI.VMWareTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareTemplate"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionVMWareTemplates WHERE VMWareTemplateIServerRole = '$ServerRole' AND VMWareTemplateIBuildVersion = '$BuildVersion'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Get VMWare OSCustomizationSpec - SQL
### --------------------------------------------------
function Get-ECI.OSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareOSCustomizationSpec"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionVMWareOSCustomizationSpec WHERE OSCustomizationSpecServerRole = '$ServerRole' AND OSCustomizationSpecBuildVersion = '$BuildVersion'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Get VM Parameters - SQL
### --------------------------------------------------
function Get-ECI.VMParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMParameters"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionVMParameters WHERE VMServerRole = '$ServerRole' AND VMBuildVersion = '$BuildVersion'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Get OS Parameters - SQL
### --------------------------------------------------
function Get-ECI.OSParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "OSParameters"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM definitionOSParameters WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'�

    Get-SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Check Server Record - SQL                           <--- Set Configuration Mode!!!!!!!!!!
### --------------------------------------------------
function Check-ServerRecord
{
    Param(
        [Parameter(Mandatory = $True)][string]$GPID,
        [Parameter(Mandatory = $True)][string]$CWID,
        [Parameter(Mandatory = $True)][string]$HostName
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 

    
    ### Get Existing Record
    $Query = �SELECT * FROM Servers WHERE GPID = '$GPID' AND CWID = '$CWID' AND HostName = '$HostName'�
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $Datatable = New-Object System.Data.DataTable
    $Datatable.Load($Reader)

    ### Check if Server Record Exists
    ###--------------------------------
    if(($Datatable.Rows.Count) -eq 0)
    {
        $global:ServerExists = $False
        $global:ConfigurationMode = "Configure"
        Write-Host `n('-' * 75)`n "This is a New Server Request: Running in Configure Mode!" `n('-' * 75)`n -ForegroundColor Yellow
    }
    elseif(($Datatable.Rows.Count) -gt 0)
    {
        $global:ServerExists = $True
        $global:ConfigurationMode = "Report"
        Write-Host `n('-' * 75)`n "A Matching Server Record already Exists: Running in Report Mode!" `n('-' * 75)`n -ForegroundColor Yellow
    }

    Write-Host "ServerExists: " $ServerExists -ForegroundColor Gray
    Write-Host "Setting ConfigurationMode: " $ConfigurationMode -ForegroundColor Gray
    #Return $global:ConfigurationMode 
}

### Write Server Status - SQL
### --------------------------------------------------
function Create-ServerStatus
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$ServerStatus
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "WRITING SERVER STATUS:  RequestID: $RequestID HostName: $HostName ServerStatus: $ServerStatus" -ForegroundColor Cyan
    #$Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,ServerStatus,ElapsedTime,VerifyErrorCount,Abort) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}')" -f $RequestID,$ServerID,$HostName,$ServerStatus,$ElapsedTime,$VerifyErrorCount,$Abort
    
    $Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,ServerStatus,ElapsedTime,VerifyErrorCount,Abort) VALUES('$RequestID','$ServerID','$HostName','$ServerStatus','$ElapsedTime','$VerifyErrorCount','$Abort')"

    ### Open Database Connection
    $ConnectionString = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
    
    Write-Host `n('-' * 50)`n "END Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
}

### Update Server Status - SQL
### --------------------------------------------------
function Update-ServerStatus
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][int]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$VerifyErrorCount,
    [Parameter(Mandatory = $True)][string]$Abort,
    [Parameter(Mandatory = $False)][string]$ElapsedTime,
    [Parameter(Mandatory = $True)][string]$ServerStatus
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "UPDATE SERVER STATUS - ServerStatus: $ServerStatus RequestID: $RequestID ServerID: $ServerID HostName: $HostName Verify : Verify Abort: $Abort ElsapsedTime: $ElapsedTime" -ForegroundColor Cyan

    #$Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,Verify,Abort,ElapsedTime,ServerStatus) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}')" -f $RequestID,$ServerID,$HostName,$Verify,$Abort,$ElapsedTime,$ServerStatus
    
    $Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,VerifyErrorCount,Abort,ElapsedTime,ServerStatus) VALUES('$RequestID','$ServerID','$HostName','$VerifyErrorCount','$Abort','$ElapsedTime','$ServerStatus')" #-f $RequestID,$ServerID,$HostName,$Verify,$Abort,$ElapsedTime,$ServerStatus
    
    ### Open Database Connection
    $ConnectionString = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

### Create Server Record - SQL
### --------------------------------------------------
function Create-ServerRecord
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][string]$GPID,
    [Parameter(Mandatory = $True)][string]$CWID,        
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$ServerRole,
    [Parameter(Mandatory = $True)][string]$BuildVersion
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ###-------------------------------
    ### Create Server Record
    ###-------------------------------
    Write-Host "CREATING SERVER RECORD:  RequestID: $RequestID GPID: $GPID CWID: $CWID HostName: $HostName ServerRole: $ServerRole BuildVersion: $BuildVersion" -ForegroundColor Cyan

    # Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   

    # Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    
    #$Query = "INSERT INTO Servers(RequestID,GPID,CWID,HostName,ServerRole,BuildVersion) VALUES('$RequestID','$GPID','$CWID','$HostName','$ServerRole','$BuildVersion')" 
    
    $Query = "INSERT INTO Servers(RequestID,GPID,CWID,HostName,ServerRole,InstanceLocation,IPv4Address,SubnetMask,DefaultGateway,PrimaryDNS,SecondaryDNS,ClientDomain,DomainUserName,BackupRecovery,DisasterRecovery,RequestDateTime,BuildVersion) VALUES('$RequestID','$GPID','$CWID','$HostName','$RequestServerRole','$InstanceLocation','$IPv4Address','$SubnetMask','$DefaultGateway','$PrimaryDNS','$SecondaryDNS','$ClientDomain','$DomainUserName','$BackupRecovery','$DisasterRecovery','$RequestDateTime','$BuildVersion')"
    
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()
}

function Create-CurrentStateRecord
{
    Param(
    [Parameter(Mandatory = $True)][int]$ServerID
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "CREATING CURRENT STATE RECORD:  ServerID: $ServerID" -ForegroundColor Cyan

    # Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   

    # Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $Query = "INSERT INTO ServerCurrentState(ServerID) VALUES('{0}')" -f $ServerID
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()
}

### Update Current State - SQL
### --------------------------------------------------
function Update-CurrentState-old # delete me????
{
    Param(
    #[Parameter(Mandatory = $False, Position = 0)] [string]$ServerID,
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$VerifyState
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray


    # Check if current state exisys...


    Write-Host "UPDATING CURRENT STATE - VM: $VM  PropertyName: $PropertyName VerifyState: $VerifyState" -ForegroundColor Gray

    $Query = "UPDATE ServerCurrentState SET $PropertyName = '$VerifyState' WHERE ServerID = $ServerID"

    # Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

### Get Server ID - SQL <--------------------------------(DATATABLE ROWS/COLUMNS!!!!!!)
### --------------------------------------------------
function Get-ServerID
{
    Param([Parameter(Mandatory = $True)][int]$RequestID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Parameters
    ###---------------------------
    $DataSetName = "ServerID"
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT ServerID FROM Servers WHERE RequestID = '$RequestID'�
    
    ### Execute Query
    ###---------------------------
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)
    $Connection.Close()

    ### Return Values
    ###----------------------------
    foreach ($Datarow in $DataTable.Rows)
    {
       #Write-Host "Value: " $DataTable.Columns 
       #Write-Host "Value: " $DataRow[0] 
       Set-Variable -Name $DataTable.Columns -Value $DataRow[0] -Scope Global
    }
    
    $global:ServerID = $ServerID
    Write-Host "Returned - ServerID: " $ServerID -ForegroundColor Yellow
    Return $ServerID
}

function Create-CurrentStateRecord
{
    Param([Parameter(Mandatory = $True)][int]$ServerID)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ###-------------------------------
    ### Create Current State Record
    ###-------------------------------
    Write-Host "CREATING CURRENT STATE RECORD:  ServerID: $ServerID HostName: $HostName" -ForegroundColor Cyan

    # Open Database Connection
    $ConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   

    # Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    
    #$Query = "INSERT INTO Servers(RequestID,GPID,CWID,HostName,ServerRole,BuildVersion) VALUES('$RequestID','$GPID','$CWID','$HostName','$ServerRole','$BuildVersion')" 
    
    $Query = "INSERT INTO ServerCurrentState(ServerID,HostName) VALUES('$ServerID','$HostName')"
    
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()
}

#########################################################

function Get-ServerRecord-SQL
{
    Write-Host "`nGetting Server Record - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow

    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    
    $Query = �SELECT * FROM Servers WHERE ServerID = '$ServerID'�
    #$Query = �SELECT * FROM Servers WHERE ServerID = '824'�
    #$Query = �SELECT * FROM ServerCurrentState WHERE CurrentStateID = '$CurrentStateID'�

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()
    $command = $connection.CreateCommand()

    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table
        
    $connection.Close()
}

function Get-ServerCurrentState-SQL
{
    Write-Host "`nGetting Server Current State - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow

    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    
    $Query = �SELECT * FROM ServerCurrentState WHERE ServerID = '$ServerID'�
    #$Query = �SELECT * FROM Servers WHERE ServerID = '824'�
    #$Query = �SELECT * FROM ServerCurrentState WHERE CurrentStateID = '$CurrentStateID'�

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()
    $command = $connection.CreateCommand()

    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table
        
    $connection.Close()
}

function Get-ServerDesiredState-SQL
{
    Write-Host "`nGetting Server Desired State - ServerID: $ServerID " `n('-' * 50) -ForegroundColor Yellow

    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    
    $Query = �SELECT * FROM ServerDesiredState WHERE ServerID = '$ServerID'�
    #$Query = �SELECT * FROM Servers WHERE ServerID = '824'�
    #$Query = �SELECT * FROM ServerCurrentState WHERE CurrentStateID = '$CurrentStateID'�

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()
    $command = $connection.CreateCommand()

    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table  | FT
        
    $connection.Close()
}

function Get-ServerConfigLog-SQL
{
    Write-Host "`nGetting Server Config Log - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow

    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    
    $Query = �SELECT * FROM ServerConfigLog WHERE ServerID = '$ServerID'�
    #$Query = �SELECT * FROM Servers WHERE ServerID = '824'�
    #$Query = �SELECT * FROM ServerCurrentState WHERE CurrentStateID = '$CurrentStateID'�

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $connectionString
    $connection.Open()
    $command = $connection.CreateCommand()

    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table | FT
        
    $connection.Close()
}



########################################################


function Restart-VMGuest
{
    Write-Host "Rebooting Server: $VM"
    Restart-Computer -Confirm:$false 
}
<#
#######################################
### Function: Reboot-Resume Guest OS
#######################################
function Reboot-Resume
{
    ###################################
    ### Reboot Guest OS
    ###################################
    Write-Host "Rebooting Server: $VM" -ForegroundColor Yellow
    Restart-Computer -VM $VM -Server $VIServer | Wait-Tools | Out-Null

    ###################################
    ### Resume Guest OS After Restart
    ###################################
    Write-Host "Waiting for Server to Resume: $VM" -ForegroundColor Yellow

    ### Pause Script
    ### ---------------------------
    ### Pause to let the Reboot command Start, otherwise the Wait-Tools will respond immediately
    $t = 15 ### Timer for Dev
    #$t = 60 ### Timer for Prod
    Write-Host "Sleeping Script for $t secs ..." -ForegroundColor Gray
    Start-Sleep -Seconds $t

    ### Wait for VM Tools
    ### ---------------------------
    $t = 60 ### Timer for Dev
    #$t = 240 ### Timer for Prod
    Write-Host "Waiting for VMTools to Respond for $t secs ..." -ForegroundColor Gray
    Wait-Tools -VM $VM -TimeoutSeconds $t -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null

    ### Resume Script
    ### ---------------------------
    Write-Host "Resuming after Restart: $VM" -ForegroundColor Yellow
    
    ### Test VMGuest Connectivity
    ### ---------------------------
    Write-Host "Verifying Invoke Connectivity to VM Guest OS:" -ForegroundColor Magenta
    $ScriptText = 
    {
        Write-Host "Computer Name: " (Get-CimInstance -ClassName Win32_LogicalDisk)
    }
    
    $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose | Select -ExpandProperty ScriptOutput
    
    
    #Test-Connection -Cn $VM.Name -BufferSize 16 -Count 1 -ea 0 -quiet

    #Do {$Service = "LanmanServer";$Service = Get-Service -computername $VM -Name $Service}
    #While ($Service.Status -ne 'Running')

    #$global:VM = Get-VM $VM
    #Write-Host "Testing Connectivity to VM Guest OS:" -ForegroundColor Magenta
    #Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    #Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    #Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta

}
#>

function Get-DecommissionData
{
    Param([Parameter(Mandatory = $True)][int]$ServerID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Parameters
    ###---------------------------
    $ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM Servers WHERE ServerID = '$ServerID'�
    
    ### Execute Query
    ###---------------------------
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)
    
    ### Return Values
    ###----------------------------
    
    $DecomData = @()
    foreach ($Datarow in $DataTable.Rows)
    {
       #Write-Host "Name: " $DataTable.Columns 
       #Write-Host "Value: " $DataRow[0] 
       Set-Variable -Name $DataTable.Columns -Value $DataRow[0] -Scope Global
       $DecomData += ($DataTable.Columns,$DataRow[0])
    }
    Write-Host "DecomData: " $DecomData
}


function GetDBSize
{
    use "devops"
    exec sp_spaceused
}

