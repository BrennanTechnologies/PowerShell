﻿[‎8/‎31/‎2018 5:11 PM]  DeSimone, Shaun:  
v https://sac-tfs01.ecicloud.com/tfs/EMS_Scripts/Scripts_InProgress_Repo/_versionControl#path=%24%2FScripts_InProgress_Repo%2Finstall-citrixVDA.ps1&_a=contents 
 

135
148

<#
This script is used to download and install the VDA v7.11 for the new multitenant citrix gateways. It is able to be used in any data center and uses the appropriate DDC in each site.

12/6/16 SD Initial upload
1/7/17 SD Complete rewrite for the install process and making the user mount the iso
1/31/17 SD Add powershell remoting
2/1/17 SD Added test for administrator and set the proper settings for enabling ps remoting
5/11/17 SD Updated comment
11/30/17 SD Updated to fix the issue with the script having to be run twice
12/2/17 SD Finished the update of the script surviving a reboot and updated for consistency
12/2/17 SD Fixed "false" with $false
#>
function Test-IsAdmin 
    {
        try 
            {
                $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
                $principal = New-Object Security.Principal.WindowsPrincipal -ArgumentList $identity
                return $principal.IsInRole( [Security.Principal.WindowsBuiltInRole]::Administrator )
            } 
        catch 
            {
                throw "Failed to determine if the current user has elevated privileges. The error was: '{0}'." -f $_
            }

        <#
            .SYNOPSIS
                Checks if the current Powershell instance is running with elevated privileges or not.
            .EXAMPLE
                PS C:\> Test-IsAdmin
            .OUTPUTS
                System.Boolean
                    True if the current Powershell is elevated, false if not.
        #>
    }

import-module servermanager
$asNetFramework = get-windowsfeature as-net-framework
    if($asNetFramework.installed -eq $false)
        {
            $scriptPath = Read-Host "Please input the FULL path of the install-citrixVDA.ps1 script"
                if((test-path $scriptPath) -eq $false)
                    {
                        Write-Host "The path you entered is incorrect, please try again"
                        sleep 5
                        exit
                    }#if its the wrong path then kick out and tell them to try again
            Write-Host -ForegroundColor yellow "Pre-Reqs need to be installed before we can continue. Please make sure you have all other applications closed while it runs." -BackgroundColor Black
            Write-Host -ForegroundColor yellow "This script requires PowerShell to be run as an administrator in order for all the functions to work properly." -BackgroundColor Black
                $adminTest = Test-IsAdmin
                    if($adminTest -ne $true)
                        {
                            Write-Host -ForegroundColor Red "You must open PowerShell as an administrator for this script to fully function. Please do so and re-run the script." -BackgroundColor Black
                            sleep 5
                            exit
                        }#use the function to see if the powershell session was run as an admin, if not, alerts and remove the session
            add-windowsfeature gpmc -ErrorAction SilentlyContinue
            add-windowsfeature as-net-framework -ErrorAction SilentlyContinue
            add-windowsfeature rds-rd-server -ErrorAction SilentlyContinue
            
            Write-Host -ForegroundColor yellow "Adding a regkey that will run this script again to finish the rest of the process." -BackgroundColor Black
            $RunOnceKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
            set-itemproperty $RunOnceKey "NextRun" ('C:\Windows\System32\WindowsPowerShell\v1.0\Powershell.exe -executionPolicy Unrestricted -File ' + $scriptPath)
            Write-Host -ForegroundColor yellow "This server will now be rebooted in 20 seconds, the rest of the script will automatically continue to run after." -BackgroundColor Black
            Write-Host -ForegroundColor yellow "Please follow ALL the instructions to the letter" -BackgroundColor Black
            shutdown /r /t 20          
        }#check if pre-reqs are installed, if not, install, reboot, run the rest of the script
    else
        {
            if((Get-ItemProperty $RunOnceKey -Name nextrun).nextrun -eq "C:\Windows\System32\WindowsPowerShell\v1.0\Powershell.exe -executionPolicy Unrestricted -File " + $scriptPath)
                {
                    Remove-ItemProperty $RunOnceKey -Name nextrun
                }#if the key exists then remove it            
        }#if the role is already installed then remove the nextrun property from the registry so the server doesn't constantly reboot

Write-Host -ForegroundColor yellow "This script will install VDA v7.11 and the Studio component. Please make sure you have all other applications closed while it runs." -BackgroundColor Black
Write-Host -ForegroundColor yellow "This script requires PowerShell to be run as an administrator in order for all the functions to work properly." -BackgroundColor Black
Write-Host -ForegroundColor yellow "`n`nPlease make sure you mount the XenApp_and_XenDesktop_7_11 ISO from the appropriate staging datastore before proceeding" -BackgroundColor Black
Write-Host -ForegroundColor yellow "Press any key to continue after you've mounted the ISO `n" -BackgroundColor Black
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
Write-Host -ForegroundColor yellow "This process should take approximately 20 minutes. `n" -BackgroundColor Black

$adminTest = Test-IsAdmin
if($adminTest -ne $true)
    {
        Write-Host -ForegroundColor Red "You must open PowerShell as an administrator for this script to fully function. Please do so and re-run the script." -BackgroundColor Black
        sleep 5
        exit
    }#use the function to see if the powershell session was run as an admin, if not, alerts and remove the session
    
Enable-PSRemoting -Force
set-item wsman:\localhost\Client\TrustedHosts -value *

$dataCenter = @("QTS","SAC","BOS","LHC","LD5","HK","SG")
Write-Host -fore yellow "Please Select the Datacenter this Server is in:" -BackgroundColor Black
$i = 0; $dataCenter | % {$i++;"$($i-1) `t $_"}

#prompt for number until someone realizes that they need to enter a number
do
{
  try
      {
        [int]$dataCenterAnswer = Read-Host "Please enter the NUMBER of the data center above this server is in"    
      }
  catch
      {
        Write-Host -ForegroundColor red "INVALID INPUT!  Please enter a numeric value from the list above." -BackgroundColor Black
      } 
}
until ((0..6) -contains $dataCenterAnswer)

#prompt for drive letter that the ISO was mounted to
do
    {
        
        $driveLetter = Read-Host "`nWhat is the drive LETTER that the ISO is mounted in (LETTER only, no other characters)"
        $tempPath = $driveLetter+":\x64\XenDesktop Setup\"
        $testISO = Test-Path $tempPath
    }
until ($testISO -eq $true)
    
#install the vda and studio

Switch($dataCenterAnswer)
{
    "0"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "qts-xendc01.ecicloud.com qts-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
    "1"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "sac-xendc01.ecicloud.com sac-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                        
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                        
                        sleep -Seconds 10
                        exit
                    }#alert failure            
        }
    "2"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "qts-xendc01.ecicloud.com qts-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                      
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
    "3"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "lhc-xendc01.ecicloud.com lhc-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
    "4"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "ld5-xendc01.ecicloud.com ld5-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
    "5"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "hk-xendc01.ecicloud.com hk-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                       
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
    "6"
        {
            Write-Host -ForegroundColor Yellow "This will begin the install of the VDA and Desktop Studio components." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "The script will alert you if there is an error and then exit, please troubleshoot accordingly." -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "If there are no errors it will prompt you to reboot" -BackgroundColor Black
            Write-Host -ForegroundColor Yellow "DO NOT REBOOT UNTIL YOU ARE PROMPTED TO!" -BackgroundColor Black

            cd $tempPath

            $installVDA = Start-Process '.\XenDesktopVDASetup.exe' -ArgumentList '/QUIET /COMPONENTS VDA /EXCLUDE "Personal vDisk" /CONTROLLERS "sg-xendc01.ecicloud.com sg-xendc02.ecicloud.com" /nodesktopexperience /ENABLE_HDX_PORTS /OPTIMIZE /NOREBOOT' -NoNewWindow -PassThru -Wait
                if ($installVDA.exitcode -eq 3)
                    {
                        Write-Host "VDA component installed correctly, installing Studio next." -BackgroundColor Black
                    }#alert that vda component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the VDA component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                        
                        sleep -Seconds 10
                        exit
                    }#alert failure

            $testRegValue = Get-ItemProperty HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name SupportMultipleForest -ErrorAction SilentlyContinue
            if(!$testRegValue)
                {
                    New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent -Name "SupportMultipleForest" -Value 1 -PropertyType DWORD -Force | Out-Null
                }#add the cross forest regkey 

            $installStudio = Start-Process -FilePath '.\XenDesktopServerSetup.exe' -ArgumentList '/Quiet /configure_firewall /components "DESKTOPSTUDIO"' -NoNewWindow -PassThru -Wait
                if($installStudio.exitcode -eq 0)
                    {
                        Write-Host -ForegroundColor Yellow "Studio component installed correctly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "The server will need to be rebooted for the VDA to register with the DDC's." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Please email EMSAdmin to create/update the appropriate Delivery Group and Machine Catalog" -BackgroundColor Black
                        
                        # add the required .NET assembly:
                        Add-Type -AssemblyName System.Windows.Forms
                        # show the MsgBox:
                        $result = [System.Windows.Forms.MessageBox]::Show('Do you want to restart?', 'Warning', 'YesNo', 'Warning')

                        # check the result:
                        if ($result -eq 'Yes')
                        {
                          Restart-Computer
                        }
                        else
                        {
                          Write-Warning 'Skipping restart, you will need to reboot for Citrix to function.'
                          sleep -Seconds 5
                        }
                    }#alert that studio component installed correctly
                else
                    {
                        Write-Host -ForegroundColor Yellow "There was a problem installing the Studio component, please use the event viewer and troubleshoot accordingly." -BackgroundColor Black
                        Write-Host -ForegroundColor Yellow "Once the errors are resolved please re-run this script" -BackgroundColor Black                     
                        sleep -Seconds 10
                        exit
                    }#alert failure
        }
}#install the vda with the correct ddc's
