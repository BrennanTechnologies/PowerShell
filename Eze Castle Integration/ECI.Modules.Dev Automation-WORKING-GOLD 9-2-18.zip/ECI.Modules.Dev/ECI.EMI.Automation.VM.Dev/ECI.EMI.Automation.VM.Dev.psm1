
#########################################
### vCenter Resources
#########################################

###-----------------------------------------------
### Get ECI Cluster
###-----------------------------------------------
function Get-ECI.Cluster
{
    param($ECIvCenter)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $global:Clusters = VMware.VimAutomation.Core\Get-Cluster #-Server $ECIvCenter
    #$global:Cluster = (Get-Cluster -Server $ECIvCenter | Get-ResourcePool -Name $ResourcePool).Name
   
    Write-Host "Clusters Found: $Cluster"s -ForegroundColor Cyan
    
    #$global:Pod = $Cluster.Split("_")[2]
    #Write-Host "Pod Found: $Pod" -ForegroundColor Cyan

    Return $Cluster
}

###-----------------------------------------------
### Get Resource Pools
###-----------------------------------------------
function Get-ECI.ResourcePool
{
    param($GPID, $ECIvCenter)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray


    Write-Host "Getting Resource Pools for GPID: $GPID" -ForegroundColor Gray

    ### Get Clusters
    #$Clusters = Get-Cluster -ECIvCenter $ECIvCenter
    #Write-Host "Clusters: $Clusters" -ForegroundColor Gray
    
    foreach($Cluster in $Clusters)
    {
        ### Get Resource Pools for each Cluster
        $ResourcePools = (Get-ResourcePool -Location $Cluster | Where-Object {$_.Name -like "*$GPID*"}).Name

        ### Write All Resource Pools
        foreach($ResourcePool in $ResourcePools)
        {
            Write-Host "Resource Pool Found: $ResourcePool " -ForegroundColor Gray
        
            ### Select Resource Pool
            if($ResourcePools.Count -gt 1)
            {
                $EMS2    = $ResourcePools | Where-Object { $_ -like "ems2*" }
                $Multi   = $ResourcePools | Where-Object { ($_ -like "multi*") -AND ($_ -notlike "*ctx") }
                $Hybrid  = $ResourcePools | Where-Object { ($_ -like "hybrid*") -AND ($_ -notlike "*ctx") }
                $Hosted  = $ResourcePools | Where-Object { $_ -like "hosted_*" }
            
                if($EMS2)
                {
                    $ResourcePool = $EMS2
                }
                elseif($Multi)
                {
                    $ResourcePool = $Multi
                }
                elseif($Hybrid)
                {
                    $ResourcePool = $Hybrid
                }
                elseif($Hosted)
                {
                    $ResourcePool = $Hosted
                }
            }

            ### Only One Resource Pool
            elseif($ResourcePools.Count -eq 1)
            {
                $ResourcePool = $ResourcePools
            }

            ### Resource Pool Not Found
            elseif($ResourcePools.Count -eq 0)
            {
                Write-Host "No Resource Pool Found for GPID: $GPID" -ForegroundColor Red
            }
        }
    }
 
    
    $global:ResourcePool = $ResourcePool

    Write-Host "Selecting Resource Pool: $ResourcePool" -ForegroundColor Yellow
}


###-----------------------------------------------
### Get Port Group
###-----------------------------------------------
function Get-ECI.PortGroup
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting Port Group for GPID: $GPID `n" -ForegroundColor Magenta

    #$global:PortGroups = Get-VDPortgroup | Where-Object {$_.Name -Like "*$GPID*"} 
    $global:PortGroups = Get-VirtualPortGroup | Where-Object {$_.Name -Like "*$GPID*"}

    foreach($PortGroup in $PortGroups)
    {
        Write-Host "Found - Port Group: " $PortGroup -ForegroundColor Yellow
    }

    if($PortGroups.Count -gt 1)
    {
        if(($PortGroups | Where-Object {$_.name -like "multi*"}))
        {
            $PortGroup =  $PortGroups | Where-Object {$_.name -like "multi*"}
        }
        else
        {
            $PortGroup =  $PortGroups | Select-Object -first 1 # <--- Really!!!???
            #$PortGroup =  $PortGroups[0] # <--- Really!!!???
        }
    }
    else
    {
        $PortGroup =  $PortGroups | Select-Object -first 1 # <--- Really!!!???
        #$PortGroup =  $PortGroups[0] # <--- Really!!!???
    }
    
    $PortGroup = "emsadmin-RED-RGEE-LAN"

    $global:PortGroup = $PortGroup

    Write-Host "Chosing First Port Group: " $PortGroup -ForegroundColor Cyan
}

###-----------------------------------------------
### Get Data Store
###-----------------------------------------------
function Get-ECI.DataStore
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Finding Datastores for ProductType: " $ProductType -ForegroundColor Yellow

     $global:DataStore = "nfs_emsadmin_sas1"

    <#
        # Naming Conventions
        #---------------------
         InstanceLocation_ProductType_Function_Pod

        # DiskType
        #---------------------
         Clinet_Files
         Client_DC_OS
         Client_DC_Swap

         Resource_OS
         Resource_Swap
         Resource_SQL

         data
         swap
         os
     #>
 
<#

NEED TO WRITE CODE TO DETEDCT DATASTORE!!!!!!!!!!!!!!!!!!!!!!!

    switch ( $ProductType )
    {
        "Lab"    { $ResourcePool = "EMS2_"   + $GPID }
        "EMI"    { $ResourcePool = "EMS2_"   + $GPID }
        "Hybrid" { $ResourcePool = "Hybrid_" + $GPID }
        "Hosted" { $ResourcePool = "Hosted" + $GPID  }
        "EMS"    { $ResourcePool = "Multi_"  + $GPID }
    }

     $DiskTypes = @("data","swap","os")

     foreach($DiskType in $DiskTypes)
     {
         $DataStore = $InstanceLocation + "_" + $ProductType + "_" + $DiskType + "_" + $Pod
         Write-Host "Datastore: $Datastore"  -ForegroundColor Cyan
     } 
#>

}

#########################################
### ECI VM Provisioning Module
#########################################

function Set-VMHostName
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### Set VM Name from HostName Parameters
    ###----------------------------------------------------------------
    $global:VM = $HostName
    Write-Host "Setting VM Host Name:" $VM -ForegroundColor Yellow
}

function Get-ECI.VMTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting VMWare Template: " $VMWareTemplateName  -ForegroundColor Yellow
    
    $ECIVMTemplate = $null

    $ECIVMTemplate = Get-Template -Name $VMWareTemplateName

    if (($ECIVMTemplate.count) -gt 1)
    {
        $ECIVMTemplate = $ECIVMTemplate[0]
    }
    
    $global:ECIVMTemplate = $ECIVMTemplate
    Write-Host "Template Found: $ECIVMTemplate" -ForegroundColor Cyan
    Return $ECIVMTemplate
}



function Set-ServerUUID
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### Set VM Name fromn HostName Parameters
    ###----------------------------------------------------------------
   
    $VMMoRef = (Get-VM -Name $VM).ID
    $VMMoRef = $VMMoRef.Split("-")
    $ServerUUID = "VI" + "." + $vCenterUUID + "." + ($VMMoRef[-2]).ToUpper() + "-" + $VMMoRef[-1]
    
    #Write-Host "VMMoRef:" $VMMoRef -ForegroundColor Yellow
    #Write-Host "vCenterUUID: " $vCenterUUID -ForegroundColor Yellow
    
    $global:ServerUUID = $ServerUUID
    Write-Host "vCenterUUID: " $ServerUUID -ForegroundColor Magenta
    Return $ServerUUID
<#
    Get-VM $VM | %{(Get-View $_.Id).config.uuid}  

    Write-Host "MoRef: " $VM.ExtensionData.MoRef
    Write-Host "InstanceUuid: " $VM.ExtensionData.Config.InstanceUuid
    
    #(Get-Datacenter -Server $ECIvCenter).ExtensionData.moref
#> 
    #Example:
    #---------
    #VI-d8c273b7-6f4e-4ce7-8986-72dfbd3f0376-VM-38002
}


function New-ECI.VM
{
    Param(
    [Parameter(Mandatory = $True)][string]$VM,
    
    [Parameter(Mandatory = $True)][string]$ECIVMTemplate,
    [Parameter(Mandatory = $True)][string]$OSCustomizationSpecName,
    
    [Parameter(Mandatory = $True)][string]$ResourcePool,
    [Parameter(Mandatory = $True)][string]$DataStore,
    [Parameter(Mandatory = $True)][string]$PortGroup,

    [Parameter(Mandatory = $True)][string]$IPv4Address,
    [Parameter(Mandatory = $True)][string]$SubnetMask,
    [Parameter(Mandatory = $True)][string]$DefaultGateway,
    [Parameter(Mandatory = $True)][string]$PrimaryDNS,
    [Parameter(Mandatory = $True)][string]$SecondaryDNS
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    function Create-OSCustomizationSpec
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec
        ###----------------------------------------------------------
        ### Remove OSCustomizationSpec
        if(Get-OSCustomizationSpec $OSCustomizationSpecName -ErrorAction SilentlyContinue)
        {
            Write-Host "Removing OSCustomizationSpec: " $OSCustomizationSpecName
            Remove-OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
        
            ### Remove OSCustomizationNicMapping
            #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
        }
        else
        {
            Write-Host "No OSCustomizationSpec Found: "
        }    
   
        ### New OSCustomizationSpec
        ###------------------------
        $OSCustomizationSpec = @{
            Name             = $OSCustomizationSpecName 
            Type             = $Type 
            OSType           = $OSType 
            NamingScheme     = $NamingScheme.trim()
            FullName         = $FullName 
            OrgName          = $OrgName 
            AdminPassword    = $AdminPassword
            ChangeSid        = $True
            DeleteAccounts   = $False 
            TimeZone         = $TimeZone 
            ProductKey       = $ProductKey 
            LicenseMode      = $LicenseMode 
            Workgroup        = $Workgroup
        }
    
        Write-Host "Creating OSCustomizationSpec: $OSCustomizationSpecName" -ForegroundColor Yellow
        New-OSCustomizationSpec @OSCustomizationSpec
    
        #New-OSCustomizationSpec -Name $OSCustomizationSpecName -Type $Type -OSType $OSType -NamingScheme $NamingScheme -FullName $FullName -OrgName $OrgName -AdminPassword $AdminPassword -ChangeSid:$true -DeleteAccounts:$false -TimeZone $TimeZone -ProductKey $ProductKey -LicenseMode $LicenseMode -Workgroup $Workgroup
    }
    
    function Create-OSCustomizationNicMapping
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec NIC Mapping
        ###----------------------------------------------------------    
        $OSCustomizationNicMapping = {
            IpMode          = "UseStaticIp"
            IpAddress       = $IPv4Address 
            SubnetMask      = $SubnetMask 
            DefaultGateway  = $DefaultGateway 
            Dns             = $PrimaryDNS + "," + $SecondaryDNS
        }
        Write-Host "Creating OSCustomizationNicMapping: $OSCustomizationSpecName" -ForegroundColor Yellow
        Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $SubnetMask -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    }
    
    function Create-VM
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New VM
        ###----------------------------------------------------------  
    
        ### Check if VM exists
        if(Get-VM -Name $VM -ErrorAction SilentlyContinue)
        {
            Write-Host "This VM Exists. Running Report Mode" -ForegroundColor Red
            $globalConfigurationMode = "Report"
        
            ### Do we want to Abort or run in Report mode ????????
            #$global:Abort = $True
            #Invoke-Abort
        }
        else
        {
            ### Create New VM
            ###----------------------------------------------------------
            Write-Host "Creating New VM: " $VM -ForegroundColor Yellow

            $VMParameters = @{
                VM                        = $VM
                Template                  = $ECIVMTemplate
                OSCustomizationSpec       = $OSCustomizationSpecName
                ResourcePool              = $ResourcePool
                DataStore                 = $DataStore
            }

            #New-VM @VMParameters
            New-VM -Name $VM -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $DataStore -OSCustomizationSpec $OSCustomizationSpecName

            ### Set Port Group
            ###----------------------------------------------------------
    #        Get-VM -Name $VM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $PortGroup -Confirm:$false
        }
    }

    &{
        BEGIN{}
        
        PROCESS
        {
            Create-OSCustomizationSpec
            Create-OSCustomizationNicMapping
            Create-VM
        }

        END{}
    }



    ### needed??????
    ###Set-VM -VM $VM -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
   

<#
    https://blogs.vmware.com/PowerCLI/2014/06/working-customization-specifications-powercli-part-2.html

    https://code.vmware.com/forums/2530/vsphere-powercli#572264

    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    Get-OSCustomizationSpec $OSCustomizationSpecName | Remove-OSCustomizationNicMapping 
            
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS

 
    #Clone the BaseVM with the adjusted Customization Specification
    New-VM -Name $OSCustomizationSpecName -VM $VM -Datastore $datastore -VMHost $ECIvCenter | Set-VM -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
 
    #Set the Network Name (I often match PortGroup names with the VLAN name)
    Get-VM -Name $VM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $vlan -Confirm:$false
 
    #Remove the NicMapping (Don't like to leave things unkept)
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
#>

}


function New-ECI.VM-orig
{
    Param(
    [Parameter(Mandatory = $True)][string]$VM,
    
    [Parameter(Mandatory = $True)][string]$ECIVMTemplate,
    [Parameter(Mandatory = $True)][string]$OSCustomizationSpecName,
    
    [Parameter(Mandatory = $True)][string]$ResourcePool,
    [Parameter(Mandatory = $True)][string]$DataStore,
    [Parameter(Mandatory = $True)][string]$PortGroup,

    [Parameter(Mandatory = $True)][string]$IPv4Address,
    [Parameter(Mandatory = $True)][string]$SubnetMask,
    [Parameter(Mandatory = $True)][string]$DefaultGateway,
    [Parameter(Mandatory = $True)][string]$PrimaryDNS,
    [Parameter(Mandatory = $True)][string]$SecondaryDNS
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ###----------------------------------------------------------
    ### Create New OSCustomizationSpec
    ###----------------------------------------------------------
    ### Remove OSCustomizationSpec
    if(Get-OSCustomizationSpec $OSCustomizationSpecName -ErrorAction SilentlyContinue)
    {
        Write-Host "Removing OSCustomizationSpec: " $OSCustomizationSpecName
        Remove-OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
        
        ### Remove OSCustomizationNicMapping
        #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
    }
    else
    {
        Write-Host "No OSCustomizationSpec Found: "
    }    

    
    ### New OSCustomizationSpec
    ###------------------------
    $OSCustomizationSpec = @{
        Name             = $OSCustomizationSpecName 
        Type             = $Type 
        OSType           = $OSType 
        NamingScheme     = $NamingScheme.trim()
        FullName         = $FullName 
        OrgName          = $OrgName 
        AdminPassword    = $AdminPassword
        ChangeSid        = $True
        DeleteAccounts   = $False 
        TimeZone         = $TimeZone 
        ProductKey       = $ProductKey 
        LicenseMode      = $LicenseMode 
        Workgroup        = $Workgroup
    }
    
    Write-Host "Creating OSCustomizationSpec: $OSCustomizationSpecName" -ForegroundColor Yellow
    New-OSCustomizationSpec @OSCustomizationSpec
    
    #New-OSCustomizationSpec -Name $OSCustomizationSpecName -Type $Type -OSType $OSType -NamingScheme $NamingScheme -FullName $FullName -OrgName $OrgName -AdminPassword $AdminPassword -ChangeSid:$true -DeleteAccounts:$false -TimeZone $TimeZone -ProductKey $ProductKey -LicenseMode $LicenseMode -Workgroup $Workgroup


    ###----------------------------------------------------------
    ### Create New OSCustomizationSpec NIC Mapping
    ###----------------------------------------------------------    
    $OSCustomizationNicMapping = {
        IpMode          = "UseStaticIp"
        IpAddress       = $IPv4Address 
        SubnetMask      = $SubnetMask 
        DefaultGateway  = $DefaultGateway 
        Dns             = $PrimaryDNS + "," + $SecondaryDNS
    }
    Write-Host "Creating OSCustomizationNicMapping: $OSCustomizationSpecName" -ForegroundColor Yellow
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $SubnetMask -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS

    ###----------------------------------------------------------
    ### Create New VM
    ###----------------------------------------------------------  
    
    ### Check if VM exists
    if(Get-VM -Name $VM -ErrorAction SilentlyContinue)
    {
        Write-Host "This VM Exists. Running Report Mode" -ForegroundColor Red
        $globalConfigurationMode = "Report"
        
        ### Do we want to Abort or run in Report mode ????????
        #$global:Abort = $True
        #Invoke-Abort
    }
    else
    {
        ### Create New VM
        ###----------------------------------------------------------
        Write-Host "Creating New VM: " $VM -ForegroundColor Yellow

        $VMParameters = @{
            VM                        = $VM
            Template                  = $ECIVMTemplate
            OSCustomizationSpec       = $OSCustomizationSpecName
            ResourcePool              = $ResourcePool
            DataStore                 = $DataStore
        }

        #New-VM @VMParameters
        New-VM -Name $VM -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $DataStore -OSCustomizationSpec $OSCustomizationSpecName

        ### Set Port Group
        ###----------------------------------------------------------
#        Get-VM -Name $VM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $PortGroup -Confirm:$false
    }

    ### needed??????
    ###Set-VM -VM $VM -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
   

<#
    https://blogs.vmware.com/PowerCLI/2014/06/working-customization-specifications-powercli-part-2.html

    https://code.vmware.com/forums/2530/vsphere-powercli#572264

    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    Get-OSCustomizationSpec $OSCustomizationSpecName | Remove-OSCustomizationNicMapping 
            
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS

 
    #Clone the BaseVM with the adjusted Customization Specification
    New-VM -Name $OSCustomizationSpecName -VM $VM -Datastore $datastore -VMHost $ECIvCenter | Set-VM -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
 
    #Set the Network Name (I often match PortGroup names with the VLAN name)
    Get-VM -Name $VM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $vlan -Confirm:$false
 
    #Remove the NicMapping (Don't like to leave things unkept)
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
#>

}

function Set-ECI.VMCPU
{
    $global:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ##########################################
    ### Modify Parameter Values
    ##########################################
    ### Cast the Variable
    [int]$vCPUCount = $vCPUCount
    
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $global:PropertyName      = "vCPUCount"
    $global:DesiredState      = $vCPUCount
    #$global:ConfigurationMode = "Configure" ### Report - Configure
    $global:AbortTrigger      = $False  ### $True - $False
    
    $golbalDSCParamerters = @{
        PropertyName      = $PropertyName
        DesiredState      = $DesiredState
        ConfigurationMode = $ConfigurationMode
        AbortTrigger      = $AbortTrigger
    }


    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$global:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VM | Select NumCpu).NumCpu
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$global:SetDesiredState =
    {
        ### Set VM CPU Count
        ###-----------------------------------------
        Write-Host "Setting VM CPU Count: " $vCPUCount -ForegroundColor Cyan
        $VM = Get-VM -Name $VM
        Set-VM -VM $VM -Confirm:$False -NumCpu $vCPUCount
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Set-ECI.VMMemory
{
    $global:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ##########################################
    ### Modify Parameter Values
    ##########################################
    ### Cast the Variable
    [int]$vCPUCount = $vCPUCount
    
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $global:PropertyName      = "vCPUCount"
    $global:DesiredState      = $vCPUCount
    #$global:ConfigurationMode = "Configure" ### Report - Configure
    $global:AbortTrigger      = $False  ### $True - $False
    
    $golbalDSCParamerters = @{
        PropertyName      = $PropertyName
        DesiredState      = $DesiredState
        ConfigurationMode = $ConfigurationMode
        AbortTrigger      = $AbortTrigger
    }


    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$global:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VM | Select MemoryGB).MemoryGB
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$global:SetDesiredState =
    {
        ### Set VM CPU Count
        ###-----------------------------------------
        Write-Host "Setting VM CPU Count: " $vCPUCount -ForegroundColor Cyan
        $VM = Get-VM -Name $VM
        Set-VM -VM $VM -Confirm:$False -MemoryGB $vMemorySizeGB
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Set-ECI.VMMemory-orig
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ScriptBlock =
    {
        Write-Host "Setting VM vMemory: " $vMemorySizeGB
        $VM = Get-VM -Name $VM
        Set-VM -VM $VM -Confirm:$False -MemoryGB $vMemorySizeGB
    }
    Try-Catch $ScriptBlock
}

function Start-ECI.VM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    $ScriptBlock =
    {
        Write-Host "Starting VM: $VM" -ForegroundColor Yellow
        Start-VM $VM
    }
    Try-Catch $ScriptBlock
}

function Wait-ECI.VMTools
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $t = 2
   
#    for ($i=1; $i -le 5; $i++)
#    {
        Write-Host "Counter: " $i
        Write-Host "START-SLEEP - $t (s): Waiting for OS Cusomization to Complete." -ForegroundColor Yellow
        Start-Sleep -Seconds $t
    
        Write-Host "WAIT-TOOLS  - $t (s): Waiting for VM Tools to Respond."
        $VMTools = Wait-Tools -VM $VM -TimeoutSeconds $t -ErrorAction SilentlyContinue
    
        if(!$VMTools)
        {
            Wait-ECI.VMTools  
        }
        if($VMTools)
        {
            Write-Host "The Server is Up: $VM" 
        }
#    }
}

function Wait-ECI.OSCusomization
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $t = 180
    For ($i=$t; $i -gt 1; $i--) 
    {  
        $a = [math]::Round($i/$t*100)
        Write-Progress -Activity "STARTING-SLEEP - for $t secinds: Waiting for OS Cusomization to Complete." -SecondsRemaining $i -CurrentOperation "$a% complete" -Status "Status: "
        Start-Sleep 1
        #Write-Host "Still Waiting ..." -ForegroundColor DarkGray
    }

    Write-Host "OS Customization is Complete." -ForegroundColor Green
    Write-Progress -Activity 'OS Cusomization' -Completed
}

<#
function Start-Sleep($seconds) 
{
    $doneDT = (Get-Date).AddSeconds($seconds)
    while($doneDT -gt (Get-Date)) 
    {
        $secondsLeft = $doneDT.Subtract((Get-Date)).TotalSeconds
        $percent = ($seconds - $secondsLeft) / $seconds * 100
        Write-Progress -Activity "Sleeping" -Status "Sleeping..." -SecondsRemaining $secondsLeft -PercentComplete $percent
        [System.Threading.Thread]::Sleep(500)
    }
    Write-Progress -Activity "Sleeping" -Status "Sleeping..." -SecondsRemaining 0 -Completed
}
#>


function Wait-InvokeVMScript
{
    $ScriptText = 
    {
        dir    
    }

    $TestInvoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser "administrator" -GuestPassword "cH3r0k33" -Verbose 
    
    if($TestInvoke.ExitCode -ne 0)
    {
        Write-Host "VM is still running OS Customization"
        Wait-InvokeVMScript
    }
    else
    {
        Write-Host "VM has completed OS Customization"
    }

}

function Stop-ECI.VM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    $ScriptBlock =
    {
        Write-Host "Stopping VM: $VM" -ForegroundColor Yellow
        Stop-VM $VM -Confirm:$false
    }
    Try-Catch $ScriptBlock
}

function Decommission-ECI.VM
{

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Stop VM if Started
    $PowerState = (Get-VM $VM | Select PowerState).PowerState
 
    if($PowerState -eq "PoweredOn")     #PoweredOff
    {
        Write-Host "WARNING! STOPPING VM: $VM" -ForegroundColor Red
        Stop-VM $VM -Confirm:$false    
    }

    ### Record VM to SQL
    Get-DecommissionData -ServerID $ServerID

    ### Delete VM
    Write-Host "WARNING! DELETING VM: $VM" -ForegroundColor Red
    Remove-VM $VM -DeletePermanently -Confirm:$false

}

function Cleanup-VMS
{
    $VMs = Get-VM | Where-Object {$_.Name -like "SRV-*"} 

    foreach($VM in $VMs)
    {
        Stop-VM $VM -Confirm:$false -ErrorAction Continue
        Remove-VM $VM -DeletePermanently -Confirm:$false -ErrorAction Continue 
    }
}
