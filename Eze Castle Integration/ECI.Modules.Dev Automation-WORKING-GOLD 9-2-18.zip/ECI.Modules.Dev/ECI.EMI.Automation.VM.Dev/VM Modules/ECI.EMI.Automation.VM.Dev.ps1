
Param(
    ### Server Request Parameters
    [Parameter(Mandatory = $True)] [string]$RequestID,
    [Parameter(Mandatory = $True)] [string]$RequestDateTime,
    [Parameter(Mandatory = $True)] [string]$HostName,
    [Parameter(Mandatory = $True)] [string]$ServerRole,
    [Parameter(Mandatory = $True)] [string]$IPv4Address,
    [Parameter(Mandatory = $True)] [string]$SubnetMask,
    [Parameter(Mandatory = $True)] [string]$Gateway,
    [Parameter(Mandatory = $True)] [string]$InstanceLocation,
    [Parameter(Mandatory = $True)] [string]$Backup,
    [Parameter(Mandatory = $True)] [string]$DR,
     
    ### VM Parameters
    [Parameter(Mandatory = $True)] [string]$VMParameterID,
    [Parameter(Mandatory = $True)] [string]$vCPUCount,
    [Parameter(Mandatory = $True)] [string]$vMemorySizeGB,
    [Parameter(Mandatory = $True)] [string]$OSVolumeGB,
    [Parameter(Mandatory = $False)] [string]$SwapVolumeGB,
    [Parameter(Mandatory = $False)] [string]$DataVolumeGB,
    [Parameter(Mandatory = $False)] [string]$LogVolumeGB,
    [Parameter(Mandatory = $False)] [string]$SysVolumeGB,

    ### OS Parameters
    [Parameter(Mandatory = $True)] [string]$OSParameterID,
    [Parameter(Mandatory = $True)] [string]$NetworkInterfacename,
    [Parameter(Mandatory = $True)] [string]$LocalAdministrator,
    [Parameter(Mandatory = $True)] [string]$CDROMLetter,
    [Parameter(Mandatory = $True)] [string]$IPv6Preference,
    [Parameter(Mandatory = $False)] [string]$WindowsFirewallPreference,
    [Parameter(Mandatory = $False)] [string]$InternetExplorerESCPreference,
    [Parameter(Mandatory = $False)] [string]$RemoteDesktopPreference,
    [Parameter(Mandatory = $False)] [string]$RDPResetrictionsPreference,
    [Parameter(Mandatory = $False)] [string]$SwapFileBufferSizeMB,
    [Parameter(Mandatory = $False)] [string]$SwapFileLocation,
    [Parameter(Mandatory = $False)] [string]$SwapFileMemoryThreshholdGB,
    [Parameter(Mandatory = $False)] [string]$SwapFileMultiplier

)

function Get-ECIVMHostName
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    $VM = $HostName
    Write-Host "Getting VM Host Name: " $VM -ForegroundColor Magenta
}

function Import-VMWareModules
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
}

function Connect-ECIVIServer
{
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Write-Host "Setting PowerCLIConfiguration: -InvalidCertificateAction Ignore" -ForegroundColor Gray
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false <#-ParticipateInCEIP:$false#> | Out-Null
    $ProgressPreference = "SilentlyContinue" #<-- Hide VMWare Module Progress Bar

    if($global:DefaultVIServers.Count -gt 0)
    {
        Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
    }
    else 
    {
        $VIServer = "ecilab-bosvcsa01.ecilab.corp"
        Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Gray
        $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
        #$VISession = Connect-VIServer -Server $VIServer  -User ezebos\cbrennan -Password Tolkien43741
        $VISession = Connect-VIServer -Server $VIServer  -User sdesimone_admin@ecilab.corp -Password cH3r0k33!B
    }

    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

function Get-ECIVMTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    #$VMTemplate = "RGEE-NoTemplate"
    #$VMTemplate = Get-Template -Name $VMTemplateName

}

function New-ECIOSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $Name = "ECIOSCustomizationSpec-2016"
    $OSType = "Windows"
    $Type = "Persistent "
    #$DnsServer = "?"
    #$DnsSuffix = "?"
    $NamingScheme = "VM"
    $FullName = "ECIAdmin"
    $OrgName = "Eze Castle Integration"
    $AdminPassword = "cH3r0k33"
    $ChangeSid = "True"
    $DeleteAccounts = "False"
    #$GuiRunOnce = "?"
    #$AutoLogonCount = "?"
    $TimeZone = "035"
    $ProductKey = "RKM9R-NTCGJ-KP4RF-FJFGF-4X9Q2" 
    $LicenseMode = "PerSeat"
    $Workgroup = "Workgroup"

    $ECIOSCustomizationSpecFile = Get-OSCustomizationSpec -Name $Name

    if(!$ECIOSCustomizationSpecFile)
    {
        Write-Host "Customizing VM: $VM  OSCustomizationSpec: $OSCustomizationSpec.Name" -ForegroundColor Yellow
        New-OSCustomizationSpec -Name $Name -Type $Type -OSType $OSType -NamingScheme $NamingScheme -FullName $FullName -OrgName $OrgName -AdminPassword $AdminPassword -ChangeSid:$true -DeleteAccounts:$false -TimeZone $TimeZone -ProductKey $ProductKey -LicenseMode $LicenseMode -Workgroup $Workgroup
    }
    else
    {
        Write-Host "Using Exising ECIOSCustomizationSpecFile: " $ECIOSCustomizationSpecFile -ForegroundColor Green
        Write-Host $ECIOSCustomizationSpecFile -ForegroundColor Green
    }
}

function Set-ECIOSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VM = Get-VM -Name $VM
    $ECIOSCustomizationSpec = "ECIOSCustomizationSpec-2016"
    $ECIOSCustomizationSpecFile = Get-OSCustomizationSpec -Name $ECIOSCustomizationSpec

    Write-Host "Customizing VM: $VM  OSCustomizationSpec: $OSCustomizationSpec.Name" -ForegroundColor Yellow
    Set-VM -VM $VM -OSCustomizationSpec $ECIOSCustomizationSpecFile -Confirm:$false

}

function New-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Creating VM: " $VM -ForegroundColor Yellow

    ### New-VM --- https://www.vmware.com/support/developer/windowstoolkit/wintk40u1/html/New-VM.html
    
    $DataStore = "nfs_emsadmin_sas1"
    $DataStore = Get-Datastore -Name $DataStore
    $ResourcePool = "ClientDCs"
    $ResourcePool = Get-ResourcePool -Name $ResourcePool

    $VMTemplate = "RGEE-NoTemplate"
    $VMTemplate = Get-Template -Name $VMTemplate    
    
    #$VMTemplate = "W2K16v2"
    #$VMTemplate  = Get-Template -Name $VMTemplate

    #New-VM -Name $VM -Datastore $DataStore -ResourcePool $ResourcePool -Template $VMTemplate #-OSCustomizationSpec $OSCustomizationSpec
    
    New-VM -Name $VM -Datastore $DataStore -ResourcePool $ResourcePool -Template $VMTemplate -OSCustomizationSpec $ECIOSCustomizationSpec

    #New-VM -Name $VM -Template $VMTemplate -ResourcePool $ResourcePool -DiskStorageFormat Thin -Datastore $TargetDataStore
    #New-VM -Name $VM -Datastore $TargetDataStore -ResourcePool $ResourcePool -Template $VMTemplate -OSCustomizationSpec $OSCustomizationSpec
    #-NumCpu $vCPUCount -MemoryMB $vMemorySize 
        
        # -CD #-DiskGB $OSVolumeSize -DiskStorageFormat $DiskStorageFormat #-InformationAction SilentlyContinue #-CD $CD #-DiskStorageFormat Thin -Datastore $TargetDataStore
        #-Template $VMTemplate
        #-AlternateGuestName $AlternateGuestName
        #-Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)
        #-OSCustomizationSpec $VMCustomSpec `
    #>  
}

function Set-ECIVMName
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -Name $VM.Name
}

function Set-ECIVMCpu
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    #$vCPU = "2"

    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -NumCpu $vCPU
}

function Set-ECIVMMemory
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    #$vMem = "6"

    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -MemoryGB $vMem

    Get-VM -Name $VM | Select-Object *
}

function New-ECINetworkAdapter
{ 
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $NetworkName = "emsadmin-RED-RGEE-LAN"

    $VM = Get-VM -Name $VM
    New-NetworkAdapter -VM $VM -Confirm:$False -NetworkName $NetworkName  
    
}

function Start-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Starting VM: $VM" -ForegroundColor Yellow
    Start-VM $VM
}

function Stop-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Stopping VM: $VM" -ForegroundColor Yellow
    Stop-VM $VM -Confirm:$false
}




&{

    BEGIN
    {
        $script:StartTime = Get-Date
        Import-VMWareModules
        Connect-ECIVIServer
        
    }

    PROCESS 
    {
        Get-ECIVMHostName
        #Get-ECIVMTemplate
        New-ECIOSCustomizationSpec
        Set-ECIOSCustomizationSpec
        #New-ECIVM
        #Set-ECIVMName
        #Set-ECIVMCPU
        #Set-ECIVMMemory
        #New-ECINetworkAdapter

        #Start-ECIVM
        #Stop-ECIVM

        #Create-ISO
        #New-ECIVM
        #New-ECIScsiController
        #Remove-ECIHardDisk
        #New-ECIHardDisk
        #Set-ECIHardDisk
        #New-AHCIController
        #New-ECICDDrive
        #Set-CDtoSATA
        #Set-CDROM <-- set to use iso & start on boot
        #Start-ECIVM
        #Install-VMTools
        #Remove-ECIVM
    }

    END
    {
        $script:StopTime = Get-Date
        Write-Host `n`n('=' * 75)`n"Script Execution Time:`t" ($StopTime-$StartTime) `n('=' * 75)`n -ForegroundColor Gray
    }


}