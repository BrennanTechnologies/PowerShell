﻿cls

#Get-ResourcePool
#Get-Datastore

### VM Host Parameters
$ProgressPreference = "SilentlyContinue" #<-- Hide VMWare Module Progress Bar
#$WarningPreference 

### VM Parameters
$VM = "RGEE-Test6"
$AlternateGuestName = $VM
$GuestId = "Windows Server 2003, Enterprise Edition"
$VMTemplate = "W2K16v2"
$ResourcePool = "ClientDCs"
$TargetDataStore = "nfs_emsadmin_sas1"
$NetworkName = ""
$DiskStorageFormat = "Thin" ### Thin/Thick

### VM Parameters
$vCPUCount = "2"
$vMemorySize = "4000"
$OSVolumeSize = "50"
$SwapVolumeSize = "10"
$DataVolumeSize = $Null
$LogVolumeSize = $Null
$SysVolumeSize = $Null


<#
1. New VM
    - CPU
    - Mem
    - SCSI Controller
    - HD
    - ISO

2. Mount-Tools
    - Install VMTOols

3. SysPrep


#>

function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
}

function Connect-ECIVIServer
{
    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Write-Host "Setting PowerCLIConfiguration: -InvalidCertificateAction Ignore" -ForegroundColor Gray
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false <#-ParticipateInCEIP:$false#> | Out-Null

    if($global:DefaultVIServers.Count -gt 0)
    {
        Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
    }
    else 
    {
        $VIServer = "ecilab-bosvcsa01.ecilab.corp"
        Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Gray
        $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
        #$VISession = Connect-VIServer -Server $VIServer  -User ezebos\cbrennan -Password Tolkien43741
        $VISession = Connect-VIServer -Server $VIServer  -User sdesimone_admin@ecilab.corp -Password cH3r0k33!B
    }

    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

function Add-ISOtoDatastore
{
    ### Add ISO
    $Datastore = "nfs_emsadmin_sas1"
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    #DIR $ISODataStore

    ### Get Datastore Items
    (Get-ChildItem $ISODataStore).Name
    
    $ItemFolder = "C:\Scripts\New_ISO\"
    #$ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM2.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $ItemFile = "VMware-tools-windows-10.1.0-4449150.iso"

    $Item = $ItemFolder + $ItemFile

    Copy-DatastoreItem -Item $Item -Destination $ISODataStore 


    #Get-VM -Name SDGRP008 | Get-CDDrive | `
    #Set-CDDrive -IsoPath "[$Datastore] ISOfiles\0.iso" -Confirm:$false


    ### Remove ISO
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $Item = $ISODataStore + $ItemFile
    
    Remove-Item $Item 
}


function Create-ISO
{
    
    $SourceWindowsIsoPath = "C:\Scripts\New_ISO\Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $VMwareToolsIsoUrl = "https://packages.vmware.com/tools/esx/6.5/windows/VMware-tools-windows-10.1.0-4449150.iso"
    $AutoUnattendXmlPath = "C:\Scripts\New_ISO\autounattend.xml"

    #Clean DISM mount point if any. Linked to the PVSCSI drivers injection.
    Clear-WindowsCorruptMountPoint
    Dismount-WindowsImage -path 'C:\CustomizedWindowsIso\Temp\MountDISM' -discard


    #The Temp folder is only needed during the creation of one ISO.
    Remove-Item -Recurse -Force 'C:\CustomizedWindowsIso\Temp'

    New-Item -ItemType Directory -Path C:\CustomizedWindowsIso\Temp
    New-Item -ItemType Directory -Path C:\CustomizedWindowsIso\Temp\WorkingFolder
    New-Item -ItemType Directory -Path C:\CustomizedWindowsIso\Temp\VMwareTools
    New-Item -ItemType Directory -Path C:\CustomizedWindowsIso\Temp\MountDISM


    #Prepare path for the Windows ISO destination file
    $SourceWindowsIsoFullName = $SourceWindowsIsoPath.split("\")[-1]
    $DestinationWindowsIsoPath = 'C:\CustomizedWindowsIso\FinalIso\' +  ($SourceWindowsIsoFullName -replace ".iso","") + '-CUSTOM.ISO'

    
    #Download VMware Tools ISO  
    $VMwareToolsIsoFullName = $VMwareToolsIsoUrl.split("/")[-1]
    $VMwareToolsIsoPath =  "C:\CustomizedWindowsIso\Temp\VMwareTools\" + $VMwareToolsIsoFullName 
    (New-Object System.Net.WebClient).DownloadFile($VMwareToolsIsoUrl, $VMwareToolsIsoPath)
    

    # Mount the source Windows iso.
    $MountSourceWindowsIso = mount-diskimage -imagepath $SourceWindowsIsoPath -passthru
    # get the drive letter assigned to the iso.
    $DriveSourceWindowsIso = ($MountSourceWindowsIso | get-volume).driveletter + ':'

    
    # Mount VMware tools ISO
    $MountVMwareToolsIso = mount-diskimage -imagepath $VMwareToolsIsoPath -passthru
    # get the drive letter assigned to the iso.
    $DriveVMwareToolsIso = ($MountVMwareToolsIso  | get-volume).driveletter + ':'
    

    # Copy the content of the Source Windows Iso to a Working Folder
    copy-item $DriveSourceWindowsIso\* -Destination 'C:\CustomizedWindowsIso\Temp\WorkingFolder' -force -recurse

    # remove the read-only attribtue from the extracted files.
    get-childitem 'C:\CustomizedWindowsIso\Temp\WorkingFolder' -recurse | %{ if (! $_.psiscontainer) { $_.isreadonly = $false } }

    
    #Copy VMware tools exe in a custom folder in the future ISO
    New-Item -ItemType Directory -Path 'C:\CustomizedWindowsIso\Temp\WorkingFolder\CustomFolder'
    #For 64 bits by default.
    copy-item "$DriveVMwareToolsIso\setup64.exe" -Destination 'C:\CustomizedWindowsIso\Temp\WorkingFolder\CustomFolder'
    #For 32 bits comment above line and uncomment line below.
    #copy-item "$DriveVMwareToolsIso\setup.exe" -Destination 'C:\CustomizedWindowsIso\TempWorkingFolder\CustomFolder'
    
    #Inject PVSCSI Drivers in boot.wim and install.vim
    #For 64 bits
    $pvcsciPath = $DriveVMwareToolsIso + '\Program Files\VMware\VMware Tools\Drivers\pvscsi\Win8\amd64\pvscsi.inf'
    #For 32 bits
    #$pvcsciPath = $DriveVMwareToolsIso + '\Program Files\VMware\VMware Tools\Drivers\pvscsi\Win8\i386\pvscsi.inf'


    #Modify all images in "boot.wim"
    #Example for windows 2016 iso:
    # Microsoft Windows PE (x64)
    # Microsoft Windows Setup (x64)

    Get-WindowsImage -ImagePath 'C:\CustomizedWindowsIso\Temp\WorkingFolder\sources\boot.wim' | foreach-object {
	    Mount-WindowsImage -ImagePath 'C:\CustomizedWindowsIso\Temp\WorkingFolder\sources\boot.wim' -Index ($_.ImageIndex) -Path 'C:\CustomizedWindowsIso\Temp\MountDISM'
	    Add-WindowsDriver -path 'C:\CustomizedWindowsIso\Temp\MountDISM' -driver $pvcsciPath -ForceUnsigned
	    Dismount-WindowsImage -path 'C:\CustomizedWindowsIso\Temp\MountDISM' -save
    }

    #Optional check all Image Index for install.wim
    Get-WindowsImage -ImagePath 'C:\CustomizedWindowsIso\Temp\WorkingFolder\sources\install.wim'

    #Modify all images in "install.wim"
    #Example for windows 2016 iso:
    # Windows Server 2016 SERVERSTANDARDCORE
    # Windows Server 2016 SERVERSTANDARD
    # Windows Server 2016 SERVERDATACENTERCORE
    # Windows Server 2016 SERVERDATACENTER

    Get-WindowsImage -ImagePath 'C:\CustomizedWindowsIso\Temp\WorkingFolder\sources\install.wim' | foreach-object {
	    Mount-WindowsImage -ImagePath 'C:\CustomizedWindowsIso\Temp\WorkingFolder\sources\install.wim' -Index ($_.ImageIndex) -Path 'C:\CustomizedWindowsIso\Temp\MountDISM'
	    Add-WindowsDriver -path 'C:\CustomizedWindowsIso\Temp\MountDISM' -driver $pvcsciPath -ForceUnsigned
	    Dismount-WindowsImage -path 'C:\CustomizedWindowsIso\Temp\MountDISM' -save
    }

    #Add the autaunattend xml for a basic configuration AND the installation of VMware tools.
    copy-item $AutoUnattendXmlPath -Destination 'C:\CustomizedWindowsIso\Temp\WorkingFolder\autounattend.xml'


    #Maybe in a future update of the script
    #Add all patches in the ISO  with ADD-WINDOWS PACKAGE


    #Now copy the content of the working folder in the new custom windows ISO.

    $OcsdimgPath = 'C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg'
    $oscdimg  = "$OcsdimgPath\oscdimg.exe"
    $etfsboot = "$OcsdimgPath\etfsboot.com"
    $efisys   = "$OcsdimgPath\efisys.bin"

    $data = '2#p0,e,b"{0}"#pEF,e,b"{1}"' -f $etfsboot, $efisys
    start-process $oscdimg -args @("-bootdata:$data",'-u2','-udfver102', 'C:\CustomizedWindowsIso\Temp\WorkingFolder', $DestinationWindowsIsoPath) -wait -nonewwindow



}

function Get-ECIVMTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VMTemplate = "RGEE-NoTemplate"
    $VMTemplate = Get-Template -Name $VMTemplateName

    $OSCustomizationSpec = "w2016"
    $OSCustomizationSpec = Get-OSCustomizationSpec -Name $OSCustomizationSpec
     $OSCustomizationSpec | Select-Object *
}

function New-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### New-VM --- https://www.vmware.com/support/developer/windowstoolkit/wintk40u1/html/New-VM.html

    Write-Host "Creating VM: " $VM "ResourcePool: " $ResourcePool -ForegroundColor Yellow
    
    #$VMTemplate = "W2K16v2"
    #$VMTemplate  = Get-Template -Name $VMTemplate

    $VMTemplate = "RGEE-NoTemplate"
    $VMTemplate = Get-Template -Name $VMTemplate



    New-VM -Name $VM -Datastore $TargetDataStore -ResourcePool $ResourcePool -Template $VMTemplate #-OSCustomizationSpec $OSCustomizationSpec



    #New-VM -Name $VM -Template $VMTemplate -ResourcePool $ResourcePool -DiskStorageFormat Thin -Datastore $TargetDataStore
    #New-VM -Name $VM -Datastore $TargetDataStore -ResourcePool $ResourcePool -Template $VMTemplate -OSCustomizationSpec $OSCustomizationSpec
    #-NumCpu $vCPUCount -MemoryMB $vMemorySize 
        
        # -CD #-DiskGB $OSVolumeSize -DiskStorageFormat $DiskStorageFormat #-InformationAction SilentlyContinue #-CD $CD #-DiskStorageFormat Thin -Datastore $TargetDataStore
        #-Template $VMTemplate
        #-AlternateGuestName $AlternateGuestName
        #-Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)
        #-OSCustomizationSpec $VMCustomSpec `
    #>  

<#
Set-VM

DrsAutomationLevel
HAIsolationResponse
HARestartPriority
VMSwapFilePolicy

Name
Notes

#>


}

function Install-VMTools
{

}

function Get-ECIOSCustomizationSpec
{
    $ECIOSCustomizationSpec = "ECIOSCustomizationSpec-2106"
    $ECIOSCustomizationSpec = "w2016"

    Get-OSCustomizationSpec -Name $ECIOSCustomizationSpec | Select-Object *
}

function Get-TimeZone
{
<#
000 Int'l Dateline 
001 Samoa 
002 Hawaii 
003 Alaskan 
004 Pacific 
010 Mountain (U.S. and Canada) 
015 U.S. Mountain: Arizona 
020 Central (U.S. and Canada) 
025 Canada Central 
030 Mexico 
033 Central America 
035 Eastern (U.S. and Canada) 
040 U.S. Eastern: Indiana (East) 
045 S.A. Pacific 
050 Atlantic (Canada) 
055 S.A. Western 
056 Pacific S.A. 
060 Newfoundland 
065 E. South America 
070 S.A. Eastern 
073 Greenland 
075 Mid-Atlantic 
080 Azores 
083 Cape Verde Islands 
085 GMT (Greenwich Mean Time) 
090 GMT Greenwich 
095 Central Europe 
100 Central European 
105 Romance 
110 W. Europe 
113 W. Central Africa 
115 E. Europe 
120 Egypt 
125 EET (Helsinki, Riga, Tallinn) 
130 EET (Athens, Istanbul, Minsk) 
135 Israel: Jerusalem 
140 S. Africa: Harare, Pretoria 
145 Russian 
150 Arab 
155 E. Africa 
160 Iran 
165 Arabian 
170 Caucasus Pacific (U.S. and Canada) 
175 Afghanistan 
180 Russia Yekaterinburg 
185 W. Asia 
190 India 
193 Nepal 
195 Central Asia 
200 Sri Lanka 
201 N. Central Asia 
203 Myanmar: Rangoon 
205 S.E. Asia 
207 N. Asia 
210 China 
215 Singapore 
220 Taipei 
225 W. Australia 
227 N. Asia East 
230 Korea: Seoul 
235 Tokyo 
240 Sakha Yakutsk 
245 A.U.S. Central: Darwin 
250 Central Australia 
255 A.U.S. Eastern 
260 E. Australia 
265 Tasmania 
270 Vladivostok 
275 W. Pacific 
280 Central Pacific 
285 Fiji 
290 New Zealand 
300 Tonga
#>
}

function New-ECIOSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $Name = "ECIOSCustomizationSpec-2016"
    $OSType = "Windows"
    $Type = "Persistent "
    #$DnsServer = "?"
    #$DnsSuffix = "?"
    $NamingScheme = "VM"
    $FullName = "ECIAdmin"
    $OrgName = "Eze Castle Integration"
    $AdminPassword = "cH3r0k33"
    $ChangeSid = "True"
    $DeleteAccounts = "False"
    #$GuiRunOnce = "?"
    #$AutoLogonCount = "?"
    $TimeZone = "035"
    $ProductKey = "RKM9R-NTCGJ-KP4RF-FJFGF-4X9Q2" 
    $LicenseMode = "PerSeat"
    $Workgroup = "Workgroup"

    Write-Host "Customizing VM: $VM  OSCustomizationSpec: $OSCustomizationSpec.Name" -ForegroundColor Yellow

    New-OSCustomizationSpec -Name $Name -Type $Type -OSType $OSType -NamingScheme $NamingScheme -FullName $FullName -OrgName $OrgName -AdminPassword $AdminPassword -ChangeSid:$true -DeleteAccounts:$false -TimeZone $TimeZone -ProductKey $ProductKey -LicenseMode $LicenseMode -Workgroup $Workgroup

    Return $ECIOSCustomizationSpec
}

function Set-ECIOSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VM = Get-VM -Name $VM
    $ECIOSCustomizationSpec = "ECIOSCustomizationSpec-2016"
    $OSCustomizationSpec = Get-OSCustomizationSpec -Name $ECIOSCustomizationSpec

    Write-Host "Customizing VM: $VM  OSCustomizationSpec: $OSCustomizationSpec.Name" -ForegroundColor Yellow
    Set-VM -VM $VM -OSCustomizationSpec $OSCustomizationSpec -Confirm:$false
}



function Set-ECIVMName
{
    $vCPU = "2"

    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -Name $VM.Name
}

function Set-ECIVMCpu
{
    $vCPU = "2"

    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -NumCpu $vCPU
}

function Set-ECIVMMemory
{
    $vMem = "6"

    $VM = Get-VM -Name $VM
    Set-VM -VM $VM -Confirm:$False -MemoryGB $vMem

    Get-VM -Name $VM | Select-Object *
}

function New-ECINetworkAdapter
{ 
    $NetworkName = "emsadmin-RED-RGEE-LAN"

    $VM = Get-VM -Name $VM
    New-NetworkAdapter -VM $VM -Confirm:$False -NetworkName $NetworkName  
    
}

function Start-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Starting VM: $VM" -ForegroundColor Yellow
    Start-VM $VM
}

function Stop-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Stopping VM: $VM" -ForegroundColor Yellow
    Stop-VM $VM -Confirm:$false
}


function Get-ESXHost
{
    Get-View -ViewType HostSystem -Property Name,Config.Product | Format-Table Name, @{L='Host Version & Build Version';E={$_.Config.Product.FullName}}
}


function Install-VMTools
{
    Mount-Tools -VM $VM
    Dismount-Tools -VM $VM
    Update-Tools -VM $VM
  
  
    #$vm.ExtensionData.Guest | Select Hostname,Tools*

<#
Copy the VMware Tools Installer to a local or shared folder
Note: There are 2 different installers: Setup.exe and Setup64.exe Choose according to the corresponding OS
Open Command Prompt
Browse to the folder that includes the setup file
type .\setup64.exe /s /v “/qn reboot=r”
The /qn means it will be a silent (quiet) installation, there will be no GUI.

reboot=r will keep your VM from restarting after the installation completes

s – silent execution

v – sends all parameters directly to the msi file.
#>

}

function New-ECIScsiController
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Creating ScsiController: " -ForegroundColor Yellow

    $ScsiControllerType = "VirtualLsiLogicSAS"
    $Disk = Get-HardDisk -VM $VM | Select -First 1
    
    New-ScsiController -HardDisk $Disk -Type $ScsiControllerType -Confirm:$false
}

function Remove-ECIHardDisk
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Removing Hard Disk: " -ForegroundColor Yellow
    
    Get-HardDisk -VM $VM | Remove-HardDisk -DeletePermanently -Confirm:$false
}

function New-ECIHardDisk
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Creating Hard Disk: " -ForegroundColor Yellow

    $Persistence = "Persistent"
    $StorageFormat = "Thin"
    $Controller = Get-ScsiController -VM $VM | Select -First 1

    ### Add OS Volume
    Get-VM $VM | New-HardDisk -CapacityGB $OSVolumeSize -Persistence $Persistence -StorageFormat $StorageFormat -Controller $Controller

    ### Add PageFile Volume
    Get-VM $VM | New-HardDisk -CapacityGB $SwapVolumeSize -Persistence $Persistence -StorageFormat $StorageFormat -Controller $Controller
}

function Get-ECIHardDisk
{
    $VM = "RGEE-NoTemplate"
    $VM = Get-VM -Name $VM

    Get-HardDisk -VM $VM

    
}


function Remove-ECIHardDisk
{

    $VM = "RGEE-NoTemplate"
    $VM = Get-VM -Name $VM

    $HardDisk = (Get-HardDisk -VM $VM).Name
    $HardDisk = Get-HardDisk -VM $VM | Where-Object {$_.CapacityGB -eq "10"}

    Remove-HardDisk  -HardDisk $HardDisk -Confirm:$false
}


function Set-ECIHardDisk 
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Setting Hard Disk: " -ForegroundColor Yellow

    $Disk = Get-HardDisk -VM $VM | Select -First 1
    Set-HardDisk -HardDisk $Disk -CapacityGB $OSVolumeSize -Confirm:$False
}

function Remove-ECIVM
{
    Write-Host "Removing VM: " -ForegroundColor Yellow
    #Stop-VM -VM $VM -Kill -Confirm:$False
    #Shutdown-VMGuest -VM $VM -Confirm:$False
    Remove-VM -VM $VM -DeletePermanently -Confirm:$False
}


function New-AHCIController 
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $VM = Get-VM $VM
    $global:VMSpec = New-Object VMware.Vim.VirtualMachineConfigSpec
    $VMSpec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $VMSpec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $VMSpec.deviceChange[0].operation = "add"
    $VMSpec.deviceChange[0].device = New-Object VMware.Vim.VirtualAHCIController
    $Busnumber = ($VM.ExtensionData.Config.Hardware.device | Where { $_.gettype().Name -eq "VirtualAHCIController" } | Select -ExpandProperty busnumber | Sort-Object -Descending | Select -First 1) +1

    #$VM.ExtensionData.Config.Hardware.device | Where { $_.gettype().Name -eq "VirtualAHCIController" } | Select -ExpandProperty busnumber 
    
    #| Select -ExpandProperty busnumber | Sort-Object -Descending | Select -First 1) +1


    $VMspec.deviceChange[0].device.busnumber = $Busnumber
    $VMspec.deviceChange[0].device.key = -1
    $VM.ExtensionData.ReconfigVM($VMSpec)       
}


function New-ECICDDrive
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $VM = Get-VM -Name $VM 

    Write-Host "Creating New CD Drive: " -ForegroundColor Yellow
 
    $ISOStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    $ISOFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM.ISO"
    $ISOFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $ISO = $ISOStore + $ISOFile
    
    $ISOFile = Get-ChildItem $ISO
    
    #ContentLibraryIso

    #$ISOPath = Join-Path $ISOFolder.DatastoreFullPath[0] $ISOFile.Name
    $ISOPath = Join-Path (Split-Path $ISOFolder.DatastoreFullPath[0] -Parent) $ISOFile
#    (Split-Path $ISOFolder.DatastoreFullPath[0] -Parent)
    #New-CDDrive -VM $VM -IsoPath $ISOPath -StartConnected -Confirm:$false
    
    New-CDDrive -VM $VM -StartConnected -Confirm:$false
}

function Set-ECICDDrive
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Setting CDROM: " -ForegroundColor Yellow

    $VM = Get-VM -Name $VM 

    $ISOStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    $ISOFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $ISO = $ISOStore + $ISOFile
    $ISOFile = Get-ChildItem $ISO
    $ISOPath = Join-Path (Split-Path $ISOFolder.DatastoreFullPath[0] -Parent) $ISOFile

    $CD = Get-CDDrive -VM $VM
    Set-CDDrive -CD $CD -IsoPath $ISOPath -StartConnected:$true -Confirm:$false
}

function Set-CDtoSATA
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $vmName = $VM
    $cdName = 'CD/DVD drive 1'
    $sataName = 'SATA controller 0'
    $vm = Get-VM -Name $vmName
    $cd = Get-CDDrive -VM $vm -Name $cdName
    #$sataCtrl = $vm.ExtensionData.Config.Hardware.Device | where{$_ -is [VMware.Vim.VirtualAHCIController] -and $_.DeviceInfo.Label -eq $sataName}
    $sataCtrl = $vm.ExtensionData.Config.Hardware.Device | where{$_ -is [VMware.Vim.VirtualAHCIController]}
    $unitInuse = $vm.ExtensionData.Config.Hardware.Device | where{$_.ControllerKey -eq $sataCtrl.Key} | %{$_.UnitNumber}
    $freeUnit = 0..29 | where{$_ -ne $sataCtrl.UnitNumber -and $unitInuse -notcontains $_ -and $_ -ne $cd.ExtensionData.UnitNumber} | Measure-Object -Minimum | select -ExpandProperty Minimum
    $spec = New-Object VMware.Vim.VirtualMachineConfigSpec

    # Point CD/DVD to SATA ctrl
    $dev = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $dev.Device = $cd.ExtensionData
    $dev.Device.ControllerKey = $sataCtrl.Key
    $dev.Device.UnitNumber = $freeUnit
    $dev.Operation = [VMware.Vim.VirtualDeviceConfigSpecOperation]::edit
    $spec.DeviceChange += $dev
    $vm.ExtensionData.ReconfigVM($spec)
}

function network
{

Get-VM $vm | Get-CDDrive | Set-CDDrive -ISOPath “[VMFS1] ISO\oel_6.4_boot.iso” -StartConnected $true -Confirm:$false
Get-VM $vm | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName Vlan126 -Confirm:$False
Get-VM $vm | Get-NetworkAdapter | Set-NetworkAdapter -Type VMXNet3 -Confirm:$False
Get-VM $vm | Get-ScsiController | Set-ScsiController -Type ParaVirtual

}


function samplevm
{
#Create the VM with 7 disks.

$name = “MyVMName”
New-VM -VMHost MyESXiHost -CD -Name $name -MemoryMB 16384 -NumCPU 1 -Version v9 -GuestId oracleLinux64Guest -Datastore VMFS3 -DiskGB 10,20,30,200,200,200,10 -DiskStorageFormat Thin

Some settings which  are annoying to do with a mouse and also easily forgotten

$vm = Get-VM $name
New-AdvancedSetting -Entity $vm -Name ‘vcpu.hotadd’ -Value ‘true’ -Confirm:$false
New-AdvancedSetting -Entity $vm -Name ‘mem.hotadd’ -Value ‘true’ -Confirm:$false
New-AdvancedSetting -Entity $vm -Name ‘svga.autodetect’ -Value ‘true’ -Confirm:$false

This is some code to do the same if the settings have already been configured

$vm | Get-AdvancedSetting -Name ‘vcpu.hotadd’ | Set-AdvancedSetting -Value ‘true’ -Confirm:$false
$vm | Get-AdvancedSetting -Name ‘mem.hotadd’ | Set-AdvancedSetting -Value ‘true’ -Confirm:$false
$vm | Get-AdvancedSetting -Name ‘svga.autodetect’ | Set-AdvancedSetting -Value ‘true’ -Confirm:$false

Change NIC and SCSI controller type

Get-VM $vm | Get-CDDrive | Set-CDDrive -ISOPath “[VMFS1] ISO\oel_6.4_boot.iso” -StartConnected $true -Confirm:$false
Get-VM $vm | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName Vlan126 -Confirm:$False
Get-VM $vm | Get-NetworkAdapter | Set-NetworkAdapter -Type VMXNet3 -Confirm:$False
Get-VM $vm | Get-ScsiController | Set-ScsiController -Type ParaVirtual

Add the last 4 disks to a seperate SCSCI controller

$disks = Get-Harddisk -VM $vm | Select -Last 4
New-ScsiController -Type ParaVirtual -Harddisk $disks

Start the VM

Start-VM $vm
}



function Start-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Starting VM: $VM" -ForegroundColor Yellow
    Start-VM $VM
}

function Stop-ECIVM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Stopping VM: $VM" -ForegroundColor Yellow
    Stop-VM $VM -Confirm:$false
}

function Remove-ECIVM
{

}

&{

    BEGIN
    {
        $script:StartTime = Get-Date
        Import-VMWareModules
        Connect-ECIVIServer
        
    }

    PROCESS 
    {

        New-ECIVM
        Set-ECIVMName
        Set-ECIVMCPU
        Set-ECIVMMemory
        New-ECINetworkAdapter
        New-ECIOSCustomizationSpec
        Set-ECIOSCustomizationSpec
        Start-ECIVM
        #Stop-ECIVM

        #Create-ISO
        #New-ECIVM
        #New-ECIScsiController
        #Remove-ECIHardDisk
        #New-ECIHardDisk
        #Set-ECIHardDisk
        #New-AHCIController
        #New-ECICDDrive
        #Set-CDtoSATA
        #Set-CDROM <-- set to use iso & start on boot
        #Start-ECIVM
        #Install-VMTools
        #Remove-ECIVM
    }

    END
    {
        $script:StopTime = Get-Date
        Write-Host `n`n('=' * 75)`n"Script Execution Time:`t" ($StopTime-$StartTime) `n('=' * 75)`n -ForegroundColor Gray
    }


}