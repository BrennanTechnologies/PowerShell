###################################
### VM Provioning Script
###################################
Param(
        [Parameter(Mandatory = $True)][int]$ServerID,
        [Parameter(Mandatory = $True)][string]$ConfigurationMode
        #[Parameter(Mandatory = $True)][string]$HostName,
     )




&{

    BEGIN
    {
        $script:VMStartTime = Get-Date
        
        ### Reset Verify Error Counter
        $global:VerifyErrorCount = 0

        List-AllParameters
        #Import-ECI.Root.ModuleLoader
        Import-VMWareModules
        Connect-ECI.VIServer -InstanceLocation $InstanceLocation

        Write-Host `n('*' * 50)`n "      --------- STARTING VM PROVISIONING ---------  " `n " --------- THIS PROCESS MAY TAKE SEVERAL MINUTES ---------  " `n('*' * 50)`n -ForegroundColor Green
    }

    PROCESS 
    {
        ### Get vCenter Resources
        ###------------------------------------------------------
        Get-ECI.Cluster -ECIvCenter $ECIvCenter
        Get-ECI.ResourcePool -GPID $GPID -ECIvCenter $ECIvCenter
        Get-ECI.PortGroup
        Get-ECI.DataStore
        Set-VMHostName
        List-AllParameters
        Get-ECI.VMTemplate
   

        ###------------------------------------------------------
        ### Create New VM
        ###------------------------------------------------------

        Write-Host "CREATING NEW VM           :" 
        Write-Host "VM                        : "   $VM
        Write-Host "ECIVMTemplate             : "   $ECIVMTemplate
        Write-Host "OSCustomizationSpecName   : "   $OSCustomizationSpecName
        Write-Host "ResourcePool              : "   $ResourcePool
        Write-Host "DataStore                 : "   $DataStore
        Write-Host "PortGroup                 : "   $PortGroup
        Write-Host "IPv4Address               : "   $IPv4Address
        Write-Host "SubnetMask                : "   $SubnetMask
        Write-Host "DefaultGateway            : "   $DefaultGateway
        Write-Host "PrimaryDNS                : "   $PrimaryDNS
        Write-Host "SecondaryDNS              : "   $SecondaryDNS

        $NewVMParameters = @{
            VM                        = $VM
            ECIVMTemplate             = $ECIVMTemplate
            OSCustomizationSpecName   = $OSCustomizationSpecName
            ResourcePool              = $ResourcePool
            DataStore                 = $DataStore
            PortGroup                 = $PortGroup
            IPv4Address               = $IPv4Address
            SubnetMask                = $SubnetMask
            DefaultGateway            = $DefaultGateway
            PrimaryDNS                = $PrimaryDNS
            SecondaryDNS              = $SecondaryDNS
        }

        New-ECI.VM @NewVMParameters


        ### Configure VM
        ###------------------------------------------------------
        Set-ServerUUID
   
        #New-ECI.NetworkAdapter
        #New-ECI.OSCustomizationSpec
        #Set-ECI.OSCustomizationSpec
        #New-ECI.OSCustomizationNicMapping

        Set-ECI.VMCPU
        Set-ECI.VMMemory


        ### Verify each function
        $VerifyErrors = $Null
        $global:Verify = $True # <--- this isnt getting passed, setting maunal here FIX!!!!!

        Start-ECI.VM
        Wait-ECI.OSCusomization #<--| combine
        Wait-InvokeVMScript     #<--| combine

        ## Enable NIC: VM Must be power op
        ###Set-ECI.NetworkAdapter -not needed

        ###---------------------------------------
        ### Write Logs to SQL
        ###---------------------------------------
        Write-ConfigLog-SQL
        Write-DesiredState-SQL
        Write-CurrentState-SQL #-ServerID $ServerID

        if ($VerifyErrors.Count -gt 0)
        {
            $Verify = $False
        }
        else
        {
            $Verify = $True
        }


     #Stop-ECI.VM
     #Decommission-ECI.VM -ServerID $ServerID


        # delete these functions from modules
        #------------------------------------------
        #Create-ISO
        #New-ECIVM
        #New-ECIScsiController
        #Remove-ECIHardDisk
        #New-ECIHardDisk
        #Set-ECIHardDisk
        #New-AHCIController
        #New-ECICDDrive
        #Set-CDtoSATA
        #Set-CDROM <-- set to use iso & start on boot
        #Start-ECIVM
        #Install-VMTools
        #Remove-EC.IVM
        #------------------------------------------

    }

    END
    {
        $VMStopTime = Get-Date
        $global:VMElapsedTime = ($VMStopTime-$VMStartTime)
        Write-Host `n`n('=' * 75)`n "VM Configuration: Total Execution Time:`t" $VMElapsedTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "END vS configuration SCRIPTS" -ForegroundColor Gray
    }


}