﻿
cls
            
$global:HostName = "SRV-98"
$global:ServerID = "439"
$ServerRole = "2016Server"
$ConfigurationMode = "Configure"
$ServerRole = "2016Server"
$IPv4Address = "10.61.1.111"
$SubnetMask = "255.255.255.0"
$DefaultGateway = "10.61.1.250"
$PrimaryDNS = "10.61.1.1"
$SecondaryDNS = "10.61.1.2"
$ClientDomain = "GEEMONEYMGMT"


function Invoke-ModuleLoader
{

    ######################################
    ### Bootstrap Module Loader
    ######################################

    ### Set Execution Policy to ByPass
    Write-Host "Setting Execution Policy: ByPass"
    #Set-ExecutionPolicy Bypass

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
            
    ((Get-PSDrive | Where {((Get-PSDrive).DisplayRoot) -like "\\eciscripts"}) | Remove-PSDrive -Force ) | Out-Null

    if(-NOT((Get-PSDrive -PSProvider FileSystem).Name) -eq "X")
    {
        ####New-PSDrive -Name $RootDrive -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope global
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    }

    $PSDrive = New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
}


function Invoke-Test
{
    $OSParameters = @{
            ServerID = $ServerID
            HostName = $HostName
            ConfigurationMode = $ConfigurationMode
            ServerRole = $ServerRole
            IPv4Address = $IPv4Address
            SubnetMask = $SubnetMask
            DefaultGateway = $DefaultGateway
            PrimaryDNS = $PrimaryDNS
            SecondaryDNS = $SecondaryDNS
            ClientDomain = $ClientDomain
    }
        
    #####################
    ### Configure OS
    #####################
   
        Get-OSParameters

        #. '\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.EMI.Automation.Dev\ECI.EMI.Automation.Scripts.Dev\ECI.EMI.Automation.Invoke-ServerBuild.ps1' @ServerRequestParameters
        . '\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.EMI.Automation.OS.Dev\ECI.EMI.Automation.Scripts.Dev\ECI.EMI.Automation.OSConfiguration.Invoke.ps1' @OSParameters

}


&{

    #Invoke-ModuleLoader
    
    #$global:ALLParameters = $null
    #$global:ALLParameters = @()
    #$global:ServerRole = "2016Server"
    #$global:BuildVersion = "1.0.0"
    #Get-OSParameters2 -ServerRole $ServerRole -BuildVersion $BuildVersion
    
    Invoke-Test 

}

       