﻿function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\VMAutomation\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

& { 

    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #<--Path
        Write-Host "`nBEGINBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        #Import-SoftParametersFromAPI #<--- delete me?????
        Show-OSParameters
        
     }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "`n" ("=" * 75) "`nPROCESSBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)
<#
        switch ( $Step )
        {
            "Configure-ECI.NetworkInterface"       { Configure-ECI.NetworkInterface       }
            "Configure-ECI.IPv6"                   { Configure-ECI.IPv6                   }
            "Configure-ECI.CDROM"                  { Configure-ECI.CDROM                  }
            "Configure-ECI.RemoteDesktop"          { Configure-ECI.RemoteDesktop          }
            "Configure-ECI.WindowsFirewallProfile" { Configure-ECI.WindowsFirewallProfile }
            "Configure-ECI.InternetExplorerESC"    { Configure-ECI.InternetExplorerESC    }
            "Configure-ECI.WindowsFeatures"        { Configure-ECI.WindowsFeatures        }
        }
#>

        if ($Step -eq "ConfigureOS")
        {
            Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 

            Start-Transcript
            Configure-ECI.NetworkInterface # -ConfigurationMode Report
            Configure-ECI.IPv6 # -ConfigurationMode Configure
            Configure-ECI.CDROM
            ##########   Configure-IPv4 # Set by Invoke-ServerBuildTemplate <-- Change to "Verify-IPv4" function       ##########   Verify-IPv4 <-- Change to "Verify-IPv4" function
           
            Configure-ECI.RemoteDesktop # says network interface ????
            Configure-ECI.WindowsFirewallProfile #-ConfigurationMode Configure
            Configure-ECI.InternetExplorerESC  # say windows firewall???
            Configure-ECI.WindowsFeatures
            
            Stop-Transcript
            #Configure-ECI.Folders
            #Configure-PageFile #<<< --- need to finsish writing  function
            #Configure-WindowsFirewallRules ?????????????
           
        }

        if ($Step -eq "Restart-VMGuest")
        {
            Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 
            Restart-VMGuest
            
        }
        if ($Step -eq "3")
        {
            Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n p
            Resume-Configure-WindowsFeatures
        }
        if ($Step -eq "4")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-LocalAdministrator
        }
        if ($Step -eq "5")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-LocalAdministrator
        }
        if ($Step -eq "6")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-GuestComputer
        }
        if ($Step -eq "7")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-GuestComputer
        }        
        if ($Step -eq "8")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Join-Domain
        }
        if ($Step -eq "9")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Join-Domain
        }
        if ($Step -eq "10")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step -ForegroundColor Yellow
            #Configure-WindowsUpdates 
            #Install-WindowsUpdates
        }
        if ($Step -eq "11")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step -ForegroundColor Yellow
            #Resume-Install-WindowsUpdates
        }
        
        Write-Host "`n" ("=" * 75) "`nOS CONFIGURATION COMPLETE - VM: $VM Date: $(Get-Date) `n" ("=" * 75)
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "ENDBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Write-ServerBuildTag
        Close-LogFile
        Stop-Transcript
    }
}
