﻿Param(
    [Parameter(Mandatory = $True)] [string]$ServerID,
    [Parameter(Mandatory = $True)] [string]$ConfigurationMode,
    [Parameter(Mandatory = $True)] [string]$HostName,
    [Parameter(Mandatory = $True)] [string]$ServerRole,
    [Parameter(Mandatory = $True)] [string]$IPv4Address,
    [Parameter(Mandatory = $True)] [string]$SubnetMask,
    [Parameter(Mandatory = $True)] [string]$DefaultGateway,
    [Parameter(Mandatory = $True)] [string]$PrimaryDNS,
    [Parameter(Mandatory = $True)] [string]$SecondaryDNS,
    [Parameter(Mandatory = $True)] [string]$ClientDomain
)

function Show-Parameters
{
    Write-Host "Running Server ECI.EMI.Automation.OSConfiguration.Invoke.ps1  : " -ForegroundColor Gray
    Write-Host "RequestID           : " $ServerID -ForegroundColor DarkGreen
    Write-Host "HostName           : " $HostName -ForegroundColor DarkGreen
    Write-Host "ServerType         : " $ServerRole -ForegroundColor DarkGreen
    Write-Host "IPv4Address        : " $IPv4Address -ForegroundColor DarkGreen
    Write-Host "SubnetMask         : " $SubnetMask -ForegroundColor DarkGreen
    Write-Host "DefaultGateway     : " $DefaultGateway -ForegroundColor DarkGreen
    Write-Host "PrimaryDNS         : " $PrimaryDNS -ForegroundColor DarkGreen
    Write-Host "SecondaryDNS       : " $SecondaryDNS -ForegroundColor DarkGreen
    Write-Host "ClientDomain       : " $ClientDomain -ForegroundColor DarkGreen
}

function Set-VMHostName
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### Set VM Name fromn HostName Parameters
    ###----------------------------------------------------------------
        $global:VM = $HostName
        Write-Host "Setting VM Host Name: VM =" $VM -ForegroundColor Yellow
}

#######################################
### Function: Set VMGuest - Execution Policy
#######################################
function Configure-VMGuestExecutionPolicy
{
    Write-Host `n`n('-' * 50)`n "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50) -ForegroundColor Magenta

    Write-Host "VM: " $VM -ForegroundColor Magenta

    $ScriptText =
    { 
        if ($(Get-ExecutionPolicy) -ne "Bypass")
        {
            Write-Host "`nSetting Execution Policy on VM Guest to Bypass:"
          
            Set-ExecutionPolicy ByPass -Scope LocalMachine

            #REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f
            #Start-Process powershell -ArgumentList '-noprofile -Command Set-ExecutionPolicy ByPass -Scope LocalMachine' -verb RunAs
            #REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f

        }
        else
        {
            Write-Host "`nExecution Policy on VM Guest already set to Bypass"     
        }
    }

    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VM" -ForegroundColor Yellow

    #$Invoke = 
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser "administrator" -GuestPassword "cH3r0k33" -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

    #if($Invoke.ExitCode -ne 0)
    #{
    #    $Abort = $True
    #    Write-Host "ABORT ERROR: Aborting Script Execution" -ForegroundColor Red
    #    #Send-Alert
    #    Exit
    #}
}

#######################################
### Import Bootstap Module
#######################################
[ScriptBlock]$BootStrapModuleLoader = 
{

ipconfig /all

    ### BEGIN: Import BootStrap Module Loader
    Set-ExecutionPolicy ByPass -Scope CurrentUser
    $AcctKey=ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials=$Null
    $Credentials=New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath="\\eciscripts.file.core.windows.net\clientimplementation"
    #((Get-PSDrive|Where {((Get-PSDrive).DisplayRoot) -like "\\eci*"})|Remove-PSDrive -Force )|Out-Null
    #$PSDrive=$Null
    #$PSDrive=
    New-PSDrive -Name V -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    #Write-Host `n
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
    ### END: Import BootStrap Module Loader
} 

#######################################
### Function: Invoke Module Loader on Guest
#######################################
function Invoke-ModuleLoaderOnGuest-deleteme #<---- delete me?????
{
    #Write-Host "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50) -ForegroundColor Magenta
    
    $ScriptText =
    {
        &{
        
        #########################################
        ### Attach to Repository
        #########################################   
        ### Set VM Execution Policy to ByPass
        Write-Host "Setting Execution Policy: ByPass"
        Set-ExecutionPolicy Bypass

        ### Connect a Non-Persistent Drive - then Import the ECI.ModuleLoader
        ### ----------------------------------------------------------------------
        $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
        $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
        $RootPath = "\\eciscripts.file.core.windows.net\clientimplementation\"
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

        #########################################
        ### Copy BootStrap Module Loader
        #########################################        
        $Path = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\Invoke-ECI.Root.ModuleLoader.ps1"
        $Destination = "C:\Scripts\VMAutomation"
        if(-NOT(Test-Path -Path $Destination)) {New-Item -ItemType directory -Path $Destination | Out-Null}
        Copy-Item -Path $Path -Destination $Destination -Force

        }

    }        
    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VM" -ForegroundColor Yellow
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose <#-Debug#> | Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

}


#######################################
### Function: Execute Invoke Process
#######################################
function Invoke-ScriptText
{

    ### Convert SubnetMask to CIDR
    ### --------------------------------------------
    switch ( $SubnetMask )
    {
        "255.255.255.0"      { $SubnetPrefixLength = "24" }
        "255.255.255.128"    { $SubnetPrefixLength = "25" }
        "255.255.255.192"    { $SubnetPrefixLength = "26" }
        "255.255.255.224"    { $SubnetPrefixLength = "27" }
        "255.255.255.240"    { $SubnetPrefixLength = "28" }
        "255.255.255.248"    { $SubnetPrefixLength = "29" }
        "255.255.255.252"    { $SubnetPrefixLength = "30" }
        "255.255.255.254"    { $SubnetPrefixLength = "31" }
    }
    Write-Host "SubnetMask: " $SubnetMask -ForegroundColor Cyan
    Write-Host "SubnetPrefixLength: " $SubnetPrefixLength -ForegroundColor Cyan

    ### Replace Parameters with #LiteralValues#
    ### ---------------------------------------
    $Params = @{
    "#Step#"                          = $Step
    "#VM#"                            = $VM
    "#ServerID#"                      = $ServerID
    "#ServerRole#"                    = $ServerRole
    "#HostName#"                      = $HostName
    "#ClientDomain#"                  = $ClientDomain
    "#IPv4Addres#"                    = $IPv4Address
    "#SubnetPrefixLength#"            = $SubnetPrefixLength
    "#DefaultGateway#"                = $DefaultGateway
    "#PrimaryDNS#"                    = $PrimaryDNS
    "#SecondaryDNS#"                  = $SecondaryDNS
    "#BuildVersion#"                  = $BuildVersion
    "#CDROMLetter#"                   = $CDROMLetter
    "#InternetExplorerESCPreference#" = $InternetExplorerESCPreference
    "#IPv6Preference#"                = $IPv6Preference
    "#LocalAdministrator#"            = $LocalAdministrator
    "#NetworkInterfaceName#"          = $NetworkInterfaceName
    "#RDPResetrictionsPreference#"    = $RDPResetrictionsPreference
    "#RemoteDesktopPreference#"       = $RemoteDesktopPreference
    "#SwapFileBufferSizeMB#"          = $SwapFileBufferSizeMB
    "#SwapFileLocation#"              = $SwapFileLocation
    "#SwapFileMemoryThreshholdGB#"    = $SwapFileMemoryThreshholdGB
    "#SwapFileMultiplier#"            = $SwapFileMultiplier
    "#WindowsFirewallPreference#"     = $WindowsFirewallPreference
    }

    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
    }

    ### Inject BootStrap Module Loader into VM Host
    ### ---------------------------------------
    $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

    ### Debugging: Write ScriptText Block to Screen
    ### ---------------------------------------
    #Write-Host "ScriptText:`n" $ScriptText -ForegroundColor Gray

    ###############################
    ### Inovke VMScript
    ###############################
        ###---------------------------------------------------------
        ### Invoke-VMScript
        ### -Verbose 
        ### -Debug
        ### | Select -ExpandProperty ScriptOutput
        ### | Select -ExpandProperty ExitCode
        ###---------------------------------------------------------

    Write-Host "Executing Invoke-VMScript Function: $((Get-PSCallStack)[0].Command) Step: $Step" -ForegroundColor Yellow

    Write-Host `n('*' * 55)`n `n"      --------- STARTING OS CONFIGURATION ---------  " `n " --------- THIS PROCESS MAY TAKE SEVERAL MINUTES ---------  " `n`n('*' * 55)`n -ForegroundColor Green

    ### Development: Run Invoke without Variable
    ### -------------------------------------------
    #$Invoke = 
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose #| Select -ExpandProperty ScriptOutput #ExitCode
    
    ### -------------------------------------------
    ### Production: Run Invoke as Variable
    ### -------------------------------------------
    #$Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose
    
#    if($Invoke)
#    {
        ### Check Exit Code for any Errors
        ### ---------------------------------------
#        Write-Host $Invoke.ScriptOutput

#        if (($Invoke.ExitCode) -eq 0) {
#            Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
#        }
#        elseif (($Invoke.ExitCode) -ne 0) {
#            Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
#        }
#    }
}

##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host "BEGIN INVOKE FUNCTION: " $((Get-PSCallStack)[0].Command) "-Step:" $Step `n('-' * 50) -ForegroundColor Gray

    [ScriptBlock]$ScriptText = 
    {
        
    ### Import BootStrap Module Loader
    ### -------------------------------
    #BootStrapModuleLoader#
        
    ### *SOFT* Paramters
    ### -------------------------------
    $global:Step                             = "#Step#"    
    $global:VM                               = "#VM#"    
    $global:ServerID                         = "#ServerID#"  
    $global:ServerRole                       = "#ServerRole#"  
    $global:HostName                         = "#HostName#"
    $global:ClientDomain                     = "#ClientDomain#"
    $global:IPv4Address                      = "#IPv4Addres#"
    $global:SubnetPrefixLength               = "#SubnetPrefixLength#"
    $global:DefaultGateway                   = "#DefaultGateway#"
    $global:PrimaryDNS                       = "#PrimaryDNS#"
    $global:SecondaryDNS                     = "#SecondaryDNS#"
    $global:BuildVersion                     = "#BuildVersion#"
    $global:CDROMLetter                      = "#CDROMLetter#"
    $global:InternetExplorerESCPreference    = "#InternetExplorerESCPreference#"
    $global:IPv6Preference                   = "#IPv6Preference#"
    $global:LocalAdministrator               = "#LocalAdministrator#"
    $global:NetworkInterfaceName             = "#NetworkInterfaceName#"
    $global:RDPResetrictionsPreference       = "#RDPResetrictionsPreference#"
    $global:RemoteDesktopPreference          = "#RemoteDesktopPreference#"
    $global:SwapFileBufferSizeMB             = "#SwapFileBufferSizeMB#"
    $global:SwapFileLocation                 = "#SwapFileLocation#"
    $global:SwapFileMemoryThreshholdGB       = "#SwapFileMemoryThreshholdGB#"
    $global:SwapFileMultiplier               = "#SwapFileMultiplier#"
    $global:WindowsFirewallPreference        = "#WindowsFirewallPreference#"

    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    #. "Y:\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.ConfigServer.OSConfiguration.VMHost.ps1"
    . "Y:\ECI.Modules.Dev\ECI.EMI.Automation.OS.Dev\ECI.EMI.Automation.Scripts.Dev\ECI.EMI.Automation.OSConfiguration.VMGuest.ps1"
    } # END ScriptText

    $ScriptTextLength = ($ScriptText | Measure-Object -Character).Characters
    if($ScriptTextLength -le 1505)
    {
        Write-Host "ScriptTextLength: $ScriptTextLength" -ForegroundColor Gray
    }    
    if($ScriptTextLength -gt 1505)
    {
        Write-Host "ScriptTextLength Is Too Long: $ScriptTextLength" -ForegroundColor DarkMagenta
    }
    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    ### Invoke-MVScript Breaks if -GT 1505
    #Invoke-Expression "dir"      
   
    ##### Testing 6-17-18 3:34
        ### Invoke VMGuest.ServerBuildTemplate.ps1
        ### ----------------------------------   
        #. "Y:\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.ConfigServer.OSConfiguration.VMGuest.ps1"    
 
    Invoke-ScriptText
}


##############################################################################
### Execute the Script
##############################################################################
&{ 

    BEGIN
    {
        #Clear-Host
        Write-Host "SCRIPT BEGIN BLOCK: " (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        $script:OSStartTime = Get-Date
        $global:VerifyErrorCount = 0
        $global:ProgressPreference = "SilentlyContinue"

        Import-VMWareModules
        Connect-ECI.VIServer -InstanceLocation $InstanceLocation
        Configure-VMGuestExecutionPolicy
        Delete-ServerLogs -HostName $HostName
        #Show-Parameters
        #Set-VMHostName
    }

    PROCESS
    {
        Write-Host "INVOKE - SCRIPT PROCESS BLOCK: " (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        
        ##########################################
        ### Invoke Configuration in VM Guest
        ##########################################

        Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step ConfigureOS 
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Restart-VMGuest
        
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.NetworkInterface
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.IPv6 
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.CDROM
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.RemoteDesktop
        #Invoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.WindowsFirewallProfile
        #nvoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.InternetExplorerESC
        #nvoke-ECI.EMI.Automation.OSConfiguration.VMGuest -Step Configure-ECI.WindowsFeatures

        ###---------------------------------------
        ### Write Logs to SQL
        ###---------------------------------------
        Write-ConfigLog-SQL
        Write-DesiredState-SQL
        Write-CurrentState-SQL #-ServerID $ServerID

    }

    END
    {
        Write-Host "SCRIPT END BLOCK:" (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        $OSStopTime = Get-Date
        $global:OSElapsedTime = ($OSStopTime-$OSStartTime)
        Write-Host `n`n('=' * 75)`n "OS Configuration: Total Execution Time:`t" $OSElapsedTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "END OS configuration SCRIPTS" -ForegroundColor Gray
        Stop-Transcript
    }

}

