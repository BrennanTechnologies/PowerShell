﻿
function Get-Parameters # <-not used??? delete me???
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$SQLTable,
        [Parameter(Mandatory = $True)] [string]$Select,
        [Parameter(Mandatory = $True)] [string]$Where,
        [Parameter(Mandatory = $True)] [string]$Filter
    )

    if(!(Get-Module -Name SqlServer)){Write-Host "Importing Module: SQLServer";Import-Module SqlServer}

    ### Set the Database Location
    $SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    Set-Location $SQLServer

    ### Execute the SQL Query and return the Columns
    $SQLQuery = "Select $Select from $SQLTable WHERE $Where = '$Filter'"
    $SQLResults = Invoke-Sqlcmd -Query $SQLQuery  -Database $SQLDatabase
    $Columns = $SQLResults | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name} | Sort-Object -Property Name

    ### Create the Variables from each Column in the Table
    $global:Parameters = @()
    foreach($Column in $Columns)
    {
        Set-Variable -Name $Column -Value $SQLResults.$Column -Scope global
        $Parameters += Get-Variable -Name $Column 
    }
    Write-Host "Getting Paramter Set: " $ParameterSet -foregroundcolor yellow
    $Parameters | FT
}

function Import-SoftParametersFromAPI
{

    Write-Host "`nImporting *SOFT* Parameters from API:`n" ("-" * 50) -ForegroundColor White
    
    ### Import *SOFT* Paramters from API
    ### -------------------------------
    $Parameters = [ordered]@{

    Step               = $Step
    VM                 = $VM
    ServerRole         = $ServerRole
    HostName           = $HostName
    ClientDomain       = $ClientDomain
    IPv4Address        = $IPv4Address
    SubnetPrefixLength = $SubnetPrefixLength
    DefaultGateway     = $DefaultGateway
    PrimaryDNS         = $PrimaryDNS
    SecondaryDNS       = $SecondaryDNS

    }

    Write-Host "`nParameters Imported to $env:COMPUTERNAME `n" ('-' * 50)
    Write-Host "Step                  : " $Step
    Write-Host "VM                    : " $VM
    Write-Host "ServerRole            : " $ServerRole
    Write-Host "HostName              : " $HostName
    Write-Host "ClientDomain          : " $ClientDomain
    Write-Host "IPv4Address           : " $IPv4Address
    Write-Host "SubnetPrefixLength    : " $SubnetPrefixLength
    Write-Host "DefaultGateway        : " $DefaultGateway
    Write-Host "PrimaryDNS            : " $PrimaryDNS
    Write-Host "SecondaryDNS          : " $SecondaryDNS
    Write-Host ('-' * 50)


    $global:SoftParameters = @()
    Write-Host "`nImporting *SOFT* Parameters from API:`n" ("-" * 50)
    foreach($Parameter in $Parameters.GetEnumerator())
    {
        Write-Host "$($Parameter.Name): $($Parameter.Value)"

        # Create Variables and Set Variable Scope to "Global"
        Set-Variable -Name $($Parameter.Name) -Value $($Parameter.Value) -Scope Global
        $global:SOFTParameters += Get-Variable -Name $($Parameter.Name)
    }
            
    Write-Host "`nVERIFY: Server Template *SOFT* Parameters:"`n("-" * 50)
    $SoftParameters | FT

}

function Send-Alert
{
    ### Manually Overide Email Parameters
    ### ---------------------------------
    $SMTPServer = "owablu.ecilab.net"
    $To         = "cbrennan@eci.com"
    $From       = "cbrennan@eci.com"
    $Subject    = ""
    $Message    = ""

    ### Email Parameters
    $EmailParams = 
    @{
        From       = $From
        To         = $To 
        #CC        = $CC
        SMTPServer = $SMTPServer
     }
    #Send-MailMessage -SmtpServer owablu.ecilab.net -To sdesimone@eci.com -From wwilson@geemoneymgmt.com -Subject "hi"
    Send-MailMessage @EmailParams -Body ($Message | Out-String) -BodyAsHtml -Subject $Subject

}

function Get-VMGuestConfiguration # <---- delete me?????
{
    Write-ConfigReport "Getting Guest Data:"
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Host ("-" * 50)
    Write-Host "VM GUEST DATA:"
    Write-Host "GuestComputerName : " $env:COMPUTERNAME
    Write-Host "GuestOSVer        : " $GuestOSVer 
    Write-Host "GuestIPv4Addr     : " $GuestIPv4Addr
    Write-Host ("-" * 50)
}

function Configure-ECI.NetworkInterface
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "NetworkInterfaceName"
    $DesiredState      = $NetworkInterfaceName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Rename-NetAdapter (Get-NetAdapter -Name $CurrentState).Name -NewName $DesiredState
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    ###----------------------------
    ### Test Variables passed from #$Variable# substitution
    Write-Host "DesiredState: " $DesiredState
    Write-Host "ServerID: " $ServerID
    ###----------------------------

    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.IPv6
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "IPv6Preference"
    $DesiredState      = $IPv6Preference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Get Current Interface
        $CurrentInterface = (Get-NetAdapter –Physical | Where-Object {$_.Status -eq 'Up'}).Name
        $IPv6State   = Get-NetAdapterBinding -InterfaceAlias $CurrentInterface -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
        $global:CurrentState = $IPv6State.Enabled ### Return True/False
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################

    [scriptblock]$script:SetDesiredState =
    {
        if ($DesiredState -eq $True)
        {
            ### Enable IPv6
            Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
        elseif ($DesiredState -eq $False)
        {
            ### Disable IPv6
            Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.CDROM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must End with Colon ":"
    $CDROMLetter = $CDROMLetter.Trim()
    $LastChar = $CDROMLetter.substring($CDROMLetter.length-1) 
    if ($LastChar -ne ":"){$CDROMLetter = $CDROMLetter + ":"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "CDROMLetter"
    $DesiredState      = $CDROMLetter
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:ComputerName = (Get-WmiObject Win32_ComputerSystem).Name
        $global:CurrentState = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $ComputerName).Drive
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $ComputerName -Filter "DriveLetter='$CurrentState'"
        Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter = $DesiredState} | Out-Null
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.Folders
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "ECIFolders"
    
    ### Create ECI Folders
    ###--------------------------------        
    $ECIFolders = @()
    $ECIFolders += "C:\Scripts"
    $ECIFolders += "D:\Kits"

    $DesiredState      = $ECIFolders
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    foreach($State in $DesiredState)
    {
        $DesiredState = $State
        
        ##################################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##################################################
        [scriptblock]$script:GetCurrentState =
        {
            if(Test-Path -Path $DesiredState){$global:CurrentState = $DesiredState}
            else{$global:CurrentState = $False}
        }

        ##################################################
        ### SET DESIRED-STATE:
        ##################################################
        [scriptblock]$script:SetDesiredState =
        {
            New-Item -ItemType Directory -Path $State -Force | Out-Null
        }

        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        ###----------------------------
        $Params = @{
            ServerID            = $ServerID 
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Configure-ECI.RemoteDesktop
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if($RemoteDesktopPreference -eq "False"){$RemoteDesktopPreferenceValue = "1"}
    elseif($RemoteDesktopPreference -eq "True"){$RemoteDesktopPreferenceValue = "0"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "RemoteDesktopPreference"
    $DesiredState      = $RemoteDesktopPreferenceValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##################################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##################################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections").fDenyTSConnections
    }

    ##################################################
    ### SET DESIRED-STATE:
    ##################################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -Value $RemoteDesktopPreferenceValue
        
        if($RemoteDesktopPreferenceValue -eq "0")
        {
            Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
        }
        elseif($RemoteDesktopPreferenceValue -eq "1")
        {
            Disable-NetFirewallRule -DisplayGroup "Remote Desktop"
        }
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.WindowsFirewallProfile
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "WindowsFirewallPreference"
    $DesiredState      = $WindowsFirewallPreference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-NetFirewallProfile -Name Domain).Enabled
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-NetFirewallProfile -Profile Domain -Enabled $WindowsFirewallPreference
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.InternetExplorerESC 
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if($InternetExplorerESCPreference -eq "False")   {$InternetExplorerESCValue = "0"}
    elseif($InternetExplorerESCPreference -eq "True"){$InternetExplorerESCValue = "1"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "InternetExplorerESCPreference"
    $script:DesiredState      = $InternetExplorerESCPreference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    $Keys = @()
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"

    foreach($Key in $Keys)
    {
        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $global:CurrentState = (Get-ItemProperty -Path $Key -Name "IsInstalled").IsInstalled
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
       [scriptblock]$script:SetDesiredState =
        {
            Set-ItemProperty -Path $Key  -Name "IsInstalled" -Value $DesiredState -Force
        }

        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        $Params = @{
            ServerID            = $ServerID
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Configure-ECI.WindowsFeatures
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "WindowsFeatures"
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    switch ( $ServerRole )
    {
        "2016Server"
        { $WindowsFeatures = 
            @(
                "NET-Framework-Features",
                "NET-Framework-Core",
                "GPMC",
                "Telnet-Client"
            )                      
        }
        "2016FS"
        { $WindowsFeatures = 
            @(
                "NET-Framework-Features",
                "NET-Framework-Core",
                "GPMC",
                "Telnet-Client",
                "RSAT"
            )                         
        }
        "2016DC"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
        "2016DCFS"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
         "2016VDA"
         { $WindowsFeatures = 
         @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
        "2016SQL"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
        "2016SQLOMS"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
    }

    foreach ($Feature in $WindowsFeatures)
    {
        $script:DesiredState = $Feature
        write-host "DesiredState: " $DesiredState

        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $global:CurrentState = ((Get-WindowsFeature -Name $Feature) | Where-Object {$_.Installed -eq $True}).Name
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
        [scriptblock]$script:SetDesiredState =
        {
            Install-WindowsFeature -name $Feature
        }
    
        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        $Params = @{
            ServerID            = $ServerID
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Configure-PageFile #<---- need to complete function!!!!!!!!!!!!!!!!!
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must NOT End with Colon ":"
    $LastChar = $PageFileLocation.substring($PageFileLocation.length-1) 
    if ($LastChar -eq ":"){$PageFileLocation = $PageFileLocation.Split(":")[0]}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    $DesiredState = @()
    $DesiredState += $PageFileSize
    $DesiredState += $PageFileLocation



    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Calculate Desired Page File Size
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $DesiredPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if($Memory -lt "4") {$NewPageFileSize = "4"} ### Set a Minimun 4GB PageFile Size
        $DesiredState = ($DesiredPageFileSize * 1000) 
        $PageFile = Get-WmiObject -Class Win32_PageFileUsage -Computer "LocalHost"
        $CurrentState = $PageFile.MaximumSize
        $Size = ($CurrentState -eq $DesiredState)

        ### PageFile Location
        $script:DesiredState = $PageFileLocation
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $CurrentState = ($PageFile.Name).Split(":")[0]
        $Location =  ($CurrentState -eq $DesiredState)
    
        ### Set $CurrentState
        $script:CurrentState = $True
        $script:DesiredState = $True  
        if (($Size -eq $False) -OR ($Location -eq $False))
        {
            $script:CurrentState = $False
        }
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $script:DesiredState = $PageFileSize
        
        # Disable Automatically Managed PageFile Setting
        $ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
        if ($ComputerSystem.AutomaticManagedPagefile -eq "True") 
        {
            Set-CimInstance -Property @{ AutomaticManagedPageFile = $False }
        }
        Write-Host "AutomaticManagedPagefile : " $(Get-CimInstance -ClassName Win32_ComputerSystem).AutomaticManagedPagefile 
        
        ### Delete Existing PageFile
        ### ---------------------------------
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $PageFile | Remove-CimInstance   


        ### Calculate Page File Size
        ### ---------------------------------
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $NewPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if ($Memory -lt "4") {$NewPageFileSize = "4"}
        [int]$NewPageFileSize = ($NewPageFileSize * 1000)
        [int]$InitialSize = ($NewPageFileSize * 1)
        [int]$MaximumSize = ($NewPageFileSize * 1.1)

        ### Create New Page File
        ### -------------------------------------------------------------------------------
        [scriptblock]$CreatePageFile =
        {
            if(-NOT(Get-CimInstance -ClassName Win32_PageFileSetting))
            {
                $PageFileName = $PageFileLocation + ":\pagefile.sys"
                Write-Host "Creating New Page File: PageFileLocation: $PageFileName InitialSize: $InitialSize MaximumSize: $MaximumSize " 
                New-CimInstance -ClassName Win32_PageFileSetting -Property  @{ Name= $PageFileName } | Out-Null
                Get-CimInstance -ClassName Win32_PageFileSetting | Set-CimInstance -Property @{InitialSize = $InitialSize; MaximumSize = $MaximumSize;} | Out-Null
                }
            else
            {
                Write-Host "PageFile Exists. Cant Configure!"
            }
        }

        ### Check Avilable Disk Space
        ### ---------------------------------
        $FreeSpace = (Get-PSDrive $PageFileLocation).Free

        #[int]$FreeSpace = $FreeSpace

        if($FreeSpace -gt $NewPageFileSize)
        {
            Write-Host "Free Space Available. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize"
            Invoke-Command -ScriptBlock $CreatePageFile
        }
        elseif($FreeSpace -le $NewPageFileSize)
        {
            Write-Host "Not Enough Avialable Space. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize `nNot Configuring!"
        }
        

    }
    
    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Join-Domain #<---- need to complete function!!!!!!!!!!!!!!!!!
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $DomainName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Import Credentials
        ### ----------------------------------------
        #$PSCrdentials = (Import-AESEncryptionKey)
        #Import-AESEncryptionKey

        $UserName = "GEEMONEYMGMT\ECIADMIN"
        $SecPasswd = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($UserName, $SecPasswd)

        Add-Computer -ComputerName $VM -DomainName $DomainName -Credential $PSCredentials -Force -Passthru -Verbose
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}











###################################################   DELETE

##############################
### | 
### | Orig 
### v
##############################
function Configure-NetworkInterface-orig
{
    Param(
    [Parameter(Mandatory = $False)] [string]$DesiredState,
    [Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report",
    [Parameter(Mandatory = $False)] [string]$AbortTrigger = "$False"
    )
    
    $Function = $((Get-PSCallStack)[0].Command); Write-ConfigReport `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Manually Overide Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False


    ### Manually Overide Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False
    $script:DesiredState = $NewInterfacename

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:ExistingInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-ConfigReport "Running in Configure Mode. Changing Configuration!"
                Rename-NetAdapter (Get-NetAdapter -Name $ExistingInterfaceName).Name -NewName $NewInterfaceName
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-ConfigReport "Running in Report Mode. Logging Data Only!"
                
            }
        }
        
        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
            if($ExistingInterfaceName -eq $NewInterfacename)
            {
                Write-ConfigReport "COMPARE: TRUE - The Current-Configuration is the same as the Desired-Configuration - ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
                Write-ConfigReport "Not Running Configuration!"
            }
            elseif ($ExistingInterfaceName -ne $NewInterfacename )
            {
                Write-ConfigReport "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
                Invoke-Command -ScriptBlock $ConfigureScriptBlock
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Compare Configuration
        ### -----------------------------------------------------------------------
        if($VerifyInterfaceName -eq $NewInterfacename)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyInterfaceName: $VerifyInterfaceName NewInterfacename: $NewInterfacename"
        }
        elseif($VerifyInterfaceName -ne $NewInterfacename)
        {
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                #Send-Alert
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY FAILURE! - Verified: $Verified Abort: $Abort VerifyInterfaceName: $VerifyInterfaceName NewInterfacename: $NewInterfacename"
            }
        }
        ###################################
        ### REPORT:
        ###################################

    }
    Try-Catch $ScriptBlock
}

function Configure-IPv6-orig
{
    Param([Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report")

    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    ### Modify Parameters
    ### --------------------------------------
    if     ($Ipv6Preference -eq "Enable") {$script:Ipv6Preference = $True}
    elseif ($Ipv6Preference -eq "Disable"){$script:Ipv6Preference = $False}
    else   {$script:Ipv6Preference  = $Null}

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            ### Get Current Interface
            $CurrentInterface     = Get-NetAdapter –Physical | Where-Object Status -eq 'Up'
            $script:CurrentInterfaceName = $CurrentInterface.Name
    
            ### Get IPv6 State
            $IPv6State   = Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
            $script:IPv6Enabled = $IPv6State.Enabled
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                if ($Ipv6Preference -eq $True)
                {
                    ### Enable IPv6
                    Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
                }
                elseif ($Ipv6Preference -eq $False)
                {
                    ### Disable IPv6
                    Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
                }
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
         }

        ###################################
        ### COMPARE:
        ###################################
        if ($IPv6Enabled -eq $Ipv6Preference)
        {
            Write-Config "COMPARE: TRUE  - The Current-Configuration is the same as the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
            Write-Config "Not Running Configuration!"
        }
        elseif ($IPv6Enabled -ne $Ipv6Preference)
        {
            Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
            Write-Config "Running Configuration!"
            Invoke-Command -ScriptBlock $ConfigureScriptBlock
        }
     
        ##########################
        ### VERIFY:
        ##########################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyIPv6Enabled = (Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)").Enabled
        }
        Invoke-Command $VerifyScriptBlock

        if ($VerifyIPv6Enabled -eq $Ipv6Preference)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified -VerifyIPv6Enabled: $VerifyIPv6Enabled -IPv6Preference: $Ipv6Preference"
        }
        elseif ($VerifyIPv6Enabled -ne $Ipv6Preference)
        {
            ### Verify Failure
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified Abort: $Abort Function: $Function `nExiting Script!"
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY ERROR! - VERIFIED: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
            }
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-IPv4-orig
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Cast the Parameters as IPAddress
        [IPAddress]$IPv4Address     = $IPv4Address.Trim()
        [IPAddress]$DefaultGateway  = $DefaultGateway.Trim()

        ### Get the Current NIC
        $CurrentInterface  = (Get-NetAdapter –Physical | where Status -eq 'Up').Name
        #write-host "CurrentInterface:" $CurrentInterface

        ### Determine if DHCP is Enabled or if IPv4 Address is Static
        $DhcpStatus = (Get-NetIPInterface -AddressFamily IPv4 -InterfaceAlias $CurrentInterface).DHCP
        #write-host "DhcpStatus:" $DhcpStatus            

        ### If DHCP is Enabled, Create New IPv4 Address, Else Set IPv4 Addres
        if ($DhcpStatus -eq "Enabled")
        {
            ### Set the IPv4 Settings
            Write-Config "`n`nSetting New IP Address and Default Gateway"
            #New-NetIPAddress $IPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $PrefixLength -DefaultGateway $DefaultGateway | Out-Null
        }
        elseif ($DhcpStatus -eq "Disabled")
        {
            Write-Config "`n`nAdding IP Address and Default Gateway"
            #Set-NetIPAddress
        }

<#
        ### Get the Current IP Address
        $CurrentIPAddress = (Get-NetIPAddress -InterfaceAlias $CurrentInterface -AddressFamily IPv4).IPv4Address

        ### Checking if the current IP Address is already the same if the New IP Address
        if($CurrentIPAddress -ne $NewIPv4Address) 
        {
            write-log "The New IP Address is Different - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow

            #$ISDHCPEnabled = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration  -Filter "IPEnabled=TRUE").DHCPEnabled

            # Remove the static ip
            #Remove-NetIPAddress -InterfaceAlias $CurrentInterface

            # Remove the default gateway
            #Remove-NetRoute -InterfaceAlias $CurrentInterface

            ### Change the IPv4 Settings
            write-log "`n`nSetting Adapter IP Address and Default Gateway"  -ForegroundColor Yellow
            New-NetIPAddress $NewIPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $NewPrefixLength -DefaultGateway $NewDefaultGateway | Out-Null

            ### Verify Settings
            $VerifyIP = (Get-NetIPAddress -InterfaceAlias $NewInterfaceName -AddressFamily IPv4).IPv4Address

            if($VerifyIP -eq $NewIPv4Address){Write-Log "IP Address set to this new value: " $VerifyIP}
            else {Write-Log "Mismatch - VerifyIP: $VerifyIP NewIPv4Address: $NewIPv4Address"}
        }
        elseif($CurrentIPAddress -eq $NewIPv4Address) 
        {
            ### Do nothing if the New iP Address is the same as the Existing IP Address 
            write-log "The IP Address is the Same - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow
        }
#>
    }

    Try-Catch $ScriptBlock
}

function Verify-IPv4
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
}

function Configure-WindowsFirewallProfile-orig
{
    Param([Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report")

    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:NetFirewallProfiles = Get-NetFirewallProfile -Name *
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                Set-NetFirewallProfile -Profile $NetFirewallProfileName -Enabled $WindowsFirewallPreference
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
        }
        
        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
            foreach($NetFirewallProfile in $NetFirewallProfiles)
            {
                $script:NetFirewallProfileName  = $NetFirewallProfile.name
                $NetFirewallProfileValue = $NetFirewallProfile.Enabled                                

                if ($NetFirewallProfileValue -eq $WindowsFirewallPreference)
                {
                   Write-Config "COMPARE: TRUE  - The Current-Configuration is the same as the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
                   Write-Config "Not Running Configuration!"
                }
                if ($NetFirewallProfileValue -ne $WindowsFirewallPreference)
                {
                    Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
                    Write-Config "Running Configuration!"
                    Invoke-Command -ScriptBlock $ConfigureScriptBlock
                }
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyNetFirewallProfiles = Get-NetFirewallProfile -Name *
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Configuration
        ### -----------------------------------------------------------------------
        foreach ($VerifyNetFirewallProfile in $VerifyNetFirewallProfiles)
        {
            $VerifyNetFirewallProfile = $VerifyNetFirewallProfile.Enabled
            
            if($VerifyNetFirewallProfile -eq $WindowsFirewallPreference)
            {
                ### Verify Success
                $global:Verified = $True
                $global:Abort    = $False
                Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyNetFirewallProfile: $VerifyNetFirewallProfile WindowesFireWallProfileValue: $WindowesFireWallProfileValue"
            }
            elseif($VerifyNetFirewallProfile -ne $WindowsFirewallPreference)
            {
                ### Verify Failure
                $global:Verified = $False
                if ($AbortTrigger -eq $True)
                {
                    ### Abort Failure
                    $global:Abort -eq $True
                    Write-Config "ABORT ERROR! - Verified: $Verified Abort: $Abort Function: $Function `nExiting Script!"
                    Exit
                }
                else
                {
                    ### Verify Error
                    $global:Abort -eq $False
                    Write-Config "VERIFY ERROR! - VERIFIED: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                }
            }
  
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-WindowsFirewallRules-orig
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
}

function Configure-CDROM-orig
{
    $Function = $((Get-PSCallStack)[0].Command)

    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    ### Modify Parameters
    ### --------------------------------------
    ### Drive Letter Must End with Colon ":"
    $LastChar = $NewCDLetter.substring($NewCDLetter.length-1) 
    if ($LastChar -ne ":"){$NewCDLetter = $NewCDLetter + ":"}

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:CurrentCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive
        }
        Invoke-Command $CurrentConfiguration


        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $env:computername -Filter "DriveLetter='$CurrentCDLetter'" -ErrorAction Stop 
                Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter=$NewCDLetter} | Out-Null
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
        }

        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
        write-host "CurrentCDLetter: " $CurrentCDLetter
        write-host "NewCDLetter: " $NewCDLetter

            if($CurrentCDLetter -eq $NewCDLetter)
            {
                Write-Config "COMPARE: TRUE - The Current-Configuration is the same as the Desired-Configuration - CurrentCDLetter: $CurrentCDLetter NewCDLetter: $NewCDLetter"
                Write-Config "Not Running Configuration!"
            }
            elseif ($ExistingInterfaceName -ne $NewInterfacename )
            {
                Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - CurrentCDLetter: $CurrentCDLetter NewCDLetter: $NewCDLetter"
                Write-Config "Running Configuration!"
                Invoke-Command -ScriptBlock $ConfigureScriptBlock
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Compare Configuration
        ### -----------------------------------------------------------------------
        if($VerifyCDLetter -eq $NewCDLetter)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyCDLetter: $VerifyCDLetter NewCDLetter: $NewCDLetter"
        }
        elseif($VerifyCDLetter -ne $NewCDLetter)
        {
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                #Send-Alert
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY FAILURE! - Verified: $Verified Abort: $Abort VerifyCDLetter: $VerifyCDLetter NewCDLetter: $NewCDLetter"
            }
        }

    }
    Try-Catch $ScriptBlock
}


###############################################
#^ New Functions
#|
#|
#v Old Functions - Need to re-write using Configure-DesiredState
###############################################

function Get-ServerBuildType-old #rename Get-ServerConfigurationDefinition
{

    Param(
    [Parameter(Mandatory = $True)] [string]$ServerRole
    #[Parameter
     )
    Write-Host `n("=" * 50)"`nSERVER BUILD TEMPLATE: `nServerRole:" $ServerRole`n("=" * 50)

    ### Set Parameters for ALL Server Build Types
    $global:BuildDate = Get-Date -Format g

    ### Set Parameters for Server Build Types

    Switch ($ServerRole)
    {
         ### Windows Server 2016 Builds
         ###-----------------------------------

         2016Server 
         {


<#
            ### Server Template "Hard" Parameters
            ### -----------------------------------------
            $vCPU = "2"
            $Memory = "4"
            $OSVolume = "50"
            $PageFileVolume = "10"
            $DataVolume = $Null
            $LogSettingsEvent = $Null 
            $Sys = $Null


$arr=@{}
$arr["Template"] = @{}
$arr["Template"]["TSHIRTS"] = @{}    
$arr["Template"]["TSHIRTS"]["SIZE"] ="M"
$arr.Template.tshirts.size
#>

            ### Server Template "Hard" Parameters
            ### -----------------------------------------
            $Parameters = [ordered]@{
                NewInterfacename            = "Ethernet1"
                NewLocalAdminName           = "ECIAdmin"
                NewCDLetter                 = "R:"
                Ipv6Preference              = "Enable"
                WindowesFireWallProfile     = "Disable"
                AutomaticReboot             = "Disable"
                RemoteDesktopPreference     = "Enable"
                RDPResitrctSessions         = "Disable"
                PageFileLabel               = "SWAP\KITS"
                PageFileSize                = "1.2"
                PageFileLocation            = "D:\"
                InternetExplorerESC         = "Disable"
            }

            $global:HardParameters = @()
            Write-Host "`nImporting *HARD* Parameters from Server Build Template:`n" ("-" * 50)
            foreach($Parameter in $Parameters.GetEnumerator())
            {
                Write-Host "$($Parameter.Name): $($Parameter.Value)"

                # Create Variables and Set Variable Scope to "Global"
                Set-Variable -Name $($Parameter.Name) -Value $($Parameter.Value) -Scope Global
                $global:HardParameters += Get-Variable -Name $($Parameter.Name)
            }
            
            Write-Host "`nVERIFY: *Hard* Parameters from Server Build Template :"`n("-" * 50)
            $HardParameters | FT
            <#
            Write-Host "NewInterfacename            : " $NewInterfacename
            Write-Host "NewLocalAdminName           : " $NewLocalAdminName
            Write-Host "NewCDLetter                 : " $NewCDLetter
            Write-Host "Ipv6Preference              : " $Ipv6Preference
            Write-Host "WindowesFireWallProfile     : " $WindowesFireWallProfile
            Write-Host "AutomaticReboot             : " $AutomaticReboot
            Write-Host "RemoteDesktopPreference     : " $RemoteDesktopPreference
            Write-Host "RDPResitrctSessions         : " $RDPResitrctSessions
            Write-Host "PageFileLabel               : " $PageFileLabel
            Write-Host "PageFileLocation            : " $PageFileLocation
            #>

            ### Windows Features
            ### -----------------------------------------
            $WindowsFeatures  = @()
            $WindowsFeatures += "NET-Framework-Features"
            $WindowsFeatures += "NET-Framework-Core"
            $WindowsFeatures += "GPMC"
            $WindowsFeatures += "Telnet-Client"
            #$WindowsFeatures += "RSAT"
            $global:WindowsFeatures = $WindowsFeatures
         
            # Server Build Functions
            #--------------------------
            
            if ($Step -eq "xyz")
            {
                #Do-Something1
                #Rename-Computer
                #Set-RegKey
                #Pause-Script
                #Reboot-Resume
                #Update-Windows
            }

            if ($Step -eq "xyz")
            {
                #Do-Something2
                Invoke-Test
                
                #Pause-Script
                #Verify-ComputerRename
                #Rename-Interface
                #Set-IPv4
                #Set-IPv6
                #Set-SwapFile
                #Add-WindowsFeatures
                #Update-Windows
                #Set-WindowsFirewall
                #Add-WindowsFeatures
                #Rename-LocalAdministrator
                #Join-Domain

                #Disable-AutomaticReboot
                #Create-KitsFolder
                #Create-ScriptsFolder
                #Enable-RemoteDesktop
                #Disable-InternetExplorerESC 

                ### Optional
                #Screen Resolution to 1024 x 768    
                #Set-TimeZone

            }
           
            if ($Step -eq "xyz")
            {
                #Set-RegKey
                #Reboot-Resume
                #Continue
            }
               
        }

         2016DC{}

         2016File{}
            
         2016Citrix{}

    }
}

function Configure-ECIFolders-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    
    $ScriptBlock = 
    {
        ### Create ECI Folders
        ###--------------------------------        
        $ECIFolders = @()
        $ECIFolders += "C:\Scripts"
        $ECIFolders += "D:\Kits"

        foreach ($Folder in $ECIFolders)
        {
            if(-NOT(Test-Path -Path $Folder)) {(New-Item -ItemType Directory -Path $Folder -Force | Out-Null);Write-Host "Creating Folder: " $Folder }
        }
        ### Verify

        foreach ($Folder in $ECIFolders)
        {
            if(Test-Path $Folder){Write-Config "VERIFY SUCCEDED: $Folder"}
            elseif(-NOT(Test-Path $Folder)){Write-Config "VERIFY FAILED: $Folder"}
        }        
    }
    Try-Catch $ScriptBlock

    ### Copy Media

}

function Configure-PageFile-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Configure-RemoteDeskto-oldp
{
    ### Configure Remote Desktop Preference: RDP
    ### ------------------------------------------------------------ 

    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    
    if($RemoteDesktopPreference -eq "Disable")
    {
        $RemoteDesktopPreferenceValue = "1"
    }
    elseif($RemoteDesktopPreference -eq "Enable")
    {
        $RemoteDesktopPreferenceValue = "0"
    }

    $ScriptBlock = 
    {
        ### Enable Remote Desktop
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections" -Value $RemoteDesktopPreferenceValue
        Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    $VerifyValue = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections").fDenyTSConnections
    if($VerifyValue -eq $RemoteDesktopPreferenceValue){Write-Config "VERIFY SUCCESS: VerifyValue: $VerifyValue RemoteDesktopPreference: $RemoteDesktopPreference"}
    elseif($VerifyValue -ne $RemoteDesktopPreferenceValue){Write-Config "VERIFY FAILURE: VerifyValue: $VerifyValue RemoteDesktopPreference: $RemoteDesktopPreference"}

    ### Configure “Restrict each user to a single session”
    #
    #This policy setting appears in both Computer Configuration and User Configuration. 
    #If both policy settings are configured, the Computer Configuration policy setting takes precedence.
    #
    #


}

function Configure-InternetExplorerESC-old
{
    ### Configure Internet Explorer Enhanced Security Configuration
    ### -------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    if($InternetExplorerESC -eq "Disable")
    {
        $InternetExplorerESCValue = "0"
    }
    elseif($InternetExplorerESC -eq "Enable")
    {
        $InternetExplorerESCValue = "1"
    }
    
    $ScriptBlock = {                
        $script:AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $script:UserKey  = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
        Set-ItemProperty -Path $UserKey  -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
        
        # Needed???
        #Stop-Process -Name Explorer
    }

    Try-Catch $ScriptBlock
    
    ### Verify Configuration
    $VerifyAdminKey = (Get-ItemProperty -Path $AdminKey -Name "IsInstalled").IsInstalled
    $VerifyUserKey  = (Get-ItemProperty -Path $UserKey  -Name "IsInstalled").IsInstalled
    
    if (($VerifyAdminKey -eq $InternetExplorerESCValue) -AND ($VerifyUserKey -eq $InternetExplorerESCValue))
    {Write-Config "VERIFY SUCCEDED: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

    elseif (($VerifyAdminKey -ne $InternetExplorerESCValue) -OR ($VerifyUserKey -ne $InternetExplorerESCValue))
    {Write-Config "VERIFY FAILURE: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

}

function Configure-PageFile-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate New Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Configure-WindowsFeatures-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    ### Windows Features
    ### -----------------------------------------
    $WindowsFeatures  = @()
    $WindowsFeatures += "NET-Framework-Features"
    $WindowsFeatures += "NET-Framework-Core"
    $WindowsFeatures += "GPMC"
    $WindowsFeatures += "Telnet-Client"
    #$WindowsFeatures += "RSAT"
    $global:WindowsFeatures = $WindowsFeatures

    $ScriptBlock = 
    {
        ### List Features to Install
        Write-Config "The following Features will be installed:"
        foreach ($Feature in $WindowsFeatures)
        {
            Write-Config $Feature
        }

        ### Instal Features
        foreach ($Feature in $WindowsFeatures)
        {
            Install-WindowsFeature -name $Feature
        } 
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    foreach ($Feature in $WindowsFeatures)
    {
        $Feature = Get-WindowsFeature -name $Feature 
        if($Feature.Installed -eq "True") {Write-Config "VERIFY SUCCEDED: " $Feature.Name "`tInstalled: " $Feature.Installed}
        if($Feature.Installed -ne "True") {Write-Config "VERIFY FAILED: " $Feature.Name "`tInstalled: " $Feature.Installed}
    }
}

function Resume-Configure-WindowsFeatures-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        foreach ($Feature in $WindowsFeatures)
        {
            $Feature = Get-WindowsFeature -ComputerName $VM -Name $Feature
            
            If($Feature.Installed -eq "Installed") {Write-Config "VERIFY SUCCEDED: " $Feature.Name "`tInstalled: " $Feature.Installed}
            Else {Write-Config "VERIFY FAILED: " $Feature.Name "`tInstalled: " $Feature.Installed}
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-WindowsUpdates-old
{
    function Get-AUSettings
    {
        $AUObj = @()
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
        $AUSettings.NotificationLevel
        $AUSettings.ReadOnly
        $AUSettings.Required
        $AUSettings.ScheduledInstallationDay
        $AUSettings.ScheduledInstallationTime
        $AUSettings.IncludeRecommendedUpdates
        $AUSettings.NonAdministratorsElevated
        $AUSettings.FeaturedUpdatesEnabled
    }

    function Get-WindowsUpdateConfig
    {
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings

        $AUObj = New-Object -TypeName System.Object
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "NotificationLevel" -Value $AutoUpdateNotificationLevels[$AUSettings.NotificationLevel]
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateDays" -Value $AutoUpdateDays[$AUSettings.ScheduledInstallationDay]
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateHour" -Value $AUSettings.ScheduledInstallationTime
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "Recommended updates" -Value $(IF ($AUSettings.IncludeRecommendedUpdates) {"Included."}  else {"Excluded."})

        $AuObj
    } 

    function Set-WindowsUpdateConfig
    {
        Param ($NotificationLevel , $Day, $hour, $IncludeRecommended)
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
        if ($NotificationLevel)  {$AUSettings.NotificationLevel         = $NotificationLevel}
        if ($Day)                {$AUSettings.ScheduledInstallationDay  = $Day}
        if ($hour)               {$AUSettings.ScheduledInstallationTime = $hour}
        if ($IncludeRecommended) {$AUSettings.IncludeRecommendedUpdates = $IncludeRecommended}
        $AUSettings.Save
    } 
}

function Install-WindowsUpdates-old
{
    $ScriptBlock = {
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }

        Get-WUInstall  -IgnoreReboot 
        Get-WUInstall -ListOnly | FT Title, KB #, ComputerName, Size  
    }
    Try-Catch $ScriptBlock

}
    
function Rename-LocalAdministrator-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal

        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name

        ### Check if Local Admin is already renamed
        if($CurrentAdminName -eq $NewLocalAdminName)
        {
            Write-Config "Local Admin Names are the same -  CurrentAdminName: $CurrentAdminName NewAdminName: $NewLocalAdminName"
            $RebootRequired = $False
        }
        elseif($CurrentAdminName -ne $NewLocalAdminName)
        {
            $RebootRequired = $True
            Write-Config "Renaming Local Admin Account: Current Admin: $CurrentAdminName New Admin: $NewLocalAdminName"
            #Rename-LocalUser -Name $CurrentAdminName -NewName $NewLocalAdminName -ErrorAction SilentlyContinue | Out-Null
        }
    }
    Try-Catch $ScriptBlock
}

function Resume-Rename-LocalAdministrator-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal
        
        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name
        wRITE-hOST "CurrentAdminName:" $CurrentAdminName
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    ### --------------------------------------------------
    if($CurrentAdminName -eq $NewLocalAdminName) 
    {
        Write-Config "VERIFY SUCCEDED - CurrentAdminName: $CurrentAdminName NewLocalAdminName: $NewLocalAdminName"
        $VerifyFailure  = $False
        $RebootRequired = $False
    }
    elseif($CurrentAdminName -ne $NewLocalAdminName)
    {
        Write-Config "VERIFY FAILED - CurrentAdminName: $CurrentAdminName NewLocalAdminName: $NewLocalAdminName"
        $VerifyFailure = $True
    }
}

function Rename-GuestComputer-old
{
    ### Rename the Computer
    ### ----------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $CurrentComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
    Write-Host "CurrentComputerName: " $CurrentComputerName
    Write-Host "VMGuestComputerName: " $GuestComputerName

    ### Import Credentials
    ### ----------------------------------------
    #$PSCrdentials = (Import-AESEncryptionKey)
    #Import-AESEncryptionKey

    $SecPasswd = ConvertTo-SecureString "cH3r0k33" -AsPlainText -Force
    $PSCredentials =  New-Object System.Management.Automation.PSCredential ("Administrator", $SecPasswd)

    $ScriptBlock =
    {
        if($CurrentComputerName -ne $GuestComputerName)
        {
            ### Rename Computer
            write-log "Renaming Local Computer - NewName: $GuestComputerName"
            Rename-Computer –ComputerName  $CurrentComputerName –NewName $GuestComputerName -Force -LocalCredential $PSCredentials  #-PassThru
        }
        elseif($CurrentComputerName -eq $GuestComputerName)
        {
            ### Names are the Same
            write-log "Computer Names are the same - CurrentComputerName: $CurrentComputerName GuestComputerName: $GuestComputerName `nNot Renaming."
        }
    }
    Try-Catch $ScriptBlock
}

function Resume-Rename-GuestComputer-old
{
    ### Resume Rename-Computer After Reboot
    ### ----------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
        
    ### Verify Configuration
    $VerifyComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
    if ($VerifyComputerName -eq $GuestComputerName) {Write-Config "VERIFY SUCCEDED: VerifyComputerName: $VerifyComputerName GuestComputerName: $GuestComputerName"}
    elseif($VerifyComputerName -ne $GuestComputerName) { Write-Config "VERIFY FAILED: VerifyComputerName: $VerifyComputerName NewComputerName: $GuestComputerName"}

}

function Join-Domain-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    <#
    ### Generate Credentials
    ### ---------------------------------
    $UserName = "ecilab-bosdev01\cbrennan_admin"
    $PasswordFile = "c:\Scripts\password.txt"
    $Password ="01000000d08c9ddf0115d1118c7a00c04fc297eb010000000ada8d4ffc858d479f28124bff339f9a000000000200000000001066000000010000200000003c54ad13b08dfcd81ce6685c230c87208f97b585dec28dfb206c6c24d9b9e41d000000000e80000000020000200000004cd87e40bd5a96af906430a54909ec1b6468d1213f2ff08fd4d439dbbd0e7be120000000154f0ce9aef1faea4984397fc9f6066a6e955aeab72b58f6971230b46b539bdf400000001230e9f850ecc30c33204a8ec5fd98c6587a9e9e575662b0eb8da8d11cee6d21b05ddfcc16b6f67805e6a48ca2e60d190992bf62d4c073a3981450167905d703"

    ### Run this Command Manually to Create Password File
    ##############################################################
    ### Read-Host "Enter Password To Be Encrypted" -AsSecureString | ConvertFrom-SecureString | Out-File $PasswordFile
    ### You have to create the password string on the same computer and with the same login that you will use to run it.
    ##############################################################

    $PSCredentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, ($Password | ConvertTo-SecureString)
    #>


    ### Import Credentials
    ### ----------------------------------------
    #$PSCrdentials = (Import-AESEncryptionKey)
    #Import-AESEncryptionKey


    $ScriptBlock = 
    {
        $UserName = "GEEMONEYMGMT\ECIADMIN"
        $SecPasswd = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($UserName, $SecPasswd)

        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain

        If (-NOT(($CurrentDomain.Split(".")) -Contains $DomainName))
        {
            Write-Config "Joining Computer $VM to Domain - DomainName: $DomainName "
            Add-Computer -ComputerName $VM -DomainName $DomainName -Credential $PSCredentials -Force -Passthru -Verbose
        }

        Elseif (($CurrentDomain.Split(".")) -Contains $DomainName)
        {
            Write-Config "Computer $VM is already a Domain Member - DomainName: $DomainName "
        }
    }

    Try-Catch $ScriptBlock
    
    $RebootPending = $False
    if (!$?){$RebootPending = $True}

}

function Resume-Join-Domain-old
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = {
        
        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
        
        If (($CurrentDomain.Split(".")) -Contains $DomainName) {Write-Config "VERIFY SUCCESS - DomainName $DomainName CurrentDomain: $CurrentDomain"}
        Else {Write-Config "VERIFY FAILURE - DomainName $DomainName CurrentDomain: $CurrentDomain"}
    }
    
    Try-Catch $ScriptBlock
}

function Function-Template-old
{
    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config "Executing Function: $Function `n " ('-' * 50)

    $ParameterValue = $ParameterValue
    $AbortTrigger = 0

    #############################################
    ### Set Configuration
    #############################################
    function Set-Configuration
    {
        $ScriptBlock = 
        {
            Set-Something -Name $Name -Value $Value
        }

        Try-Catch $ScriptBlock
    }
    
    #############################################
    ### Get Current Configuration
    #############################################
    $CurrentValue = Set-Something -Name $Name -Value $Value

    if ($CurrentValue -ne $ParameterValue)
    {
        Write-Config "Values are the Different. Configuring: CurrentValue: $CurrentValue ParameterValue: $ParameterValue"
        Set-Configuration
    }
    elseif ($CurrentValue -eq $ParameterValue)
    {
        Write-Config "Values are the Same. Not Configuring: CurrentValue: $CurrentValue ParameterValue: $ParameterValue"
    }
    else
    {
        Write-Config "Values cant be identified. Aborting!"
        $Abort = $True
    }

    #############################################
    ### Verify Configuration
    #############################################
    $VerifyValue = Get-Something -Name $Name -Value $Value

    if ($VerifyValue -eq $ParameterValue)
    {
        $Verified = $True
        $Abortvalue = $False

        Write-Config "VERIFED: $Verifed $VerifyValue ParameterValue: $ParameterValue"
    }
    else 
    {
        $Verified = $False
        if($AbortTrigger = 1){$Abortvalue = $True}
        
        Write-Config "VERIFED: $Verifed $VerifyValue ParameterValue: $ParameterValue"
        Write-Cookie $VM $Function $Verified $AbortValue
    }
}

function Configure-GuestVMDebuging-old
{
    Param([Parameter(Mandatory = $True,  Position = 0)] [string]$Mode = "Enable")

    $global:VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools\Tools.conf"

    function Create-VMToolsConfigFile    {        ### Create Log Folder        $DebugLogPath = "C:\Temp\VMTools"        if(-NOT(Test-Path -Path $DebugLogPath)) {New-Item -ItemType directory -Path $DebugLogPath | out-null}        ### Create VM Tools Guest Config File        $TextBlock = {
        [logging]        log = true        vmtoolsd.level = debug        vmtoolsd.handler = file
        vmtoolsd.data = c:/temp/vmtoolsd.log        }        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}

        #$TextBlock | 
        #$TextBlock | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII #UTF8 #ASCII #String #Unicode
        #Set-Content -Value $TextBlock -Path $VMGuestConfigFile #-Force


        # Hard Code & Copy Conf File - Until above gets fixed!
        $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\Tools.conf"
        $VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools"

        #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
        Copy-Item -Path $Src -Destination $VMGuestConfigFile -Force

    }

    if($Mode -eq "Enable")    {        Write-Host "Enabling Debug Logging a Guest VM"        Create-VMToolsConfigFile    }    elseif($Mode -eq "Disable")    {        Write-Host "Disbling Debug Logging a Guest VM"        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}            }}

##################################################################################################################
##################################################################################################################
##################################################################################################################
# Junk?

function Dev-Update-Windows-junk?
{
    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[-1].Command) `n('-' * 50)
### Windows Server 2016 Update settings
<#
– 2 = Notify before download.
– 3 = Automatically download and notify of installation.
– 4 = Automatically download and schedule installation. Only valid if values exist for ScheduledInstallDay and ScheduledInstallTime.
– 5 = Automatic Updates is required and users can configure it.
#>
#HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

$WindowsUpdateAU = HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

Set-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU -Name AUOptions -Value 3

        
        write-host "PSVersion: " $PSVersionTable.PSVersion
        <#
        if ($PSVersionTable.PSVersion -gt "5")
        {
            write-host "PSVersion: " $PSVersionTable.PSVersion
        }
        #>
        
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
                
        if ($PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate is already loaded." -ForegroundColor Green

        }

        write-host "PSWindowsUpdateModuleisLoaded: " $PSWindowsUpdateModuleisLoaded

        <#
        ### Get Microsoft Updates
        ### -----------------------------------
        $UpdateSession = new-object -com "Microsoft.Update.Session"
        $Criteria="IsInstalled=0 and IsHidden=0"
        $Updates=$UpdateSession.CreateupdateSearcher().Search($Criteria).Updates
        $Updates | Format-Table -property Title
        #>

        <#
        ### Get WSUSUpdates
        ### -----------------------------------
        $UpdateServer = "BLU-MGMT01.ecilab.net"
        
        Get-WSUSServer -Name "10.70.0.8" -Port 8530 
        Get-WSUSServer -Name "BLU-MGMT01.ecilab.net" -Port 8530

        Get-WsusUpdate -UpdateServer "BLU-MGMT01.ecilab.net"
         Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        #Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        
        #https://blogs.technet.microsoft.com/heyscriptingguy/2012/01/19/use-powershell-to-find-missing-updates-on-wsus-client-computers/
        #>


        <#
        $WindowsUpdateModuleisAvailable = (Get-Module -ListAvailable WindowsUpdate)
        if ($WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module is available" -ForegroundColor Green
            #Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            #Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
        if (!$WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module not available" -ForegroundColor Red
        }
        #>

    }
    
    Try-Catch $ScriptBlock
}

function Set-FirewallRules-junk?
{
    $ScriptBlock = 
    {
        $Parameters = @{
            DisplayName = "Allow RDP from 10.0.0.0/24"
            LocalPort = 3390
            Direction="Inbound"
            Protocol ="TCP" 
            Action = "Allow"
                
            # Get the Remote Address from the $ParamaterFile
            RemoteAddress = $AllowRDPSubnet
        }

        ## Checking if the Rule Exists
        write-host "Checking if rule exists: " $Parameters.DisplayName
        $Rules = Get-NetFirewallRule -DisplayName *
            
        if (-not $Rules.DisplayName.Contains($Parameters.DisplayName)) 
        {
            ### Create New Firewall Rule
            Write-Log "This rule Does not exist. Creating New Firewall Rule"
            New-NetFirewallRule -DisplayName $Parameters.DisplayName -Action $Parameters.Action -Direction $Parameters.Direction `
            –LocalPort $Parameters.LocalPort -Protocol $Parameters.Protocol -RemoteAddress $Parameters.RemoteAddress| Out-Null
        }
        else
        {
            write-host "This rule already exists. Not Creating"
        }

        ### Show the Firewall Settings
        write-log "Checking the Firewall Settings"
        $FirewallRule = Get-NetFirewallRule -DisplayName $Parameters.DisplayName
        write-host "DisplayName: " $FirewallRule.DisplayName "Action: " $FirewallRule.Action "Enabled: " $FirewallRule.Enabled
    }
    Try-Catch $ScriptBlock
}

function OldRename-LocalAdministrator
{

    $ScriptBlock = 
    {

        function Get-CurrentAdmin
        {
            ### Find the Current Local Administrator Account
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
            $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
            $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
            $Searcher.QueryFilter = $UserPrincipal

            ### The Administrator account is the only account that has a SID that ends with “-500”
            $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
            $script:CurrentAdminName = $Account.Name
            Write-Log "The current Local Administrator Account is: $CurrentAdminName"
        }

        function Rename-Admin
        {
            ### Get the Current Local Admin Account
            $User= Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | Where {$_.Name -eq $CurrentAdminName}

            ### Rename the Current Local Admin Account
            write-host "Renaming $CurrentAdminName to $NewAdminName "
            $user.Rename($NewAdminName) | Out-Null
        }

        function Check-CurrentAdmin
        {
            ### Check if Local Admin is already renamed

            if($CurrentAdminName -eq $NewAdminName)
            {
                write-host "CurrentAdminName is the same as NewAdminName"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
            }
            elseif($CurrentAdminName -ne $NewAdminName)
            {
                write-host "Renaming Local Admin Account"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
                Rename-Admin
            }
        }

        function Verify-NewAdmin
        {
            write-host "Verifying new Admin Account Name"
            Get-CurrentAdmin
        }

        Get-CurrentAdmin
        Check-CurrentAdmin
        Verify-NewAdmin

    }

    Try-Catch $ScriptBlock
}

function Test-VMGuestConnection-junk?
{
    Write-Host "Getting Guest Data:" -ForegroundColor Cyan
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestComputerName = $env:COMPUTERNAME
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Log "GuestComputerName : " $env:COMPUTERNAME
    Write-Log "GuestOSVer        : " $GuestOSVer 
    Write-Log "GuestIPv4Addr     : " $GuestIPv4Addr
}

function CopyFile-ToGuestVM-junk?
{
    # Hard Code & Copy Conf File - Until above gets fixed!
    $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\tools.conf"
    $Dest = "C:\ProgramData\VMware\VMware Tools"

    #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
    Write-Host "Copying File: SRC: $Src DEST: $Dest"
    Copy-Item -Path $Src -Destination $Dest -Force

}

function Get-VMToolsStatus-junk?
{

    Restart-VM -VM $dbvm2 -Confirm :$false
    Sleep 10
    while (((get-vm $dbvm2 ).ExtensionData.Guest.ToolsRunningStatus ) -ne "guestToolsRunning" ) {
    Write-Host "....." -ForegroundColor Yellow
    Sleep 5
    }
 
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    while ( $? -eq $false ) {
    Get-Date -Format HH :mm :ss
    sleep 2
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    }
}

function Restart-VMGuestService-junk?
{
    write-host "VMTools Status: " (Get-Service -Name VMTools).Status

    ### Restart the VMTools Service
    if((Get-Service -Name VMTools).Status -eq "Running")
    {
        Write-Host "Re-Starting VMTools:"
        Get-Service -Name VMTools | Restart-Service -Force
        Wait-Tools -VM $VM -TimeoutSeconds 60
    }
    else
    {
        Write-Host "Starting VMTools:"
        #Get-Service -Name VMTools | Start-Service -Name VMTools
    }
}


function Start-ConfigReport-junk?
{
    $script:ConfigReportFile = $ReportPath + "\ConfigReport_" + $ScriptName + "_" + $TimeStamp + ".log"

    ### Write Config Report Header
    Write-Config "Server Configuration Report:"
    Write-Config  ('-' * 50) 
    $ConfigReport = @()
    $ReportHeader = @{
        New_Server_Name = $NewServerName
        Build_Date = (Get-Date)
        New_Domain = $NewDomain
        Target_Server = $env:COMPUTERNAME
        Target_Domain = $env:USERDNSDOMAIN
    }

    $PSObject      = New-Object PSObject -Property $ReportHeader
    $ConfigReport += $PSObject 
    $ConfigReport | Format-List
    $ConfigReport | Format-List | Out-File  -filepath $ConfigReportFile -append 
    
    ### Write Input Parameters
    Write-Config "Input Parameters:"
    Write-Config  ('-' * 50) 

    $Params = @()
    foreach ($Parameter in $Parameters)
    {
        $NewParams = [ordered]@{
        NewParameter = $Parameter.NewParameter
        NewValue     = $Parameter.NewValue
        }

        ### Build Parameter Report Header
        $PSObject      = New-Object PSObject -Property $NewParams
        $Params       += $PSObject 
    }  
    $Params | Format-Table -AutoSize
    $Params | Format-Table -AutoSize | Out-File  -filepath $ConfigReportFile -append 
}

function Import-Parameters-junk?
{
    $ScriptBlock = 
    {
        ### Hard Code the Parameter File
        $ParameterFile = "Parameters.csv"

        ### Set Parameter File Path 
        $ParametersFilePath =  $ScriptPath + "\" + $ParameterFile

        ### Check if Parameter File Exits
        write-log "Checking for Parameter File: $ParameterFile"

        if(-not (Test-Path $ParametersFilePath))
        {
            write-log "Parameter File Missing: $ParameterFile" -Foregroundcolor Red
            write-log "Exiting Script!" -Foregroundcolor Red
            Exit
        }
        else
        {
            write-log "Parameter File Exists. Importing: $ParameterFile" -Foregroundcolor Green
        }

        ###########################
        ### Initialize Parameters
        ###########################

        ### Import from CSV file
        $script:Parameters = Import-CSV -path $ParametersFilePath 

        foreach ($Parameter in $Parameters)
        {
            # Set Variable Scope to "Script" for Functions
            Set-Variable -Name $Parameter.NewParameter -Value $Parameter.NewValue -scope global
                
            # Verify Variables
            $Verify = Get-Variable -Name $Parameter.NewParameter
            #$Parameter.NewParameter
            #$Parameter.NewValue
        }            
    }

    Try-Catch $ScriptBlock
}

####################################