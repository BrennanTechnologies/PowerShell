﻿cls

function Get-ECIParameters
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$SQLTable,
        [Parameter(Mandatory = $True)] [string]$Select,
        [Parameter(Mandatory = $True)] [string]$Where,
        [Parameter(Mandatory = $True)] [string]$Filter
    )

    if(!(Get-Module -Name SqlServer)){Write-Host "Importing Module: SQLServer";Import-Module SqlServer}

    ### Set the Database Location
    $SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    Set-Location $SQLServer

    ### Execute the SQL Query and return the Columns
    $SQLQuery = "Select $Select from $SQLTable WHERE $Where = '$Filter'"
    $SQLResults = Invoke-Sqlcmd -Query $SQLQuery  -Database $SQLDatabase
    $Columns = $SQLResults | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name} | Sort-Object -Property Name

    ### Create the Variables from each Column in the Table
    $global:Parameters = @()
    foreach($Column in $Columns)
    {
        Set-Variable -Name $Column -Value $SQLResults.$Column -Scope global
        $Parameters += Get-Variable -Name $Column 
    }
    Write-Host "Getting Paramter Set: " $ParameterSet -foregroundcolor yellow
    $Parameters | FT
}

### Get Server Request
$ParameterSet = "ServerRequest"
$SQLTable = "ServerRequest"
$Select = "*"
$Where = "RequestID"
$Filter = "4"
Get-ECIParameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter

### Get OS Parameters
$ParameterSet = "OSParameters"
$SQLTable = "configOSParameters"
$Select = "*"
$Where = "ServerTemplate"
$Filter = "2016Server"
Get-Parameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter

### Get VM Parameters
$ParameterSet = "VMParameters"
$SQLTable = "configVMParameters"
$Select = "*"
$Where = "ServerTemplate"
$Filter = "2016Server"
Get-Parameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter



Write-Host "HostName: " $HostName -ForegroundColor Magenta
Write-Host "CDROMLetter: " $CDROMLetter -ForegroundColor Magenta
Write-Host "vCPU: " $vCPU -ForegroundColor Magenta





### Server Request
### --------------------------
Write-Host "VM Parameters: " -ForegroundColor Yellow
Write-Host "RequestID: " $RequestID -ForegroundColor Gray
Write-Host "RequestDateTime: " $RequestDateTime -ForegroundColor Gray
Write-Host "ServerTemplate: " $ServerTemplate -ForegroundColor Gray
Write-Host "GPID: " $GPID -ForegroundColor Gray
Write-Host "HostName: " $HostName -ForegroundColor Gray
Write-Host "IPv4Address: " $IPv4Address -ForegroundColor Gray
Write-Host "SubnetMask: " $SubnetMask -ForegroundColor Gray
Write-Host "PrimaryDNS: " $PrimaryDNS -ForegroundColor Gray
Write-Host "SecondaryDNS: " $SecondaryDNS -ForegroundColor Gray
Write-Host "Gateway: " $Gateway -ForegroundColor Gray
Write-Host "InstanceLocation: " $InstanceLocation -ForegroundColor Gray
Write-Host "DomainCredentials: " $DomainCredentials -ForegroundColor Gray
Write-Host "Backup: " $Backup -ForegroundColor Gray
Write-Host "DR: " $DR -ForegroundColor Gray


### VM Parameters
### --------------------------
Write-Host "VM Parameters: " -ForegroundColor Yellow
Write-Host "ServerTemplate: " $ServerTemplate -ForegroundColor Gray
Write-Host "vCPU: " $vCPU -ForegroundColor Gray
Write-Host "vMem: " $vMem -ForegroundColor Gray
Write-Host "OSVolumeSize: " $OSVolumeSize -ForegroundColor Gray
Write-Host "SwapVolumeSize: " $SwapVolumeSize -ForegroundColor Gray
Write-Host "DataVolumeSize: " $DataVolumeSize -ForegroundColor Gray
Write-Host "SysVolumeSize: " $SysVolumeSize -ForegroundColor Gray
Write-Host "LogVolumeSize: " $LogVolumeSize -ForegroundColor Gray


### OS Parameters
### --------------------------
Write-Host "OS Parameters: " -ForegroundColor Yellow
Write-Host "ServerTemplate: " $ServerTemplate -ForegroundColor Gray
Write-Host "CDROMLetter: " $CDROMLetter -ForegroundColor Gray
Write-Host "InternetExplorerESCPreference: " $InternetExplorerESCPreference -ForegroundColor Gray
Write-Host "IPv6Preference: " $IPv6Preference -ForegroundColor Gray
Write-Host "LocalAdministrator: " $LocalAdministrator -ForegroundColor Gray
Write-Host "NetworkInterfacename: " $NetworkInterfacename -ForegroundColor Gray
Write-Host "RDPResetrictionsPreference: " $RDPResetrictionsPreference -ForegroundColor Gray
Write-Host "RemoteDesktopPreference: " $RemoteDesktopPreference -ForegroundColor Gray
Write-Host "SwapFileLocation: " $SwapFileLocation -ForegroundColor Gray
Write-Host "SwapFileMultiplier: " $SwapFileMultiplier -ForegroundColor Gray
Write-Host "WindowsFirewallPreference: " $WindowsFirewallPreference -ForegroundColor Gray


