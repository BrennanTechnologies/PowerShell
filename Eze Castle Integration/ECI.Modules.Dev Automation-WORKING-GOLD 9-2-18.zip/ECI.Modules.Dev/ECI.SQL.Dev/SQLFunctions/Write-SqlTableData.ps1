﻿cls

if(!(Get-Module -Name SqlServer)){Write-Host "Importing Module: SQLServer";Import-Module SqlServer}

### Set the Database Location
$SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"

Set-Location $SQLServer

#Write-SqlTableData -serverInstance localhost\sql2016 -database Test2 -TableName TestInsert -SchemaName dbo -InputData @{ 01='abc'; 02='xyz'} -PassThru



#Write-SqlTableData -ServerInstance ECILAB-BOSDEV01\SQLEXPRESS -DatabaseName ServerConfiguration-Dev-Lab -SchemaName dbo -TableName Cookies -InputData ('1','1','3','4') -Force

#Write-SqlTableData -ServerInstance ECILAB-BOSDEV01\SQLEXPRESS -DatabaseName ServerConfiguration-Dev-Lab -SchemaName dbo -TableName Cookies -InputData @{VM="VM2";Verified="True";Abort="False"} -Force

$ServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
$SchemaName  = "dbo"
$SQLDatabase = "ServerConfiguration-Dev-Lab"
$SQLTable = "Cookies2"

$InputDataHash = @{
    VM = "VM-Test1"
    FunctionName = "Test-Function1"
    Verified = "True"
    Abort = "True"
}
#$InputDataHash | FL
#exit

$InputData = @()
foreach ($Column in $InputDataHash.GetEnumerator())
{
    #Write-Host "Name: " $Column.Name
    #Write-Host "Vaslue: " $Column.Value
    $InputData += ($Column.Name + "=" + $Column.Value)
}
#$InputData | FL


$InputDataArray = @(
    ("VM", "VM-Test1"),
    ("FunctionName", "Test-Function1"),
    ("Verified", "True"),
    ("Abort", "True")
)
#$InputDataArray | FT
#$InputDataArray -is [array]
#exit

<#
$TableName = "Table"

#Create Table object
$Table = New-Object system.Data.DataTable “$TableName”

#Define Columns
$col1 = New-Object system.Data.DataColumn ColumnName1,([string])
$col2 = New-Object system.Data.DataColumn ColumnName2,([string])
#Add the Columns
$table.columns.add($col1)
$table.columns.add($col2)
#Create a row
$row = $table.NewRow()

#Enter data in the row
$row.ColumnName1 = "A" 
$row.ColumnName2 = "1" 

#Add the row to the table
$table.Rows.Add($row)

#Display the table
$table | format-table -AutoSize 
#>


$InputDataHash = @{
    VM = "VM-Test1"
    FunctionName = "Test-Function1"
    Verified = "True"
    Abort = "True"
}

$InputData = [PSCustomObject] $InputDataHash 

Write-SqlTableData -ServerInstance $ServerInstance -SchemaName $SchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData $InputData -Force

exit



#Write-SqlTableData -ServerInstance $ServerInstance -SchemaName $SchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData $InputData -Force

Write-SqlTableData -ServerInstance $ServerInstance -SchemaName $SchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData @{col1="VM2";col2="Test-Funtion";col3="True";col4="False"} -Force
