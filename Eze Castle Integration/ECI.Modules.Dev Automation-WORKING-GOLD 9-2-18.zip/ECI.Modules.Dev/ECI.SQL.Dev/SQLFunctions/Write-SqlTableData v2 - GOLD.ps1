﻿cls

if(!(Get-Module -Name SqlServer)){Write-Host "Importing Module: SQLServer";Import-Module SqlServer}

### Set the Database Location
$SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"

Set-Location $SQLServer



function Write-Cookie
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$Abort
    )
    
    $ServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
    $SchemaName  = "dbo"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    $SQLTable = "Cookies"

    ### IMPORTANT: Values must be in the same order as the columns in the table.
    $InputDataHash = [ordered]@{
        VM = $VM 
        FunctionName = $FunctionName
        Verified = $Verified
        Abort = $Abort
    }

    $InputData = [PSCustomObject] $InputDataHash 
    $InputData

    Write-SqlTableData -ServerInstance $ServerInstance -SchemaName $SchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData $InputData -Force

}



### Write Cookie
$VM = "VM-Test112"
$FunctionName = "Test-Function167"
$Verified = "False"
$Abort = "True"
Write-Cookie -VM $VM -FunctionName $FunctionName -Verified $Verified -Abort $Abort


### Write Cookie
$VM = "VM-Test2"
$FunctionName = "Test-Function2"
$Verified = "True"
$Abort = "False"
Write-Cookie -VM $VM -FunctionName $FunctionName -Verified $Verified -Abort $Abort


function Write-CurrentState
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$VerifyState
    )
    
    $ServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
    $SchemaName  = "dbo"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    $SQLTable = "Cookies"

    ### IMPORTANT: Values must be in the same order as the columns in the table.
    $InputDataHash = [ordered]@{
        VM = $VM 
        FunctionName = $FunctionName
        Verified = $Verified
        Abort = $Abort
    }

    $InputData = [PSCustomObject] $InputDataHash 
    $InputData

    Write-SqlTableData -ServerInstance $ServerInstance -SchemaName $SchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData $InputData -Force

}