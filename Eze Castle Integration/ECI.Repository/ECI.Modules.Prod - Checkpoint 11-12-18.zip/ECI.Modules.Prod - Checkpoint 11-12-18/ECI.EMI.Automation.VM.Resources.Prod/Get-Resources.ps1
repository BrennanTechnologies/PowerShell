﻿
function Get-ResourcePool
{
    ### Take GPID as Input Parameter
    Param([Parameter(Mandatory = $True)][string]$GPID)

    <#

        ... Do stuff here to find the Resource Pool ...

    #>

    ### Return ResourcePool Variable
    Return $ResourcePool
}

function Get-PortGroup
{
    ### Take GPID as Input Parameter
    Param([Parameter(Mandatory = $True)][string]$GPID)

    <#

        ... Do stuff here to find the Port Group ...

    #>

    ### Return PortGroup Variable
    Return $PortGroup
}

function Get-Datastore
{
    ### Take GPID as Input Parameter
    Param([Parameter(Mandatory = $True)][string]$GPID)

    <#

        ... Do stuff here to find the Datastores ...

    #>

    ### Return DataStore Variable
    Return $DataStore
}


# Set Test GPID
### --------------------
$GPID = "ETEST040"


### Call the functions
### --------------------
Get-ResourcePool -GPID $GPID

Get-PortGroup -GPID $GPID

Get-Datastore -GPID $GPID
