﻿

$schoenerPortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like "multi_schoener*"}
$schoenerPortGroups.count
$schoenerPortGroups[1].name

$vcenter = "qts"
$serverType = "emi"

$podAndPortGroupName = @()

foreach($group in $schoenerPortGroups){
$tempPodNum = (Get-VDPortgroup -Name $group.name | Get-VDSwitch).name.split("\-")[1].Replace("POD","")
$tempOsDatastoreName = $vcenter + "_" + $serverType +"_os_" + $tempPodNum
$tempSwapDatastoreName = $vcenter + "_" + $serverType +"_swap_" + $tempPodNum
$tempOsDastoreCluster = get-datastorecluster -name $tempOsDatastoreName
$tempSwapDatastoreCluster = get-datastorecluster -name $tempSwapDatastoreName
$portGrpHash = [ordered]@{
'portGroupName' = $group.name
'podClusterNumber' = $tempPodNum
'datastoreClusOS' = $tempOsDastoreCluster.name
'datastoreClusSwap' = $tempSwapDatastoreCluster.name
}
$obj = New-Object -TypeName psobject -Property $portGrpHash
$podAndPortGroupName += $obj
Clear-Variable tempPodNum,tempOsDatastoreName,tempSwapDatastoreName,tempOsDastoreCluster,tempSwapDatastoreCluster
}


$apexPortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like "*apexf401*"}
$apexPortGroups.count
$apexPortGroups[1].name

$vcenter = "ld5"
$serverType = "emi"

$podAndPortGroupName = @()

foreach($group in $apexPortGroups){
$tempPodNum = (Get-VDPortgroup -Name $group.name | Get-VDSwitch).name.split("\-")[2]
$tempOsDatastoreName = $vcenter + "_" + $serverType +"_os_" + $tempPodNum
$tempSwapDatastoreName = $vcenter + "_" + $serverType +"_swap_" + $tempPodNum
$tempOsDastoreCluster = get-datastorecluster -name $tempOsDatastoreName
$tempSwapDatastoreCluster = get-datastorecluster -name $tempSwapDatastoreName
$portGrpHash = [ordered]@{
'portGroupName' = $group.name
'podClusterNumber' = $tempPodNum
'datastoreClusOS' = $tempOsDastoreCluster.name
'datastoreClusSwap' = $tempSwapDatastoreCluster.name
}
$obj = New-Object -TypeName psobject -Property $portGrpHash
$podAndPortGroupName += $obj
Clear-Variable tempPodNum,tempOsDatastoreName,tempSwapDatastoreName,tempOsDastoreCluster,tempSwapDatastoreCluster
}

$chiltonPortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like "*chilt002*"}
$chiltonPortGroups.count
$schoenerPortGroups[1].name

$vcenter = "qts"
$serverType = "emi"

$podAndPortGroupName = @()

foreach($group in $chiltonPortGroups){
$tempPodNum = (Get-VDPortgroup -Name $group.name | Get-VDSwitch).name.split("\-")[1].Replace("POD","")
$tempOsDatastoreName = $vcenter + "_" + $serverType +"_os_" + $tempPodNum
$tempSwapDatastoreName = $vcenter + "_" + $serverType +"_swap_" + $tempPodNum
$tempOsDastoreCluster = get-datastorecluster -name $tempOsDatastoreName
$tempSwapDatastoreCluster = get-datastorecluster -name $tempSwapDatastoreName
$portGrpHash = [ordered]@{
'portGroupName' = $group.name
'podClusterNumber' = $tempPodNum
'datastoreClusOS' = $tempOsDastoreCluster.name
'datastoreClusSwap' = $tempSwapDatastoreCluster.name
}
$obj = New-Object -TypeName psobject -Property $portGrpHash
$podAndPortGroupName += $obj
Clear-Variable tempPodNum,tempOsDatastoreName,tempSwapDatastoreName,tempOsDastoreCluster,tempSwapDatastoreCluster
}




cls

$GPID = "schoener"
#$GPID = "Etest040"

$PortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like "*$GPID*"}
#Write-Host "Count: " $PortGroups.count
#Write-Host "Name: " $PortGroups[1].name

$Resources = @()

foreach($Group in $PortGroups)
{
    $PodNum = (Get-VDPortgroup -Name $Group.Name | Get-VDSwitch).name.split("\-")[1].Replace("POD","")
    
    Write-Host "POD: " $PodNum

    $Hash = [ordered]@{

        "portGroupName"    = $Group.Name
        "podClusterNumber" = $PodNum

    }
}
$PSObject = New-Object -TypeName PSObject -Property $Hash

$Resources += $PSObject

$Resources

Clear-Variable tempPodNum 

Write-Host "DS: " (Get-DatastoreCluster | Where {$_.Location -like ("*$podAndPortGroupName.podClusterNumber*") }) #-Location ("*" + $podAndPortGroupName.podClusterNumber + "*"))
 <#

portGroupName          podClusterNumber
-------------          ----------------
multi_schoenermgmt_ptp 201
multi_schoenermgmt_dmz 201
multi_schoenermgmt     201 
 
 #>