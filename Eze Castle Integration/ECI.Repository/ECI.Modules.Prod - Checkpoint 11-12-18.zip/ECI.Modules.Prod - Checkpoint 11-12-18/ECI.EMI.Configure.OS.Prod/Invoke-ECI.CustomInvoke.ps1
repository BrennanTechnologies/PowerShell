﻿function Invoke-ECI.CustomInvokeVMScript
{

<#
    Invoke Script Process
    ------------------------------------------
    1. Authenticate to VM Guest
    2. Copy Script to VM Guest as Temp File
    3. Make Script File Executable
    4. Run Script in Temp File
    5. Wait for Script to Finish
    6. Retrieve Output from Script
    7. Clean Up - Remove Temp Files

#>

    $si       = Get-View ServiceInstance
    $guestMgr = Get-View -Id $si.Content.GuestOperationsManager
    $gFileMgr = Get-View -Id $guestMgr.FileManager
    $gProcMgr = Get-View -Id $guestMgr.ProcessManager


    ### 1. Authenticate
    ###----------------------------------------------
    if($PSCmdlet.ParameterSetName -eq 'PSCredential')
    {
        $GuestUser = $GuestCredential.GetNetworkCredential().username
        $GuestPassword = $GuestCredential.GetNetworkCredential().password
    }
    $auth = New-Object VMware.Vim.NamePasswordAuthentication
    $auth.InteractiveSession = $false
    $auth.Username = $GuestUser
    $auth.Password = $GuestPassword


    ### 2. Copy Script to VM Guest as Temp File
    ###----------------------------------------------
    $lCode = $ScriptText.Split("`r") -join ''
    $attr = New-Object VMware.Vim.GuestFileAttributes
    $clobber = $true
    $filePath = $gFileMgr.InitiateFileTransferToGuest($moref,$auth,$tempFile,$attr,$lCode.Length,$clobber)
    $copyResult = Invoke-WebRequest -Uri $filePath -Method Put -Body $lCode
            
    if($copyResult.StatusCode -ne 200)
    {
        Throw "ScripText copy failed!`rStatus $($copyResult.StatusCode)`r$(($copyResult.Content | %{[char]$_}) -join '')"
    }
                
    ### 3. Make Script File Executable
    ###----------------------------------------------
    $spec = New-Object VMware.Vim.GuestProgramSpec
    $spec.Arguments = "751 $($tempFile.Split('/')[-1])"
    $spec.ProgramPath = '/bin/chmod'
    $spec.WorkingDirectory = '/tmp'
    Try
    {
        $procId = $gProcMgr.StartProgramInGuest($moref,$auth,$spec)
    }
    Catch
    {
        Throw "$error[0].Exception.Message"
    }
            
    ### 4. Run Script in Temp File
    ###----------------------------------------------            
    $spec = New-Object VMware.Vim.GuestProgramSpec
    $spec.Arguments = " > $($tempOutput)"
    $spec.ProgramPath = "$($tempFile)"
    $spec.WorkingDirectory = '/tmp'
    Try
    {
        $procId = $gProcMgr.StartProgramInGuest($moref,$auth,$spec)
    }
    Catch
    {
        Throw "$error[0].Exception.Message"
    }
            
    ### 5. Wait for Script to Finish
    ###----------------------------------------------
    Try
    {
        $pInfo = $gProcMgr.ListProcessesInGuest($moref,$auth,@($procId))
        while($pInfo.EndTime -eq $null){
            sleep 1
            $pInfo = $gProcMgr.ListProcessesInGuest($moref,$auth,@($procId))
        }
    }
    Catch
    {
        Throw "$error[0].Exception.Message"
    }
 
    ### 6. Retrieve Output from Script
    ###----------------------------------------------
    $fileInfo = $gFileMgr.InitiateFileTransferFromGuest($moref,$auth,$tempOutput)
    $fileContent = Invoke-WebRequest -Uri $fileInfo.Url -Method Get
    if($fileContent.StatusCode -ne 200)
    {
        Throw "Retrieve of script output failed!`rStatus $($fileContent.Status)`r$(($fileContent.Content | %{[char]$_}) -join '')"
    }
            
    # 7. Clean Up - Remove Temp Files
    ###----------------------------------------------
    # Remove output file
    $gFileMgr.DeleteFileInGuest($moref,$auth,$tempOutput)
            
    # Remove temp script file
    $gFileMgr.DeleteFileInGuest($moref,$auth,$tempFile)

}