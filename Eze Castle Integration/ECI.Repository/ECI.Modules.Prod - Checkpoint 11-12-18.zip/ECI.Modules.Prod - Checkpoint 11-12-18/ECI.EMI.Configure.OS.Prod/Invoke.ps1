﻿$VMHost = "ETEST040_Test-LD5-4o3A6"


function Wait-ECI.EMI.Automation.VM.VMTools
{
    Param(
    [Parameter(Mandatory = $true)][string]$VMName,
    [Parameter(Mandatory = $false)][int16]$t,
    [Parameter(Mandatory = $false)][int16]$RetryCount
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    Write-Host "Waiting for VMTools: " $VMName -ForegroundColor Yellow

    if(!$t)          { $t = $WaitTime_VMTools }
    if(!$RetryCount) { $RetryCount = 5 }

    $VMTools = Wait-Tools -VM $VMName -TimeoutSeconds $t -ErrorAction SilentlyContinue
    
    if(!$VMTools)
    {
        for ($i=1; $i -le $RetryCount; $i++)
        {
            Write-Warning  "VMTools Not Responding. Retrying...." -WarningAction Continue
            Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName #-t 60
        }
    }
    if($VMTools)
    {
        Write-Host "The Server is Up - VMNAME: $VMName" -ForegroundColor Green
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Test-ECI.EMI.VM.GuestState
{
    Param ([Parameter(Mandatory = $True)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 50)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 50) -ForegroundColor Gray

    ### Guest States
    ###----------------------------
    $GuestStates = @{
        GuestState                        = (Get-VM -Name $VMName).Guest.State                                              ### <---- RETRUN: Running/NotRunning
        ToolsVersionStatus                = (Get-VM -Name $VMName).ExtensionData.Summary.Guest.ToolsVersionStatus           ### <---- RETRUN: guestToolsCurrent
        VirtualMachineToolsStatus         = (Get-VM -Name $VMName).ExtensionData.Guest.ToolsStatus                          ### <---- RETRUN: toolsNotInstalled/toolsNotRunning/toolsOk/toolsOld
        ConfigToolsToolsVersion           = (Get-VM -Name $VMName | Get-View).Config.Tools.ToolsVersion                    
        Configversion                     = (Get-VM -Name $VMName | Get-View).Config.version
        VMguestState                      = (Get-VM -Name $VMName).ExtensionData.guest.guestState                           ### <---- RETRUN: running/notRunning
        VMguestOperationsReady            = (Get-VM -Name $VMName).ExtensionData.guest.guestOperationsReady                 ### <---- RETRUN: True/False
        VMinteractiveGuestOperationsReady = (Get-VM -Name $VMName).ExtensionData.guest.interactiveGuestOperationsReady      ### <---- RETRUN: True/False
        VMguestStateChangeSupported       = (Get-VM -Name $VMName).ExtensionData.guest.guestStateChangeSupported            ### <---- RETRUN: True/False
    }

    foreach($State in $GuestStates.GetEnumerator())
    {
        Write-Host "VMState: " $State.Key ":  " $State.Value -ForegroundColor DarkCyan

    }

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    
<#   
    ### Tools-OK
    write-host “Waiting for VM Tools to Start”
    do 
    {
        $toolsStatus = (Get-VM $vmName | Get-View).Guest.ToolsStatus
        write-host $toolsStatus
        sleep 3
    } 
    until ( $toolsStatus -eq ‘toolsOk’ )

    ### Get Name
    write-host “Waiting for VM Name”
    Do 
        {
        $GuestHostName = (Get-VM -Name $VMName | Get-View).Name
        Start-Sleep -Seconds 10
        } 
    Until ($GuestHostName -eq $VMName)


    # Port 902 open
    $originalEA = $ErrorActionPreference
    $ErrorActionPreference = “SilentlyContinue”
    $socket = New-Object Net.Sockets.TcpClient
    $socket.Connect($VMName,902)

    if($socket.Connected)
    {
        Write-Host "Port 902 is Open"
        $condPort = $True
        $socket.Close()
    }
    Remove-Variable -Name socket -Confirm:$false
    $ErrorActionPreference = $originalEA
#>

}

function Test-ECI.EMI.Automation.VM.InvokeVMScript
{
    Param([Parameter(Mandatory = $true)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $ScriptText =  { 
    
        ### Test VM Tools Service
        #$VMTools = Get-Service -Name VMTools  
        #Write-Host "VMTools Status: " $VMTools.Status

        ### Test New File
        $TestPath = "C:\Temp"
        if(-NOT(Test-Path -Path $TestPath)) {(New-Item -ItemType directory -Path $TestPath -Force | Out-Null)}

        $TestFile = $TestPath + "\" + "deleteme.txt"
        New-Item $TestFile -ItemType file -Force

        if([System.IO.File]::Exists($TestFile))
        {
            Write-Host "TEST FILE: Exists."
        }
        elseif(-NOT([System.IO.File]::Exists($TestFile)))
        {
            Write-Host "TEST FILE: Failed!!!"
            $Abort = $True
            Write-ECI.ErrorStack
        }
    }
    Write-Host "Test-ECI.EMI.Automation.VM.InvokeVMScript..." -ForegroundColor Cyan
    $TestInvoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword
    Write-Host "TestInvoke.ExitCode:" $TestInvoke.ExitCode -ForegroundColor Gray
    Write-Host "TestInvoke.ScriptOutput:" $TestInvoke.ScriptOutput -ForegroundColor Gray

    if($TestInvoke.ExitCode -eq 0)
    {
        Write-Host "INVOKE TEST: Succeded." -ForegroundColor Green
    }
    elseif($TestInvoke.ExitCode -ne 0)
    {
        Write-Host "INVOKE TEST: Failed. Retrying ..." -ForegroundColor Red
        Start-ECI.EMI.Automation.Sleep -t 60
        Test-ECI.EMI.Automation.VM.InvokeVMScript
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Restart-ECI.EMI.VM.VMTools
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $StopVMTools = {(Get-WmiObject -Computer . win32_service -filter "name='VMtools'").StopService()}

    $StartVMTools = {(Get-WmiObject -Computer . win32_service -filter "name='VMtools'").StartService()}            

    Write-Host "Invoking: Stop-Tools " -ForegroundColor Yellow
    Invoke-VMScript -ScriptText $StopVMTools -VM $VMName -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction Continue -ErrorVariable ECIError
    Start-ECI.EMI.Automation.Sleep -t 60
    Write-Host "Invoking: Start-Tools " -ForegroundColor Yellow
    Invoke-VMScript -ScriptText $StartVMTools -VM $VMName -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction Continue -ErrorVariable ECIError

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}



function Invoke-ECI.EMI.Configure.OS.InGuest
{
    [CmdletBinding()]
    Param([Parameter(Mandatory = $True)] [string]$Step)

    #####################################################
    ### Script Text Block
    #####################################################
    function Process-ECI.ScripttextBlock
    {
        [scriptblock]$script:ScriptText = {
        
        #BootStrapModuleLoader#       
        
        $global:Env                               = "#Env#"    
        $global:Environment                       = "#Environment#"    
        $global:Step                              = "#Step#"    
        $global:VMName                            = "#VMName#"    
        $global:ServerID                          = "#ServerID#"  
        $global:ServerRole                        = "#ServerRole#"  
        $global:HostName                          = "#HostName#"
        $global:ClientDomain                      = "#ClientDomain#"
        $global:IPv4Address                       = "#IPv4Addres#"
        $global:SubnetPrefixLength                = "#SubnetPrefixLength#"
        $global:DefaultGateway                    = "#DefaultGateway#"
        $global:PrimaryDNS                        = "#PrimaryDNS#"
        $global:SecondaryDNS                      = "#SecondaryDNS#"
        $global:BuildVersion                      = "#BuildVersion#"
        $global:CDROMLetter                       = "#CDROMLetter#"
        $global:InternetExplorerESCPreference     = "#InternetExplorerESCPreference#"
        $global:IPv6Preference                    = "#IPv6Preference#"
        $global:NetworkInterfaceName              = "#NetworkInterfaceName#"
        $global:SMBv1                             = "#SMBv1#"
        $global:RDPResetrictionsPreference        = "#RDPResetrictionsPreference#"
        $global:RemoteDesktopPreference           = "#RemoteDesktopPreference#"
        $global:PageFileLocation                  = "#PageFileLocation#"
        $global:PageFileMultiplier                = "#PageFileMultiplier#"
        $global:WindowsFirewallPreference         = "#WindowsFirewallPreference#"
        $global:AdministrativeUserName            = "#AdministrativeUserName#"
        $global:AdministrativePassword            = "#AdministrativePassword#"
        $global:AutomationLogPath                 = "#AutomationLogPath#"
        
        foreach($Module in (Get-Module -ListAvailable ECI.*)){Import-Module -Name $Module.Path -DisableNameChecking}
        
        . "C:\Program Files\WindowsPowerShell\Modules\ECI.Modules.$Env\ECI.EMI.Configure.OS.$Env\ECI.EMI.Configure.OS.InGuest.$Env.ps1" 

        } # END ScriptText

        ### Clean the Scripttext Block
        ###-----------------------------------------------------------------------
        $CleanScriptText = $Null
        foreach( $Line in (((($Scripttext -replace("  ","") -replace("= ","=")) -replace(" =","=") ) -split("`r`n"))) | ? {$_.Trim() -ne ""} )
        {
            $Line = ($Line) + "`r`n"
            $CleanScriptText = $CleanScriptText + $Line
        }
   
        [int]$CharLimit = 2869
        [int]$CharCount = ($CleanScriptText | Measure-Object -Character).Characters
        if($CharCount -gt $CharLimit)
        {
            Write-Warning "The Scripttect block exceeds $CharLimit Chararter Limit."
        }
        elseif($CharCount -lt $CharLimit)
        {
            Write-Host "The Scripttect block is under the $CharLimit Chararter Limit." -ForegroundColor DarkGreen
        }
        Write-Host "Scripttext Character Count: " $CharCount -ForegroundColor DarkGray
        $script:ScriptText = $CleanScriptText

        Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray

        Return $script:ScriptText
    }

    #####################################################
    ### Invoke ScriptText
    #####################################################
    function Invoke-ECI.ScriptTextBlock  
    {
        Param([Parameter(Mandatory = $True)][scriptblock]$ScriptText)

        $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

        ### Replace Parameters with #LiteralValues#
        ### ---------------------------------------
        $Params = @{
        "#Env#"                           = $Env
        "#Environment#"                   = $Environment
        "#Step#"                          = $Step
        "#VMName#"                        = $VMName
        "#ServerID#"                      = $ServerID
        "#ServerRole#"                    = $ServerRole
        "#HostName#"                      = $HostName
        "#ClientDomain#"                  = $ClientDomain
        "#IPv4Addres#"                    = $IPv4Address
        "#SubnetMask#"                    = $SubnetMask
        "#DefaultGateway#"                = $DefaultGateway
        "#PrimaryDNS#"                    = $PrimaryDNS
        "#SecondaryDNS#"                  = $SecondaryDNS
        "#BuildVersion#"                  = $BuildVersion
        "#CDROMLetter#"                   = $CDROMLetter
        "#InternetExplorerESCPreference#" = $InternetExplorerESCPreference
        "#IPv6Preference#"                = $IPv6Preference
        "#NetworkInterfaceName#"          = $NetworkInterfaceName
        "#SMBv1#"                         = $SMBv1
        "#RDPResetrictionsPreference#"    = $RDPResetrictionsPreference
        "#RemoteDesktopPreference#"       = $RemoteDesktopPreference
        "#PageFileLocation#"              = $PageFileLocation
        "#PageFileMultiplier#"            = $PageFileMultiplier
        "#WindowsFirewallPreference#"     = $WindowsFirewallPreference
        "#AdministrativeUserName#"        = $AdministrativeUserName
        "#AdministrativePassword#"        = $AdministrativePassword
        "#AutomationLogPath#"             = $AutomationLogPath
        }

        ### Inject Variables into ScriptText Block
        ### ---------------------------------------
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
        }

        ### Inject BootStrap Module Loader into VM Host                                          # <----- not using bootstrap ????
        ### ---------------------------------------
        #$ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

        ### Debugging: Write ScriptText Block to Screen
        ### ---------------------------------------
        #Write-Host "ScriptText:`r`n" $ScriptText -ForegroundColor Gray

        ### Test Guest
        ###---------------------------------
        Start-ECI.EMI.Automation.Sleep              -t $WaitTime_StartSleep
        Wait-ECI.EMI.Automation.VM.VMTools          -VMName $VMName -t $WaitTime_VMTools 
        Test-ECI.EMI.VM.GuestState                  -VMName $VMName
        Test-ECI.EMI.Automation.VM.InvokeVMScript   -VMName $VMName

        ### Invoke Script Block
        ### ---------------------------------------

        function Try-InvokeScriptext
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

            Write-Host "Invoke: Please Wait. This may take a while ..." -ForegroundColor Yellow
            Write-Host "ScriptText: " `r`n $ScriptText -ForegroundColor DarkGray

            ### -------------------------------------------
            ### Production: Run Invoke as Variable
            ### -------------------------------------------

            ###############################
            ### Inovke VMScript
            ###############################
            #---------------------------------------------------------
            #   Invoke-VMScript
            #     -Verbose 
            #     -Debug
            #     | Select -ExpandProperty ScriptOutput
            #     | Select -ExpandProperty ExitCode
            #---------------------------------------------------------

            $global:Invoke = $False
            Invoke-VMScript -ScriptText $ScriptText -VM $VMName -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction Stop -ErrorVariable ECIError
            
            Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        function Retry-InvokeScriptext
        {
            Param([Parameter(Mandatory = $True)][int]$InvokeRetryCounter)

            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

            $InvokeRetryCounter = 0
            $RetryCount       = 3  
         
            for ($i=1; $i -le $RetryCount; $i++)
            {
                Start-ECI.EMI.Automation.Sleep -t 30
                Write-Warning "Re-trying Invoke....  Count: " $InvokeRetryCounter -WarningAction Continue
                Write-Host    "ERROR:" `r`n $Error[0] -ForegroundColor Red

                Try-InvokeScriptext
            }

            Write-Host "ABORT ERROR! (at end of Retry-InvokeScriptext)" -ForegroundColor Red
            #Write-ECI.ErrorStack
            
            Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray 
        }

        try
        {
            Try-InvokeScriptext
        }

        catch [VMware.VimAutomation.ViCore.Types.V1.ErrorHandling.GuestOperationsUnavailable]
        {
            ### The guest operations agent could not be contacted.
        
            $InvokeRetryCounter ++
            Write-Host "ERROR     :" `r`n $Error[0] -ForegroundColor Red
            Write-Host "CAUGHT    : VMware.VimAutomation.ViCore.Types.V1.ErrorHandling.GuestOperationsUnavailable" -ForegroundColor DarkGray
            Write-Host "EXCEPTION :" $Error[0].Exception.GetType().Fullname -ForegroundColor Red

            Write-Host "Restarting VMTools."  -ForegroundColor DarkGray
            Restart-ECI.EMI.VM.VMTools
        
            Write-Host "Re-Try Invoke."  -ForegroundColor DarkGray
            Retry-InvokeScriptext -InvokeRetryCount $InvokeRetryCount
        }
    
        catch [VMware.VimAutomation.ViCore.Types.V1.ErrorHandling.SystemError]
        {
            $InvokeRetryCounter ++
            Write-Host "ERROR     :" `r`n $Error[0] -ForegroundColor Red
            Write-Host "CAUGHT    :  System.Management.Automation.ErrorRecord"  -ForegroundColor DarkGray
            Write-Host "EXCEPTION :" $Error[0].Exception.GetType().Fullname     -ForegroundColor Red
        
            Write-Host "Restarting VMTools."  -ForegroundColor DarkGray
            Restart-ECI.EMI.VM.VMTools

            Write-Host "Re-Try Invoke."  -ForegroundColor DarkGray
            Retry-InvokeScriptext
        }
    
        catch
        {
            $InvokeRetryCounter ++
            Write-Host "ERROR     :" `r`n $Error[0] -ForegroundColor Red
            Write-Host "CAUGHT    :  Error"  -ForegroundColor DarkGray
            Write-Host "EXCEPTION :" $Error[0].Exception.GetType().Fullname -ForegroundColor Red

            Write-Host "Restarting VMTools."  -ForegroundColor DarkGray
            Restart-ECI.EMI.VM.VMTools            

            Write-Host "Re-Try Invoke."  -ForegroundColor DarkGray
            Retry-InvokeScriptext
        }
    
        finally
        {
            if($Invoke)
            {
                ### Check Exit Code for any Errors
                ### ---------------------------------------
                if (($Invoke.ExitCode) -eq 0) 
                {
                    $ExitCodeStatus = "Success"
                    $ExitCodeColor  = "Green"
                }
                elseif (($Invoke.ExitCode) -ne 0) 
                {
                    $ExitCodeStatus = "Failure"
                    $ExitCodeColor  = "Red"
                }

                Write-Host "Invoke.ExitCode Status :"       $ExitCodeStatus      -ForegroundColor $ExitCodeColor
                Write-Host "Invoke.ExitCode        :"       $Invoke.ExitCode     -ForegroundColor $ExitCodeColor
                Write-Host "Invoke.ScriptOutput    : " `r`n $Invoke.ScriptOutput -ForegroundColor $ExitCodeColor
            }
        }

        Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    }

    #####################################################
    ### Execute Invoke Functions
    #####################################################
    &{
        BEGIN
        {
            Write-Host `r`n('=' * 100)`r`n "BEGIN INVOKE FUNCTION - IN-GUEST  : " `r`n $((Get-PSCallStack)[0].Command) "-Step:"`r`n$Step `r`n('=' * 100) -ForegroundColor DarkCyan
            Write-Host `r`n('*' * 55)`r`n`r`n "      ~~~~~~~~ INVOKING OS CONFIGURATION ~~~~~~~~  " `r`n`r`n(' ' * 18) "STEP:" $Step `r`n`r`n " --------- THIS PROCESS MAY TAKE SEVERAL MINUTES ---------  " `r`n`r`n('*' * 55)`r`n -ForegroundColor Cyan
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray        
        }

        PROCESS
        {
            Process-ECI.ScripttextBlock
            Process-ECI.ScripttextBlock -ScriptText $ScriptText
        }


        END 
        {
            Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }
    }
}



&{
    PROCESS 
    {

        Start-ECI.EMI.Automation.Sleep -t $WaitTime_StartSleep
        Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName -t $WaitTime_VMTools 
        Test-ECI.EMI.VM.GuestState -VMName $VMName
        Test-ECI.EMI.Automation.VM.InvokeVMScript -VMName $VMName

            #in Invoke function
            Restart-ECI.EMI.VM.VMTools
            Retry-InvokeScriptext
    }
}
