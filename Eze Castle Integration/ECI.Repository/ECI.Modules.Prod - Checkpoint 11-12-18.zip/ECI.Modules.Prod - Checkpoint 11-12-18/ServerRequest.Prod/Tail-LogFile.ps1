﻿
function Tail-ECI.Log
{
    cls
    $File       = $Null
    $Dir        = "C:\Scripts\ServerRequest\TranscriptLogs\"
    $Filter     = "PowerShell_transcript*.txt"
    $LatestFile = Get-ChildItem -Path $Dir -Filter $Filter | Sort-Object LastAccessTime -Descending | Select-Object -First 1
    Get-Content ($Dir + $LatestFile) –Wait
}

Tail-ECI.Log