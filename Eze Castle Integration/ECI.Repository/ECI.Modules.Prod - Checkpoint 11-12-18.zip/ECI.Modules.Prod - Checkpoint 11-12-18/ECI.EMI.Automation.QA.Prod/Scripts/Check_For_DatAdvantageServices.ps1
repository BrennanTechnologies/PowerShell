﻿#Read Active Directory/DFS to find what servers are hosting DFS targets and then if DataAdvantage is running on them
#
#Version 1.0 6/8/2017 Shaun DeSimone/Rob West - ECI


$dfsTargets = @()

$dnsRoot = Get-ADDomain | select -ExpandProperty dnsroot
$dfsnRootPath = Get-DfsnRoot -Domain $dnsRoot | select -ExpandProperty path
$dfsnFolderPath = Get-DfsnFolder -Path ($dfsnRootPath + "\*") | select -ExpandProperty path

foreach($folder in $dfsnFolderPath)
    {
        $tempServer = Get-DfsnFolderTarget -Path $folder | Select-Object -ExpandProperty targetpath | sort -Unique
            foreach($server in $tempServer)
                {
                    $dfsTargets += $server.split("\")[2]
                }#loop through all folder targets and get unique values
    }#loop through all folders in DFS

#get only unique values in the array and also force them all to lower case for consistency 
$dfsTargets = $dfsTargets.tolower() | sort -Unique

foreach ($target in $dfsTargets)
    {
        $vrnsService = Get-Service -ComputerName $target -Name "vrns*" | select name,status | sort status
            foreach($service in $vrnsService)
                {
                    $hash = [ordered]@{
                                        'Server' = $target
                                        'ServiceName' = $service.Name
                                        'Status' = $service.Status
                                      }
                    $obj = New-Object -TypeName psobject -Property $hash
                    $obj
                }#write the values to the console        
    }#connect to each server and check for the vrns service
