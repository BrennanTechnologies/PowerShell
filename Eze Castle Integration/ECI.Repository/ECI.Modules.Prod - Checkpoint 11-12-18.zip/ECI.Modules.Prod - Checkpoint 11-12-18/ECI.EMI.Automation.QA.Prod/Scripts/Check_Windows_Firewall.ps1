﻿#Read Active Directory for all server names and report Windows Firewall status
#Will only work properly on PS 3 machines (Server 2012 and higher)
#Version 1.0 4/16/2016 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

foreach ($server in $servers) {

if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)

    {

    # Output server name and firewall status
    Write-Host -ForegroundColor Green "Server Name"
    $server.DNSHostname

    Get-Service -ComputerName $server.DNSHostName -DisplayName "Windows Firewall"
    
    Get-NetFirewallProfile -CimSession $server.DNSHostName -profile domain

    Write-Host ""
    
   }
   
    

}