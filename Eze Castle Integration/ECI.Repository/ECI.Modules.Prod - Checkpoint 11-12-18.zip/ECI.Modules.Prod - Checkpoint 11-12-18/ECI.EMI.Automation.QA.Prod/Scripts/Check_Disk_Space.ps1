﻿#Read Active Directory for all server names and checks for total, used and free fixed disk size.
#Less than or equal to 5% free will be reported in red.
#
#Version 1.0 8/21/2013 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}


foreach ($server in $servers)
{
	
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
    {
	
	$Disks=Get-WmiObject -Class Win32_logicalDisk -Filter "DriveType=3" -computer $server.DNSHostName

	foreach($Disk in $Disks)
	{
		$usedsize=(($disk.size)-($Disk.FreeSpace))/1gb
		$usedsize=[math]::truncate($usedsize)

        $freesize=($Disk.FreeSpace)/1gb
		$freesize=[math]::truncate($freesize)

        $totalsize=($Disk.size)/1gb
		$totalsize=[math]::truncate($totalsize)
        
		write-host -ForegroundColor Cyan $server.Name
        write-host "Total Size" $Disk.DeviceID $Disk.VolumeName $totalsize "GB"
        write-host "Used" $Disk.DeviceID $usedsize "GB"

        if($freesize -le (.05*$totalsize))
        {
            write-host -ForegroundColor Red "Free" $Disk.DeviceID $freesize "GB"
        }

        else {
            write-host  "Free" $Disk.DeviceID $freesize "GB"
		}
		
	}
	 
	write-host ""
    }

}