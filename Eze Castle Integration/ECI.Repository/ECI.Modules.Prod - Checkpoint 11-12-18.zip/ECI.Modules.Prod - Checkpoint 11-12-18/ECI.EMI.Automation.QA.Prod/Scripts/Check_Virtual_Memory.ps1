﻿#Read Active Directory for all server names, physical memory, architecture, and swap file size, locations, and policies.
#
#Version 1.1 9/6/2013 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

foreach ($server in $servers) {

if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)

    {

    # Output server name and DNS hostname
    Write-Host -ForegroundColor Green "Server Name"
    $server.DNSHostname

    # Check if x86 or x64
    Write-Host -ForegroundColor Green "OS Architecture"
    (Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server.DNSHostName).OSArchitecture

    # Check memory size
    Write-Host -ForegroundColor Green "Physical Memory"
    (Get-WMIObject -class Win32_PhysicalMemory -ComputerName $server.DNSHostName | Measure-Object -Property capacity -Sum).Sum / 1MB
   
    # Check swap file information
    Write-Host -ForegroundColor Green "Swap File Location (Size 0=System Managed Size)"
    (Get-WmiObject -Class Win32_pageFileSetting -ComputerName $server.DNSHostName)

    # Check swap file management
    Write-Host -ForegroundColor Green "Automatic Managed Paging File?"
    (Get-WmiObject -Class Win32_ComputerSystem -ComputerName $server.DNSHostname).AutomaticManagedPagefile

    Write-Host ""
    Write-Host ""
   }
   
    
}