#########################################
### VM Provisioning Module
### ECI.EMI.Automation.VM.Prod.psm1
#########################################

function Get-ECI.EMI.Automation.VM.VMTemplate
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    Write-Host "Getting VMWare Template : $VMTemplateName"  -ForegroundColor DarkCyan
    
    #$ECIVMTemplate = $VMTemplateName
    $ECIVMTemplate = Get-Template -Name $VMTemplateName -Server $ECIvCenter

    if (($ECIVMTemplate.count) -gt 1)
    {
        $ECIVMTemplate = $ECIVMTemplate[0]
    }
    
    $global:ECIVMTemplate = $ECIVMTemplate
    Write-Host "Template Selected       : $ECIVMTemplate" -ForegroundColor Cyan
    
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray

    Return $ECIVMTemplate
}

function Set-ECI.EMI.Automation.VM.ServerUUID
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    
    ### Set VM Name fromn HostName Parameters
    ###----------------------------------------------------------------
   
    $VMMoRefID = (Get-VM -Name $VMName).ID
    $VMMoRefID = $VMMoRefID.Split("-")
    
    $vMoRef = $VMMoRefID[-2].ToUpper() + "-" + $VMMoRefID[-1]

    $ServerUUID = "VI" + "." + $vCenterUUID + "." + ($VMMoRefID[-2]).ToUpper() + "-" + $VMMoRefID[-1]
    
    $global:vCenterUUID  = $vCenterUUID
    $global:vMoRef       = $vMoRef
    $global:ServerUUID   = $ServerUUID

    Write-Host "vCenterUUID   : " $vCenterUUID -ForegroundColor DarkCyan
    Write-Host "vMMoRef       : " $vMoRef      -ForegroundColor DarkCyan
    Write-Host "ServerUUID    : " $ServerUUID  -ForegroundColor Cyan
    
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    Return $ServerUUID
   
    #Example:
    #---------
    #VI-d8c273b7-6f4e-4ce7-8986-72dfbd3f0376-VM-38002
}

###############################################
### Create New VM
###############################################

function New-ECI.EMI.Automation.VM
{
    Param(
    [Parameter(Mandatory = $True)][string]$ConfigurationMode,
    [Parameter(Mandatory = $True)][string]$VMName,
    
    [Parameter(Mandatory = $True)][string]$ECIVMTemplate,
    [Parameter(Mandatory = $True)][string]$OSCustomizationSpecName,
    
    [Parameter(Mandatory = $True)][string]$ResourcePool,
    [Parameter(Mandatory = $True)][string]$OSDataStore,
    [Parameter(Mandatory = $True)][string]$PortGroup,

    [Parameter(Mandatory = $True)][string]$IPv4Address,
    [Parameter(Mandatory = $True)][string]$SubnetMask,
    [Parameter(Mandatory = $True)][string]$DefaultGateway,
    [Parameter(Mandatory = $True)][string]$PrimaryDNS,
    [Parameter(Mandatory = $True)][string]$SecondaryDNS
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    function New-ECI.EMI.Automation.VM.OSCustomizationSpec
    {
        $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec
        ###----------------------------------------------------------
        ### Remove OSCustomizationSpec
        if(Get-OSCustomizationSpec $OSCustomizationSpecName -ErrorAction SilentlyContinue)
        {
            Write-Host "Removing OSCustomizationSpec   : " $OSCustomizationSpecName
            Remove-OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
        
            ### Remove OSCustomizationNicMapping
            #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
        }
        else
        {
            Write-Host "No OSCustomizationSpec Found: "
        }    
    
        ### New OSCustomizationSpec
        ###------------------------
        $OSCustomizationSpec = @{
            Name             = $OSCustomizationSpecName 
            Type             = $Type 
            OSType           = $OSType 
            NamingScheme     = $NamingScheme.trim()
            FullName         = $FullName 
            OrgName          = $OrgName 
            AdminPassword    = $AdminPassword
            ChangeSid        = $True
            DeleteAccounts   = $False 
            TimeZone         = $TimeZone 
            ProductKey       = $ProductKey 
            LicenseMode      = $LicenseMode 
            Workgroup        = $Workgroup
        }
    
        Write-Host "Creating - OSCustomizationSpec : $OSCustomizationSpecName" -ForegroundColor Cyan
        New-OSCustomizationSpec @OSCustomizationSpec
        Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    }

    function New-ECI.EMI.Automation.VM.OSCustomizationNicMapping
    {
        $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec NIC Mapping
        ###----------------------------------------------------------    
        $OSCustomizationNicMapping = {
            IpMode          = "UseStaticIp"
            IpAddress       = $IPv4Address 
            SubnetMask      = $SubnetMask 
            DefaultGateway  = $DefaultGateway 
            Dns             = $PrimaryDNS + "," + $SecondaryDNS
        }
        Write-Host "Creating - OSCustomizationNicMapping  : $OSCustomizationSpecName" -ForegroundColor Cyan
        #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping @OSCustomizationNicMapping
        Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IPMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $SubnetMask -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS

        Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    }

    function New-ECI.EMI.Automation.VM.VM
    {
        $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New VM
        ###----------------------------------------------------------  

        ### Check if VM exists
        ###--------------------------
        if(Get-VM -Name $VMName -ErrorAction SilentlyContinue)          ###<---- NOTE: This gerenerats a false error if the VM does not exist.
        {
            ### Do we want to Abort or run in Report mode ????????
            
            ### Run in Report Mode
            ###--------------------------
            #Write-Host "This VM Exists. Running Report Mode" -ForegroundColor Red
            #$globalConfigurationMode = "Report"

            ### Throw Abort
            ###--------------------------
            $global:Abort = $True
            
            Write-Host "Invoking Abort Error!!!" -ForegroundColor red
            Invoke-ECI.Abort
        }
        
        ### VM does not exist
        ###--------------------------
        else
        {
            ### Create New VM
            ###----------------------------------------------------------
            Write-Host "Creating New VM       : " $VMName -ForegroundColor Cyan
            Write-Host "Please wait. The VM Provisioning process may take a while . . .  " -ForegroundColor Yellow
            try
            {
                $VMParameters = @{
                    VMName                    = $VMName
                    Template                  = $ECIVMTemplate
                    vCenterFolder             = $vCenterFolder
                    OSCustomizationSpec       = $OSCustomizationSpecName
                    ResourcePool              = $ResourcePool
                    OSDataStore               = $OSDataStore
                } 

                $ScriptBlock = 
                {
                    ### Without Folder
                    #New-VM @VMParameters
                    #New-VM -Name $VMName -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $OSDataStore -OSCustomizationSpec $OSCustomizationSpecName

                    ### With Folder
                    New-VM -Name $VMName -Template $ECIVMTemplate -Location $vCenterFolder -ResourcePool $ResourcePool -Datastore $OSDataStore -OSCustomizationSpec $OSCustomizationSpecName
                }
                
                if($ConfigurationMode -eq "Configure")
                {
                    try
                    {
                        Invoke-Command -ScriptBlock $ScriptBlock -ErrorVariable ECIErrorVar
                    }
                    catch
                    {
                        Write-ECI.ErrorStack
                    }
                }
                if($ConfigurationMode -eq "Report")
                {
                    Write-Host "ECI-WHATIF-COMMAND: " $ScriptBlock
                    Write-ECI.EMI.Report -Report $ScriptBlock
                }

            }

            catch
            {
                Write-ECI.ErrorStack
            }
        }

        Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

   &{
        BEGIN {}

        PROCESS 
        {
            New-ECI.EMI.Automation.VM.OSCustomizationSpec
            New-ECI.EMI.Automation.VM.OSCustomizationNicMapping
            New-ECI.EMI.Automation.VM.VM
        }

        END {}

    }

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Set-ECI.EMI.Automation.VM.VMCPU
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    
    ##########################################
    ### Modify Parameter Values
    ##########################################
    ### Cast the Variable
    [int]$vCPUCount = $vCPUCount
    
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "vCPUCount"
    $DesiredState      = $vCPUCount
    #ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VMName | Select NumCpu).NumCpu
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Set VM CPU Count
        ###-----------------------------------------
        Write-Host "Setting VM CPU Count: " $vCPUCount -ForegroundColor Cyan
        $VMName = Get-VM -Name $VMName
        Set-VM -VM $VMName -Confirm:$False -NumCpu $vCPUCount
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Set-ECI.EMI.Automation.VM.VMMemory
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
       
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "vMemoryGB"
    $DesiredState      = $vMemoryGB
    #ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    
    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VMName | Select MemoryGB).MemoryGB
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Set VM Memory
        ###-----------------------------------------
        Write-Host "Setting VM vMemorySizeGB: " $vMemoryGB -ForegroundColor Cyan
        $VMName = Get-VM -Name $VMName
        Set-VM -VM $VMName -Confirm:$False -MemoryGB $vMemoryGB
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function New-ECI.EMI.Automation.VM.HardDisk
{
    Param(
        [Parameter(Mandatory = $true)][string]$VMName,
        [Parameter(Mandatory = $true)][string]$Datastore,
        [Parameter(Mandatory = $true)][string]$CapacityGB
    )
    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
        
    $Params = @{
        VM             = $VMName
        Datastore      = $Datastore
        CapacityGB     = $CapacityGB
        StorageFormat  = "Thin"
        Persistence    = "Persistent"
        Confirm        = $false
    }
    #New-HardDisk @Params
    
    try
    {
        New-HardDisk -VM $VMName -Datastore $DataStore -CapacityGB $CapacityGB -StorageFormat Thin -Persistence persistent -Confirm:$false
    }
    catch
    {
        Write-ECI.ErrorStack
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Get-ECI.EMI.Automation.VM.DataStore
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    Get-ECI.EMI.Automation.VM.Resources.DataStore -Environment $Environment -ServerRole $ServerRole
    
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Configure-ECI.EMI.Automation.VM.HardDisks
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $DataSetName = "ServerHardDisks"
    $ConnectionString =  $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionVMParameters WHERE ServerRole = '$ServerRole'�
    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query


    $Volumes = @{
        OSVolumeCapacity   = $ServerHardDisks.OSVolumeCapacityGB
        SwapVolumeCapacity = $ServerHardDisks.SwapVolumeCapacityGB
        DataVolumeCapacity = $ServerHardDisks.DataVolumeCapacityGB
        LogVolumeCapacity  = $ServerHardDisks.LogVolumeCapacityGB
        SysVolumeCapacity  = $ServerHardDisks.SysVolumeCapacityGB
    }
       
    foreach($Volume in $Volumes.GetEnumerator())
    {
        if(([string]::IsNullOrEmpty($Volume.Value)) -ne $true)
        {
            Write-Host "Volume: " $Volume.Name `t "VolumeSize: " $Volume.Value
            #New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB
        }
    }

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function New-ECI.EMI.Automation.VM.HardDisks
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $Disk = @()
    $OS   = @( $OSDataStore,   $OSVolumeCapacity   )
    $Swap = @( $SwapDataStore, $SwapVolumeCapacity )
    $Data = @( $DataDataStore, $DataVolumeCapacity )
    $Log  = @( $LogDataStore,  $LogVolumeCapacity  )
    $Sys  = @( $SysDataStore,  $SysVolumeCapacity  )


    #New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}


function New-ECI.EMI.Automation.VM.HardDisk.PageFile
{
    Param(
        [Parameter(Mandatory = $true)][string]$VMName
    )
    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
   
    $Datastore = $SwapDataStore
    $CapacityGB = $SwapVolumeCapacityGB
    
    #$Datastore =  "LD5_EMS_Client_DC_OS_401"

    try
    {
        ### Create New Disk
        ### --------------------------
        New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB #-StorageFormat Thin -Persistence Persistent -Confirm:$false
     }
    catch
    {
        Write-ECI.ErrorStack
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Start-ECI.EMI.Automation.VM
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    Write-Host "Starting VM: $VMName" -ForegroundColor Cyan
    Start-VM $VMName
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Wait-ECI.EMI.Automation.VM.VMTools
{
    Param(
    [Parameter(Mandatory = $true)][string]$VMName,
    [Parameter(Mandatory = $false)][int16]$t,
    [Parameter(Mandatory = $false)][int16]$RetryCount
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    Write-Host "Waiting for VMTools: " $VMName -ForegroundColor Yellow

    if(!$t)          { $t = $WaitTime_VMTools }
    if(!$RetryCount) { $RetryCount = 5 }

    $VMTools = Wait-Tools -VM $VMName -TimeoutSeconds $t -ErrorAction SilentlyContinue
    
    if(!$VMTools)
    {
        for ($i=1; $i -le $RetryCount; $i++)
        {
            Write-Warning  "VMTools Not Responding. Retrying...." -WarningAction Continue
            Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName #-t 60
        }
    }
    if($VMTools)
    {
        Write-Host "The Server is Up - VMNAME: $VMName" -ForegroundColor Green
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Wait-ECI.EMI.Automation.VM.OSCusomizationSpec
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    
    $t = 240

    Write-Host "START-SLEEP - for $t seconds: Waiting for OS CusomizationSpec to Complete." -ForegroundColor Yellow

    For ($i=$t; $i -gt 1; $i--) 
    {  
        #$a = [math]::Round((($i/$t)/1)*100)  ### Amount Remaining
        
        $a = [math]::Round( (($t-$i)/$t)*100) ### Amount Completed

        Write-Progress -Activity "START-SLEEP - for $t seconds: Waiting for OS CusomizationSpec to Complete." -SecondsRemaining $i -CurrentOperation "Completed: $a%" -Status "Waiting"
        Start-Sleep 1
        #Write-Host "Still Waiting ..." -ForegroundColor DarkGray
    }

    Write-Host "Done Waiting." -ForegroundColor Cyan
    Write-Progress -Activity 'OS Cusomization' -Completed
}

function Wait-ECI.EMI.Automation.VM.InvokeVMScript-deleteme
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 50)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 50) -ForegroundColor Gray

    $ScriptText =  { dir }   # <-- What is a good Service to look for???? VM Tools is redundant

    $TestInvoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminAccount -ErrorAction silentlycontinue
    if($TestInvoke.ExitCode -ne 0)
    {
        Write-Host "Still Running OS Customization - VMName: $VMName" -ForegroundColor Red
        $t = 45
        Write-Host "START-SLEEP: $t seconds"  -ForegroundColor Yellow
        
        Start-Sleep -Seconds $t
        Wait-ECI.EMI.Automation.VM.InvokeVMScript
    }
    else
    {
        Write-Host "VM has completed OS Customization"-ForegroundColor Cyan
    }
}

function Test-ECI.EMI.Automation.VM.InvokeVMScript
{
    Param([Parameter(Mandatory = $true)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $ScriptText =  { 
    
        ### Test VM Tools Service
        #$VMTools = Get-Service -Name VMTools  
        #Write-Host "VMTools Status: " $VMTools.Status

        ### Test New File
        $TestPath = "C:\Temp"
        if(-NOT(Test-Path -Path $TestPath)) {(New-Item -ItemType directory -Path $TestPath -Force | Out-Null)}

        $TestFile = $TestPath + "\" + "deleteme.txt"
        New-Item $TestFile -ItemType file -Force

        if([System.IO.File]::Exists($TestFile))
        {
            Write-Host "TEST FILE: Exists."
        }
        elseif(-NOT([System.IO.File]::Exists($TestFile)))
        {
            Write-Host "TEST FILE: Failed!!!"
            $Abort = $True
            Write-ECI.ErrorStack
        }
    }
    Write-Host "Test-ECI.EMI.Automation.VM.InvokeVMScript..." -ForegroundColor Cyan
    $TestInvoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword
    Write-Host "TestInvoke.ExitCode:" $TestInvoke.ExitCode -ForegroundColor Gray
    Write-Host "TestInvoke.ScriptOutput:" $TestInvoke.ScriptOutput -ForegroundColor DarkGray

    if($TestInvoke.ExitCode -eq 0)
    {
        Write-Host "INVOKE TEST: Succeded." -ForegroundColor Green
    }
    elseif($TestInvoke.ExitCode -ne 0)
    {
        Write-Host "INVOKE TEST: Failed. Retrying ..." -ForegroundColor Red
        Start-ECI.EMI.Automation.Sleep -t 60
        Test-ECI.EMI.Automation.VM.InvokeVMScript
    }
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Test.ECI.EMI.VM.GuestReady-notneeded???
{
    Param([Parameter(Mandatory = $true)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $VMguestOperationsReady  = (Get-VM -Name $VMName).ExtensionData.guest.guestOperationsReady   ### <---- RETURN: True/False

<#
    $RetryCount = 5
    for ($i=1; $i -le $RetryCount; $i++)
    {

    }
#>

    if($VMguestOperationsReady -eq $False)
    {
        Write-Host "Guest OS Not Ready." -ForegroundColor Yellow
        Start-ECI.EMI.Automation.Sleep -t $WaitTime_StartSleep
        Test.ECI.EMI.VM.GuestReady
    }
    elseif($VMguestOperationsReady -eq $True)
    {
        Continue
    }
    else
    {
        Write-Host "Server not responding. `n Exiting!" -ForegroundColor Red
        #Exit
    }
}

function Stop-ECI.EMI.Automation.VM
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    Write-Warning "Stopping VM: $VMName" -WarningAction Continue
    #Write-Host "Stopping VM: $VMName" -ForegroundColor Yellow
    Stop-VM $VMName -Confirm:$false
    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function Restart-ECI.EMI.Automation.VM #<--deleteme???
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $t = $WaitTime_VMTools
    Write-Host "Restarting VM: $VMName in $t seconds."
    Start-Sleep -seconds $t

    Restart-VM -VM $VMName -Confirm:$false
    Wait-ECI.VMTools -VM $VMName -t $t


}


function Mount-ECI.EMI.Automation.VM.ISO
{
    param(
    [Parameter(Mandatory = $True,Position=0)][string]$ISOName,
    [Parameter(Mandatory = $True,Position=1)][string]$VMName
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    Write-Host "Getting ISO from SQL: " $ISOName -ForegroundColor Cyan

    #$isoDataSore = "cloud_staging_pub_lhc"
    #$isoDataSoreFolderPath = "ISO/Current/Microsoft"
    #$isoDataSoreFileName = "SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO"
    
    ### Get ISO Parameters from DB
    ###---------------------------------
    $DataSetName = "ISOParameters"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionISOs WHERE ISOName = '$ISOName'"
    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query

    try
    {
        ### Get ISO from Datastore
        $ISODataStoreFile = $((Get-Datastore $isoDataStore).DatastoreBrowserPath + $isoDataStoreFolderPath) + "/" + $isoDataStoreFileName 
        $DatastoreFullPath = (Get-Item $ISODataStoreFile).DatastoreFullPath

        ### Mount ISO
        ###---------------------------------        
        #Get-CDDrive -VM $VMName | Set-CDDrive -IsoPath $DatastoreFullPath -StartConnected:$true -Connected:$true -Confirm:$false
        Get-CDDrive -VM $VMName | Set-CDDrive -IsoPath $DatastoreFullPath -Confirm:$false | select *
        Start-ECI.EMI.Automation.Sleep -t 30
        (Get-CDDrive -VM $VMName | Set-CDDrive -connected $true -Confirm:$false).ISOPath
    }
    catch
    {
        Write-ECI.ErrorStack
    }

    function Check-ECI.VM.State
    {
        ### Check VM State
        ###-------------------------------
        $Message = (Get-VMQuestion -VM $VMName).Text
        if($Message)
        {
            if( $Message.Conains("The operation on file") -AND $Message.Conains("failed") )
            {
                if( ((Get-VMQuestion -VM $VMName).Options.Summary).Contains("Retry") | Out-Null)
                {
                    Get-VM -Name $VMName | Get-VMQuestion | Set-VMQuestion �Option button.retry -Confirm:$false
                }
            }
        }
    }
    #Check-ECI.VM.State

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    Return $ISODataStoreFile
}

function Restart-ECI.VMGuest-deleteme #<--deleteme???
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray
    
    $t = $WaitTime_GuestOSRestart
    Write-Host "Restarting VM: $VMName in $t seconds."
    Start-Sleep -seconds $t

    Restart-VMGuest -VM $VMName -Confirm:$false
    #Restart-VMGuest -VM $VMName -Server $VIServer | Wait-Tools | Out-Null
    
    #Wait-ECI.VMTools -VM $VMName -t $t
}

function Decommission-ECI.VM
{

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    ### Stop VM if Started
    $PowerState = (Get-VM $VMName | Select PowerState).PowerState
 
    if($PowerState -eq "PoweredOn")     #PoweredOff
    {
        Write-Host "WARNING! STOPPING VM: $VMName" -ForegroundColor Red
        Stop-VM $VMName -Confirm:$false    
    }

    ### Record VM to SQL
    Get-DecommissionData -ServerID $ServerID
    
    #### Write-DecomtoSQL

    ### Delete VM
    Write-Host "WARNING! DELETING VM: $VMName" -ForegroundColor Red
    Remove-VM $VMName -DeletePermanently -Confirm:$false

}

function Delete-ECI.VMs
{
    #### need to add CmdletBinding ShouldProcess
    
    
    ######################################################################################################
    ### *** DANGER: *** Set $Filter carefully!!! This function could potentially delete the wrong VM's.
    ######################################################################################################

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $FilTer = "ETEST040_Test-LD5*"

    Write-Host "Cleaning Up Test VM's." -ForegroundColor Yellow

    #$VMs = Get-VM | Where-Object {$_.Name -like "*_GEEMO001*"} # LAB
    
    $VMs = Get-VM | Where-Object {$_.Name -like $Filter} # LD5

    foreach($VM in $VMs)
    {
        if($VM.PowerState -eq "PoweredOn")
        {
            Write-Host "Stopping VM: " $VM -ForegroundColor DarkGray
            Stop-VM $VM -Confirm:$false -ErrorAction Continue
        }
        Write-Host "Deleting VM: " $VM -ForegroundColor Red
        
        ### Set Confirm = True
        Remove-VM $VM -DeletePermanently -Confirm:$true -ErrorAction Continue 
    }
}

function Add-ISOtoDatastore
{
    ### Add ISO
    $Datastore = "nfs_emsadmin_sas1"
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    #DIR $ISODataStore

    ### Get Datastore Items
    (Get-ChildItem $ISODataStore).Name
    
    $ItemFolder = "C:\Scripts\New_ISO\"
    #$ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM2.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $ItemFile = "VMware-tools-windows-10.1.0-4449150.iso"

    $Item = $ItemFolder + $ItemFile

    Copy-DatastoreItem -Item $Item -Destination $ISODataStore 


    #Get-VM -Name SDGRP008 | Get-CDDrive | `
    #Set-CDDrive -IsoPath "[$Datastore] ISOfiles\0.iso" -Confirm:$false


    ### Remove ISO
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $Item = $ISODataStore + $ItemFile
    
    Remove-Item $Item 
}

function Get-Vix.Version
{
    $propertiesVix =[System.Diagnostics.FileVersionInfo]::GetVersionInfo($env:programfiles + '\VMware\VMware VIX\VixCOM.dll')
    $majorVix = $propertiesVix.FileMajorPart
    $minorVix = $propertiesVix.FileMinorPart
    $buildVix = $propertiesVix.FileBuildPart
    $versionVix = ([string]$majorVix + '.' + [string]$minorVix + '.' + [string]$buildVix)
    if(($pCLIMajor -eq 5 -and $versionVix -eq '1.10.0') -or ($pCLIMajor -eq 4 -and $versionVix -eq '1.6.2'))
    {
        $condVix = $true
    }
}

function Get-VMTools.Version
{
    Param([Parameter(Mandatory = $True)][string]$VMName)

    <#	
        Operation mode of guest operating system:
        "running" - Guest is running normally.
        "shuttingdown" - Guest has a pending shutdown command.
        "resetting" - Guest has a pending reset command.
        "standby" - Guest has a pending standby command.
        "notrunning" - Guest is not running.
        "unknown" - Guest information is not available.
    #>

    $VMGuestToolsVersion = Get-VM -Name $VMName | Get-VMGuest | Select ToolsVersion
    Write-Host "VMGuestToolsVersion : " $VMGuestToolsVersion

    $GuestExtensionData = Get-VM -Name $VMName | Select -expandproperty ExtensionData | Select -expandproperty Guest 
    Write-Host "GuestExtensionData  : " $GuestExtensionData
}

function Get-PowerCLI.Version
{
    Get-PowerCLIVersion 
}

function Restart-ECI.EMI.VM.VMTools
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `r`n('-' * 75)`r`n "EXECUTING FUNCTION: " $FunctionName `r`n('-' * 75) -ForegroundColor Gray

    $StopVMTools = {(Get-WmiObject -Computer . win32_service -filter "name='VMtools'").StopService()}

    $StartVMTools = {(Get-WmiObject -Computer . win32_service -filter "name='VMtools'").StartService()}            

    Write-Host "Invoking: Stop-Tools " -ForegroundColor Yellow
    try
    {
        Invoke-VMScript -ScriptText $StopVMTools -VM $VMName -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction Continue -ErrorVariable ECIError
    }
    catch
    {
        Write-Host "ERROR STOPPING VMTOOLS: "  -ForegroundColor Red
        Write-Host "ERROR[0]: "$Error[0] -ForegroundColor Red
    }

    Start-ECI.EMI.Automation.Sleep -t 60
    Write-Host "Invoking: Start-Tools " -ForegroundColor Yellow
    Invoke-VMScript -ScriptText $StartVMTools -VM $VMName -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction Continue -ErrorVariable ECIError

    Write-Host `r`n('-' * 50)`r`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}


