﻿cls

Import-Module SqlServer 

### SQL Server
###--------------------------------------------------------------------
$SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
Write-Host "SQLServer: " $SQLServer -ForegroundColor Magenta
#Set-Location $SQLServer


### Instance (Database)
###--------------------------------------------------------------------
$Instance = "ServerConfiguration-Dev-Lab"
$Instance = Get-ChildItem -Path $SQLServer | Where-Object {$_.Name -eq $Instance}
Write-Host "Instance: " $Instance -ForegroundColor Yellow
Set-Location $SQLServer


### Tables
###--------------------------------------------------------------------
$TablePath = $SQLServer + "\" + $Instance + "\Tables"
Set-Location SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases\ServerConfiguration-Dev-Lab\Tables
$AllTables = Get-ChildItem #-Path $TablePath
Write-Host "AllTables: " $AllTables

foreach($Table in $AllTables)
{
    Write-Host "Table: " $Table -ForegroundColor Gray
}


### tblServerRequest
###--------------------------------------------------------------------
$tblServerRequest = "Server.Request"
$tblServerRequest = Get-ChildItem | Where-Object {$_.Name -eq $tblServerRequest}
Write-Host "tblServerRequest: " $tblServerRequest -ForegroundColor Cyan


### Query
###--------------------------------------------------------------------
$SQLQuery = "Select * from $tblServerRequest WHERE ServerTemplate = '2016Server'"
$QueryResults = Invoke-Sqlcmd -Query $SQLQuery -ServerInstance $SQLInstance #-Username $SQLUsername -Password $SQLPassword

Write-Host "QueryResults: " $QueryResults.Count

foreach($Row in $tblServerRequest)
{
    #Write-Host "Row: " $Row[0] -ForegroundColor Yellow
}


exit


### Database
#$SQLInstance = ".\SQLEXPRESS"
#$SQLInstance = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
$SQLInstance = "ECILAB-BOSDEV01\SQLEXPRESS"

$SQLDatabase = "ServerConfiguration-Dev-Lab"
#$SQLUsername = "sa"
#$SQLPassword = "Password123!" 

### Query
#$SQLQuery = "Select * from dbo.[Config.Definition.OSParameters] WHERE ServerTemplate='2016Server'"
$SQLQuery = "Select * from [Config.Definition.OSParameters] WHERE ServerTemplate='2016Server'"

Invoke-Sqlcmd -Query $SQLQuery -ServerInstance $SQLInstance #-Username $SQLUsername -Password $SQLPassword
Invoke-Sqlcmd