﻿cls

#“Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;”

$Query = “SELECT * FROM definitionOSParameters"
Invoke-Sqlcmd -ServerInstance 'automate1.database.windows.net' -Database 'DevOps' -Username 'devops' -Password "JKFLKA8899*(*(32faiuynv" -Query $Query 