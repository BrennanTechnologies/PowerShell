﻿

### Parameters
$Server =  "ECILAB-BOSDEV01\SQLEXPRESS"
$Database = "ServerConfiguration-Dev-Lab"
$Query = "Select * from dbo.[Config.Definition.OSParameters] WHERE ServerTemplate='2016Server'"
$ServerTemplate = "2016Server"

### Create Database Connection
$Connection = New-Object System.Data.SQLClient.SQLConnection
$Connection.ConnectionString = "server=$($Server);database=$($Database);trusted_connection=true;"
$Connection.Open()
### Execute SQL Query
$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$Command.CommandText = $Query
#
        
<#
### Get Datatable
$Reader = $Command.ExecuteReader()
$Datatable = New-Object System.Data.DataTable
$Datatable.Load($Reader)
#$Datatable
#>



#
### User DataAdapter & DataSet
$DataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command
$Dataset = New-Object System.Data.Dataset
$DataAdapter.Fill($Dataset) | Out-Null
#$DataSet.Tables[0]
#$DataSet.Tables[1]
#>
                
#$DataSet.Tables

$DataSet.Tables[0].Rows[0]["ServerTemplate"]

write-host "is array: " ($DataSet.Tables -is [Array]) -ForegroundColor Magenta
#$Datatable | Get-Member
#$Datatable.GetType();

#$ServerTemplate = $OSParameters.ServerTemplate
        

### Close Database Connection
$Connection.Close()
