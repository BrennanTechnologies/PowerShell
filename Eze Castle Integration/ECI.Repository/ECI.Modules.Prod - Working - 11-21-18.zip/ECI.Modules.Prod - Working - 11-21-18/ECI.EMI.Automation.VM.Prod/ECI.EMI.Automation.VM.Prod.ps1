###################################
### VM Provioning Script
### ECI.EMI.Automation.VM.Prod.ps1
###################################
Param(
        [Parameter(Mandatory = $True)][int]$ServerID,
        [Parameter(Mandatory = $True)][string]$Environment,
        [Parameter(Mandatory = $True)][string]$ConfigurationMode
     )

&{
    BEGIN
    {
        ### Write Header Information
        ###---------------------------------
        Write-Host `r`n`r`n('*' * 100)`r`n (' ' * 20)" --------- STARTING VM PROVISIONING --------- " `r`n('*' * 100)  -ForegroundColor Cyan
        Write-Host ('-' * 50)`r`n                                                                                      -ForegroundColor DarkCyan
        Write-Host "Env         : " $Env                                                                               -ForegroundColor DarkCyan
        Write-Host "Environment : " $Environment                                                                       -ForegroundColor DarkCyan
        Write-Host "Script      : " (Split-Path (Get-PSCallStack)[0].ScriptName -Leaf)                                 -ForegroundColor DarkCyan
        Write-Host `r`n('-' * 50)`r`n                                                                                  -ForegroundColor DarkCyan
        
        ### Script Setup
        ###---------------------------------
        $script:VMStartTime = Get-Date
        $global:VerifyErrorCount = 0 ### Reset Verify Error Counter
        Connect-ECI.EMI.Automation.VIServer -InstanceLocation $InstanceLocation
    }

    PROCESS 
    {
        ###---------------------------------
        ### Get vCenter Resources
        ###---------------------------------
        Get-ECI.EMI.Automation.VM.Resources.ResourcePool -GPID $GPID
        Get-ECI.EMI.Automation.VM.Resources.PortGroup -GPID $GPID
        Get-ECI.EMI.Automation.VM.Resources.DataStore -Environment $Environment -ServerRole $ServerRole
        Get-ECI.EMI.AutoMation.VM.VMTemplate

        ###======================================================
        ### Create New VM
        ###======================================================
        Write-Host "CREATING NEW VM           : " 
        Write-Host "ConfigurationMode         : "   $ConfigurationMode
        Write-Host "VMName                    : "   $VMName
        Write-Host "ECIVMTemplate             : "   $ECIVMTemplate
        Write-Host "OSCustomizationSpecName   : "   $OSCustomizationSpecName
        Write-Host "ResourcePool              : "   $ResourcePool
        Write-Host "OSDataStore               : "   $OSDataStore
        Write-Host "PortGroup                 : "   $PortGroup
        Write-Host "IPv4Address               : "   $IPv4Address
        Write-Host "SubnetMask                : "   $SubnetMask
        Write-Host "DefaultGateway            : "   $DefaultGateway
        Write-Host "PrimaryDNS                : "   $PrimaryDNS
        Write-Host "SecondaryDNS              : "   $SecondaryDNS

        $NewVMParameters = @{
            ConfigurationMode                 = $ConfigurationMode
            VMName                            = $VMName
            ECIVMTemplate                     = $ECIVMTemplate
            OSCustomizationSpecName           = $OSCustomizationSpecName
            ResourcePool                      = $ResourcePool
            OSDataStore                       = $OSDataStore
            PortGroup                         = $PortGroup
            IPv4Address                       = $IPv4Address
            SubnetMask                        = $SubnetMask
            DefaultGateway                    = $DefaultGateway
            PrimaryDNS                        = $PrimaryDNS
            SecondaryDNS                      = $SecondaryDNS
        }
        
        ### Create New VM (ECI Cmdlet))
        ###------------------------
        New-ECI.EMI.Automation.VM @NewVMParameters
        
        ### Set UUID + MoRef
        ###------------------------
        Set-ECI.EMI.Automation.VM.ServerUUID

        ### Configure Hard Disks
        ###-----------------------
        Configure-ECI.EMI.Automation.VM.HardDisks
        New-ECI.EMI.Automation.VM.HardDisk.PageFile -VMName $VMName

        ### Configure CPU & Memoery
        ###-----------------------
        Set-ECI.EMI.Automation.VM.VMCPU
        Set-ECI.EMI.Automation.VM.VMMemory

        ### Start VM
        ###-----------------------
        Start-ECI.EMI.Automation.VM

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Start-ECI.EMI.Automation.Sleep -t $WaitTime_OSCustomization -Message "Waiting for OS Customization to Complete."
#Wait-ECI.EMI.Automation.VM.OSCusomizationSpec -VMName $VMName            #<--| combine
#Wait-ECI.EMI.Automation.VM.InvokeVMScript                               #<--| combine
#Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName                       #<--| combine
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        ### Write Logs to SQL
        ###------------------------
        Write-ECI.EMI.Automation.VMLogstoSQL
    }

    END
    {
        $VMStopTime = Get-Date
        $global:VMElapsedTime = ($VMStopTime-$VMStartTime)
        Write-Host `r`n`r`n('=' * 75)`r`n "VM Configuration: Total Execution Time:`t" $VMElapsedTime `r`n`r`n('=' * 75)`r`n -ForegroundColor Gray
        Write-Host "END VM CONFIGURATION SCRIPTS" -ForegroundColor Gray
        ### END VM PROVISIONING SCRIPT
    }
}