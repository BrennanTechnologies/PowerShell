﻿Param(
    [Parameter(Mandatory = $True,Position=0)][string]$Env,
    [Parameter(Mandatory = $True,Position=1)][string]$VMName,
    [Parameter(Mandatory = $True,Position=2)][string]$VMMoRef,
    [Parameter(Mandatory = $True,Position=3)][string]$VMUUID
    
)

#Power Off
if($Request = "PowerOn")
{

    
}

#Power On
elseif($Request = "PowerOff")
{
    

}
