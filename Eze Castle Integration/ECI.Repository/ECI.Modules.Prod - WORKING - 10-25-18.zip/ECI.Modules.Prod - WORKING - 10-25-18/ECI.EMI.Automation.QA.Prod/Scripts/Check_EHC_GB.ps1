﻿#Prompts for MS Domain and runs through QA checks
#
#Version 1.1 3/14/2018 Rob West - ECI


#Connect to MSOL
$username = "rwest@eciadmingb.onmicrosoft.com"
$password = Read-Host -Prompt 'Enter MSOnline password' -AsSecureString
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $password
Connect-MsolService -Credential $cred

#Prompt for Tenant Domain
$domain = Read-Host -prompt 'Input Microsoft Tenant Domain (domain.onmicrosoft.com)'
$guid = Get-MsolPartnerContract -DomainName $domain
$guid = $guid.TenantId.guid

#AD Settings
$ADConnectStatus = Get-MsolCompanyInformation -TenantId $guid | FL -Property DisplayName,DirectorySynchronizationEnabled,LastDirSyncTime,LastPasswordSyncTime 
$FederationStatus = Get-MsolDomain -TenantId $guid
$UserStatus = Get-MsolUser -TenantId $guid | FL -Property DisplayName,IsLicensed,Licenses,ProxyAddresses

Write-Host -ForegroundColor DarkGreen "Federation and AD Connect Status:" 
Write-Output $FederationStatus
Write-Output $ADConnectStatus

Write-Host -ForegroundColor DarkGreen "Licensing and Proxy Addresses:" 
Write-Output $UserStatus


#Connect to MSOL Exchange
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.outlook.com/powershell-liveid?DelegatedOrg=$domain -Credential $cred -Authentication Basic -AllowRedirection -erroraction silentlycontinue
Import-PSSession $Session -DisableNameChecking | out-null

#ActiveSync Settings:
$lockbox=get-organizationconfig
$activesyncquarantine=Get-ActiveSyncOrganizationSettings
$activesyncencryption= Get-MobileDeviceMailboxPolicy
$autoforward=Get-RemoteDomain

#Write-Host -ForegroundColor DarkGreen "Lockbox Enabled (Should be True):" 
#Write-Output $lockbox.CustomerLockboxEnabled

Write-Host -ForegroundColor DarkGreen "OAuth2 Enabled (Should be True):" 
Write-Output $lockbox.OAuth2ClientProfileEnabled

Write-Host -ForegroundColor DarkGreen "ActiveSync Quarantine Status (Should be Quarantined):" 
Write-Output $activesyncquarantine.defaultaccesslevel

Write-Host -ForegroundColor DarkGreen "ActiveSync Encryption Enabled (Should be True):" 
Write-Output $activesyncencryption.RequireDeviceEncryption

Write-Host -ForegroundColor DarkGreen "AutoForward Enabled (Should be False):" 
Write-Output $autoforward.AutoForwardEnabled

Write-Host -ForegroundColor DarkGreen "AutoReply Enabled (Should be False):" 
Write-Output $autoforward.AutoReplyEnabled


#Connect to Skype/Lync
$cssession=new-csonlinesession -overrideadmindomain $domain -Credential $cred
import-pssession $cssession  | out-null

#Skype/Lync settings:
$lyncoauth=Get-CsOAuthConfiguration	

Write-Host -ForegroundColor DarkGreen "Skype/Lync OAuth2 (Should be Allowed):" 
Write-Output $lyncoauth.ClientAdalAuthOverride

#Clear variables and drop PS sessions
Clear-Variable ADConnectStatus,FederationStatus,UserStatus,lockbox,activesyncquarantine,activesyncencryption,autoforward,lyncoauth
Get-PSSession | remove-pssession