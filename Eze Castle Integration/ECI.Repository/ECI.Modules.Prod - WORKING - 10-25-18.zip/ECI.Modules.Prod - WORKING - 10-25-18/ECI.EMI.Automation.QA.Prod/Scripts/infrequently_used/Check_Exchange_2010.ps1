﻿#Displays ECI Standard configuration information for Exchange 2010 Servers.
#
#Version 1.1 9/23/2013 Rob West - ECI



#Exchange Server information

write-host""

write-host -ForegroundColor cyan "Exchange Servers"

Get-ExchangeServer  | fl -property name,site,domain,edition,ServerRole,AdminDisplayVersion


#Disk information for every Exchange Server

$servers = Get-ExchangeServer

write-host -ForegroundColor cyan "Disk Information"

foreach ($server in $servers)
{
	write-host ""
	write-host -ForegroundColor Green $server.fqdn
	
	$Disks=Get-WmiObject -Class Win32_logicalDisk -Filter "DriveType=3" -computer $server.fqdn

	foreach($Disk in $Disks)
	{
		$usedsize=(($disk.size)-($Disk.FreeSpace))/1gb
		$usedsize=[math]::truncate($usedsize)

        $freesize=($Disk.FreeSpace)/1gb
		$freesize=[math]::truncate($freesize)

        $totalsize=($Disk.size)/1gb
		$totalsize=[math]::truncate($totalsize)
        
		
        write-host "Total Size" $Disk.DeviceID $Disk.VolumeName $totalsize "GB"
        write-host "Used" $Disk.DeviceID $usedsize "GB"
        write-host "Free" $Disk.DeviceID $freesize "GB"

    }
}


write-host ""
write-host ""

#Mailbox Server Configuration

write-host -ForegroundColor cyan "Mailbox Server Configuration"

Get-MailboxDatabase | fl -Property Name,Server,ReplicationType,JournalRecipient,MailboxRetention,DeletedItemRetention,RetainDeletedItemsUntilBackup,EdbFilePath,LogFolderpath,OfflineAddressBook
Get-MailboxDatabase -status | fl -Property Name,LastFullBackup
Get-PublicFolderDatabase | fl -Property Name,Server,DeletedItemRetension,RetainDeletedItemsUntilBackup,EdbFilePath,LogFolderpath
Get-PublicFolderDatabase -status | fl -Property Name,LastFullBackup

#Message Tracking, Accepted Domains, and Email Address Policies

write-host ""

write-host -ForegroundColor cyan "Message Tracking, Accepted Domains, and Email Address Policies"

Get-Remotedomain | fl -property allowedooftype,autoreplyenabled,autoforwardenabled
Get-TransportServer  | fl -property name,messagetrackinglogenabled,messagetrackinglogmaxdirectorysize,messagetrackinglogmaxage,messagetrackinglogsubjectloggingenabled,connectivitylogpath,messagetrackinglogpath,routingtablelogpath,receiveprotocollogpath,sendprotocollogpath,messageexpirationtimeout,delaynotificationtimeout
get-accepteddomain | fl -property Name,DomainName,DomainType,Default
get-emailaddresspolicy | fl -property name,priority,EnabledPrimarySMTPAddressTemplate,Enabled 

write-host ""
write-host -ForegroundColor cyan "Send Connectors"
get-sendconnector | fl -property name,protocollogginglevel,maxmessagesize,fqdn,addressspaces,DnsRoutingEnabled,smarthosts,sourcetransportservers
write-host ""


#Transport Server Configuration

write-host -ForegroundColor cyan "Certificates"
write-host ""

$hubservers = Get-TransportServer

foreach ($hubserver in $hubservers)

{
	write-host -ForegroundColor Green $hubserver.name
	write-host ""
	Get-ExchangeCertificate -server $hubserver	| fl

	
}


write-host ""
	write-host -ForegroundColor cyan "Receive Connectors"
	get-receiveconnector | fl -property identity,name,maxmessagesize,fqdn,bindings,remoteipranges,protocollogginglevel,permissiongroups




write-host ""
write-host -ForegroundColor cyan "Transport Queues"

foreach ($hubserver in $hubservers)

{
	write-host ""
    	write-host -ForegroundColor Green $hubserver.name

	
	
	$config = [xml](Get-Content -Path "\\$hubserver\C$\Program Files\Microsoft\Exchange Server\V14\Bin\EdgeTransport.exe.config")
 	$config.configuration.appSettings.add | Where-Object {$_.key -like "*QueueDatabaseLoggingPath*"}
    	$config.configuration.appSettings.add | Where-Object {$_.key -like "*IPFilterDatabaseLoggingPath*"}
    	$config.configuration.appSettings.add | Where-Object {$_.key -like "*QueueDatabasePath*"}
    	$config.configuration.appSettings.add | Where-Object {$_.key -like "*IPFilterDatabasePath*"}
    	$config.configuration.appSettings.add | Where-Object {$_.key -like "*TemporaryStoragePath*"}
		

}

