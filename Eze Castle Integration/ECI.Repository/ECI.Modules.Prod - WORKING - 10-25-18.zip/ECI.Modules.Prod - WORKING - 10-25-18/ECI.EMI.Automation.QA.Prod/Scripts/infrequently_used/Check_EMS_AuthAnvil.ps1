﻿#Reads Active Directory for all server names and checks for EMS AuthAnvil Service URL settings and EMS Certificates.
#
#WinRM needs to be enabled on Server 2008 R2 (on by default on 2012 and higher)
#WinRM needs to be allowed inbound on Windows Firewall
#Version 1.0 9/8/2014 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

foreach ($server in $servers) 
{
    
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
        {
           
            $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey= $reg.OpenSubKey("SOFTWARE\Scorpion Software\AuthAnvilLogon")


            if ($regkey -eq $null)
                {
                write-host -ForegroundColor Red $server.Name "does not have AuthAnvil installed!"
                
                }

                if ($regkey -ne $null)
                    {
                    write-host -ForegroundColor Green $server.Name "Service URL:" $regkey.GetValue("ServiceURL")
                    write-host -ForegroundColor Green $server.Name "Secondary Service URL:" $regkey.GetValue("ServiceSecondaryURL")
                    }

                        If (Invoke-Command -ComputerName $server.DNSHostName {Test-Path -path cert:\LocalMachine\Root\47BEABC922EAE80E78783462A79F45C254FDE68B})
                        {
                        write-host -ForegroundColor Green "Root CA Certificate for $server.DNSHostname exists"
                        }


                           If (Invoke-Command -ComputerName $server.DNSHostName {Test-Path -path cert:\LocalMachine\CA\7C4656C3061F7F4C0D67B319A855F60EBC11FC44})
                           {
                           write-host -ForegroundColor Green "Intermediate Certificate for $server.DNSHostname exists"
                           }

                                else
                                {
                                write-host -ForegroundColor Red $server.Name "One or more Certificate(s) not installed!"{
                                }
                   
                    
                }
        }
    }
