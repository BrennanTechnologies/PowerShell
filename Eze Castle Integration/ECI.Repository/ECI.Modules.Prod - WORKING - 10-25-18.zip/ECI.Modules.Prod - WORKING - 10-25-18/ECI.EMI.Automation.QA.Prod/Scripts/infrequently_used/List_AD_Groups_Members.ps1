﻿#Read Active Directory for all security groups and displays members
#
#Version 1.0 9/13/2013 Rob West - ECI

import-module ActiveDirectory

$Groups = Get-ADGroup -Properties * -Filter *
Foreach($Group In $Groups)
{

Write-Host -foregroundcolor Green $Group.Name ":"
Get-ADGroupMember -identity $Group |  select Name
Write-Host ""

}