﻿#Read Active Directory for all server names and display disk time out settings.
#
#Version 1.0 8/21/2013 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"} 

foreach ($server in $servers)
{
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
    {
        if (Get-WmiObject -Class Win32_diskdrive -ComputerName $server.DNSHostName | Where-Object {$_.Model -like "NETAPP*"}) 
        {
              $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
              $regKey= $reg.OpenSubKey("SYSTEM\CurrentControlSet\Services\Disk")
        
                if ($regkey.GetValue("TimeOutValue") -ge '120') 
                 {
                    write-host -ForegroundColor Green $server.Name $regkey.GetValue("TimeOutValue")
                 }
                    else 
                        {
                        write-host -ForegroundColor Red $server.Name $regkey.GetValue("TimeOutValue")
                        }
        }
    }
 }  
   

   





