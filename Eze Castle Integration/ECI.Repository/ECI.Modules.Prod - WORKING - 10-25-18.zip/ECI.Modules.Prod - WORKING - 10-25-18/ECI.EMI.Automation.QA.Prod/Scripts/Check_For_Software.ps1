﻿#Read Active Directory for all server names and checks for specified software.
#
#Version 1.1 5/2/2018 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

foreach ($server in $servers) 
{
    
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
        {
            # Output server name and DNS hostname
            Write-Host -ForegroundColor Cyan "Server Name"
            $server.DNSHostname

            # Check for software
            Write-Host -ForegroundColor Green "Software"
           #Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%AuthAnvil%'"
            #Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%VMWare%'"
            #Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%Server Administrator%'"
            Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%Acronis%'"
            Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%Endpoint Protection%'"
           #Get-WmiObject -Class Win32_Product -ComputerName $server.DNSHostName -Filter "Name like '%Host Utilities%'"
        
        }
    }
