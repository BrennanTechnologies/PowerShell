﻿function PowerOnVM
{

}


function PowerOffVM
{

}


