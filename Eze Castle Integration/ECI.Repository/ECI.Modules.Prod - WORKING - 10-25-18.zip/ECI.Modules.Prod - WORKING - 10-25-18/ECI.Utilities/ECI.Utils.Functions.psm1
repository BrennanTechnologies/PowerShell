﻿

function Show-Colors
{
    [enum]::GetValues([System.ConsoleColor]) | Foreach-Object {Write-Host $_ -ForegroundColor $_} 
}

function Get-PSColors
{
    Get-PSReadlineOption | Select *color
}
