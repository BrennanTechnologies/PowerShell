﻿######################################
### Execute Commands In-Guest
### ECI.EMI.Automation.OS.InGuest.ps1
######################################

function Show-InGuestParameters
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50)

    $Params = @{
    Env                           = $Env
    Environment                   = $Environment
    Step                          = $Step
    VMName                        = $VMName
    ServerID                      = $ServerID
    ServerRole                    = $ServerRole
    HostName                      = $HostName
    ClientDomain                  = $ClientDomain
    IPv4Addres                    = $IPv4Address
    SubnetPrefixLength            = $SubnetPrefixLength
    DefaultGateway                = $DefaultGateway
    PrimaryDNS                    = $PrimaryDNS
    SecondaryDNS                  = $SecondaryDNS
    BuildVersion                  = $BuildVersion
    CDROMLetter                   = $CDROMLetter
    InternetExplorerESCPreference = $InternetExplorerESCPreference
    IPv6Preference                = $IPv6Preference
    NetworkInterfaceName          = $NetworkInterfaceName
    SMBv1                         = $SMBv1
    RDPResetrictionsPreference    = $RDPResetrictionsPreference
    RemoteDesktopPreference       = $RemoteDesktopPreference
    PageFileLocation              = $PageFileLocation
    PageFileMultiplier            = $PageFileMultiplier
    WindowsFirewallPreference     = $WindowsFirewallPreference
    AdministrativeUserName        = $AdministrativeUserName
    AdministrativePassword        = $AdministrativePassword
    LocalAdminName                = $LocalAdminName
    LocalAdminPassword            = $LocalAdminPassword
    }

    foreach($Param in $Params)
    {
        Write-Host $Param.Key "           :" $Param.Value
    }

    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}


function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\_VMAutomationLogs\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

& { 
    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        #Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #<--SET Path C:\Scripts\VMAutomation\Transcripts
        Start-ECI.EMI.Automation.Transcript -TranscriptPath "C:\Scripts\_VMAutomationLogs\Transcripts\" -TranscriptName "ECI.EMI.Configure.OS.InGuest.$Env.ps1.Step-$Step"
        Write-Host "`n" ("=" * 75) "`nBEGIN BLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)
        Show-InGuestParameters
     }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "`n" ("=" * 75) "`nPROCESS BLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)

        ###----------------------------------------------
        ### STEP 1: Rename-ECI.LocalAdmin
        ###----------------------------------------------
        if ($Step -eq "Rename-ECI.EMI.Configure.OS.LocalAdministrator")
        {
            #Start-Transcript
            Rename-LocalAdministrator
            #Stop-Transcript
        }

        ###----------------------------------------------
        ### STEP 2: Rename-ECI.GuestComputer
        ###----------------------------------------------
        if ($Step -eq "Rename-ECI.EMI.Configure.OS.GuestComputer")
        {
            #Start-Transcript
            Rename-ECI.EMI.Configure.OS.GuestComputer
            Restart-ECI.EMI.Configure.OS.GuestComputer
            #Stop-Transcript
        }

        ###----------------------------------------------
        ### STEP 3: Configure OS
        ###----------------------------------------------
        if ($Step -eq "Configure-ECI.EMI.Configure.OS.GuestComputer")
        {
            Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 

            #Start-Transcript
           
            Configure-ECI.EMI.Configure.OS.NetworkInterface
           # Configure-ECI.EMI.Configure.OS.SMBv1
            Configure-ECI.EMI.Configure.OS.IPv6
            Configure-ECI.EMI.Configure.OS.CDROM
            Configure-ECI.EMI.Configure.OS.RemoteDesktop 
            Configure-ECI.EMI.Configure.OS.WindowsFirewallProfile
            Configure-ECI.EMI.Configure.OS.InternetExplorerESC
            Configure-ECI.EMI.Configure.OS.WindowsFeatures
            Initialize-ECI.EMI.Configure.OS.HardDisks
            Configure-ECI.EMI.Configure.OS.Folders
            

            # ~~~ cUrReNt dEvoL0PmEnt~~~
            Configure-ECI.EMI.Configure.OS.PageFileLocation   #<------ COMBINE
            Configure-ECI.EMI.Configure.OS.PageFileSize       #<------ COMBINE

            Configure-ECI.EMI.Configure.OS.JoinDomain

            #Stop-Transcript
        }

        ###----------------------------------------------
        ### STEP 4: Configure Roles
        ###----------------------------------------------
        Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 
        #Start-Transcript

        switch ( $Step )
        {
            "2016Server" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }

            "2016FS" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016DC" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016DCFS" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016VDA" 
            {
                Write-Host $Step
                Import-Module ECI.EMI.Automation.Role.Citrix.Dev -DisableNameChecking
                Install-ECI.XenDesktopVDA 
                Configure-CrossForest
                Install-XenDesktopStudio
        
            }
            "2016SQL" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016SQLOMS"  
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
        }
        #Stop-Transcript
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "`n" ("=" * 75) "`nEND BLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)
        #Write-ServerBuildTag                                                               # <---- write new Server Build Tag function !!!!!!!!!!!!!!!
        Stop-Transcript
    }
}
