﻿cls


Start-Transcript

#######################
### Params
#######################

$InstanceLocation = "LD5"
$InstanceLocation = "QTS"
#$GPID = "GEEMO001"


#corp.ercolanoam.com


### --------------------------------------------------
### Import-VMWareModules
### --------------------------------------------------
function Import-VMWareModules
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $env:PSModulePath = $env:PSModulePath + ";" + "C:\Program Files (x86)\VMware\Infrastructure\vSphere PowerCLI\Modules"

    $VMModules = "VMware*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Teh VMAware Modules are not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
}

###-----------------------------------------------
### Get vCenter Location
###-----------------------------------------------
function Get-ECI.vCenter
{
   Param([Parameter(Mandatory = $True)][string]$InstanceLocation)

   $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    switch ( $InstanceLocation )
    {
        "Lab" { $ECIvCenter = "ecilab-bosvcsa01.ecilab.corp"}
        "BOS" { $ECIvCenter = "bosvc.eci.cloud"      }
        "QTS" { $ECIvCenter = "cloud-qtsvc.eci.corp" }
        "SAC" { $ECIvCenter = "sacvc.eci.cloud"      }
        "LHC" { $ECIvCenter = "lhcvc.eci.cloud"      }
        "LD5" { $ECIvCenter = "ld5vc.eci.cloud"      }
        "HK"  { $ECIvCenter = "hkvc.eci.cloud"       }
        "SG"  { $ECIvCenter = "sgvc.eci.cloud"       }
    }

    $global:ECIvCenter = $ECIvCenter

    Write-Host "Setting Instance Location: " $InstanceLocation "vCenter: " $ECIvCenter -ForegroundColor Yellow
}

###-----------------------------------------------
### Connect to vCenter
###-----------------------------------------------
function Connect-ECI.vCenter
{
        Write-Host "Connecting New Session to VI Server: "  $ECIvCenter -ForegroundColor Gray
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false | Out-Null
        #$VISession = Connect-VIServer -Server $ECIvCenter  -User sdesimone_admin@ecilab.corp -Password cH3r0k33!B
        $VISession = Connect-VIServer -Server $ECIvCenter  -User ezebos\cbrennan -Password Tolkien43741
}

###-----------------------------------------------
### Import GPIDs
###-----------------------------------------------
function Import-GPIDs
{
    #$GPIDs = Import-Csv -Path "X:\ServerRequest\Get-vCenterResources\GPIDs.csv"
    
    $GPIDs = "611"
    
        foreach($GPID in $GPIDs)
    {
        Write-Host "GPUD: " $GPID.gpid
    }
}

function Get-CompanyConfiguration
{
    Param([Parameter(Mandatory = $True)][int]$RequestID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Parameters
    ###---------------------------
    $DataSetName = "ServerID"
    $ConnectionString = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    $Query = “SELECT Role FROM CompanyConfiguration WHERE CompanyID = '$CompanyID'”
    
    ### Execute Query
    ###---------------------------
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)
    
    ### Return Values
    ###----------------------------
    foreach ($Datarow in $DataTable.Rows)
    {
       #Write-Host "Value: " $DataTable.Columns 
       #Write-Host "Value: " $DataRow[0] 
       Set-Variable -Name $DataTable.Columns -Value $DataRow[0] -Scope Global
    }
    Write-Host "Returned - ServerID: " $ServerID -ForegroundColor Yellow
}

###==============================================================================

###-----------------------------------------------
### Get Resource Pools
###-----------------------------------------------
function Get-ECI.ResourcePool
{
    param($GPID)

    #$script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    #Write-Host "Getting Resource Pools for GPID: $GPID" -ForegroundColor Magenta
    Write-Host "GPID: $GPID" -ForegroundColor Magenta

        ### Get Resource Pools
        $ResourcePools = (Get-ResourcePool -Location $Cluster | Where-Object {$_.Name -like "*$GPID*"}).Name

        ### Write All Resource Pools
        foreach($ResourcePool in $ResourcePools)
        {
            Write-Host "Resource Pool Found: $ResourcePool " -ForegroundColor Gray
        
            ### Select Resource Pool
            if($ResourcePools.Count -gt 1)
            {
                $EMS2    = $ResourcePools | Where-Object { $_ -like "ems2*" }
                $Multi   = $ResourcePools | Where-Object { ($_ -like "multi*") -AND ($_ -notlike "*ctx") }
                $Hybrid  = $ResourcePools | Where-Object { ($_ -like "hybrid*") -AND ($_ -notlike "*ctx") }
                $Hosted  = $ResourcePools | Where-Object { $_ -like "hosted_*" }
            
                if($EMS2)
                {
                    $ResourcePool = $EMS2
                }
                elseif($Multi)
                {
                    $ResourcePool = $Multi
                }
                elseif($Hybrid)
                {
                    $ResourcePool = $Hybrid
                }
                elseif($Hosted)
                {
                    $ResourcePool = $Hosted
                }
            }

            ### Only One Resource Pool
            elseif($ResourcePools.Count -eq 1)
            {
                $global:ResourcePool = $ResourcePools
            }

            ### Resource Pool Not Found
            elseif($ResourcePools.Count -eq 0)
            {
                Write-Host "No Resource Pool Found for GPID: $GPID" -ForegroundColor Red
            }
        }


    Write-Host "Selecting Resource Pool: $ResourcePool" -ForegroundColor Yellow
}


###-----------------------------------------------
### Get Resource Pools
###-----------------------------------------------
function Get-ECI.ResourcePool-old
{
    param($GPID)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    Write-Host "Getting Resource Pools for GPID: $GPID" -ForegroundColor Magenta

    $Clusters = Get-Cluster -Server $ECIvCenter

    foreach($Cluster in $Clusters)
    {
        $ResourcePools = (Get-ResourcePool -Location $Cluster | Where-Object {$_.Name -like "*$GPID*"}).Name


        ### Write All Resource Pools
        foreach($ResourcePool in $ResourcePools)
        {
            Write-Host "Resource Pool Found: $ResourcePool " -ForegroundColor Yellow
        }
        
        If($ResourcePools.Count -gt 1)
        {
            if(($ResourcePools | Where-Object {$_ -like "multi*"}))
            {
                $ResourcePools =  $ResourcePools | Where-Object {($_ -like "multi*") -AND $_ -notlike "*ctx"}

                foreach($ResourcePool in $ResourcePools)
                {
                    $ResourcePool = $ResourcePool
                    Write-Host "Resource Pool: " $ResourcePool  -ForegroundColor Green
                }
            }
                    
            $global:ResourcePool = $ResourcePool

       }
        else
        {
            $ResourcePool = $ResourcePools
        }

        ## Set variable scope to global
        $global:ResourcePool = $ResourcePool
    }
   
    Write-Host "Selecting Resource Pool: $ResourcePool" -ForegroundColor Cyan
}

###-----------------------------------------------
### Get ECI Cluster
###-----------------------------------------------
function Get-ECI.Cluster
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $global:Cluster = (Get-Cluster -Server $ECIvCenter | Get-ResourcePool -Name $ResourcePool).Name

    $global:Pod = $Cluster.Split("_")[2]

    Write-Host "Cluster Found: $Cluster" -ForegroundColor Cyan
    Write-Host "Pod Found: $Pod" -ForegroundColor Cyan
}

###-----------------------------------------------
### Get Port Group
###-----------------------------------------------
function Get-ECI.PortGroup
{
    param($GPID)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting Port Group for GPID: $GPID `n" -ForegroundColor Magenta

    $global:PortGroups = Get-VDPortgroup | Where-Object {$_.Name -Like "*$GPID*"} 
    #$global:PortGroups = Get-VirtualPortGroup | Where-Object {$_.Name -Like "*$GPID*"}
    
    foreach($PortGroup in $PortGroups)
    {
        Write-Host "Found - Port Group: " $PortGroup -ForegroundColor Yellow

        if ($PortGroup.Count -eq 1)
        {
            $PortGroup = $PortGroup
        }
        elseif ($PortGroup.Count -gt 1)
        {
            if(($PortGroup | Where-Object {$_.name -eq ("multi_" + $GPID )}) )
            {
                $PortGroup = ($PortGroup | Where-Object {$_.name -eq ("multi_" + $GPID )})
                        
                if ($PortGroup.Count -gt 1)
                {
                    $PortGroup =  $PortGroup | Select-Object -first 1
                }
            }
            else
            {

                $PortGroup = ($PortGroup | Where-Object {$_.name -like (*$GPID )})
                if ($PortGroup.Count -gt 1)
                {
                    $PortGroup =  $PortGroup | Select-Object -first 1
                }
            }
        }


        $global:PortGroup = $PortGroup
        Write-Host $PortGroup -ForegroundColor Green
        #Write-Host ($PortGroup | Where-Object {$_.name -like "multi*"}) -ForegroundColor Green
<#        
        if ( ($PortGroup | Where-Object {$_.name -eq ("multi_" + $GPID )}) )
        {
            $PortGroup = ($PortGroup | Where-Object {$_.name -eq ("multi_" + $GPID )})
        }
        elseif()
        {


        }
#>
       

        #if($PortGroups.Count -eq 1)
        #{
        #    $PortGroup = $PortGroups
        #}
        #if($PortGroups.Count -gt 1)
        #{
            
        #}
    
    }




<#
    elseif($PortGroups.Count -gt 1)
    {
        if(($PortGroups | Where-Object {$_.name -like "multi*"}))
        {
            $PortGroup =  $PortGroups | Where-Object {$_.name -like "multi*"}
            $PortGroup =  $PortGroups | Where-Object {$_.name -like "multi*"}
            if ($PortGroup.Count -gt 1)
            {
                $PortGroup =  $PortGroup | Select-Object -first 1   
            }
        }
        else
        {
            $PortGroup =  $PortGroups | Select-Object -first 1 # <--- Really!!!???
            #$PortGroup =  $PortGroups[0] # <--- Really!!!???
        }
    }
    else
    {
        $PortGroup =  $PortGroups | Select-Object -first 1 # <--- Really!!!???
        #$PortGroup =  $PortGroups[0] # <--- Really!!!???
    }
  #>  
    

    #Write-Host "Chosing Port Group: " $PortGroup -ForegroundColor Cyan
}

###-----------------------------------------------
### Get Data Store
###-----------------------------------------------
function Get-ECI.DataStore
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Finding Datastores for ProductType: " $ProductType -ForegroundColor Yellow


    <#
        # Naming Conventions
        #---------------------
         InstanceLocation_ProductType_Function_Pod

        # DiskType
        #---------------------
         Clinet_Files
         Client_DC_OS
         Client_DC_Swap

         Resource_OS
         Resource_Swap
         Resource_SQL

         data
         swap
         os
     #>
 

    switch ( $ProductType )
    {
        "Lab"    { $ResourcePool = "EMS2_"   + $GPID }
        "EMI"    { $ResourcePool = "EMS2_"   + $GPID }
        "Hybrid" { $ResourcePool = "Hybrid_" + $GPID }
        "Hosted" { $ResourcePool = "Hosted" + $GPID  }
        "EMS"    { $ResourcePool = "Multi_"  + $GPID }
    }

     $DiskTypes = @("data","swap","os")

     foreach($DiskType in $DiskTypes)
     {
         $DataStore = $InstanceLocation + "_" + $ProductType + "_" + $DiskType + "_" + $Pod
         Write-Host "Datastore: $Datastore"  -ForegroundColor Cyan
     } 
}


&{
    BEGIN
    {
        #Import-ECI.Root.ModuleLoader
        #Import-VMWareModules    
        Get-ECI.vCenter -InstanceLocation $InstanceLocation
        Connect-ECI.vCenter
    }

    PROCESS
    {
        

        #Import-GPIDs
        
        #(Get-ResourcePool -Location $Cluster | Where-Object {$_.Name -like "*$GPID*"}).Name
        #Get-ResourcePool | where {$_.name -like "*erc*"}| select name

        #<#
        $GPIDs = Import-Csv -Path "C:\Scripts\ServerRequest\GPIDs.csv"

        foreach($GPID in $GPIDs)
        {
            $GPID = $GPID.gpid
            #Get-ECI.ResourcePool -GPID $GPID
            Get-ECI.PortGroup -GPID $GPID
        }
        #>
      
      
      #Get-ECI.ResourcePool
        #Get-ECI.Cluster 
        Get-ECI.PortGroup
        #Get-ECI.DataStore


        #Get-ECI.PortGroup
        #Get-ECI.Switch
        #Get-ECI.Pod
        #Get-ECI.ResourceRool
        #Get-ECI.ProductType
        #Get-ECI.DataStore
        
        <#
        Write-Host `n('=' * 50)`n"`n`nParameters       : " `n('-' * 50)`n
        Write-Host "GPID             : $GPID"
        Write-Host "InstanceLocation : $InstanceLocation"

        Write-Host "`n`nResources Found  : " `n('-' * 50)`n
        Write-Host "ECIvCenter       : $ECIvCenter"
        Write-Host "PortGroup        : $PortGroup"
        Write-Host "Switch           : $Switch"
        Write-Host "Pod              : $Pod"
        Write-Host "ResourcePool     : $ResourcePool"
        Write-Host "ProductType      : $ProductType"

        
        Write-Host "DataStore        : $DataStore"
        Write-Host `n('=' * 50)`n
        #>
    }

    END{}
}

Stop-Transcript
