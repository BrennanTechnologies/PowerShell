﻿cls


Install-Module -Name AzureRM
Get-Module -Name AzureRM
Import-Module AzureRM
Get-Command -Module AzureRM
Connect-AzureRmAccount
Update-Module -Name AzureRM



$pscredential = Get-Credential
Connect-AzureRmAccount -ServicePrincipal -ApplicationId  "http://my-app" -Credential $pscredential -TenantId $tenantid


#Get-AzureSqlDatabaseServer
1
Get-AzureRmSqlServer



$params = @{
      'Database' = 'Automation1'
      'ServerInstance' = 'automate1.database.windows.net'
      'Username' = 'devops'
      'Password' = 'JKFLKA8899*(*(32faiuynv'
      'OutputSqlErrors' = $true
      'Query' = 'SELECT * FROM Servers'
}
Invoke-Sqlcmd @params


$server = " tcp:automate1.database.windows.net,1433" 
$database = "devops" 
$adminName = "devops" 
$adminPassword = "JKFLKA8899*(*(32faiuynv" 


$connectionString = "Server=$server;Database=$database;User ID=$adminName;Password=$adminPassword;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;" 
$connection = New-Object -TypeName System.Data.SqlClient.SqlConnection($connectionString)
	

exit



$ServerInstance = "CBRENNAN3420\SQLEXPRESS"
$DatabaseName = "ServerConfiguration"

$ServerInstance = "\\automate1.database.windows.net"
$DatabaseName = "DevOps"

Import-Module SqlServer 
Get-Command -Module SqlServer
Set-Location $ServerInstance



#Get-Command -Module SqlServer

#$Query = "SELECT dbo.[Config.Definition.ServerTemplates].* FROM dbo.[Config.Definition.ServerTemplates]"

#Set-Location "SQLSERVER:\SQL\MyComputer\MainInstance"

#Set-Location "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
#Invoke-Sqlcmd -Query $Query

#Get-SqlInstance -ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases

#Invoke-Sqlcmd -query 'Select * from dbo.[Config.Definition.ServerTemplates]' -ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases -Database ServerConfiguration  

Invoke-Sqlcmd -query 'Select * from dbo.[Config.Definition.ServerTemplates]' -Database ServerConfiguration  
##-ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases

