﻿
cls

### Parameters
$SQLServer =  "ECILAB-BOSDEV01\SQLEXPRESS"
#$SQLServer =  "ECILAB-BOSDEV01"

$SQLDatabase = "ServerConfiguration-Dev-Lab"
$SQLQuery = "Select * from defServerTemplates"

function Write-SQLTable
{

    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$Abort
    )

    $ServerTemplateName = "Testing1"

    #Open
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = "Data Source = ECILAB-BOSDEV01\SQLEXPRESS; Initial Catalog=ServerConfiguration; Integrated Security=SSPI;"
    $connection.Open()

    #Insert
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = "INSERT INTO [ServerConfiguration].[dbo].[Servers](ServerName) VALUES('{0}')" -f $ServerTemplateName
    #$cmd.CommandText = "INSERT INTO Servers(ServerName) VALUES('{0}')" -f $ServerTemplateName
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()

}

#Write-SQLTable