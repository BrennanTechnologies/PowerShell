﻿
cls

### Parameters
$SQLServer =  "ECILAB-BOSDEV01\SQLEXPRESS"
#$SQLServer =  "ECILAB-BOSDEV01"
$SQLDatabase = "ServerConfiguration-Dev-Lab"



$VM = "CB-SRV"
$FunctionName = "Test-Function"
$Verified = "True"
$Abort = "False"

function Write-SQLTable
{

    Param(
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$Abort
    )

    $ServerTemplateName = "Testing1"

    ### Open SQL Connection
    $Connection = New-Object System.Data.SqlClient.SqlConnection
    #$Connection.ConnectionString = "Data Source = ECILAB-BOSDEV01\SQLEXPRESS; Initial Catalog=[ServerConfiguration-Dev-Lab]; Integrated Security=SSPI;"
    #$Connection.ConnectionString = "Data Source = ECILAB-BOSDEV01\SQLEXPRESS; Initial Catalog=[ServerConfiguration-Dev-Lab]; Integrated Security=True;"
       
    #$Connection.ConnectionString="Server=ECILAB-BOSDEV01\SQLEXPRESS;Database=ServerConfiguration-Dev-Lab;User ID=svc_ConfigureServer;pwd=Tolkien4374"
    $Connection.ConnectionString="Server=ECILAB-BOSDEV01\SQLEXPRESS;Initial Catalog=[ServerConfiguration-Dev-Lab];User ID=svc_ConfigureServer;Password=Tolkien4374;"
    
    $Connection.Open()



    ### Create SQL Command
    $Cmd = New-Object System.Data.SqlClient.SqlCommand
    $Cmd.Connection = $Connection
   
    #$cmd.CommandText = "INSERT INTO [ServerConfiguration].[dbo].[Servers](ServerName) VALUES('{0}')" -f $ServerTemplateName

    $Cmd.CommandText = "INSERT Cookies VALUES (‘Server1’, ‘C’, 'True','False')"

    #$cmd.CommandText = "INSERT INTO Servers(ServerName) VALUES('{0}')" -f $ServerTemplateName
    
    $Cmd.ExecuteNonQuery() | Out-Null

    #Close
    #$Connection.Close()

}

Write-SQLTable -VM $VM -FunctionName $FunctionName -Verified $Verified -Abort $Abort

function write-test2
{
    ### SQL Connection
    $Connection = New-OBJECT SYSTEM.DATA.SqlClient.SQLConnection
    $Connection.ConnectionString = "Server=ECILAB-BOSDEV01\SQLEXPRESS;Database=[ServerConfiguration-Dev-Lab];Integrated Security=True;"
    $Connection.OPEN()

    ### SQL Command
    $SQLCmd = New-OBJECT SYSTEM.DATA.SqlClient.SqlCommand
    $SQLCmd.Connection = $Connection
    $SQLCmd.CommandText = "INSERT Cookies VALUES (‘Server1’, ‘C’, 'True','False')"
    $SQLCmd.ExecuteNonQuery()
    #$sqlCmnd.Parameters.ADD((New-OBJECT DATA.SQLClient.SQLParameter("@ServerName",[Data.SQLDBType]::VarChar, 255))) | OUT-NULL
    #$sqlCmnd.Parameters.ADD((New-OBJECT DATA.SQLClient.SQLParameter("@MemoryUsed",[Data.SQLDBType]::DECIMAL, 5,2))) | OUT-NULL
}