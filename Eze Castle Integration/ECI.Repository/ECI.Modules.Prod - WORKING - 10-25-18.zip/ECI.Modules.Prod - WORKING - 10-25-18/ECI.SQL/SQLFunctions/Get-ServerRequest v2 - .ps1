﻿cls

function Get-Parameters
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$SQLTable,
        [Parameter(Mandatory = $True)] [string]$Select,
        [Parameter(Mandatory = $True)] [string]$Where,
        [Parameter(Mandatory = $True)] [string]$Filter
    )

    if(!(Get-Module -Name SqlServer)){Write-Host "Importing Module: SQLServer";Import-Module SqlServer}

    ### Set the Database Location
    $SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    Set-Location $SQLServer

    ### Execute the SQL Query and return the Columns
    $SQLQuery = "Select $Select from $SQLTable WHERE $Where = '$Filter'"
    $SQLResults = Invoke-Sqlcmd -Query $SQLQuery  -Database $SQLDatabase
    $Columns = $SQLResults | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name} | Sort-Object -Property Name

    ### Create the Variables from each Column in the Table
    $global:Parameters = @()
    foreach($Column in $Columns)
    {
        Set-Variable -Name $Column -Value $SQLResults.$Column -Scope global
        $Parameters += Get-Variable -Name $Column 
    }
    Write-Host "Getting Paramter Set: " $ParameterSet -foregroundcolor yellow
    $Parameters | FT
}


### Get Server Request
$ParameterSet = "ServerRequest"
$SQLTable = "ServerRequest"
$Select = "*"
$Where = "RequestID"
$Filter = "4"

Get-Parameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter


### Get OS Parameters
$ParameterSet = "OSParameters"
$SQLTable = "configOSParameters"
$Select = "*"
$Where = "ServerTemplate"
$Filter = "2016Server"

Get-Parameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter

### Get VM Parameters
$ParameterSet = "VMParameters"
$SQLTable = "configVMParameters"
$Select = "*"
$Where = "ServerTemplate"
$Filter = "2016Server"

Get-Parameters -ParameterSet $ParameterSet -SQLTable $SQLTable -Select $Select -Where $Where -Filter $Filter


Write-Host "HostName: " $HostName -ForegroundColor Magenta
Write-Host "CDROMLetter: " $CDROMLetter -ForegroundColor Magenta
Write-Host "vCPU: " $vCPU -ForegroundColor Magenta