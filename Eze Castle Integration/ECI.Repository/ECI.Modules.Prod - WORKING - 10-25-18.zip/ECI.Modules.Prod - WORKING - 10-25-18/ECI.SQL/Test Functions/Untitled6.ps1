﻿cls

### Create a Connection
$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = “Server=automate1.database.windows.net;Initial Catalog=DevOps;;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;”
$sqlConn.Open()

### Create Your Command
$sqlcmd = New-Object System.Data.SqlClient.SqlCommand
$sqlcmd.Connection = $sqlConn
$query = “SELECT * FROM defServerTemplates”
$sqlcmd.CommandText = $query


### Create Your Data Adapter
$adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd



### Create Your DataSet (and fill it)

$data = New-Object System.Data.DataSet
$adp.Fill($data) | Out-Null

$data


<#
$params = @{
      'Database' = 'Automation1'
      'ServerInstance' = 'automate1.database.windows.net'
      'Username' = 'devops'
      'Password' = 'JKFLKA8899*(*(32faiuynv'
      'OutputSqlErrors' = $true
      'Query' = 'SELECT * FROM Servers'
}
Invoke-Sqlcmd @params


$server = " tcp:automate1.database.windows.net,1433" 
$database = "devops" 
$adminName = "devops" 
$adminPassword = "JKFLKA8899*(*(32faiuynv" 


$connectionString = "Server=$server;Database=$database;User ID=$adminName;Password=$adminPassword;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;" 
$connection = New-Object -TypeName System.Data.SqlClient.SqlConnection($connectionString)
	

exit

#>
