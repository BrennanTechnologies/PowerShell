﻿cls
Import-Module SQLPS -DisableNameChecking

#Get-Command -Module SqlServer

#$Query = "SELECT dbo.[Config.Definition.ServerTemplates].* FROM dbo.[Config.Definition.ServerTemplates]"

#Set-Location "SQLSERVER:\SQL\MyComputer\MainInstance"

Set-Location "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
#Invoke-Sqlcmd -Query $Query

Get-SqlInstance -ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases

Invoke-Sqlcmd -query 'Select * from dbo.[Config.Definition.ServerTemplates]' -ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases -Database ServerConfiguration  

Invoke-Sqlcmd -query 'Select * from dbo.[Config.Definition.ServerTemplates]' -Database ServerConfiguration  
#-ServerInstance SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases

$ServerInstance = "CBRENNAN3420\SQLEXPRESS"
$DatabaseName = "ServerConfiguration"
read-sqltabledata -serverInstance $ServerInstance  -databasename $DatabaseName -schemaname dbo -tablename Config.Definition.ServerTemplates #-schemaname person -tablename person -top 2


#read-sqltabledata -serverInstance localhost\sql2016 -databasename adventurworks2012_2014 -schemaname person -tablename person -top 2

#Write-SqlTableData [[-ServerInstance] <String[]> ] -InputData <PSObject> [-ConnectionTimeout <Int32> ] [-Credential <PSCredential> ] [-DatabaseName <String> ] [-Force] [-IgnoreProviderContext] [-Passthru] [-SchemaName <String> ] [-SuppressProviderContextWarning] [-TableName <String> ] [-Timeout <Int32> ] [ <CommonParameters>]

#Invoke-Sqlcmd -ServerInstance localhost\sql2016 -Database master -OutputAs DataTables -Query "select name,database_id,compatibility_level,collation_name ,user_access_desc from sys.databases"|Write-SqlTableData -ServerInstance localhost\sql2016 -DatabaseName Test2 -SchemaName dbo -TableName testdatabases -Force

