###################################
### AD Script
### ECI.EMI.Automation.AD.Prod.ps1
###################################
Param(
        [Parameter(Mandatory = $True)][int]$ServerID,
        [Parameter(Mandatory = $True)][string]$Environment,
        [Parameter(Mandatory = $True)][string]$ConfigurationMode
     )

&{

    BEGIN
    {
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        Write-Host `n('*' * 50)`n`n " --------- STARTING QA --------- " `n`n('*' * 50)`n -ForegroundColor Green
        $script:QAStartTime = Get-Date    
    }

    PROCESS
    {
        QA-SMBv1
    }

    END
    {
        $QAStopTime = Get-Date
        $global:QAElapsedTime = ($QAStopTime-$QAStartTime)
        Write-Host `n`n('=' * 75)`n "QA: Total Execution Time:`t" $QAElapsedTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "END QA SCRIPTS" -ForegroundColor Gray
        Stop-Transcript    
    }


}