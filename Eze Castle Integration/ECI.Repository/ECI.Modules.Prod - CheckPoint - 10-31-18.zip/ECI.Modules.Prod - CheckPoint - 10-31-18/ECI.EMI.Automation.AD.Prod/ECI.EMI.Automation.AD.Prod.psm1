###################################
### AD Script
### ECI.EMI.Automation.AD.Prod.psm1
###################################


function Get-ECI.EMI-ADComputer
{


}


function Get-ECI.EMI-ADComputer
{


}