﻿cls
$VMName = "ETEST040_Test-LD5-3mF44"
$vCenter_Account = "portal-int@eci.cloud"
$vCenter_Password = "7Gc^jfzaZnzD"
$StartSleep = "5"

function ECI.VM.PowerOn
{
    Param([Parameter(Mandatory = $True)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $CurrentState = (Get-VM -Name $VMName).PowerState

    Write-Host "InitialVMPowerState: " $CurrentState `n  -ForegroundColor DarkGray

    if($CurrentState -eq "PoweredOff")
    {
        Write-Host "VM is currently PowerOff" -ForegroundColor Gray

        function PowerOn-VM
        {
            ### Power ON
            ###----------------
            Write-Host "Powering ON VM: " $VMName -ForegroundColor Yellow
            try
            {
                Start-VM -VM $VMName | Out-Null
            }
            catch
            {
                Write-Host "ERROR: " $Error[0] -ForegroundColor Red
            }
    
            ### Wait
            ###----------------
            Write-Host "START-SLEEP: Wating for VM to start. $StartSleep seconds." -ForegroundColor DarkCyan
            Start-Sleep -Seconds $StartSleep
        }
        PowerOn-VM

        ### Verify State
        ###----------------
        $VerifyState = (Get-VM -Name $VMName).PowerState
        $VMguestStateChangeSupported  = (Get-VM -Name $VMName).ExtensionData.guest.guestStateChangeSupported

        if($VerifyState -eq "PoweredOn")
        {
            Write-Host "Success: $VMName was set to $VerifyState" -ForegroundColor Green
        }
        elseif(($VerifyState -eq "PoweredOff") -AND ($VMguestStateChangeSupported -eq $True))
        {
            $RetryCount = 5
            for ($i=1; $i -le $RetryCount; $i++)
            {
                Write-Host "Re-trying PowerOn VM: "  -ForegroundColor DarkCyan
                PowerOn-VM
            }

            Write-Host "Abort Error:" -ForegroundColor Red 
        }
    }
    elseif($CurrentState -eq "PoweredOn")
    {
        Write-Host "PowerState: $VMName - already Powered On."
    }

    Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}


function ECI.VM.PowerOff
{
    Param([Parameter(Mandatory = $True)][string]$VMName)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $CurrentState = (Get-VM -Name $VMName).PowerState
    Write-Host "InitialVMPowerState: " $CurrentState `n  -ForegroundColor DarkGray

    if($CurrentState -eq "PoweredOn")
    {
        Write-Host "VM is currently PoweredON" -ForegroundColor Gray

        function PowerOff-VM
        {
            ### Power ON
            ###----------------
            Write-Host "Powering OFF VM: " $VMName -ForegroundColor Yellow
            try
            {
                Shutdown-VMGuest -VM $VMName -Confirm:$false | Out-Null
            }
            catch
            {
                Write-Host "ERROR: " $Error[0] -ForegroundColor Red
            }
    
            ### Wait
            ###----------------
            Write-Host "START-SLEEP: Wating for VM to start. $StartSleep seconds." -ForegroundColor DarkCyan
            #Start-Sleep -Seconds $StartSleep
        }
        PowerOff-VM

        ### Test State
        ###----------------
        $VerifyState = (Get-VM -Name $VMName).PowerState
        $VMguestStateChangeSupported  = (Get-VM -Name $VMName).ExtensionData.guest.guestStateChangeSupported

        if($VerifyState -eq "PoweredOff")
        {
            Write-Host "VM was successfully  Powered OFF" -ForegroundColor Green
        }
        elseif(($VerifyState -eq "PoweredOn") -AND ($VMguestStateChangeSupported -eq $True))
        {
            $RetryCount = 5
            for ($i=1; $i -le $RetryCount; $i++)
            {
                DO
                {
                    Write-Host "Re-trying PowerOff VM : " $RetryCount -ForegroundColor DarkCyan
                    PowerOff-VM
                }
                UNTIL((Get-VM -Name $VMName).PowerState -eq "PoweredOff")
            }
        }
    }
    elseif($CurrentState -eq "Poweredff")
    {
        Write-Host "VM already Powered Off."
    }

    Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}


&{

    $DesiredState = "PowerOn"
    $DesiredState = "PowerOff"

    $CurrentState = (Get-VM -Name $VMName).PowerState

    ECI.VM.PowerOn -VMName $VMName
    #ECI.VM.PowerOff -VMName $VMName
}

function Retry
{

    $Stoploop = $false
    [int]$Retrycount = "0"

    DO 
    {
        try
        {
            ### Do something here
            Write-Host "Job completed"
            $Stoploop = $true
        }
        catch 
        {
            if ($Retrycount -gt 3)
            {
                Write-Host "Could not send Information after 3 retrys."
                $Stoploop = $true
            }
            else 
            {
                Write-Host "Could not send Information retrying in 30 seconds..."
                Start-Sleep -Seconds 30
                $Retrycount = $Retrycount + 1
            }
        }
    }
    WHILE ($Stoploop -eq $false)

}




function Get-VMStates
{
    $PowerState  = (Get-VM -Name $VMName).PowerState 
    $guestState = (Get-VM -Name $VMName).ExtensionData.guest.guestState


    (Get-VM -Name $VMName).ExtensionData.guest.guestOperationsReady

    $VMinteractiveGuestOperationsReady = (Get-VM -Name $VMName).ExtensionData.guest.interactiveGuestOperationsReady

    (Get-VM -Name $VMName).ExtensionData.guest.guestStateChangeSupported

    ### #https://www.vmware.com/support/orchestrator/doc/vro-vsphere65-api/html/VcGuestInfo.html                         ### <---- RETRUN: True/False
    $VMguestState                      = (Get-VM -Name $VMName).ExtensionData.guest.guestState                           ### <---- RETRUN: running/notRunning
    $VMguestOperationsReady            = (Get-VM -Name $VMName).ExtensionData.guest.guestOperationsReady                 ### <---- RETRUN: True/False
    $VMinteractiveGuestOperationsReady = (Get-VM -Name $VMName).ExtensionData.guest.interactiveGuestOperationsReady      ### <---- RETRUN: True/False
    $VMguestStateChangeSupported       = (Get-VM -Name $VMName).ExtensionData.guest.guestStateChangeSupported
}