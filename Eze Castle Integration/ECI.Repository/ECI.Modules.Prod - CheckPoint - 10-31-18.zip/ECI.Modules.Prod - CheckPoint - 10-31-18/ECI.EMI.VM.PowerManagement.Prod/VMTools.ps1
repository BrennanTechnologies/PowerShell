﻿#https://www.vmware.com/support/orchestrator/doc/vro-vsphere65-api/html/VcGuestInfo.html


toolsInstallType	String	
Current installation type of VMware Tools in the guest operating system. The set of possible values is described in {@link vim.vm.GuestInfo.ToolsInstallType} @since vSphere API 6.5
toolsRunningStatus	String	
Current running status of VMware Tools in the guest operating system, if known. The set of possible values is described in {@link vim.vm.GuestInfo.ToolsRunningStatus} @since vSphere API 4.0
toolsStatus	VcVirtualMachineToolsStatus	Deprecated.
Current status of VMware Tools in the guest operating system, if known. @since VI API 2.5
toolsUpdateStatus	VcVirtualMachineToolsUpdateStatus	
Current updating status of VMware Tools in the guest operating system. Not set if {@link vim.vm.ToolsConfigInfo}.upgradeRebootPredict is false. @since vim legacy version
toolsVersion	String	
Current version of VMware Tools, if known. @since VI API 2.5
toolsVersionStatus	String	Deprecated.
Current version status of VMware Tools in the guest operating system, if known. The set of possible values is described in {@link vim.vm.GuestInfo.ToolsVersionStatus} for vSphere API 5.0. @since vSphere API 4.0
toolsVersionStatus2	String	
Current version status of VMware Tools in the guest operating system, if known. The set of possible values is described in {@link vim.vm.GuestInfo.ToolsVersionStatus} @since vSphere API 5.0