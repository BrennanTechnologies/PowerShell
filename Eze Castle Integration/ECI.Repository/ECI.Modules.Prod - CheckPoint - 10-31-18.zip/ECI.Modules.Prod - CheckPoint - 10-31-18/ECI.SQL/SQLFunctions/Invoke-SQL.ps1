﻿$dataSource = "ECILAB-BOSDEV01\SQLEXPRESS"
$database = "ServerConfiguration-Dev-Lab"
$sqlCommand = "SELECT * FROM ServerTemplates"



$conn = New-Object System.Data.SqlClient.SqlConnection(“Data Source=YourMachineName\YourInstanceName; InitialCatalog=master; Integrated Security=SSPI”)            
$conn.Open()            
$cmd1 = $conn.CreateCommand()            
$cmd1.CommandType = [System.Data.CommandType]::StoredProcedure            
$cmd1.CommandText =“sp_databases”            
$data = $cmd1.ExecuteReader()            
$dt = new-object “System.Data.DataTable”            
$dt.Load($data)            
$dt | format-table #PipeLining is Awesome!            
$conn.Close()

<#
$connectionString = "Data Source=$dataSource; " +
    "Integrated Security=SSPI; " +
    "Initial Catalog=$database"

$connection = new-object system.data.SqlClient.SQLConnection($connectionString)
$command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
$connection.Open()

$adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
$dataset = New-Object System.Data.DataSet
$adapter.Fill($dataSet) | Out-Null

$connection.Close()
$dataSet.Tables

#>


function Invoke-SQL {
    param(
        [string] $dataSource = ".\SQLEXPRESS",
        [string] $database = "MasterData",
        [string] $sqlCommand = $(throw "Please specify a query.")
      )

    $connectionString = "Data Source=$dataSource; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog=$database"

    $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
    $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
    $connection.Open()

    $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
    $dataset = New-Object System.Data.DataSet
    $adapter.Fill($dataSet) | Out-Null

    $connection.Close()
    $dataSet.Tables

}