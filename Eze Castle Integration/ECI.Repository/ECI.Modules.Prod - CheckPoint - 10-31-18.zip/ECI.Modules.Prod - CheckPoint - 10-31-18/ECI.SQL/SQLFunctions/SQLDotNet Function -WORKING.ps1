﻿cls

### Parameters
$SQLServer =  "ECILAB-BOSDEV01\SQLEXPRESS"
#$SQLServer =  "ECILAB-BOSDEV01"

$SQLDatabase = "ServerConfiguration-Dev-Lab"
$SQLQuery = "Select * from defServerTemplates"

$SQLServer =  "ECILAB-BOSDEV01\SQLEXPRESS"
$SQLDatabase = "ServerConfiguration-Dev-Lab"
$ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"

<#
### Create Database Connection
$Connection = New-Object System.Data.SQLClient.SQLConnection
$Connection.ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"
$Connection.Open()

$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$Command.CommandText = $Query
$Reader = $Command.ExecuteReader()
        
### Datatable
$Datatable = New-Object System.Data.DataTable
$Datatable.Load($Reader)
$Datatable

### Close Database Connection
$Connection.Close()
#>


function Get-SQLDataTable
{
    BEGIN
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"
        $Connection.Open()
    }

    PROCESS
    {
        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
        
        ### Datatable
        $Datatable = New-Object System.Data.DataTable
        $Datatable.Load($Reader)
        $Datatable
    }
    END
    {
        ### Close Database Connection
        $Connection.Close()
    }
}
#Get-SQLDataTable




function Get-SQLDataSet
{
    BEGIN
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"
        $Connection.Open()
    }

    PROCESS
    {
        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
        
        ### DataAdapter & DataSet
        $DataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command
        $Dataset = New-Object System.Data.Dataset
        $DataAdapter.Fill($Dataset) | Out-Null
        $DataSet.Tables[0]
        $DataSet.Tables[1]
    }
    END
    {
        ### Close Database Connection
        $Connection.Close()
    }
}
#Get-SQLDataSet




#$ServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
#$DatabaseName = "ServerConfiguration"
#$Table = "Config.Definition.ServerTemplates"


#$WriteQuery = "INSERT INTO [ServerConfiguration].[dbo].[Config.Definition.ServerTemplates](ServerTemplateID,ServerTemplateName) VALUES ('ServerTemplateID','ServerTemplateName')"
#$insert = INSERT INTO [ServerConfiguration].[dbo].[Config.Definition.ServerTemplates](ServerTemplateID,ServerTemplateName) VALUES ('{0}','{1}')

$VM = "RGEE-SRV"
$FunctionName = "Test-Function"
$Verified = "True"
$Abort = "False"

function Write-SQLTable
{

    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$Abort
    )


    #Open
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = "Data Source = ECILAB-BOSDEV01\SQLEXPRESS; Initial Catalog=ServerConfiguration; Integrated Security=SSPI;"
    $connection.Open()

    #Insert
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = "INSERT INTO [ServerConfiguration].[dbo].[Servers](ServerName) VALUES('{0}')" -f $ServerTemplateName
    #$cmd.CommandText = "INSERT INTO Servers(ServerName) VALUES('{0}')" -f $ServerTemplateName
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()

}

#Write-SQLTable



function Write-Cookie
{


    $SQLServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
    $SQLSchemaName  = "dbo"
    $SQLDatabase = "ServerConfiguration-Dev-Lab"
    $SQLTable = "Cookies"

    ### Create Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"
    $Connection.Open()
            


    ### IMPORTANT: Values must be in the same order as the columns in the table.
    $InputDataHash = [ordered]@{
        VM = $VM 
        FunctionName = $FunctionName
        Verified = $Verified
        Abort = $Abort
    }

    $InputData = [PSCustomObject] $InputDataHash 
    $InputData

    Write-SqlTableData -ServerInstance $SQLServerInstance -SchemaName $SQLSchemaName -DatabaseName $SQLDatabase  -TableName $SQLTable -InputData $InputData -Force

}

