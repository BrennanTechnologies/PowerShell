﻿cls


function Get-SQLTable
{
    $Query = “SELECT * FROM defServerTemplate”

    ### Create Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = “Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;”
    $Connection.Open()

    ### Execute SQL Query
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
        
    ### Datatable
    $Datatable = New-Object System.Data.DataTable
    $Datatable.Load($Reader)
    $Datatable

    ### Close Database Connection
    $Connection.Close()
}

$VM = "RGEE-SRV1"
$FunctionName = "Test-Function2"
$Verified = "True"
$Abort = "False"

function Write-SQLTable
{
    Param(
        #[Parameter(Mandatory = $True)] [string]$ParameterSet,
        [Parameter(Mandatory = $True)] [string]$VM,
        [Parameter(Mandatory = $True)] [string]$FunctionName,
        [Parameter(Mandatory = $True)] [string]$Verified,
        [Parameter(Mandatory = $True)] [string]$Abort
    )

   # Open Connection
    $Connection = New-Object System.Data.SqlClient.SqlConnection
    $Connection.ConnectionString = “Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;”
    $Connection.Open()

    #Insert
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = "INSERT INTO Cookies(VM,FunctionName,Verified,Abort) VALUES('$VM','$FunctionName','$Verified','$Abort')" 

    #$cmd.CommandText = "INSERT INTO Servers(ServerName) VALUES('{0}')" -f $ServerTemplateName
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $Connection.Close()

}

Write-SQLTable -VM $VM -FunctionName $FunctionName -Verified $Verified -Abort $Abort