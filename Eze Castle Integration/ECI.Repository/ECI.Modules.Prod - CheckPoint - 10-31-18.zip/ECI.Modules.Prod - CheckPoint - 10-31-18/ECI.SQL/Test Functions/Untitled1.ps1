﻿#Import-ECI.Root.ModuleLoader
Import-VMWareModules
Connect-ECIVIServer

$VM = "CB-SRV1"

$VM = Get-VM -Name $VM
