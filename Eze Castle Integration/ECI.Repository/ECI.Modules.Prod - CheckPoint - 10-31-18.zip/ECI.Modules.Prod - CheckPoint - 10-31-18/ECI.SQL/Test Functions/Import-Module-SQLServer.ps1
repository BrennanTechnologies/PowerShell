﻿Save-Module -Name SqlServer -Path c:\scripts

Install-Module -Name SqlServer

Import-Module -Name SqlServer

Get-Command -Module SqlServer