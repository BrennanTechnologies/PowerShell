﻿#############################################
### Invoke Commands on Guest from vCenter
### ECI.EMI.Automation.OS.Invoke.ps1
#############################################

Param(
    [Parameter(Mandatory = $True)] [string]$ServerID,
    [Parameter(Mandatory = $True)] [string]$ConfigurationMode,
    [Parameter(Mandatory = $True)] [string]$HostName,
    [Parameter(Mandatory = $True)] [string]$ServerRole,
    [Parameter(Mandatory = $True)] [string]$IPv4Address,
    [Parameter(Mandatory = $True)] [string]$SubnetMask,
    [Parameter(Mandatory = $True)] [string]$DefaultGateway,
    [Parameter(Mandatory = $True)] [string]$PrimaryDNS,
    [Parameter(Mandatory = $True)] [string]$SecondaryDNS,
    [Parameter(Mandatory = $True)] [string]$ClientDomain,
    [Parameter(Mandatory = $True)] [string]$AdministrativeUserName,
    [Parameter(Mandatory = $True)] [string]$AdministrativePassword
)


#######################################
### Import Bootstap Module
#######################################
[ScriptBlock]$BootStrapModuleLoader = 
{
    ipconfig /all
    ### BEGIN: Import BootStrap Module Loader
    Set-ExecutionPolicy ByPass -Scope CurrentUser
    $AcctKey=ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials=$Null
    $Credentials=New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath="\\eciscripts.file.core.windows.net\clientimplementation"
    New-PSDrive -Name V -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    #. "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
    ### END: Import BootStrap Module Loader
} 

function Rename-ECI.EMI.Configure.OS.Invoke.LocalAdmin
{
    Param(
    [Parameter(Mandatory = $True)] [string]$NewName,
    [Parameter(Mandatory = $True)] [string]$LocalAdminName,
    [Parameter(Mandatory = $True)] [string]$LocalAdminPassword
    )
    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ECILocalAdminName = $NewName

    $Params = @{
        "#ECILocalAdminName#" = $ECILocalAdminName
    }

    Write-Host "RENAMING LOCALADMIN  :"                     -ForegroundColor Yellow
    Write-Host "Old LocalAdminName   : $LocalAdminName"     -ForegroundColor Cyan
    Write-Host "New LocalAdminName   : $ECILocalAdminName"  -ForegroundColor Cyan

    $RenameLocalAdmin ={
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName         = [System.Net.Dns]::GetHostName()
        $PrincipalContext     = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal        = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher             = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal

        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $CurrentAdminName = $Account.Name
            
        $ECILocalAdminName = "#ECILocalAdminName#" 


        Rename-LocalUser -Name $CurrentAdminName -NewName $ECILocalAdminName -ErrorAction SilentlyContinue | Out-Null
    }


    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $RenameLocalAdmin =  $RenameLocalAdmin -replace $Param.Key,$Param.Value
    }

    try
    {
        ### IMPORTANT! Rename-Admin will genererate an error, as expected. Use "-ErrorAction SilentlyContinue | Out-Null".
        Invoke-VMScript -VM $VMName -ScriptText $RenameLocalAdmin -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword -ErrorAction SilentlyContinue | Out-Null 
    }
    catch
    {
        Write-ECI.ErrorStack
    }
    Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

#######################################
### Function: Execute Invoke Process
#######################################
function Invoke-ECI.ScriptText
{
    ### Convert SubnetMask to CIDR
    ### --------------------------------------------
    switch ( $SubnetMask )
    {
        "255.255.255.0"      { $SubnetPrefixLength = "24" }
        "255.255.255.128"    { $SubnetPrefixLength = "25" }
        "255.255.255.192"    { $SubnetPrefixLength = "26" }
        "255.255.255.224"    { $SubnetPrefixLength = "27" }
        "255.255.255.240"    { $SubnetPrefixLength = "28" }
        "255.255.255.248"    { $SubnetPrefixLength = "29" }
        "255.255.255.252"    { $SubnetPrefixLength = "30" }
        "255.255.255.254"    { $SubnetPrefixLength = "31" }
    }

    ### Replace Parameters with #LiteralValues#
    ### ---------------------------------------
    $Params = @{
    "#Env#"                           = $Env
    "#Environment#"                   = $Environment
    "#Step#"                          = $Step
    "#VMName#"                        = $VMName
    "#ServerID#"                      = $ServerID
    "#ServerRole#"                    = $ServerRole
    "#HostName#"                      = $HostName
    "#ClientDomain#"                  = $ClientDomain
    "#IPv4Addres#"                    = $IPv4Address
    "#SubnetPrefixLength#"            = $SubnetPrefixLength
    "#DefaultGateway#"                = $DefaultGateway
    "#PrimaryDNS#"                    = $PrimaryDNS
    "#SecondaryDNS#"                  = $SecondaryDNS
    "#BuildVersion#"                  = $BuildVersion
    "#CDROMLetter#"                   = $CDROMLetter
    "#InternetExplorerESCPreference#" = $InternetExplorerESCPreference
    "#IPv6Preference#"                = $IPv6Preference
    "#NetworkInterfaceName#"          = $NetworkInterfaceName
    "#SMBv1#"                         = $SMBv1
    "#RDPResetrictionsPreference#"    = $RDPResetrictionsPreference
    "#RemoteDesktopPreference#"       = $RemoteDesktopPreference
    "#PageFileLocation#"              = $PageFileLocation
    "#PageFileMultiplier#"            = $PageFileMultiplier
    "#WindowsFirewallPreference#"     = $WindowsFirewallPreference
    "#AdministrativeUserName#"        = $AdministrativeUserName
    "#AdministrativePassword#"        = $AdministrativePassword
    "#LocalAdminName#"                = $Creds.LocalAdminName
    "#LocalAdminPassword#"            = $Creds.LocalAdminPassword
    }

    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
    }

    ### Inject BootStrap Module Loader into VM Host                                          # <----- not using bootstrap ????
    ### ---------------------------------------
    #$ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

    ### Debugging: Write ScriptText Block to Screen
    ### ---------------------------------------
    #Write-Host "ScriptText:`n" $ScriptText -ForegroundColor Gray

    ###############################
    ### Inovke VMScript
    ###############################
    #---------------------------------------------------------
    #   Invoke-VMScript
    #     -Verbose 
    #     -Debug
    #     | Select -ExpandProperty ScriptOutput
    #     | Select -ExpandProperty ExitCode
    #---------------------------------------------------------

    Write-Host `n('*' * 55)`n `n "      ~~~~~~~~ INVOKING OS CONFIGURATION ~~~~~~~~  " `n`n(' ' * 18) "STEP:" $Step `n  `n " --------- THIS PROCESS MAY TAKE SEVERAL MINUTES ---------  " `n`n('*' * 55)`n -ForegroundColor Cyan

    ### -------------------------------------------
    ### Production: Run Invoke as Variable
    ### -------------------------------------------
    Write-Host "Invoke using GuestUser: " $Creds.LocalAdminName
    $Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $Creds.LocalAdminName -GuestPassword $Creds.LocalAdminPassword

    if($Invoke)
    {
        ### Check Exit Code for any Errors
        ### ---------------------------------------
        Write-Host $Invoke.ScriptOutput

        if (($Invoke.ExitCode) -eq 0) {
            Write-Host "Invoke-VMScript Successful: Invoke-ECI.EMI.Configure.OS.InGuest" -ForegroundColor Darkcyan
        }
        elseif (($Invoke.ExitCode) -ne 0) {
            Write-Host "Error in Invoke-VMScript Commands! Invoke-ECI.EMI.Configure.OS.InGuest" -ForegroundColor Red
        }
    }
}

##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-ECI.EMI.Configure.OS.InGuest
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host `n`r('=' * 100)`n "BEGIN INVOKE FUNCTION - IN-GUEST  : " `n $((Get-PSCallStack)[0].Command) "-Step:" $Step `n`r('=' * 100) -ForegroundColor DarkCyan

    [ScriptBlock]$ScriptText = 
    {
    ### Import BootStrap Module Loader
    ### -------------------------------
    #BootStrapModuleLoader#       
    
    ### Import Parameters
    ### -------------------------------
    $global:Env                              = "#Env#"    
    $global:Environment                      = "#Environment#"    
    $global:Step                             = "#Step#"    
    $global:VMName                           = "#VMName#"    
    $global:ServerID                         = "#ServerID#"  
    $global:ServerRole                       = "#ServerRole#"  
    $global:HostName                         = "#HostName#"
    $global:ClientDomain                     = "#ClientDomain#"
    $global:IPv4Address                      = "#IPv4Addres#"
    $global:SubnetPrefixLength               = "#SubnetPrefixLength#"
    $global:DefaultGateway                   = "#DefaultGateway#"
    $global:PrimaryDNS                       = "#PrimaryDNS#"
    $global:SecondaryDNS                     = "#SecondaryDNS#"
    $global:BuildVersion                     = "#BuildVersion#"
    $global:CDROMLetter                      = "#CDROMLetter#"
    $global:InternetExplorerESCPreference    = "#InternetExplorerESCPreference#"
    $global:IPv6Preference                   = "#IPv6Preference#"
    $global:NetworkInterfaceName             = "#NetworkInterfaceName#"
    $global:SMBv1                            = "#SMBv1#"
    $global:RDPResetrictionsPreference       = "#RDPResetrictionsPreference#"
    $global:RemoteDesktopPreference          = "#RemoteDesktopPreference#"
    $global:PageFileLocation                 = "#PageFileLocation#"
    $global:PageFileMultiplier               = "#PageFileMultiplier#"
    $global:WindowsFirewallPreference        = "#WindowsFirewallPreference#"
    $global:AdministrativeUserName           = "#AdministrativeUserName#"
    $global:AdministrativePassword           = "#AdministrativePassword#"
    $global:LocalAdminName                   = "#LocalAdminName#"
    $global:LocalAdminPassword               = "#LocalAdminPassword#"
    ### -------------------------------
    foreach($Module in (Get-Module -ListAvailable ECI.*)) {Import-Module -Name $Module.Path -DisableNameChecking}

    ### Launch In-Guest Script
    ### -------------------------------
    . "C:\Program Files\WindowsPowerShell\Modules\ECI.Modules.$Env\ECI.EMI.Configure.OS.$Env\ECI.EMI.Configure.OS.InGuest.$Env.ps1" 
    } # END ScriptText

    Invoke-ECI.ScriptText
}

##############################################################################
### Execute the Script
##############################################################################
&{ 
    BEGIN
    {
        #Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #<--(Set Path)
        #Start-ECI.Transcript -TranscriptPath "C:\Scripts\ServerRequest\TranscriptLogs\" -TranscriptName "ECI.EMI.Configure.OS.Invoke.$Env.ps1"

        ### Write Header Information
        ###---------------------------------
        Write-Host `n`n('*' * 50)`n " --------- STARTING OS CONFIGURATION --------- " `n('*' * 50)`n  -ForegroundColor Cyan
        Write-Host `n('-' * 50)`n                                           -ForegroundColor DarkCyan                           # <----- COMBINE!!!!
        Write-Host "Env         : " $Env                                    -ForegroundColor DarkCyan                           # <----- COMBINE!!!!
        Write-Host "Environment : " $Environment                            -ForegroundColor DarkCyan
        Write-Host "Script      : " (Split-Path (Get-PSCallStack)[0].ScriptName -Leaf) -ForegroundColor DarkCyan
        Write-Host `n('-' * 50)`n                                           -ForegroundColor DarkCyan

        ### Script Setup
        ###---------------------------------
        $script:OSStartTime = Get-Date
        $global:VerifyErrorCount = 0
        Set-ECI.EMI.Automation.LocalAdminAccount -Template
        Start-ECI.EMI.Automation.Sleep -t $WaitTime_StartSleep                                    #<--- COMBINE!!!!!
        Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName -t $WaitTime_VMTools                   #<--- COMBINE!!!!!
        Configure-ECI.EMI.Automation.ExecutionPolicyonVMGuest -VMName $VMName
        Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
        
        ### Install ECI Modules on Guest
        ###---------------------------------
        $Params = @{
            Env         = $Env 
            Environment = $Environment
        }
        Install-ECI.EMI.Automation.ECIModulesonVMGuest @Params
    }

    PROCESS
    {
        ##########################################
        ### Invoke Configuration in VM Guest
        ##########################################

        ###----------------------------------------------
        ### STEP 1: Rename-ECI.LocalAdmin
        ###----------------------------------------------
        function Rename-ECI.EMI.Configure.OS.LocalAdmin
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            #Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName

            ###---------------------------------------------------------------------------------------------
            Set-ECI.EMI.Automation.LocalAdminAccount -Template
            
            Rename-ECI.EMI.Configure.OS.Invoke.LocalAdmin -NewName $ECILocalAdminName -LocalAdminName $Creds.LocalAdminName -LocalAdminPassword $Creds.LocalAdminPassword
            Set-ECI.EMI.Automation.LocalAdminAccount -ECI
            ###---------------------------------------------------------------------------------------------
            
            #Copy-ECI.EMI.Automation.VMLogsfromGuest
            #Write-ECI.EMI.Automation.VMLogstoSQL

            Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        ###----------------------------------------------
        ### STEP 2: Rename-ECI.GuestComputer
        ###----------------------------------------------
        function Rename-ECI.EMI.Configure.OS.GuestComputer
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
        
            ###---------------------------------------------------------------------------------------------
            Invoke-ECI.EMI.Configure.OS.InGuest -Step Rename-ECI.EMI.Configure.OS.GuestComputer
            ###---------------------------------------------------------------------------------------------

            Write-Host "Guest OS was restarted after Renaming Computer:  `nWaiting for Guest OS to Resume . . ." -ForegroundColor Yellow
            Start-ECI.EMI.Automation.Sleep -t $WaitTime_StartSleep                                            #<---- Consolidate
            Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName -t $WaitTime_VMTools                           #<---- Consolidate
            Copy-ECI.EMI.Automation.VMLogsfromGuest
            Write-ECI.EMI.Automation.VMLogstoSQL

            Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        ###----------------------------------------------
        ### STEP 3: Configure OS
        ###----------------------------------------------
        function Configure-ECI.EMI.Configure.OS.GuestComputer
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            Test-ECI.EMI.Automation.VM.InvokeVMScript -VMName $VMName                        #<---- Consolidate
            #Test.ECI.EMI.VM.GuestReady  -VMName $VMName                         #<---- Consolidate
            Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName

            ### Mount OS ISO
            ###---------------------------------
            $Params = @{
                VMName      = $VMName 
                ISOName     = "2016Server"
            }
            Mount-ECI.EMI.Automation.VM.ISO -VMName $VMName -ISOName 2016Server
                
            ###---------------------------------------------------------------------------------------------
            Invoke-ECI.EMI.Configure.OS.InGuest -Step Configure-ECI.EMI.Configure.OS.GuestComputer
            ###---------------------------------------------------------------------------------------------
            
            ### Copy Log Files and Write to SQL
            ###---------------------------------
            Copy-ECI.EMI.Automation.VMLogsfromGuest
            Write-ECI.EMI.Automation.VMLogstoSQL

            Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        ###----------------------------------------------
        ### STEP 4: Configure Roles
        ###----------------------------------------------
        function Configure-ECI.EMI.Configure.Roles.GuestComputer
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray
            
            Write-Host `n('=' * 75)`n "Configuring Server Role: " $ServerRole `n('=' * 75)`n -ForegroundColor Cyan

            ### Role Specific Configurerations
            ###---------------------------------
            switch ( $ServerRole )
            {
                "2016Server"
                {
                    $ConfigureRole = $False
                }
                "2016FS" 
                {
                    $ConfigureRole = $False
                }
                "2016DC" 
                {
                    $ConfigureRole = $False
                }
                "2016DCFS" 
                {
                    $ConfigureRole = $False
                }
                "2016VDA" 
                { 
                    $ConfigureRole = $True
                    Mount-ECI.EMI.Automation.VM.ISO -VM $VMName -ISOName "XenApp"
                }
                "2016SQL" 
                {
                    $ConfigureRole = $False
                }
                "2016SQLOMS"  
                {
                    $ConfigureRole = $False
                }
            }

            ### Execute Role Configureration
            ###---------------------------------
            if($ConfigureRole -eq $True)
            {
                Write-Host "ConfigureRole:  " $ConfigureRole -ForegroundColor Cyan
                Write-Host "Configuring Server Role . . . " -ForegroundColor Cyan
            
                Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
            
                ###---------------------------------------------------------------------------------------------
                Invoke-ECI.EMI.Configure.OS.InGuest -Step $ServerRole
                ###---------------------------------------------------------------------------------------------
            
                Copy-ECI.EMI.Automation.VMLogsfromGuest
                Write-ECI.EMI.Automation.VMLogstoSQL
            }

            elseif($ConfigureRole -eq $False)
            {
                Write-Host "ConfigureRole:  " $ConfigureRole -ForegroundColor Cyan
                Write-Host "There are no specific Role based configurations needed for this build." -ForegroundColor DarkCyan
            }
            Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        ###----------------------------------------------
        ### STEP 5: Restart Guest OS
        ###----------------------------------------------
        function Restart-ECI.EMI.Configure.OS.GuestComputer
        {
            $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "EXECUTING FUNCTION: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            ### Stop VM
            ###----------------------------
            Stop-ECI.EMI.Automation.VM                                               # <--- need gracefule shutdown and restart!!!!!!!!!!!!!!!!!!!
            
            ### Stop VM
            ###----------------------------
            Start-ECI.EMI.Automation.VM

            Write-Host `n('-' * 50)`n "END FUNCTION:" $FunctionName -ForegroundColor DarkGray
        }

        &{
            PROCESS
            {
                Rename-ECI.EMI.Configure.OS.LocalAdmin
                Rename-ECI.EMI.Configure.OS.GuestComputer
                Configure-ECI.EMI.Configure.OS.GuestComputer
                Configure-ECI.EMI.Configure.Roles.GuestComputer
                Restart-ECI.EMI.Configure.OS.GuestComputer
                Start-ECI.EMI.Automation.Sleep -t $WaitTime_StartSleep                        #<--- COMBINE !!!!!
                Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName -t $WaitTime_VMTools       #<--- COMBINE !!!!!
            }
        }
    }

    END
    {
        Delete-ECI.EMI.Automation.ServerLogs
        #Delete-ECI.EMI.Automation.ECIModulesonVMGuest
        $OSStopTime = Get-Date
        $global:OSElapsedTime = ($OSStopTime-$OSStartTime)
        Write-Host `n`n('=' * 75)`n "OS Configuration: Total Execution Time:`t" $OSElapsedTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "END OS onfiguration Script" -ForegroundColor Gray
        #Stop-Transcript
    }

}

