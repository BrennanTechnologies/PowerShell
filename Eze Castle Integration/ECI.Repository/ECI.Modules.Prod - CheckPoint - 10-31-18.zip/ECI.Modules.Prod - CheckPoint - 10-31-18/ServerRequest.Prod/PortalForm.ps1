﻿cls

$RequestID = "844"

function Set-Parameters
{
    $script:GPID = "GEEMO001"
    $script:CWID = "611"
    $script:ClientDomain = "corp.geemoneymgmt.com"

    $script:RequestServerRole = "2016Server"
    $script:IPv4Address = "10.61.1.111"
    $script:SubnetMask = "255.255.255.0"
    $script:DefaultGateway = "10.61.1.1"
    $script:PrimaryDNS = "10.61.1.1"
    $script:SecondaryDNS = "10.61.1.2"
    $script:InstanceLocation = "Lab"
    $script:DomainUserName = "cbrennan@eci.com"
    $script:BackupRecovery = $True
    $script:DisasterRecovery = $False
    $script:ConnectionString = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    $script:AdministrativeUserName = "cbrennan@eci.com"
    $script:AdministrativePassword = "myPassword"
    }

function Get-HostName
{
    $Query = “SELECT TOP 1 HostName FROM ServerRequest ORDER BY RequestID DESC"

    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $Datatable = New-Object System.Data.DataTable
    $Datatable.Load($Reader)
    Return $Datatable
}

function Create-ServerName
{
    $NewServerName = "LAB-"+ (Get-Random -Minimum 1 -Maximum 9)
    $global:HostName = $NewServerName
    Write-Host "New Server Name: " $NewServerName
}

function Create-ServerName-orig
{
    $LastServer = Get-HostName
    [string]$LastServer = $LastServer[0]
    #Write-Host "Last Server Name: " $LastServer

    [int]$LastNum = $LastServer.Split("-")[1]
    $NextNum = $LastNum + 1

    $NewServerName = "SRV-"+$NextNum 
    $global:HostName = $NewServerName
    #Write-Host "New Server Name: " $NewServerName
}

function Write-ServerRequest
{
   
    Write-Host "Inserting Server Request for HostName: $HostName" -ForegroundColor Yellow
    $Query = "INSERT INTO ServerRequest(GPID,CWID,ClientDomain,HostName,RequestServerRole,IPv4Address,SubnetMask,DefaultGateway,PrimaryDNS,SecondaryDNS,InstanceLocation,DomainUserName,BackupRecovery,DisasterRecovery) VALUES('$GPID','$CWID','$ClientDomain','$HostName','$RequestServerRole','$IPv4Address','$SubnetMask','$DefaultGateway','$PrimaryDNS','$SecondaryDNS','$InstanceLocation','$DomainUserName','$BackupRecovery','$DisasterRecovery')"
    
    # Open Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    # Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    #Close
    $connection.Close()
}

function Get-RequestID
{
    #$Query = “SELECT RequestID FROM ServerRequest WHERE HostName = '$HostName'”
    $Query = “SELECT TOP 1 RequestID FROM ServerRequest ORDER BY RequestID DESC”

    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $Datatable = New-Object System.Data.DataTable
    $Datatable.Load($Reader)
    
    Return $Datatable[0]

}

function Submit-WebForm
{
    $RequestID = Get-RequestID

    [int]$RequestID = $RequestID[0]
    #$RequestID = $RequestID[0]

    . 'c:\scripts\ServerRequest\Invoke-ServerRequest.ps1' -RequestID $RequestID
    
}

&{
    Set-Parameters
    Create-ServerName
    Write-ServerRequest
    Get-RequestID
    Submit-WebForm
}
