﻿Param([Parameter(Mandatory = $True,Position=0)][string]$RequestID)


function Import-ECI.Root.ModuleLoader
{

    ######################################
    ### Bootstrap Module Loader
    ######################################

    ### Set Execution Policy to ByPass
    Write-Host "Setting Execution Policy: ByPass"
    #Set-ExecutionPolicy Bypass

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
    
    
            
#New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    #((Get-PSDrive | Where {((Get-PSDrive).DisplayRoot) -like "\\eciscripts"}) | Remove-PSDrive -Force ) | Out-Null

    if(-NOT((Get-PSDrive -PSProvider FileSystem).Name) -eq "X")
    {
        ####New-PSDrive -Name $RootDrive -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope global
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    }

    #$PSDrive = New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\Prod\ECI.Root.ModuleLoader.ps1" -Env dev


}

&{

    BEGIN
    {
        Import-ECI.Root.ModuleLoader -Env Dev
    }
        
    PROCESS
    {
        Start-Process powershell.exe -ArgumentList "-noexit -file \\eciscripts.file.core.windows.net\clientimplementation\Production\ECI.Modules.Prod\ECI.EMI.Automation.Prod\ECI.EMI.Automation.Prod.ps1", $RequestID
        
    }

    END{}

}

