﻿cls
$Env = "Prod"
$GPID = "ETEST040"
$ServerRole = "2016Server"

function Import-ECI.Root.ModuleLoader
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Gray

    ######################################
    ### Bootstrap Module Loader
    ######################################

    ### Set Execution Policy to ByPass
    #Write-Host "Setting Execution Policy: ByPass"
    #Set-ExecutionPolicy Bypass

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
    
    
            
#New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    #((Get-PSDrive | Where {((Get-PSDrive).Root) -like "\\eciscripts*"}) | Remove-PSDrive -Force ) | Out-Null

    $Mapped = (Get-PSDrive -PSProvider FileSystem).Name -like "X"
    
    

    if(!$Mapped)
    {
        ####New-PSDrive -Name $RootDrive -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope global
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Scope Global
    }

    #$PSDrive = New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\Prod\ECI.Root.ModuleLoader.ps1" -Env Prod
}


function Import-VMModules
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Gray

    $VMModulesPath = "C:\Program Files (x86)\VMware\Infrastructure\vSphere PowerCLI\Modules\"
    $env:PSModulePath = $env:PSModulePath + ";" +  $VMModulesPath

    Get-Module -ListAvailable VM* | Import-Module
}


function Connect-ECI.VIServer
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Gray

    $InstanceLocation = "LD5"

    switch ( $InstanceLocation )
    {
        "Lab" { $ECIvCenter = "ecilab-bosvcsa01.ecilab.corp" }
        "BOS" { $ECIvCenter = "bosvc.eci.cloud"      }
        "QTS" { $ECIvCenter = "cloud-qtsvc.eci.corp" }
        "SAC" { $ECIvCenter = "sacvc.eci.cloud"      }
        "LHC" { $ECIvCenter = "lhcvc.eci.cloud"      }
        "LD5" { $ECIvCenter = "ld5vc.eci.cloud"      }
        "HK"  { $ECIvCenter = "hkvc.eci.cloud"       }
        "SG"  { $ECIvCenter = "sgvc.eci.cloud"       }
    }

    $global:ECIvCenter = $ECIvCenter
    Connect-VIServer -Server $ECIvCenter  -User ezebos\cbrennan -Password Tolkien43741
    Return $ECIvCenter
}

function Get-VMStore
{
    $Datastore = "cloud_staging_pub_lhc"
    $Datastore = Get-Datastore | Where-Object {$_.Name -like $Datastore}
    $ISO = "*DataCtr_Core_2016*"
    $ISO = "*VM*"
    Get-ChildItem -Path $Datastore.DatastoreBrowserPath  -Include *.iso -recurse | ?{$_.name -like $ISO} | fl name,datastorefullpath


    #$lhcDatastoreInLd5 = Get-Datastore cloud_staging_pub_lhc
    #gci -Path $lhcDatastoreInLd5.DatastoreBrowserPath 


<#
ld5vc.eci.cloud
Item:  ld5vc.eci.cloud
ISOs:  cloud_staging_pub_lhc


$lhcDatastoreInLd5 = Get-Datastore cloud_staging_pub_lhc
gci -Path $lhcDatastoreInLd5.DatastoreBrowserPath -Include *.iso -recurse | ?{$_.name -like "*DataCtr_Core_2016*"} | fl name,datastorefullpath

Name              : SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO
DatastoreFullPath : [cloud_staging_pub_lhc] ISO/Current/Microsoft/SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO
#>

}


&{
    BEGIN
    {
        Import-ECI.Root.ModuleLoader
        #Import-VMModules
        Connect-ECI.VIServer
    }

    PROCESS 
    {
        Get-VMStore

        #Get-ECI.EMI.Automation.VM.Resources.ResourcePool -GPID $GPID
        #Get-ECI.EMI.Automation.VM.Resources.PortGroup -GPID $GPID
        #Get-ECI.EMI.Automation.VM.Resources.OSDataStore -ServerRole $ServerRole

    }
}