﻿cls

$global:gpid = "apexf401"
$global:gpid = "RIVER004"
#$global:gpid = "MATRI003"
#$global:gpid = "1234567"    

$instanceLocation = "LD5"
$productType = "EMI"

$portGroup = $null

function Get-ECI.vCenter.Resources
{
    Param(
        [Parameter(Mandatory = $True)][string]$gpid,
        [Parameter(Mandatory = $True)][string]$instanceLocation,
        [Parameter(Mandatory = $True)][string]$productType
    )

    ###------------------------------------------
    ### Get ALL Port Groups
    ###------------------------------------------
    try
    {
       $portGroups = Get-vdPortGroup | Where-Object {$_.Name -Like ("*" + $gpid + "*")}
    }
    catch
    {
        $AbortError = $True
        Write-Error -Message "CATCH-ERROR: Error Getting PortGroups."
        Throw-ECI.AbortError
    }

    ###------------------------------------------
    ### Select Port Group
    ###------------------------------------------
    if($portGroups.Count -eq 1)
    {
        $portGroup = $portGroups
    }
    elseif($portGroups.Count -gt 1)
    {
        if(($portGroups | Where-Object {$_ -like ("multi_" + $GPID) }))
        {
            $portGroup =  $portGroups  | Where-Object {$_ -like ("multi_" + $GPID) }
        }
        elseif(!($portGroups | Where-Object {$_ -like ("multi_" + $GPID) }))
        {
            $portGroup =  $portGroups  | Where-Object {$_ -like ($GPID) }
        }
        else
        {
            $AbortError = $True
            Write-Error -Message "ERROR: No Matching Port Group Found."
            Throw-ECI.AbortError
        }
    }
    Write-Host "GPID                  :" $gpid
    Write-Host "PortGroup Count       :" $portGroups.Count
    Write-Host "PortGroup Selected    :" $portGroup


    ###------------------------------------------
    ### Get Datastores
    ###------------------------------------------
    $vCenterResources = @()
    foreach($portGroup in $portGroups)         # <----- NOTE: DO NOT Loop through all Port Groups.. use the "selected" port group
    {
        ### Get POD Number
        ###--------------------
        if($instanceLocation -eq "QTS")
        {
            $podNumber = (Get-VDPortgroup -Name $portGroup.Name | Get-VDSwitch).Name.split("\-")[2]
        }
        elseif($instanceLocation -eq "LD5")
        {
            $podNumber = (Get-VDPortgroup -Name $portGroup.name | Get-VDSwitch).name.split("\-")[1].Replace("POD","")
            Write-Host "Pod Number: " $podNumber
        }

        ### Select DataStores
        ###--------------------
        $tempOsDatastoreName   = $instanceLocation + "_" + $productType + "_os_" + $podNumber
        $tempSwapDatastoreName = $instanceLocation + "_" + $productType + "_swap_" + $podNumber

        
        #testing
        Write-Host "Pod: " $podNumber
        Write-Host "looking for - tempOsDatastoreName   :" $tempOsDatastoreName
        Write-Host "looking for - tempSwapDatastoreName :" $tempSwapDatastoreName
        Get-DatastoreCluster #| Where {$_.name -like "$PodNumber"}
        exit

        try
        {
            $osDastoreCluster      = Get-DatastoreCluster -name $tempOsDatastoreName
            $swapDatastoreCluster  = Get-DatastoreCluster -name $tempSwapDatastoreName
        }
        catch
        {
            $AbortError = $True
            Write-Error -Message "CATCH-ERROR: Error Getting Datastores."
            Throw-ECI.AbortError
        }

        ###------------------------------------------
        ### Select vCenter Resources
        ###------------------------------------------
        $hash = [ordered]@{
                "resourcePool"   = ""                                        # <-----  Need Resource Pool
                "portGroup"      = $portGroup.Name
                "pODNumber"      = $podNumber
                "oSDataStore"    = $osDastoreCluster.Name
                "swapDataStore"  = $swapDatastoreCluster.Name
            }
        $pSObject = New-Object -TypeName PSObject -Property $hash
        $vCenterResources += $pSObject
    }
    Return $vCenterResources
}
Get-ECI.vCenter.Resources -gpid $gpid -instanceLocation $instanceLocation -productType $productType


function shauns-function
{
    #$PortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like "*apexf401*"}
    $PortGroups = Get-vdPortGroup | Where-Object {$_.Name -Like ("*" + $gpid + "*")}
    $PortGroups.count
    #PortGroups[1].name
    $PortGroups
    $vcenter = "ld5"
    $serverType = "emi"

    $podAndPortGroupName = @()

    foreach($group in $PortGroups){
    #$tempPodNum = (Get-VDPortgroup -Name $group.name | Get-VDSwitch).name.split("\-")[2]
    $temppodNum = (Get-VDPortgroup -Name $Group.name | Get-VDSwitch).name.split("\-")[1].Replace("POD","")

    $tempOsDatastoreName = $vcenter + "_" + $serverType +"_os_" + $tempPodNum
    $tempSwapDatastoreName = $vcenter + "_" + $serverType +"_swap_" + $tempPodNum
    
    $tempOsDastoreCluster = get-datastorecluster -name $tempOsDatastoreName
    $tempSwapDatastoreCluster = get-datastorecluster -name $tempSwapDatastoreName
    
    $portGrpHash = [ordered]@{
    'portGroupName' = $group.name
    'podClusterNumber' = $tempPodNum
    'datastoreClusOS' = $tempOsDastoreCluster.name
    'datastoreClusSwap' = $tempSwapDatastoreCluster.name
    }
    $obj = New-Object -TypeName psobject -Property $portGrpHash
    $podAndPortGroupName += $obj
    Clear-Variable tempPodNum,tempOsDatastoreName,tempSwapDatastoreName,tempOsDastoreCluster,tempSwapDatastoreCluster
    }

    Return $podAndPortGroupName
}
#shauns-function



#get-datastorecluster | select name