
function Write-ECI.EMI.QA.Report
{
    Param(
        [Parameter(Mandatory = $True)] [string]$FunctionName
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)
   
    $QAReportFile = "C:\Scripts\QAReport.txt"


    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function QA-SMBv1
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)
    
    
    $keyname = 'SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'

    $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("LocalMachine", $server.Name)
    $key = $reg.OpenSubKey($keyname)
    $value = $key.GetValue('SMB1')

    if ($value -eq "0")
    {
        write-host -ForegroundColor Green $server.Name "SMBv1 Disabled"
    }    
    else
    {
       Write-Host "QA Failed" -ForegroundColor Red
       (write-host -ForegroundColor Red $server.name "SMBv1 Enabled")
    }
    
    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray
    Write-ECI.EMI.QA.Report -FunctionName $FunctionName 
}


function QA-WindowsFirewall
{
    Get-Service -ComputerName . -DisplayName "Windows Firewall"
    Get-NetFirewallProfile -CimSession . -profile domain
    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function QA-Disks
{
    $Disks=Get-WmiObject -Class Win32_logicalDisk -Filter "DriveType=3" -computer .

    foreach($Disk in $Disks)
    {
	    $usedsize=(($disk.size)-($Disk.FreeSpace))/1gb
	    $usedsize=[math]::truncate($usedsize)

        $freesize=($Disk.FreeSpace)/1gb
	    $freesize=[math]::truncate($freesize)

        $totalsize=($Disk.size)/1gb
	    $totalsize=[math]::truncate($totalsize)
        
	    write-host -ForegroundColor Cyan $server.Name
        write-host "Total Size" $Disk.DeviceID $Disk.VolumeName $totalsize "GB"
        write-host "Used" $Disk.DeviceID $usedsize "GB"

        if($freesize -le (.05*$totalsize))
        {
            write-host -ForegroundColor Red "Free" $Disk.DeviceID $freesize "GB"
        }

        else {
            write-host  "Free" $Disk.DeviceID $freesize "GB"
	    }
    }
    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray
}

function QA-SwapFile
{
    # Output server name and DNS hostname
    Write-Host -ForegroundColor Green "Server Name"
    $server.DNSHostname

    # Check if x86 or x64
    Write-Host -ForegroundColor Green "OS Architecture"
    (Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server.DNSHostName).OSArchitecture

    # Check memory size
    Write-Host -ForegroundColor Green "Physical Memory"
    (Get-WMIObject -class Win32_PhysicalMemory -ComputerName $server.DNSHostName | Measure-Object -Property capacity -Sum).Sum / 1MB
   
    # Check swap file information
    Write-Host -ForegroundColor Green "Swap File Location (Size 0=System Managed Size)"
    (Get-WmiObject -Class Win32_pageFileSetting -ComputerName $server.DNSHostName)

    # Check swap file management
    Write-Host -ForegroundColor Green "Automatic Managed Paging File?"
    (Get-WmiObject -Class Win32_ComputerSystem -ComputerName $server.DNSHostname).AutomaticManagedPagefile

    Write-Host ""
    Write-Host ""

    Write-Host `n('-' * 50)`n"END FUNCTION:" $FunctionName -ForegroundColor DarkGray

}