﻿#Reads Active Directory for all 2016 Servers and checks for correct Server 2016 specific and hardening settings per ECI Standard
#
#
#Version 1.5 3/18/2018 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*Server 2016*" }

foreach ($server in $servers) 
{
    
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
        {
           
           
#Load Variables         
           
           
            $reg1 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey1= $reg1.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Personalization")

            $reg2 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey2= $reg2.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Personalization")

            $reg3 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey3= $reg3.OpenSubKey("SOFTWARE\Policies\Microsoft\InputPersonalization")

           # $reg4 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
           # $regKey4= $reg4.OpenSubKey("SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters")

            $reg5 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey5= $reg5.OpenSubKey("SOFTWARE\Policies\Microsoft\Peernet")

            $reg6 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey6= $reg6.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Network Connections")

            $reg7 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey7= $reg7.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Explorer")

            $reg9 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey9= $reg9.OpenSubKey("SOFTWARE\policies\Microsoft\Windows\AdvertisingInfo")

            $reg10 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey10= $reg10.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Windows Search")

            $reg11 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey11= $reg11.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\Windows Search")

          #  $reg12 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
          #  $regKey12= $reg12.OpenSubKey("SYSTEM\CurrentControlSet\Services\Tcpip\Parameters")
            
          #  $reg13 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
          #  $regKey13= $reg13.OpenSubKey("SYSTEM\CurrentControlSet\Services\Tcpip\Parameters")
            
          #  $reg14 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
          #  $regKey14= $reg14.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths")
            
          #  $reg15 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
          #  $regKey15= $reg15.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths")
            
            $reg16 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey16= $reg16.OpenSubKey("SYSTEM\CurrentControlSet\Services\OneSyncSvc")

            $reg17 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey17= $reg17.OpenSubKey("SYSTEM\CurrentControlSet\Control\FileSystem")

          # $reg18 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
          # $regKey18= $reg18.OpenSubKey("SYSTEM\CurrentControlSet\Control\Terminal Server")

                   
            write-host ""
            write-host -ForegroundColor Yellow "The following settings are for" $server.Name
            write-host ""

  
#Windows Customization Settings  

          
            write-host -ForegroundColor Cyan "Local Accounts Named Administrator if any:"
            
            
            Get-WmiObject -Namespace "root\cimv2" -Class Win32_UserAccount -Filter "LocalAccount='True'" -ComputerName $server.name | Where-Object  {$_.name -eq 'Administrator' -and $_.Disabled -ne 'True'} | format-list -Property Name,Caption

            
            
            if ($regkey17 -ne $null)
                    {
                    write-host "Is NTFS File System Compression Disabled? (Value should be 1 - not 0 or blank):" $regkey17.GetValue("NtfsDisableCompression")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "NTFS File System Compress is not Disabled"
                        }                                                              

 #           if ($regkey18 -ne $null)
 #                   {
 #                   write-host "Are RDP users restricted to a single session on Non-Citrix Servers? (Value should be 0 - not 1 or blank):" $regkey18.GetValue("fSingleSessionPerUser")
 #                   }
 #                       else
 #                       {
 #                       write-host -ForegroundColor Red "RDP users are restricted to a single session on Non-Citrix Servers"
 #                       }    
                                                                                 


#Registry Hardening Settings


            write-host ""
           

            if ($regkey1 -ne $null)
                    {
                    write-host "Is Locked Screen Camera Disabled? (Value should be 1 - not 0 or blank):" $regkey1.GetValue("NoLockScreenCamera")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Locked Screen Camera is Enabled"
                        }

            if ($regkey2 -ne $null)
                    {
                    write-host "Is Locked Screen Slideshow Disabled? (Value should be 1 - not 0 or blank):" $regkey2.GetValue("NoLockScreenSlideshow")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Locked Screen Slideshow is Enabled"
                        }             
            
            if ($regkey3 -ne $null)
                    {
                    write-host "Is Input Personalization Disabled? (Value should be 0 - not 1 or blank):" $regkey3.GetValue("AllowInputPersonalization")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Input Personalization is Enabled"
                        }             
                                    
         #   if ($regkey4 -ne $null)
         #           {
         #           write-host "Is IPv6 IP Source Routing Disabled? (Value should be 1 - not 0 or blank):" $regkey4.GetValue("DisableIPSourceRouting")
         #           }
         #               else
         #               {
         #               write-host -ForegroundColor Red "IPv6 Source Routing is Enabled"
         #               }             
         
            if ($regkey5 -ne $null)
                    {
                    write-host "Is Peer to Peer Networking Disabled? (Value should be 1 - not 0 or blank):" $regkey5.GetValue("Disabled")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Peer to Peer Networking is Enabled"
                        }             
         
            if ($regkey6 -ne $null)
                    {
                    write-host "Is Internet Connection Sharing Disabled? (Value should be 0 - not 1 or blank):" $regkey6.GetValue("NC_ShowSharedAccessUI")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Internet Connection Sharing is Enabled"
                        }

            if ($regkey7 -ne $null)
                    {
                    write-host "Is Store Access is Disabled? (Value should be 1 - not 0 or blank):" $regkey7.GetValue("NoUseStoreOpenWith")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Store Access is Enabled"
                        }  
                                                            
            if ($regkey9 -ne $null)
                    {
                    write-host "Is Advertising ID Disabled? (Value should be 1 - not 0 or blank):" $regkey9.GetValue("DisabledByGroupPolicy")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Advertising ID is Enabled"
                        }

            if ($regkey10 -ne $null)
                    {
                    write-host "Is Cortana Disabled? (Value should be 0 - not 1 or blank):" $regkey10.GetValue("AllowCortana")
                    }
                        else
                        {
                        write-host -ForegroundColor Red  "Cortana is Enabled"
                        }

            if ($regkey11 -ne $null)
                    {
                    write-host "Is Cortana Above Lock Screen Disabled? (Value should be 0 - not 1 or blank):" $regkey11.GetValue("AllowCortanaAboveLock")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Cortana above lock screen is Enabled"
                        }  

         #   if ($regkey12 -ne $null)
         #           {
         #           write-host "Is Custom TCP/IP Keepalive Time Set? (Value should be 1200000 - not blank):" $regkey12.GetValue("KeepAliveTime")
         #           }
         #               else
         #               {
         #               write-host -ForegroundColor Red "TCP/IP Keepalive time is default"
         #               }   
            
         #   if ($regkey13 -ne $null)
         #           {
         #           write-host "Is Custom TCP/IP Retransmit Time Set? (Value should be 720000 - not blank):" $regkey13.GetValue("TcpMaxDataRetransmissions")
         #           }
         #               else
         #               {
         #               write-host -ForegroundColor Red "TCP/IP Retransmit time is default"
         #               }   

         #   if ($regkey14 -ne $null)
         #           {
         #           write-host "Is Hardened NETLOGON path Set? (Value should be RequireMutualAuthentication=1, RequireIntegrity=1 - not blank):" $regkey14.GetValue("\\*\NETLOGON")
         #           }
         #               else
         #               {
         #               write-host -ForegroundColor Red "Hardened NETLOGON path is not set"
         #               }   
            
         #   if ($regkey15 -ne $null)
         #           {
         #           write-host "Is Hardened SYSVOL path Set? (Value should be RequireMutualAuthentication=1, RequireIntegrity=1 - not blank):" $regkey15.GetValue("\\*\SYSVOL")
         #           }
         #               else
         #               {
         #               write-host -ForegroundColor Red "Hardened SYVOL path is not set"
         #               }   


#Service Settings

 
  
            write-host ""   
            Write-Host -ForeGroundColor Cyan "The following services should be disabled:"
            write-host ""             
                        
            if ($regkey16 -ne $null)
                    {
                    write-host "Is Sync Host Service Disabled? (Value should be 4 - not 2 or blank):" $regkey16.GetValue("Start")
                    }
                        else
                        {
                        write-host -ForegroundColor Red "Sync Host Service is Enabled"
                        }                                                              
           


            Get-Service -ComputerName $server.DNSHostName -DisplayName "Downloaded Maps Manager" | format-list -Property DisplayName, Status, StartType
            Get-Service -ComputerName $server.DNSHostName -DisplayName "Connected User Experiences and Telemetry" | format-list -Property DisplayName, Status, StartType
            Get-Service -ComputerName $server.DNSHostName -DisplayName "Geolocation Service" | format-list -Property DisplayName, Status, StartType
            Get-Service -ComputerName $server.DNSHostName -DisplayName "Xbox Live Auth Manager" | format-list -Property DisplayName, Status, StartType
            Get-Service -ComputerName $server.DNSHostName -DisplayName "Xbox Live Game Save" | format-list -Property DisplayName, Status, StartType
            Get-Service -ComputerName $server.DNSHostName -DisplayName "Sync Host_*" | format-list -Property DisplayName, Status, StartType

     
 #Scheduled Tasks

    

            write-host -ForegroundColor Cyan "The Following Tasks Should Be Disabled:"
       
            Invoke-Command -ComputerName $server.DNSHostName -ScriptBlock {Get-ScheduledTask | where {$_.TaskName -eq 'XblGameSaveTask'} | format-list -Property TaskName, State }
            Invoke-Command -ComputerName $server.DNSHostName -ScriptBlock {Get-ScheduledTask | where {$_.TaskName -eq 'XblGameSaveTaskLogon'} | format-list -Property TaskName, State }
           
            
 #Windows Features

            write-host -ForegroundColor Cyan "The Following Features Should not be Installed:"
 
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "Windows-Defender-Features" | Format-List -Property Name, InstallState
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "Windows-Defender" | Format-List -Property Name, InstallState
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "Windows-Defender-Gui" | Format-List -Property Name, InstallState
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "RSAT-Hyper-V-Tools " | Format-List -Property Name, InstallState
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "Hyper-V-Tools" | Format-List -Property Name, InstallState
            Get-WindowsFeature -ComputerName $server.DNSHostName -Name "Hyper-V-PowerShell" | Format-List -Property Name, InstallState
            #Get-WindowsFeature -ComputerName $server.DNSHostName -Name "FS-SMB1" | Format-List -Property Name, InstallState

            write-host ""


                        
    }
            }