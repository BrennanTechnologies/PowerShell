﻿#Reads Active Directory for all Citrix Servers and checks for correct XenApp VDA/Shared Netscaler, Office licensing regkey settings, cals, etc. 
#VDA's must be running 2012 R2 to pull correct RDS licensing.
#Must be run from a DC with the RD Licensing installed.
#

#Version 3.0 3/15/2018 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*" -and name -like "*ctx*" -or name -like "*citrix*" -or name -like "*vda*" -or name -like "*xenapp*" }

foreach ($server in $servers) 
{
    
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
        {
           
            $reg1 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey1= $reg1.OpenSubKey("SOFTWARE\Citrix\VirtualDesktopAgent")

            $reg2 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey2= $reg2.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services")

            $reg3 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey3= $reg3.OpenSubKey("SOFTWARE\Microsoft\Office\ClickToRun\Configuration")

            $reg4 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $server.Name)
            $regKey4= $reg4.OpenSubKey("SOFTWARE\Microsoft\Office\ClickToRun\Scenario\Install")


            if ($regkey1 -eq $null)
                {
                write-host -ForegroundColor Red $server.Name "does not have XenApp installed!"
                
                }

                if ($regkey1 -ne $null)
                    {
                    write-host -ForegroundColor Cyan $server.Name "Multiple Forest Support (Should be 1):" $regkey1.GetValue("SupportMultipleForest")
                    write-host -ForegroundColor Cyan $server.Name "DDC Servers:" $regkey1.GetValue("ListOfDDCs")
                    write-host -ForegroundColor Cyan $server.Name "Configured RDS Licensing Servers:" $regkey2.GetValue("LicenseServers")
                    write-host -ForegroundColor Cyan $server.Name "Configured RDS Licensing Mode (Should be 4):" $regkey2.GetValue("LicensingMode")
                    write-host ""
                    }
                        
                     if ($regkey3 -ne $null)
                         {
                         write-host ""
                         write-host -ForegroundColor Cyan $server.Name "Shared Office Licensing Mode (Should be 1):" $regkey3.GetValue("SharedComputerLicensing")
                         }

                            if ($regkey3 -eq $null)
                                {
                                write-host ""
                                write-host -ForegroundColor Red $server.Name "does not have shared Office Licensing configured!"
                                }

                                if ($regkey4 -ne $null)
                                     {
                                     write-host ""
                                     write-host -ForegroundColor Cyan $server.Name "Microsoft O365 Products Installed:" $regkey4.GetValue("ProductsToAdd")
                                     }
                                        
                                        if ($regkey4 -eq $null)
                                            {
                                            write-host ""
                                            write-host -ForegroundColor Red $server.Name "does not have any O365 Office products installed!"
                                            }
                }
       
       
        }

Write-host “”
Write-host -ForegroundColor Green "RD CALS:”
    
# Filename of the export
$filename = “RDS-CAL-Report.csv”
# Import RDS PowerShell Module
import-module remotedesktopservices

# Open RDS Location
Set-Location -path rds:

# Remove previous reports (Optional)
remove-item RDS:\LicenseServer\IssuedLicenses\PerUserLicenseReports\* -Recurse

# Create new RDS report
Invoke-WmiMethod -Class Win32_TSLicenseReport -Name GenerateReportEx

# Name is automatically generated
$NewReportName = Get-ChildItem RDS:\LicenseServer\IssuedLicenses\PerUserLicenseReports -name

# Get issued licenses
$IssuedLicenseCount = get-item RDS:\LicenseServer\IssuedLicenses\PerUserLicenseReports\$NewReportName\Win8\IssuedCount
# Count issued licenses
$IssuedLicenseCountValue = $IssuedLicenseCount.CurrentValue

# Get installed licenses
$InstalledLicenseCount = get-item RDS:\LicenseServer\IssuedLicenses\PerUserLicenseReports\$NewReportName\Win8\InstalledCount
# Count installed licenses
$InstalledLicenseCountValue = $InstalledLicenseCount.CurrentValue

# Installed – Issued
$Available = $InstalledLicenseCount.CurrentValue – $IssuedLicenseCount.CurrentValue
# Show percentage available
$AvailablePercent = ($Available /$InstalledLicenseCount.CurrentValue)*100
$AvailablePercent = “{0:N0}” -f $AvailablePercent

# Display info

Write-host “Installed: $InstalledLicenseCountValue”
Write-host “Issued: $IssuedLicenseCountValue”
Write-host “Available: $Available [ $AvailablePercent % ]”

# Add the information into an Array

[System.Collections.ArrayList]$collection = New-Object System.Collections.ArrayList($null)
$obj = @{
Installed = $InstalledLicenseCountValue
Available = $Available
AvailablePercent = $AvailablePercent
Issued = $IssuedLicenseCountValue
Date = get-date
}