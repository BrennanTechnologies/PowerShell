﻿#Read Active Directory for all server names and lists NIC settings.
#
#Version 1.0 5/4/2015 Rob West - ECI


import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

foreach ($server in $servers) {

if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)

  {

    # Output server name and NIC settings via external script (Get-ServerDNS.ps1 must be in same directory)
   

    $scriptPath = Split-Path $myInvocation.MyCommand.Path

    & $scriptpath\Get-ServerDNS.ps1 -computername $server.DNSHostName

    Write-Host "__________________________________________________________________"
    Write-Host ""
    
   }
   
    
}