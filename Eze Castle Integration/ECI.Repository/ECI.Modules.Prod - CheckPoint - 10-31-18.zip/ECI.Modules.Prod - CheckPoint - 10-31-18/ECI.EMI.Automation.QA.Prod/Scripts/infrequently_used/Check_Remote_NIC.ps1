$serverName = Read-Host �Enter server name�
$NicConfig = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -ComputerName $serverName
$NicConfig | Format-List *