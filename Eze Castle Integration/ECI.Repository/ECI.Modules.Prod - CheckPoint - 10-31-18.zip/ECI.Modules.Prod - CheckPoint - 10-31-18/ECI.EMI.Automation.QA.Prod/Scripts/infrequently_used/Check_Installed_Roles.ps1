﻿#Read Active Directory for all server names and checks for installed Roles and Features.
#
#
#Version 1.0 5/20/2014 Rob West - ECI

import-module ActiveDirectory

$results = @()

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}


foreach ($server in $servers)



{
	
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
    {
	
  

    $results = Get-WmiObject Win32_ServerFeature -ComputerName $server.DNSHostName | Select-Object PSComputerName, Name
   
    
    }

}

$results | Export-Csv -NoTypeInformation -path $env:userprofile\Desktop\Server_Features.csv

