﻿#Checks for IIS/SSL/FTP/Cert security settings.
#
#Version 1.1 9/16/2013 Rob West - ECI



#Checks to see if IIS is running

$iis = get-wmiobject Win32_Service -Filter "name='W3SVC'"

write-host ""

if($iis.State -eq "Running")
{Write-Host -ForeGroundColor Red "IIS is running"}
 
else
{Write-Host -ForeGroundColor Green "IIS is not running"}

write-host ""



#Checks to see if FTP is running plain text



$Computer = "127.0.0.1"
$Port = "21"
        
        
        $Socket = New-Object Net.Sockets.TcpClient
        $ErrorActionPreference = 'SilentlyContinue'
        $Socket.Connect($Computer, $Port)
        $ErrorActionPreference = 'Continue'
        
        
        if ($Socket.Connected) {
            
            Write-Host -ForeGroundColor Red "Port 21 is open - FTP is using Plain Text"
            $Socket.Close()
            
        }
         
        else {
            
            Write-Host -ForeGroundColor Green  "Port 21 is closed - FTP is not using Plain Text"
            
        }
        
       
        $Socket = $null
        
        write-host ""




#Looks for Powershell Version 2 or higher

If ((Get-Host).Version.Major -ge 2) 

{



#Looks in the registry for SSL 3.0

if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000000)
    {
    write-host -ForegroundColor Green "SSL 3.0 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "SSL 3.0 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, SSL 3.0 is enabled"
}


#Looks in the registry for TLS 1.0

if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000000)
    {
    write-host -ForegroundColor Green "TLS 1.0 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "TLS 1.0 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, TLS 1.0 is enabled"
}

    
#Looks in the registry for TLS 1.1

if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000000)
    {
    write-host -ForegroundColor Green "TLS 1.1 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "TLS 1.1 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, TLS 1.1 is enabled"
}

#Looks in the registry for TLS 1.2

if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000000)
    {
    write-host -ForegroundColor Green "TLS 1.2 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "TLS 1.2 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, TLS 1.2 is enabled"
}


#Looks in the registry for Multi-Protocol Unified Hello

if (Test-Path -Path "HKLM:SYSTEM\ControlSet001\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server" -Name "DisabledByDefault"  -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000001)
    {
    write-host -ForegroundColor Green "Multi-Protocol Unified Hello is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "Multi-Protocol Unified Hello is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, Multi-Protocol Unified Hello is enabled!"
}



#Looks in the registry for PCT 1.0

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000001)
    {
    write-host -ForegroundColor Green "PCT 1.0 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "PCT 1.0 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, PCT 1.0 is enabled!"
}



#Looks in the registry for SSL 2.0

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server" -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    if($reg1.DisabledByDefault -eq 00000001)
    {
    write-host -ForegroundColor Green "SSL 2.0 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "SSL 2.0 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, SSL 2.0 is enabled!"
}


#Looks in the registry for NULL ciphers



if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\NULL")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\NULL" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "NULL is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "NULL is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist,NULL is enabled!"
}



#Looks in the registry for weak (DES 56/56) ciphers



if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\DES 56/56")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\DES 56/56" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "DES 56/56 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "DES 56/56 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, DES 56/56 is enabled!"
}




#Looks in the registry for weak (RC2 40/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC2 40/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC2 40/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC2 40/128 is enabled!"
}


#Looks in the registry for weak (RC4 128/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    
    {
    write-host -ForegroundColor Green "RC4 128/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC4 128/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC4 128/128 is enabled!"
}

#Looks in the registry for weak (RC2 40/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    
    {
    write-host -ForegroundColor Green "RC2 40/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC2 40/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC4 128/128 is enabled!"
}

#Looks in the registry for weak (RC4 40/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC4 40/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC4 40/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC4 40/128 is enabled!"
}

#Looks in the registry for weak (RC2 56/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 56/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 56/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC2 56/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC2 56/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC2 56/128 is enabled!"
}



#Looks in the registry for weak (RC4 56/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC4 56/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC4 56/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC4 56/128 is enabled!"
}

#Looks in the registry for weak (RC4 64/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 64/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 64/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC4 64/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC4 64/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC4 56/128 is enabled!"
}


#Looks in the registry for weak (RC2 40/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 40/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 00000000)
    {
    write-host -ForegroundColor Green "RC2 40/128 is explicitly disabled"
    }
        else 
        {
        write-host -ForegroundColor Red "RC2 40/128 is explicitly enabled!"
        }
  }    

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, RC2 40/128 is enabled!"
}




#Looks in the registry for strong (Triple DES 168/168) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168/168")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168/168" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "Triple DES 168/168 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "Triple DES 168/168 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, Triple DES 168/168 is enabled"
}


#Looks in the registry for strong (AES 128/128) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\AES 128/128")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\AES 128/128" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "AES 128/128 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "AES 128/128 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, AES 128/128 is enabled"
}


#Looks in the registry for strong (AES 256/256) ciphers

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\AES 256/256")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\AES 256/256" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "AES 256/256 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "AES 256/256 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, AES 256/256 is enabled"
}


#Looks in the registry for strong (MD5) Hash

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "MD5 is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "MD5 is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, MD5 is enabled"
}


#Looks in the registry for strong (SHA) Hash

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "SHA is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "SHA is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, SHA is enabled"
}

#Looks in the registry for strong (Diffie Hellman) Key Exchange

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "Diffie Hellman is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "Diffie Hellman is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, Diffie Hellman is enabled"
}


#Looks in the registry for strong (PKCS) Key Exchange

if (Test-Path -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS")

{
    $reg1 = Get-ItemProperty -Path "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS" -Name "Enabled" -ErrorAction SilentlyContinue

    if($reg1.Enabled -eq 0xFFFFFFFF)
    
    {
    write-host -ForegroundColor Green "PKCS is explicitly enabled"
    }
        else 
        {
        write-host -ForegroundColor Red "PKCS is explicitly disabled!"
        }
  }    

else

{
write-host -ForegroundColor Green "The Registry Key does not exist, PKCS is enabled"
}



#Looks in the registry for Weak CSG Cipher Strength

if (Test-Path -Path "HKLM:\SYSTEM\ControlSet001\services\CtxSecGwy\LogonAgent")

{
    $reg1 = Get-ItemProperty -Path "HKLM:\SYSTEM\ControlSet001\services\CtxSecGwy\LogonAgent" -Name "CipherStrength" -ErrorAction SilentlyContinue

    if($reg1.CipherStrength -eq "GOV")
    {
    write-host -ForegroundColor Green "CSG Cipher Strength is Correct"
    }
        else 
        {
        write-host -ForegroundColor Red "CSG Cipher Strength is Inorrect!"
        }
  }    

 

else

{
write-host -ForegroundColor Red "The Registry Key does not exist, CSG not installed"
}

Write-Host ""

}

else

{
write-host ""
write-host -ForegroundColor Red "Cipher checks are unsupported on Powershell prior to Version 2.0, please compare registry to script settings manually or install PS 2.0 or higher"
}







#Looks in XenApp Website web.config for http error settings

write-host ""	

if (test-path "C:\inetpub\wwwroot\Citrix\XenApp")
{
$config = [xml](Get-Content -Path "C:\inetpub\wwwroot\Citrix\XenApp\web.config")


    if ($config.configuration."system.web".CustomErrors.Mode -like "Off")
    {
    write-host -ForegroundColor Red "IIS Error Reporting appears to be Detailed (incorrect setting)"
    }
    elseif ($config.configuration."system.web".CustomErrors.Mode -like "On")
    {
    write-host -ForegroundColor Green "IIS Error Reporting appears to be Custom (correct setting)"
    }

 }
 
 else
 {
 write-host -ForegroundColor Red "CSG doesn't appear to be installed / web.config not in location we're looking for"
 }

 write-host ""	


#Look for expiring or expired certificates


#Number of days to look for expiring certificates

$threshold = 14

$deadline = (Get-Date).AddDays($threshold)

$store=new-object System.Security.Cryptography.X509Certificates.X509Store("My","LocalMachine")

$store.open("ReadOnly")

$store.certificates | % {

If ($_.NotAfter -lt $deadline) {

write-host ""
write-host -ForegroundColor Red "The following certificates are expiring or have expired!"


$_ | Select Issuer, Subject, NotAfter, @{Label="ExpiresIn"; Expression={($_.NotAfter - (Get-Date)).Days}}

}

}