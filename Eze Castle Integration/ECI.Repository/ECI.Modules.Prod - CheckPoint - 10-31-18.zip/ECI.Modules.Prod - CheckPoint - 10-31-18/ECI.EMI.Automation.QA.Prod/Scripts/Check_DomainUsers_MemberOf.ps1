﻿#Read Active Directory to find what groups Domain Users is a Member of
#
#Version 1.0 5/30/2017 Rob West - ECI

import-module ActiveDirectory

$GroupNames = Get-ADPrincipalGroupMembership -Identity "Domain Users"

foreach($GroupName in $GroupNames) 
    {
    
    if ($GroupName.distinguishedName -like "*Builtin*")
        {
       "`n"
            write-host "These are Built-In groups and are likely okay :"
            write-host ""
            write-host -ForegroundColor Green "Name:" $GroupName.Name,"Scope:"$GroupName.GroupScope,"Category:"$GroupName.GroupCategory
            write-host ""
       
        }
            else
            {
            "`n"
                write-host "These are custom groups and could be security risks :"
                write-host ""
                write-host -ForegroundColor Red "Name:" $GroupName.Name,"Scope:"$GroupName.GroupScope,"Category:"$GroupName.GroupCategory
                write-host ""
            }
    }