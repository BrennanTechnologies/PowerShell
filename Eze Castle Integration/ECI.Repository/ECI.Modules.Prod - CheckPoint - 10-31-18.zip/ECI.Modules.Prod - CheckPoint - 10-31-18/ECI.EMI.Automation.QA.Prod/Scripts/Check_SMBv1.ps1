﻿#Reads Active Directory for all Servers and checks to see if SMBv1 is enabled/disabled
#

#Version 1.0 9/20/2017 Rob West - ECI

import-module ActiveDirectory

$servers = Get-ADComputer -Filter {operatingsystem -like "*server*"}

$keyname = 'SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'

foreach ($server in $servers) 
{
    
    if (test-connection -ComputerName $server.DNSHostName -count 2 -quiet)
        {
           $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("LocalMachine", $server.Name)
           $key = $reg.OpenSubKey($keyname)
           $value = $key.GetValue('SMB1')
            

            if ($value -eq "0")
                {
                write-host -ForegroundColor Green $server.Name "SMBv1 Disabled"
                }    
                  
                    else
                    {
                    (write-host -ForegroundColor Red $server.name "SMBv1 Enabled")
                    }
                    
         }
 }
    
