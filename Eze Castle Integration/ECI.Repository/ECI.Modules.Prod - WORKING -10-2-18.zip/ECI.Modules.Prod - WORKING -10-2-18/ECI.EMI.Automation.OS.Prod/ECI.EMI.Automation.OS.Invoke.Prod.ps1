﻿#############################################
### Invoke Commands on Guest from vCenter
### ECI.EMI.Automation.OS.Invoke.ps1
#############################################

Param(
    [Parameter(Mandatory = $True)] [string]$ServerID,
    [Parameter(Mandatory = $True)] [string]$ConfigurationMode,
    [Parameter(Mandatory = $True)] [string]$HostName,
    [Parameter(Mandatory = $True)] [string]$ServerRole,
    [Parameter(Mandatory = $True)] [string]$IPv4Address,
    [Parameter(Mandatory = $True)] [string]$SubnetMask,
    [Parameter(Mandatory = $True)] [string]$DefaultGateway,
    [Parameter(Mandatory = $True)] [string]$PrimaryDNS,
    [Parameter(Mandatory = $True)] [string]$SecondaryDNS,
    [Parameter(Mandatory = $True)] [string]$ClientDomain = "corp.geemoneymgmt.com"
)

function Show-Parameters-DELETEME
{
    Write-Host "PARAMETERS: ECI.EMI.Automation.OSConfiguration.Invoke.ps1  : " -ForegroundColor Gray
    Write-Host "RequestID          : " $ServerID         -ForegroundColor DarkGreen
    Write-Host "HostName           : " $HostName         -ForegroundColor DarkGreen
    Write-Host "ServerType         : " $ServerRole       -ForegroundColor DarkGreen
    Write-Host "IPv4Address        : " $IPv4Address      -ForegroundColor DarkGreen
    Write-Host "SubnetMask         : " $SubnetMask       -ForegroundColor DarkGreen
    Write-Host "DefaultGateway     : " $DefaultGateway   -ForegroundColor DarkGreen
    Write-Host "PrimaryDNS         : " $PrimaryDNS       -ForegroundColor DarkGreen
    Write-Host "SecondaryDNS       : " $SecondaryDNS     -ForegroundColor DarkGreen
    Write-Host "ClientDomain       : " $ClientDomain     -ForegroundColor DarkGreen
}

function Set-VMHostName-DELETEME
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### Set VM Name fromn HostName Parameters
    ###----------------------------------------------------------------
        $global:VM = $HostName
        Write-Host "Setting VM Host Name: VM =" $VMName -ForegroundColor Yellow
}

#######################################
### Import Bootstap Module
#######################################
[ScriptBlock]$BootStrapModuleLoader = 
{
    ipconfig /all
    ### BEGIN: Import BootStrap Module Loader
    Set-ExecutionPolicy ByPass -Scope CurrentUser
    $AcctKey=ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials=$Null
    $Credentials=New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath="\\eciscripts.file.core.windows.net\clientimplementation"
    New-PSDrive -Name V -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    #. "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
    ### END: Import BootStrap Module Loader
} 

#######################################
### Function: Execute Invoke Process
#######################################
function Invoke-ECI.ScriptText
{
    ### Convert SubnetMask to CIDR
    ### --------------------------------------------
    switch ( $SubnetMask )
    {
        "255.255.255.0"      { $SubnetPrefixLength = "24" }
        "255.255.255.128"    { $SubnetPrefixLength = "25" }
        "255.255.255.192"    { $SubnetPrefixLength = "26" }
        "255.255.255.224"    { $SubnetPrefixLength = "27" }
        "255.255.255.240"    { $SubnetPrefixLength = "28" }
        "255.255.255.248"    { $SubnetPrefixLength = "29" }
        "255.255.255.252"    { $SubnetPrefixLength = "30" }
        "255.255.255.254"    { $SubnetPrefixLength = "31" }
    }

    ### Replace Parameters with #LiteralValues#
    ### ---------------------------------------
    $Params = @{
    "#Env#"                           = $Env
    "#Environment#"                   = $Environment
    "#Step#"                          = $Step
    "#VMName#"                        = $VMName
    "#ServerID#"                      = $ServerID
    "#ServerRole#"                    = $ServerRole
    "#HostName#"                      = $HostName
    "#ClientDomain#"                  = $ClientDomain
    "#IPv4Addres#"                    = $IPv4Address
    "#SubnetPrefixLength#"            = $SubnetPrefixLength
    "#DefaultGateway#"                = $DefaultGateway
    "#PrimaryDNS#"                    = $PrimaryDNS
    "#SecondaryDNS#"                  = $SecondaryDNS
    "#BuildVersion#"                  = $BuildVersion
    "#CDROMLetter#"                   = $CDROMLetter
    "#InternetExplorerESCPreference#" = $InternetExplorerESCPreference
    "#IPv6Preference#"                = $IPv6Preference
    "#LocalAdministrator#"            = $LocalAdministrator
    "#NetworkInterfaceName#"          = $NetworkInterfaceName
    "#RDPResetrictionsPreference#"    = $RDPResetrictionsPreference
    "#RemoteDesktopPreference#"       = $RemoteDesktopPreference
    "#SwapFileBufferSizeMB#"          = $SwapFileBufferSizeMB
    "#SwapFileLocation#"              = $SwapFileLocation
    "#SwapFileMemoryThreshholdGB#"    = $SwapFileMemoryThreshholdGB
    "#SwapFileMultiplier#"            = $SwapFileMultiplier
    "#WindowsFirewallPreference#"     = $WindowsFirewallPreference
    }

    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
    }

    ### Inject BootStrap Module Loader into VM Host
    ### ---------------------------------------
    #$ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

    ### Debugging: Write ScriptText Block to Screen
    ### ---------------------------------------
    #Write-Host "ScriptText:`n" $ScriptText -ForegroundColor Gray

    ###############################
    ### Inovke VMScript
    ###############################
        ###---------------------------------------------------------
        ### Invoke-VMScript
        ### -Verbose 
        ### -Debug
        ### | Select -ExpandProperty ScriptOutput
        ### | Select -ExpandProperty ExitCode
        ###---------------------------------------------------------

   
   # Write-Host "Executing Invoke-VMScript Function: $((Get-PSCallStack)[0].Command) Step: $Step" -ForegroundColor Yellow

    Write-Host `n('*' * 55)`n `n "      ~~~~~~~~ INVOKING OS CONFIGURATION ~~~~~~~~  " `n`n(' ' * 18) "STEP:" $Step `n  `n " --------- THIS PROCESS MAY TAKE SEVERAL MINUTES ---------  " `n`n('*' * 55)`n -ForegroundColor Green

    ### Development: Run Invoke without Variable
    ### -------------------------------------------
    #$Invoke = 
    Write-Host "HostName  : " $HostName
    Write-Host "VMName    : " $VMName

    #Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose #| Select -ExpandProperty ScriptOutput #ExitCode
    
    ### -------------------------------------------
    ### Production: Run Invoke as Variable
    ### -------------------------------------------
    #$Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 #-Verbose
    $Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminPassword #-Verbose
    
    if($Invoke)
    {
        ### Check Exit Code for any Errors
        ### ---------------------------------------
        Write-Host $Invoke.ScriptOutput

        if (($Invoke.ExitCode) -eq 0) {
            Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
        }
        elseif (($Invoke.ExitCode) -ne 0) {
            Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
        }
    }
}

##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-ECI.EMI.Automation.OS.InGuest
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host `n`r('=' * 100)`n "BEGIN INVOKE FUNCTION - IN-GUEST  : " $((Get-PSCallStack)[0].Command) "-Step:" $Step `n`r('=' * 100) -ForegroundColor Gray
    
    

    [ScriptBlock]$ScriptText = 
    {
    ### Import BootStrap Module Loader
    ### -------------------------------
    #BootStrapModuleLoader#       
    ### *SOFT* Paramters
    ### -------------------------------
    $global:Env                              = "#Env#"    
    $global:Environment                      = "#Environment#"    
    $global:Step                             = "#Step#"    
    $global:VM                               = "#VM#"    
    $global:ServerID                         = "#ServerID#"  
    $global:ServerRole                       = "#ServerRole#"  
    $global:HostName                         = "#HostName#"
    $global:ClientDomain                     = "#ClientDomain#"
    $global:IPv4Address                      = "#IPv4Addres#"
    $global:SubnetPrefixLength               = "#SubnetPrefixLength#"
    $global:DefaultGateway                   = "#DefaultGateway#"
    $global:PrimaryDNS                       = "#PrimaryDNS#"
    $global:SecondaryDNS                     = "#SecondaryDNS#"
    $global:BuildVersion                     = "#BuildVersion#"
    $global:CDROMLetter                      = "#CDROMLetter#"
    $global:InternetExplorerESCPreference    = "#InternetExplorerESCPreference#"
    $global:IPv6Preference                   = "#IPv6Preference#"
    $global:LocalAdministrator               = "#LocalAdministrator#"
    $global:NetworkInterfaceName             = "#NetworkInterfaceName#"
    $global:RDPResetrictionsPreference       = "#RDPResetrictionsPreference#"
    $global:RemoteDesktopPreference          = "#RemoteDesktopPreference#"
    $global:SwapFileBufferSizeMB             = "#SwapFileBufferSizeMB#"
    $global:SwapFileLocation                 = "#SwapFileLocation#"
    $global:SwapFileMemoryThreshholdGB       = "#SwapFileMemoryThreshholdGB#"
    $global:SwapFileMultiplier               = "#SwapFileMultiplier#"
    $global:WindowsFirewallPreference        = "#WindowsFirewallPreference#"
    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    #. "Y:\ECI.Modules.Dev\ECI.EMI.Automation.OS.Dev\ECI.EMI.Automation.OS.InGuest.ps1"

    foreach($Module in (Get-Module -ListAvailable ECI.*))
    {
        Write-Host "Importing Module: " $Module
        Import-Module -Name $Module.Path -DisableNameChecking
    }
    
    ### Launch In-Guest Script
    #. "C:\Program Files\WindowsPowerShell\Modules\ECI.Modules.Dev\ECI.EMI.Automation.OS.Dev\ECI.EMI.Automation.OS.InGuest.Prod.ps1"  #<---- NEED $ENV VAriable!!!!!!!!!!!!!!!!!!!!!!!!!!
    . "C:\Program Files\WindowsPowerShell\Modules\ECI.Modules.$Env\ECI.EMI.Automation.OS.$Env\ECI.EMI.Automation.OS.InGuest.$Env.ps1"  #<---- NEED $ENV VAriable!!!!!!!!!!!!!!!!!!!!!!!!!!

    } # END ScriptText

    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    ### Invoke-MVScript Breaks if -GT 1505
    #Invoke-Expression "dir"      
   
    ##### Testing 6-17-18 3:34
        ### Invoke VMGuest.ServerBuildTemplate.ps1
        ### ----------------------------------   
        #. "Y:\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.ConfigServer.OS.InGuest.ps1"    
 
    Invoke-ECI.ScriptText
}

##############################################################################
### Execute the Script
##############################################################################
&{ 
    BEGIN
    {
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #<--(Set Path)
        Write-Host `n`n('*' * 50)`n " --------- STARTING OS CONFIGURATION --------- " `n('*' * 50)`n    `n('-' * 50)`n "ECI.EMI.Automation.OS.Invoke.$Env.ps1" `n('-' * 50)`n -ForegroundColor Green
        $script:OSStartTime = Get-Date
        $global:VerifyErrorCount = 0
        $global:ProgressPreference = "SilentlyContinue"
        $global:ErrorActionPreference = "Stop"
        Get-ECI.EMI.Automation.LocalAdminAccount -Environment $Environment -Preconfig
        Configure-ECI.EMI.Automation.ExecutionPolicyonVMGuest -VMName $VMName
        Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
        
        ### Install ECI Modules on Guest
        ###---------------------------------
        $Params = @{
            Env         = $Env 
            Environment = $Environment
        }
        Install-ECI.EMI.Automation.ECIModulesonVMGuest @Params
    }

    PROCESS
    {
        Write-Host `n('-' * 75)`n "BEGIN INVOKE FUNCTION - vCenter   : " (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 30) -ForegroundColor Yellow
        
        ##########################################
        ### Invoke Configuration in VM Guest
        ##########################################

        ###----------------------------------------------
        ### Step 1: Rename-ECI.GuestComputer
        ###----------------------------------------------
        function Rename-ECI.EMI.Automation.OS.GuestComputer
        {
            $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
        
            ###---------------------------------------------------------------------------------------------
            Invoke-ECI.EMI.Automation.OS.InGuest -Step Rename-ECI.EMI.Automation.OS.GuestComputer
            ###---------------------------------------------------------------------------------------------

            Write-Host "Guest OS was restarted after Renaming Computer:  `nWaiting for Guest OS to Resume . . ." -ForegroundColor Yellow
            Start-ECI.EMI.Automation.Sleep -t 60
            Wait-ECI.EMI.Automation.VM.VMTools -VMName $VMName -t 240
            Copy-ECI.EMI.Automation.VMLogsfromGuest
            Write-ECI.EMI.Automation.VMLogstoSQL

        }

        ###----------------------------------------------
        ### Step 2: Configure OS
        ###----------------------------------------------
        function Configure-ECI.EMI.Automation.OS.GuestComputer
        {
            $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

            Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName

            ### Mount OS ISO
            ###---------------------------------
            $Params = @{
                VMName      = $VMName 
                ISOName     = "2016Server"
            }
            Mount-ECI.EMI.Automation.VM.ISO -VMName $VMName -ISOName 2016Server
                
            ###---------------------------------------------------------------------------------------------
            Invoke-ECI.EMI.Automation.OS.InGuest -Step Configure-ECI.EMI.Automation.OS.GuestComputer
            ###---------------------------------------------------------------------------------------------
            
            ### Copy Log Files and Write to SQL
            ###---------------------------------
            Copy-ECI.EMI.Automation.VMLogsfromGuest
            Write-ECI.EMI.Automation.VMLogstoSQL
        }

        ###----------------------------------------------
        ### Step 3: Configure Roles
        ###----------------------------------------------
        function Configure-ECI.EMI.Automation.Roles.GuestComputer
        {
            $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
            
            Write-Host `n('=' * 75)`n "Configuring Server Role: " $ServerRole `n('=' * 75)`n -ForegroundColor Magenta

            ### Role Specific Configurerations
            ###---------------------------------
            switch ( $ServerRole )
            {
                "2016Server"
                {
                    $ConfigureRole = $False
                }
                "2016FS" 
                {
                    $ConfigureRole = $False
                }
                "2016DC" 
                {
                    $ConfigureRole = $False
                }
                "2016DCFS" 
                {
                    $ConfigureRole = $False
                }
                "2016VDA" 
                { 
                    $ConfigureRole = $True
                    Mount-ECI.EMI.Automation.VM.ISO -VM $VMName -ISOName "XenApp"
                }
                "2016SQL" 
                {
                    $ConfigureRole = $False
                }
                "2016SQLOMS"  
                {
                    $ConfigureRole = $False
                }
            }

            ### Execute Role Configureration
            ###---------------------------------
            if($ConfigureRole -eq $True)
            {
                Write-Host "ConfigureRole:  " $ConfigureRole -ForegroundColor Yellow
                Write-Host "Configuring Server Role . . . " -ForegroundColor Yellow
            
                Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
            
                ###---------------------------------------------------------------------------------------------
                Invoke-ECI.EMI.Automation.OS.InGuest -Step $ServerRole
                ###---------------------------------------------------------------------------------------------
            
                Copy-ECI.EMI.Automation.VMLogsfromGuest
                Write-ECI.EMI.Automation.VMLogstoSQL
            }

            elseif($ConfigureRole -eq $False)
            {
                Write-Host "ConfigureRole:  " $ConfigureRole -ForegroundColor Magenta
                Write-Host "There are no specific Role based configurations needed for this build." -ForegroundColor Gray
            }

            else
            {
                Write-Host "There are no specific Role based configurations needed for this build." -ForegroundColor Red
            }
        }

        ###----------------------------------------------
        ### Step 4: Restart Guest OS
        ###----------------------------------------------
        function Restart-ECI.EMI.Automation.OS.GuestComputer
        {
            ### Stop VM
            ###----------------------------
            Stop-ECI.EMI.Automation.VM                                               # <--- need gracefule shutdown and restart!!!!!!!!!!!!!!!!!!!
            
            ### Stop VM
            ###----------------------------
            Start-ECI.EMI.Automation.VM
        }

        &{
            PROCESS
            {
                Rename-ECI.EMI.Automation.OS.GuestComputer
                Configure-ECI.EMI.Automation.OS.GuestComputer
                Configure-ECI.EMI.Automation.Roles.GuestComputer
                Restart-ECI.EMI.Automation.OS.GuestComputer
            }
        }
    }

    END
    {
        Delete-ECI.EMI.Automation.ServerLogs -HostName $HostName
        Delete-ECI.EMI.Automation.ECIModulesonVMGuest
        Write-Host "SCRIPT END BLOCK:" (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        $OSStopTime = Get-Date
        $global:OSElapsedTime = ($OSStopTime-$OSStartTime)
        Write-Host `n`n('=' * 75)`n "OS Configuration: Total Execution Time:`t" $OSElapsedTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "END OS configuration SCRIPTS" -ForegroundColor Gray
        Stop-Transcript
    }

}

