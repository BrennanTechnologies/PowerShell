﻿######################################
### Execute Commands In-Guest
### ECI.EMI.Automation.OS.InGuest.ps1
######################################

function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\_VMAutomationLogs\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

& { 
    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #<--SET Path C:\Scripts\VMAutomation\Transcripts
        Write-Host "`nBEGINBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        #Import-SoftParametersFromAPI #<--- delete me?????
        Show-ECI.EMI.Automation.OSParameters
        
     }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "`n" ("=" * 75) "`nPROCESSBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)

        ###----------------------------------------------
        ### Step 1: Rename-ECI.GuestComputer
        ###----------------------------------------------
        if ($Step -eq "Rename-ECI.EMI.Automation.OS.GuestComputer")
        {
            Start-Transcript
            Rename-ECI.EMI.Automation.OS.GuestComputer
            Restart-ECI.EMI.Automation.OS.GuestComputer
            Stop-Transcript
        }

        ###----------------------------------------------
        ### Step 2: Configure OS
        ###----------------------------------------------
        if ($Step -eq "Configure-ECI.EMI.Automation.OS.GuestComputer")
        {
            Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 

            Start-Transcript
           
            Configure-ECI.EMI.Automation.OS.NetworkInterface # -ConfigurationMode Report
            Configure-ECI.EMI.Automation.OS.IPv6 # -ConfigurationMode Configure
            Configure-ECI.EMI.Automation.OS.CDROM
            Configure-ECI.EMI.Automation.OS.RemoteDesktop 
            Configure-ECI.EMI.Automation.OS.WindowsFirewallProfile #-ConfigurationMode Configure
            Configure-ECI.EMI.Automation.OS.InternetExplorerESC
            Configure-ECI.EMI.Automation.OS.WindowsFeatures

            Initialize-ECI.EMI.Automation.OS.SwapFileDisk

            Configure-ECI.EMI.Automation.OS.Folders
            Configure-ECI.EMI.Automation.OS.JoinDomain

            Stop-Transcript
        }

        ###----------------------------------------------
        ### Step 3: Configure Roles
        ###----------------------------------------------
        Write-Host `n('-' * 50)`n "Executing: " $Step `n('-' * 50)`n 
        Start-Transcript

        switch ( $Step )
        {
            "2016Server" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }

            "2016FS" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016DC" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016DCFS" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016VDA" 
            {
                Write-Host $Step
                Import-Module ECI.EMI.Automation.Role.Citrix.Dev -DisableNameChecking
                Install-ECI.XenDesktopVDA 
                Configure-CrossForest
                Install-XenDesktopStudio
        
            }
            "2016SQL" 
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
            "2016SQLOMS"  
            {
                Write-Host $Step
                Write-Host "The configuration for this Role is not available yet."
                Start-ECI.EMI.Automation.Sleep
            }
        }
        Stop-Transcript
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "ENDBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Write-ServerBuildTag
        Close-LogFile
        Stop-Transcript
    }
}
