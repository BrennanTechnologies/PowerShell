﻿###################################
### Configure Guest OS Module
### ECI.EMI.Automation.OS.Prod.psm1
###################################

function Configure-ECI.EMI.Automation.OS.NetworkInterface
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "NetworkInterfaceName"
    $DesiredState      = $NetworkInterfaceName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Rename-NetAdapter (Get-NetAdapter -Name $CurrentState).Name -NewName $DesiredState
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    ###----------------------------
    ### Test Variables passed from #$Variable# substitution
    Write-Host "DesiredState  : " $DesiredState
    Write-Host "ServerID      : " $ServerID
    ###----------------------------

    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.EMI.Automation.OS.IPv6
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "IPv6Preference"
    $DesiredState      = $IPv6Preference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Get Current Interface
        $CurrentInterface = (Get-NetAdapter –Physical | Where-Object {$_.Status -eq 'Up'}).Name
        $IPv6State   = Get-NetAdapterBinding -InterfaceAlias $CurrentInterface -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
        $global:CurrentState = $IPv6State.Enabled ### Return True/False
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################

    [scriptblock]$script:SetDesiredState =
    {
        if ($DesiredState -eq $True)
        {
            ### Enable IPv6
            Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
        elseif ($DesiredState -eq $False)
        {
            ### Disable IPv6
            Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.EMI.Automation.OS.CDROM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must End with Colon ":"
    $CDROMLetter = $CDROMLetter.Trim()
    $LastChar = $CDROMLetter.substring($CDROMLetter.length-1) 
    if ($LastChar -ne ":"){$CDROMLetter = $CDROMLetter + ":"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "CDROMLetter"
    $DesiredState      = $CDROMLetter
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:ComputerName = (Get-WmiObject Win32_ComputerSystem).Name
        $global:CurrentState = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $ComputerName).Drive
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $ComputerName -Filter "DriveLetter='$CurrentState'"
        Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter = $DesiredState} | Out-Null
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.EMI.Automation.OS.Folders
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "ECIFolders"
    
    ### Create ECI Folders
    ###--------------------------------        
    $ECIFolders = @()
    $ECIFolders += "C:\Scripts"
    $ECIFolders += "D:\Kits"

    $DesiredState      = $ECIFolders
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    foreach($State in $DesiredState)
    {
        $DesiredState = $State
        
        ##################################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##################################################
        [scriptblock]$script:GetCurrentState =
        {
            if(Test-Path -Path $DesiredState){$global:CurrentState = $DesiredState}
            else{$global:CurrentState = $False}
        }

        ##################################################
        ### SET DESIRED-STATE:
        ##################################################
        [scriptblock]$script:SetDesiredState =
        {
            New-Item -ItemType Directory -Path $State -Force | Out-Null
        }

        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        ###----------------------------
        $Params = @{
            ServerID            = $ServerID 
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Configure-ECI.EMI.Automation.OS.RemoteDesktop
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ### Modify Parameter Values
    ### --------------------------------------
    if($RemoteDesktopPreference -eq "False"){$RemoteDesktopPreferenceValue = "1"}
    elseif($RemoteDesktopPreference -eq "True"){$RemoteDesktopPreferenceValue = "0"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "RemoteDesktopPreference"
    $DesiredState      = $RemoteDesktopPreferenceValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##################################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##################################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections").fDenyTSConnections
    }

    ##################################################
    ### SET DESIRED-STATE:
    ##################################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -Value $RemoteDesktopPreferenceValue
        
        if($RemoteDesktopPreferenceValue -eq "0")
        {
            Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
            Netsh advfirewall firewall set rule group=”remote desktop” new enable=yes
        }
        elseif($RemoteDesktopPreferenceValue -eq "1")
        {
            Disable-NetFirewallRule -DisplayGroup "Remote Desktop"
        }
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.EMI.Automation.OS.WindowsFirewallProfile
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "WindowsFirewallPreference"
    $DesiredState      = $WindowsFirewallPreference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-NetFirewallProfile -Name Domain).Enabled
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-NetFirewallProfile -Profile Domain -Enabled $WindowsFirewallPreference
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Configure-ECI.EMI.Automation.OS.InternetExplorerESC 
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ### Modify Parameter Values
    ### --------------------------------------
    if($InternetExplorerESCPreference -eq "False")   {$InternetExplorerESCValue = "0"}
    elseif($InternetExplorerESCPreference -eq "True"){$InternetExplorerESCValue = "1"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "InternetExplorerESCPreference"
    $script:DesiredState      = $InternetExplorerESCPreference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    $Keys = @()
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"

    foreach($Key in $Keys)
    {
        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $global:CurrentState = (Get-ItemProperty -Path $Key -Name "IsInstalled").IsInstalled
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
       [scriptblock]$script:SetDesiredState =
        {
            Set-ItemProperty -Path $Key  -Name "IsInstalled" -Value $DesiredState -Force
        }

        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        $Params = @{
            ServerID            = $ServerID
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Initialize-ECI.EMI.Automation.OS.SwapFileDisk
{
    ### Initalzie Disk
    ### --------------------------
    $OfflineDisk = Get-Disk | Where-Object IsOffline –Eq $True | Set-Disk –IsOffline $False
    Initialize-Disk -Number 1

}

function Configure-ECI.EMI.Automation.OS.WindowsFeatures
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "WindowsFeatures"
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    switch ( $ServerRole )
    {
        "2016Server"
        { $WindowsFeatures = 
            @(
                "NET-Framework-Features",
                "NET-Framework-Core",
                "GPMC",
                "Telnet-Client"
            )                      
        }
        "2016FS"
        { $WindowsFeatures = 
            @(
                "NET-Framework-Features",
                "NET-Framework-Core",
                "GPMC",
                "Telnet-Client",
                "RSAT"
            )                         
        }
        "2016DC"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
        "2016DCFS"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
         "2016VDA"
         { $WindowsFeatures = 
         @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            "AS-Net-Framework",
            "RDS-RD-Server"
            )                         
        }
        "2016SQL"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
        "2016SQLOMS"
        { $WindowsFeatures = 
        @(
            "NET-Framework-Features",
            "NET-Framework-Core",
            "GPMC",
            "Telnet-Client",
            "RSAT"
            )                         
        }
    }
    foreach ($Feature in $WindowsFeatures)
    {
        $script:DesiredState = $Feature
        write-host "DesiredState: " $DesiredState

        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $global:CurrentState = ((Get-WindowsFeature -Name $Feature) | Where-Object {$_.Installed -eq $True}).Name
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
        [scriptblock]$script:SetDesiredState =
        {
            Write-Host "Installing Feature: " $Feature
            
            #$WindowsMediaSource = "R:\sources\sxs\microsoft-windows-netfx3-ondemand-package.cab"
            $WindowsMediaSource = "R:\sources\sxs"
            Install-WindowsFeature -Name $Feature -Source $WindowsMediaSource
        }
    
        ##########################################
        ### CALL CONFIGURE DESIRED STATE:
        ##########################################
        $Params = @{
            ServerID            = $ServerID
            HostName            = $HostName 
            FunctionName        = $FunctionName 
            PropertyName        = $PropertyName 
            DesiredState        = $DesiredState 
            GetCurrentState     = $GetCurrentState 
            SetDesiredState     = $SetDesiredState 
            ConfigurationMode   = $ConfigurationMode 
            AbortTrigger        = $AbortTrigger
        }
        Configure-DesiredState @Params
    }
}

function Configure-PageFile #<---- need to complete function!!!!!!!!!!!!!!!!!
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must NOT End with Colon ":"
    $LastChar = $PageFileLocation.substring($PageFileLocation.length-1) 
    if ($LastChar -eq ":"){$PageFileLocation = $PageFileLocation.Split(":")[0]}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    $DesiredState = @()
    $DesiredState += $PageFileSize
    $DesiredState += $PageFileLocation



    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Calculate Desired Page File Size
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $DesiredPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if($Memory -lt "4") {$NewPageFileSize = "4"} ### Set a Minimun 4GB PageFile Size
        $DesiredState = ($DesiredPageFileSize * 1000) 
        $PageFile = Get-WmiObject -Class Win32_PageFileUsage -Computer "LocalHost"
        $CurrentState = $PageFile.MaximumSize
        $Size = ($CurrentState -eq $DesiredState)

        ### PageFile Location
        $script:DesiredState = $PageFileLocation
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $CurrentState = ($PageFile.Name).Split(":")[0]
        $Location =  ($CurrentState -eq $DesiredState)
    
        ### Set $CurrentState
        $script:CurrentState = $True
        $script:DesiredState = $True  
        if (($Size -eq $False) -OR ($Location -eq $False))
        {
            $script:CurrentState = $False
        }
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $script:DesiredState = $PageFileSize
        
        # Disable Automatically Managed PageFile Setting
        $ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
        if ($ComputerSystem.AutomaticManagedPagefile -eq "True") 
        {
            Set-CimInstance -Property @{ AutomaticManagedPageFile = $False }
        }
        Write-Host "AutomaticManagedPagefile : " $(Get-CimInstance -ClassName Win32_ComputerSystem).AutomaticManagedPagefile 
        
        ### Delete Existing PageFile
        ### ---------------------------------
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $PageFile | Remove-CimInstance   


        ### Calculate Page File Size
        ### ---------------------------------
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $NewPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if ($Memory -lt "4") {$NewPageFileSize = "4"}
        [int]$NewPageFileSize = ($NewPageFileSize * 1000)
        [int]$InitialSize = ($NewPageFileSize * 1)
        [int]$MaximumSize = ($NewPageFileSize * 1.1)

        ### Create New Page File
        ### -------------------------------------------------------------------------------
        [scriptblock]$CreatePageFile =
        {
            if(-NOT(Get-CimInstance -ClassName Win32_PageFileSetting))
            {
                $PageFileName = $PageFileLocation + ":\pagefile.sys"
                Write-Host "Creating New Page File: PageFileLocation: $PageFileName InitialSize: $InitialSize MaximumSize: $MaximumSize " 
                New-CimInstance -ClassName Win32_PageFileSetting -Property  @{ Name= $PageFileName } | Out-Null
                Get-CimInstance -ClassName Win32_PageFileSetting | Set-CimInstance -Property @{InitialSize = $InitialSize; MaximumSize = $MaximumSize;} | Out-Null
                }
            else
            {
                Write-Host "PageFile Exists. Cant Configure!"
            }
        }

        ### Check Avilable Disk Space
        ### ---------------------------------
        $FreeSpace = (Get-PSDrive $PageFileLocation).Free

        #[int]$FreeSpace = $FreeSpace

        if($FreeSpace -gt $NewPageFileSize)
        {
            Write-Host "Free Space Available. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize"
            Invoke-Command -ScriptBlock $CreatePageFile
        }
        elseif($FreeSpace -le $NewPageFileSize)
        {
            Write-Host "Not Enough Avialable Space. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize `nNot Configuring!"
        }
        

    }
    
    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Rename-ECI.EMI.Automation.OS.GuestComputer
{

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "HostName"
    $DesiredState      = $HostName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = 	(Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName).ComputerName

        #$ActiveComputerName = (Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName).ComputerName
        #$ComputerName = (Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName).ComputerName

    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Rename-computer –ComputerName $(Get-CIMInstance CIM_ComputerSystem).Name –NewName $HostName
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    ###----------------------------
    ### Test Variables passed from #$Variable# substitution
    Write-Host "DesiredState  : " $DesiredState
    Write-Host "ServerID      : " $ServerID
    ###----------------------------

    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
     
}

function Restart-ECI.EMI.Automation.OS.GuestComputer
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)
    
    $t = 10

    Write-Host "Restarting Guest OS in $t seconds . . . "
    Shutdown /r -t $t

}

function Configure-ECI.EMI.Automation.OS.JoinDomain
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "ClientDomain"
    $DesiredState      = $ClientDomain
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $global:ClientDomain = "corp.geemoneymgmt.com"

        #$AdministrativeUserName = "GEEMONEYMGMT\ECIADMIN"
        #$AdministrativePassword = ConvertTo-SecureString $AdministrativePassword -AsPlainText -Force

        $AdministrativeUserName = "GEEMONEYMGMT\ECIADMIN"
        $AdministrativePassword = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($AdministrativeUserName, $AdministrativePassword)

        #$ComputerName = (Get-CIMInstance CIM_ComputerSystem).Name
        #$FullComputerName = [System.Net.Dns]::GetHostName()

        Add-Computer -ComputerName $HostName -DomainName $ClientDomain -Credential $PSCredentials -Force -Passthru -Verbose
    }

    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    ###----------------------------
    ### Test Variables passed from #$Variable# substitution
    Write-Host "DesiredState  : " $DesiredState
    Write-Host "ServerID      : " $ServerID
    ###----------------------------

    $Params = @{
        ServerID            = $ServerID
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Restart-ECI.GuestOS
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-ConfigReport `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100)

    $t = 30
    Write-Host "Restarting Guest OS on Server - $Hostname in $t seconds:" -ForegroundColor Magenta
    Start-Sleep -Seconds $t
    Restart-Computer -ComputerName . -Force #-Wait -For PowerShell -Timeout 300 -Delay $t -Verbose
}

function Rename-LocalAdministrator
{
    Write-Host "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 100)

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal

        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name

        ### Check if Local Admin is already renamed
        if($CurrentAdminName -eq $NewLocalAdminName)
        {
            Write-Host "Local Admin Names are the same -  CurrentAdminName: $CurrentAdminName NewAdminName: $NewLocalAdminName"
            $RebootRequired = $False
        }
        elseif($CurrentAdminName -ne $NewLocalAdminName)
        {
            $RebootRequired = $True
            Write-Host "Renaming Local Admin Account: Current Admin: $CurrentAdminName New Admin: $NewLocalAdminName"
            Rename-LocalUser -Name $CurrentAdminName -NewName $NewLocalAdminName -ErrorAction SilentlyContinue | Out-Null
        }
    }
    Try-Catch $ScriptBlock
}


