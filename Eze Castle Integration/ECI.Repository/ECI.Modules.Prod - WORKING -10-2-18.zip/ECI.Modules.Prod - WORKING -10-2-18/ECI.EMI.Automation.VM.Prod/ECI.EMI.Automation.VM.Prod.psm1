#########################################
### VM Provisioning Module
### ECI.EMI.Automation.VM.Prod.psm1
#########################################

function Get-ECI.EMI.AutoMation.VM.VMTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting VMWare Template: " $VMTemplateName  -ForegroundColor Yellow
    
    #$ECIVMTemplate = $VMTemplateName
    $ECIVMTemplate = Get-Template -Name $VMTemplateName -Server $ECIvCenter

    if (($ECIVMTemplate.count) -gt 1)
    {
        $ECIVMTemplate = $ECIVMTemplate[0]
    }
    
    $global:ECIVMTemplate = $ECIVMTemplate
    Write-Host "Template Selected: $ECIVMTemplate" -ForegroundColor DarkGray
    Return $ECIVMTemplate
}

function Set-ECI.EMI.Automation.VM.ServerUUID
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### Set VM Name fromn HostName Parameters
    ###----------------------------------------------------------------
   
    $VMMoRefID = (Get-VM -Name $VMName).ID
    $VMMoRefID = $VMMoRefID.Split("-")
    
    $vMoRef = $VMMoRefID[-2].ToUpper() + "-" + $VMMoRefID[-1]

    $ServerUUID = "VI" + "." + $vCenterUUID + "." + ($VMMoRefID[-2]).ToUpper() + "-" + $VMMoRefID[-1]
    
    $global:vCenterUUID  = $vCenterUUID
    $global:vMoRef       = $vMoRef
    $global:ServerUUID   = $ServerUUID

    Write-Host "vCenterUUID   : " $vCenterUUID -ForegroundColor Gray
    Write-Host "vMMoRef       : " $vMoRef -ForegroundColor Gray
    Write-Host "ServerUUID    : " $ServerUUID -ForegroundColor Magenta
    #Return $ServerUUID

<#
    Get-VM $VMName | %{(Get-View $_.Id).config.uuid}  

    Write-Host "MoRef: " $VMName.ExtensionData.MoRef
    Write-Host "InstanceUuid: " $VMName.ExtensionData.Config.InstanceUuid
    
    #(Get-Datacenter -Server $ECIvCenter).ExtensionData.moref
#> 
    
    #Example:
    #---------
    #VI-d8c273b7-6f4e-4ce7-8986-72dfbd3f0376-VM-38002
}

###############################################
### Create New VM
###############################################

function New-ECI.EMI.Automation.VM
{
    Param(
    [Parameter(Mandatory = $True)][string]$VMName,
    
    [Parameter(Mandatory = $True)][string]$ECIVMTemplate,
    [Parameter(Mandatory = $True)][string]$OSCustomizationSpecName,
    
    [Parameter(Mandatory = $True)][string]$ResourcePool,
    [Parameter(Mandatory = $True)][string]$OSDataStore,
    [Parameter(Mandatory = $True)][string]$PortGroup,

    [Parameter(Mandatory = $True)][string]$IPv4Address,
    [Parameter(Mandatory = $True)][string]$SubnetMask,
    [Parameter(Mandatory = $True)][string]$DefaultGateway,
    [Parameter(Mandatory = $True)][string]$PrimaryDNS,
    [Parameter(Mandatory = $True)][string]$SecondaryDNS
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    function New-ECI.EMI.Automation.VM.OSCustomizationSpec
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec
        ###----------------------------------------------------------
        ### Remove OSCustomizationSpec
        if(Get-OSCustomizationSpec $OSCustomizationSpecName -ErrorAction SilentlyContinue)
        {
            Write-Host "Removing OSCustomizationSpec: " $OSCustomizationSpecName
            Remove-OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
        
            ### Remove OSCustomizationNicMapping
            #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
        }
        else
        {
            Write-Host "No OSCustomizationSpec Found: "
        }    
    
        ### New OSCustomizationSpec
        ###------------------------
        $OSCustomizationSpec = @{
            Name             = $OSCustomizationSpecName 
            Type             = $Type 
            OSType           = $OSType 
            NamingScheme     = $NamingScheme.trim()
            FullName         = $FullName 
            OrgName          = $OrgName 
            AdminPassword    = $AdminPassword
            ChangeSid        = $True
            DeleteAccounts   = $False 
            TimeZone         = $TimeZone 
            ProductKey       = $ProductKey 
            LicenseMode      = $LicenseMode 
            Workgroup        = $Workgroup
            #DomainUsername   = $DomainUsername
            #DomainPassword   = $DomainPassword
        }
    
        Write-Host "Creating - OSCustomizationSpec        : $OSCustomizationSpecName" -ForegroundColor Yellow
        New-OSCustomizationSpec @OSCustomizationSpec | Out-Null
    
        #New-OSCustomizationSpec -Name $OSCustomizationSpecName -Type $Type -OSType $OSType -NamingScheme $NamingScheme -FullName $FullName -OrgName $OrgName -AdminPassword $AdminPassword -ChangeSid:$true -DeleteAccounts:$false -TimeZone $TimeZone -ProductKey $ProductKey -LicenseMode $LicenseMode -Workgroup $Workgroup

    }

    function New-ECI.EMI.Automation.VM.OSCustomizationNicMapping
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec NIC Mapping
        ###----------------------------------------------------------    
        $OSCustomizationNicMapping = {
            IpMode          = "UseStaticIp"
            IpAddress       = $IPv4Address 
            SubnetMask      = $SubnetMask 
            DefaultGateway  = $DefaultGateway 
            Dns             = $PrimaryDNS + "," + $SecondaryDNS
        }
        Write-Host "Creating - OSCustomizationNicMapping  : $OSCustomizationSpecName" -ForegroundColor Yellow
        Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $SubnetMask -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    }

    function New-ECI.EMI.Automation.VM.VM
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New VM
        ###----------------------------------------------------------  
    
        ### Check if VM exists
        if(Get-VM -Name $VMName -ErrorAction SilentlyContinue)
        {
        Write-Host "This VM Exists. Running Report Mode" -ForegroundColor Red
        $globalConfigurationMode = "Report"
        
        ### Do we want to Abort or run in Report mode ????????
        #$global:Abort = $True
        #Invoke-Abort
    }
        
    else
    {
        ### Create New VM
        ###----------------------------------------------------------
        Write-Host "Creating New VM      : " $VMName -ForegroundColor Yellow
        Write-Host "Please wait. The VM Provisioning process may take a while . . .  " -ForegroundColor Gray

        $VMParameters = @{
        VMName                    = $VMName
        Template                  = $ECIVMTemplate
        OSCustomizationSpec       = $OSCustomizationSpecName
        ResourcePool              = $ResourcePool
        OSDataStore               = $OSDataStore
        } 

        #New-VM @VMParameters
        New-VM -Name $VMName -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $OSDataStore -OSCustomizationSpec $OSCustomizationSpecName

        ### Set Port Group
        ###----------------------------------------------------------
        # Get-VM -Name $VMName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $PortGroup -Confirm:$false
    }

   
}

   &{
        BEGIN {}

        PROCESS 
        {
            New-ECI.EMI.Automation.VM.OSCustomizationSpec
            New-ECI.EMI.Automation.VM.OSCustomizationNicMapping
            New-ECI.EMI.Automation.VM.VM
        }

        END {}

    }
}

###############################################


function New-ECI.VM-UseAlternateGuestName
{
    Param(
    [Parameter(Mandatory = $True)][string]$VMName,
    [Parameter(Mandatory = $True)][string]$ECIVMTemplate,
    [Parameter(Mandatory = $True)][string]$OSCustomizationSpecName,
    [Parameter(Mandatory = $True)][string]$ResourcePool,
    [Parameter(Mandatory = $True)][string]$DataStore,
    [Parameter(Mandatory = $True)][string]$PortGroup,
    [Parameter(Mandatory = $True)][string]$IPv4Address,
    [Parameter(Mandatory = $True)][string]$SubnetMask,
    [Parameter(Mandatory = $True)][string]$DefaultGateway,
    [Parameter(Mandatory = $True)][string]$PrimaryDNS,
    [Parameter(Mandatory = $True)][string]$SecondaryDNS
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    function Create-OSCustomizationSpec
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec
        ###----------------------------------------------------------
        ### Remove OSCustomizationSpec
        if(Get-OSCustomizationSpec $OSCustomizationSpecName -ErrorAction SilentlyContinue)
        {
            Write-Host "Removing OSCustomizationSpec: " $OSCustomizationSpecName
            Remove-OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
        
            ### Remove OSCustomizationNicMapping
            #Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
        }
        else
        {
            Write-Host "No OSCustomizationSpec Found: "
        }    
   
        ### New OSCustomizationSpec
        ###------------------------
        $OSCustomizationSpec = @{
            Name             = $OSCustomizationSpecName 
            Type             = $Type 
            OSType           = $OSType 
            NamingScheme     = $NamingScheme.trim()
            FullName         = $FullName 
            OrgName          = $OrgName 
            AdminPassword    = $AdminPassword
            ChangeSid        = $True
            DeleteAccounts   = $False 
            TimeZone         = $TimeZone 
            ProductKey       = $ProductKey 
            LicenseMode      = $LicenseMode 
            Workgroup        = $Workgroup
        }
    
        Write-Host "Creating OSCustomizationSpec: $OSCustomizationSpecName" -ForegroundColor Yellow
        New-OSCustomizationSpec @OSCustomizationSpec
    }
    
    function Create-OSCustomizationNicMapping
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New OSCustomizationSpec NIC Mapping
        ###----------------------------------------------------------    
        $OSCustomizationNicMapping = {
            IpMode          = "UseStaticIp"
            IpAddress       = $IPv4Address 
            SubnetMask      = $SubnetMask 
            DefaultGateway  = $DefaultGateway 
            Dns             = $PrimaryDNS + "," + $SecondaryDNS
        }
        Write-Host "Creating OSCustomizationNicMapping: $OSCustomizationSpecName" -ForegroundColor Yellow
        Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $SubnetMask -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    }
    
    function Create-VM
    {
        $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

        ###----------------------------------------------------------
        ### Create New VM
        ###----------------------------------------------------------  
    
        ### Check if VM exists
        if(Get-VM -Name $VMName -ErrorAction SilentlyContinue)
        {
            Write-Host "This VM Exists. Running Report Mode" -ForegroundColor Red
            $globalConfigurationMode = "Report"
        
            ### Do we want to Abort or run in Report mode ????????
            #$global:Abort = $True
            #Invoke-Abort
        }
        else
        {
            ### Create New VM
            ###----------------------------------------------------------
            Write-Host `n('=' * 50)`n "Creating New VM: " $VMName `n('=' * 50)`n -ForegroundColor Yellow
            Write-Host "Please Wait - This Process may take a while ... "  -ForegroundColor Gray

            $VMFolderLocation = ""
             
            $VMParameters = @{
                VMName                    = $VMName
                Template                  = $ECIVMTemplate
                OSCustomizationSpec       = $OSCustomizationSpecName
                ResourcePool              = $ResourcePool
                DataStore                 = $DataStore
            }

            #New-VM @VMParameters
            #orig New-VM -Name $VMName -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $DataStore -OSCustomizationSpec $OSCustomizationSpecName
            
            #New-VM -Name $VMName -AlternateGuestName $HostName -Location $VMFolderLocation -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $DataStore -OSCustomizationSpec $OSCustomizationSpecName
            New-VM -Name $VMName -AlternateGuestName $HostName -Template $ECIVMTemplate -ResourcePool $ResourcePool -Datastore $DataStore -OSCustomizationSpec $OSCustomizationSpecName

            ## delete me ??????
            ### Set Port Group
            ###----------------------------------------------------------
    #        Get-VM -Name $VMName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $PortGroup -Confirm:$false
        }
    }

    &{
        BEGIN{}
        
        PROCESS
        {
            
            Create-OSCustomizationSpec
            Create-OSCustomizationNicMapping
            Create-VM
        }

        END{}
    }



    ### delete me ??????
    ###Set-VM -VM $VMName -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
   

<#
    https://blogs.vmware.com/PowerCLI/2014/06/working-customization-specifications-powercli-part-2.html

    https://code.vmware.com/forums/2530/vsphere-powercli#572264

    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS
    Get-OSCustomizationSpec $OSCustomizationSpecName | Remove-OSCustomizationNicMapping 
            
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIp -IpAddress $IPv4Address -SubnetMask $subnet -DefaultGateway $DefaultGateway -DefaultGateway $DefaultGateway -Dns $PrimaryDNS,$SecondaryDNS

 
    #Clone the BaseVM with the adjusted Customization Specification
    New-VM -Name $OSCustomizationSpecName -VM $VMName -Datastore $datastore -VMHost $ECIvCenter | Set-VM -OSCustomizationSpec $OSCustomizationSpecName -Confirm:$false
 
    #Set the Network Name (I often match PortGroup names with the VLAN name)
    Get-VM -Name $VMName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $vlan -Confirm:$false
 
    #Remove the NicMapping (Don't like to leave things unkept)
    Get-OSCustomizationSpec $OSCustomizationSpecName | Get-OSCustomizationNicMapping | Remove-OSCustomizationNicMapping -Confirm:$false
#>

}


function Set-ECI.EMI.Automation.VM.VMCPU
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ##########################################
    ### Modify Parameter Values
    ##########################################
    ### Cast the Variable
    [int]$vCPUCount = $vCPUCount
    
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "vCPUCount"
    $DesiredState      = $vCPUCount
    #ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VMName | Select NumCpu).NumCpu
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Set VM CPU Count
        ###-----------------------------------------
        Write-Host "Setting VM CPU Count: " $vCPUCount -ForegroundColor Cyan
        $VMName = Get-VM -Name $VMName
        Set-VM -VM $VMName -Confirm:$False -NumCpu $vCPUCount
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function Set-ECI.EMI.Automation.VM.VMMemory
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
   
    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $PropertyName      = "vMemoryGB"
    $DesiredState      = $vMemoryGB
    #ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    
    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $global:CurrentState = (Get-VM $VMName | Select MemoryGB).MemoryGB
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Set VM Memory
        ###-----------------------------------------
        Write-Host "Setting VM vMemorySizeGB: " $vMemoryGB -ForegroundColor Cyan
        $VMName = Get-VM -Name $VMName
        Set-VM -VM $VMName -Confirm:$False -MemoryGB $vMemoryGB
    }
    
    ##########################################
    ### CALL CONFIGURE DESIRED STATE:
    ##########################################
    $Params = @{
        ServerID            = $ServerID 
        HostName            = $HostName 
        FunctionName        = $FunctionName 
        PropertyName        = $PropertyName 
        DesiredState        = $DesiredState 
        GetCurrentState     = $GetCurrentState 
        SetDesiredState     = $SetDesiredState 
        ConfigurationMode   = $ConfigurationMode 
        AbortTrigger        = $AbortTrigger
    }
    Configure-DesiredState @Params
}

function New-ECI.EMI.Automation.VM.HardDisk
{
    Param(
        [Parameter(Mandatory = $true)][string]$VMName,
        [Parameter(Mandatory = $true)][string]$Datastore,
        [Parameter(Mandatory = $true)][string]$CapacityGB
    )
        
    $Params = @{
        VM             = $VMName
        Datastore      = $Datastore
        CapacityGB     = $CapacityGB
        StorageFormat  = "Thin"
        Persistence    = "Persistent"
        Confirm        = $false
    }
    #New-HardDisk @Params
    
    try
    {
        New-HardDisk -VM $VMName -Datastore $DataStore -CapacityGB $CapacityGB -StorageFormat Thin -Persistence persistent -Confirm:$false
    }
    catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red
    }

}

function Get-ECI.EMI.Automation.VM.DataStore
{
    Get-ECI.EMI.Automation.VM.Resources.DataStore -Environment $Environment -ServerRole $ServerRole
}

function Configure-ECI.EMI.Automation.VM.HardDisks
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerHardDisks"
    $ConnectionString =  $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionVMParameters WHERE ServerRole = '$ServerRole'�
    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query


    $Volumes = @{
        OSVolumeCapacity   = $ServerHardDisks.OSVolumeCapacityGB
        SwapVolumeCapacity = $ServerHardDisks.SwapVolumeCapacityGB
        DataVolumeCapacity = $ServerHardDisks.DataVolumeCapacityGB
        LogVolumeCapacity  = $ServerHardDisks.LogVolumeCapacityGB
        SysVolumeCapacity  = $ServerHardDisks.SysVolumeCapacityGB
    }
       
    foreach($Volume in $Volumes.GetEnumerator())
    {
        if(([string]::IsNullOrEmpty($Volume.Value)) -ne $true)
        {
            Write-Host "Volume: " $Volume.Name `t`t "VolumeSize: " $Volume.Value
            #New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB
        }
    }

}

function New-ECI.EMI.Automation.VM.HardDisks
{

    $Disk = @()
    $OS   = @( $OSDataStore,   $OSVolumeCapacity   )
    $Swap = @( $SwapDataStore, $SwapVolumeCapacity )
    $Data = @( $DataDataStore, $DataVolumeCapacity )
    $Log  = @( $LogDataStore,  $LogVolumeCapacity  )
    $Sys  = @( $SysDataStore,  $SysVolumeCapacity  )


    #New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB
}


function New-ECI.EMI.Automation.VM.HardDisk.PageFile
{
    Param(
        [Parameter(Mandatory = $true)][string]$VMName
    )
    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
   
    $Datastore = $SwapDataStore
    $CapacityGB = $SwapVolumeCapacityGB
    
    #$Datastore =  "LD5_EMS_Client_DC_OS_401"

    try
    {
        ### Create New Disk
        ### --------------------------
        New-ECI.EMI.Automation.VM.HardDisk -VMName $VMName -Datastore $Datastore -CapacityGB $CapacityGB #-StorageFormat Thin -Persistence Persistent -Confirm:$false
        
            ### Initalzie Disk
            ### --------------------------
            $OfflineDisk = Get-Disk | Where-Object IsOffline �Eq $True | Set-Disk �IsOffline $False
            Initialize-Disk -Number 1
    }
    catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red
    }

}

function Start-ECI.EMI.Automation.VM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    $ScriptBlock =
    {
        Write-Host "Starting VM: $VMName" -ForegroundColor Yellow
        Start-VM $VMName
    }
    Try-Catch $ScriptBlock
}

function Wait-ECI.EMI.Automation.VM.VMTools
{
    Param(
    [Parameter(Mandatory = $true)][string]$VMName,
    [Parameter(Mandatory = $false)][int]$t
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    if(!$t) { $t = 180 }
    
    $VMTools = Wait-Tools -VM $VMName -TimeoutSeconds $t -ErrorAction SilentlyContinue
    
    if(!$VMTools)
    {
        $RetryCount = 5
        for ($i=1; $i -le $RetryCount; $i++)
        {
            Write-Host  "VMNAME: $VMName - Retry Wait-ECI.EMI.Automation.VM.VMTools" -ForegroundColor Red
            Wait-ECI.EMI.Automation.VM.VMTools
        }
    }
    if($VMTools)
    {
        Write-Host "VMNAME: $VMName - The Server is Up: $VMName" -ForegroundColor Green
    }
}

function Wait-ECI.EMI.Automation.VM.OSCusomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $t = 240

    Write-Host "STARTING-SLEEP - for $t seconds: Waiting for OS CusomizationSpec to Complete."

    For ($i=$t; $i -gt 1; $i--) 
    {  
        #$a = [math]::Round((($i/$t)/1)*100)  ### Amount Remaining
        
        $a = [math]::Round( (($t-$i)/$t)*100) ### Amount Completed

        Write-Progress -Activity "STARTING-SLEEP - for $t seconds: Waiting for OS CusomizationSpec to Complete." -SecondsRemaining $i -CurrentOperation "Completed: $a%" -Status "Waiting"
        Start-Sleep 1
        #Write-Host "Still Waiting ..." -ForegroundColor DarkGray
    }

    Write-Host "Done Waiting." -ForegroundColor Green
    Write-Progress -Activity 'OS Cusomization' -Completed
}

function Wait-ECI.EMI.Automation.VM.InvokeVMScript
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ScriptText =  { dir }   # <-- What is a good Service to look for???? VM Tools is redundant

    $TestInvoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminAccount -ErrorAction silentlycontinue
    if($TestInvoke.ExitCode -ne 0)
    {
        Write-Host "Still Running OS Customization - VMName: $VMName" -ForegroundColor Red
        $t = 45
        Write-Host "START SLEEP: $t seconds"  -ForegroundColor Gray
        Start-Sleep -Seconds $t
        Wait-ECI.EMI.Automation.VM.InvokeVMScript
    }
    else
    {
        Write-Host "VM has completed OS Customization"-ForegroundColor Green
    }
}

function Stop-ECI.EMI.Automation.VM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    $ScriptBlock =
    {
        Write-Host "Stopping VM: $VMName" -ForegroundColor Yellow
        Stop-VM $VMName -Confirm:$false
    }
    Try-Catch $ScriptBlock
}

function Restart-ECI.EMI.Automation.VM
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $t = 60
    Write-Host "Restarting VM: $VMName in $t seconds."
    Start-Sleep -seconds $t

    Restart-VM -VM $VMName -Confirm:$false
    Wait-ECI.VMTools -VM $VMName -t $t


}

function Get-VMStore
{
    $Datastore = "cloud_staging_pub_lhc"
    $Datastore = Get-Datastore | Where-Object {$_.Name -like $Datastore}
    $ISO = "*DataCtr_Core_2016*"
    $ISO = "*VM*"
    Get-ChildItem -Path $Datastore.DatastoreBrowserPath  -Include *.iso -recurse | ?{$_.name -like $ISO} | fl name,datastorefullpath


    #$lhcDatastoreInLd5 = Get-Datastore cloud_staging_pub_lhc
    #gci -Path $lhcDatastoreInLd5.DatastoreBrowserPath 


<#
ld5vc.eci.cloud
Item:  ld5vc.eci.cloud
ISOs:  cloud_staging_pub_lhc


$lhcDatastoreInLd5 = Get-Datastore cloud_staging_pub_lhc
gci -Path $lhcDatastoreInLd5.DatastoreBrowserPath -Include *.iso -recurse | ?{$_.name -like "*DataCtr_Core_2016*"} | fl name,datastorefullpath

Name              : SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO
DatastoreFullPath : [cloud_staging_pub_lhc] ISO/Current/Microsoft/SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO
#>

}

function Mount-ECI.EMI.Automation.VM.ISO
{
    param(
    [Parameter(Mandatory = $True,Position=0)][string]$ISOName,
    [Parameter(Mandatory = $True,Position=1)][string]$VMName
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray    
    
    ### Get ISO Parameters from DB
    ###---------------------------------
    $DataSetName = "ISOParameters"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionISOs WHERE ISOName = '$ISOName'"
    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query

    try
    {
        ### Get ISO from Datastore
        ###---------------------------------
        $ds = Get-Datastore -Name $isoDatastore 
        New-PSDrive -Name DS -Location $ds -PSProvider VimDatastore -Root '\' | Out-Null
        $Path = "DS:\" + $isoDatastoreFolderPath
        $ISO = Get-ChildItem -Path $Path -Recurse | Where {$_.Name -like $isoDatastoreFileName } | select *
        $ISOName = $ISO.Name
        $ISODatastoreFullPath = $ISO.DatastoreFullPath

        ### Mount ISO
        ###---------------------------------        
        Get-CDDrive -VM $VMName | Set-CDDrive -IsoPath $ISODatastoreFullPath -StartConnected:$true -Connected:$true -Confirm:$false
    }
    catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red
    }
    finally
    {
        Remove-PSDrive -Name DS
    }



    $global:ISOName               = $ISOName   
    $global:ISODatastoreFullPath  = $ISODatastoreFullPath   

    Write-Host "ISOName              : " $ISOName -ForegroundColor Yellow
    Write-Host "ISODatastoreFullPath : " $ISODatastoreFullPath -ForegroundColor Yellow
    
    Return $ISOName              | Out-Null
    Return $ISODatastoreFullPath | Out-Null

    
}

function Restart-ECI.VMGuest
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $t = 60
    Write-Host "Restarting VM: $VMName in $t seconds."
    Start-Sleep -seconds $t

    Restart-VMGuest -VM $VMName -Confirm:$false
    #Restart-VMGuest -VM $VMName -Server $VIServer | Wait-Tools | Out-Null
    
    #Wait-ECI.VMTools -VM $VMName -t $t
}

function Decommission-ECI.VM
{

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Stop VM if Started
    $PowerState = (Get-VM $VMName | Select PowerState).PowerState
 
    if($PowerState -eq "PoweredOn")     #PoweredOff
    {
        Write-Host "WARNING! STOPPING VM: $VMName" -ForegroundColor Red
        Stop-VM $VMName -Confirm:$false    
    }

    ### Record VM to SQL
    Get-DecommissionData -ServerID $ServerID
    
    #### Write-DecomtoSQL

    ### Delete VM
    Write-Host "WARNING! DELETING VM: $VMName" -ForegroundColor Red
    Remove-VM $VMName -DeletePermanently -Confirm:$false

}

function Delete-ECI.VMs
{
    #### need to add CmdletBinding ShouldProcess
    
    
    ######################################################################################################
    ### *** DANGER: *** Set $Filter carefully!!! This function could potentially delete the wrong VM's.
    ######################################################################################################

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $Fitler = "*_GEEMO001*"

    Write-Host "Cleaning Up Test VM's." -ForegroundColor Yellow

    $VMs = Get-VM | Where-Object {$_.Name -like "*_GEEMO001*"} 

    foreach($VM in $VMs)
    {
        if($VM.PowerState -eq "PoweredOn")
        {
            Write-Host "Stopping VM: " $VM -ForegroundColor DarkGray
            Stop-VM $VM -Confirm:$false -ErrorAction Continue
        }
        Write-Host "Deleting VM: " $VM -ForegroundColor Red
        
        ### Set Confirm = True
        Remove-VM $VM -DeletePermanently -Confirm:$true -ErrorAction Continue 
    }
}

function Add-ISOtoDatastore
{
    ### Add ISO
    $Datastore = "nfs_emsadmin_sas1"
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    #DIR $ISODataStore

    ### Get Datastore Items
    (Get-ChildItem $ISODataStore).Name
    
    $ItemFolder = "C:\Scripts\New_ISO\"
    #$ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM2.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $ItemFile = "VMware-tools-windows-10.1.0-4449150.iso"

    $Item = $ItemFolder + $ItemFile

    Copy-DatastoreItem -Item $Item -Destination $ISODataStore 


    #Get-VM -Name SDGRP008 | Get-CDDrive | `
    #Set-CDDrive -IsoPath "[$Datastore] ISOfiles\0.iso" -Confirm:$false


    ### Remove ISO
    $ISODataStore = "vmstore:\Boston\nfs_iso\Microsoft\Windows\"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh-CUSTOM.ISO"
    $ItemFile = "Windows_Server_2016_Auto.ISO"
    $ItemFile = "Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
    $Item = $ISODataStore + $ItemFile
    
    Remove-Item $Item 
}



