﻿cls

Import-Module SqlServer 

### SQL Server (Databases)
###--------------------------------------------------------------------
$SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"
#$SQLServer = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS"
Write-Host "SQLServer: " $SQLServer -ForegroundColor Magenta
Set-Location $SQLServer
$Databases = Get-ChildItem -Path "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases"

$Database = "ServerConfiguration-Dev-Lab"



### Instance (Database)
###--------------------------------------------------------------------
$SQLInstance = "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases\ServerConfiguration-Dev-Lab"
$SQLInstance = "ServerConfiguration-Dev-Lab"
$SQLInstance = Get-ChildItem -Path $SQLServer | Where-Object {$_.Name -eq $SQLInstance}

#Write-Host "Instance: " $Instance -ForegroundColor Yellow
#Set-Location $SQLInstance


### Tables
###--------------------------------------------------------------------
$TablePath = $SQLServer + "\" + $SQLInstance + "\Tables"
#Set-Location SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases\ServerConfiguration-Dev-Lab\Tables
#Set-Location $TablePath


### tblServerRequest
###--------------------------------------------------------------------

$Table = "ServerRequest"
$RequestID = "1"

$Table = $TablePath + "\" + $Table
write-host "Table: "  $Table -ForegroundColor Yellow
write-host "ServerInstance: "  $SQLInstance -ForegroundColor Yellow


### Query
###--------------------------------------------------------------------
$SQLQuery = "Select * from $Table WHERE RequestID = $RequestID"
$SQLQuery = "Select * from ServerRequest"
#$QueryResults = Invoke-Sqlcmd -Query $SQLQuery -ServerInstance $SQLInstance #-Username $SQLUsername -Password $SQLPassword
$QueryResults = Invoke-Sqlcmd -Query $SQLQuery -ServerInstance $SQLInstance
$QueryResults = Invoke-Sqlcmd -Query $SQLQuery -Database ServerConfiguration-Dev-Lab

Invoke-Sqlcmd -Query $SQLQuery  -Database $Database

	
$results = (get-childitem -path "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases" | where-object {$_.Name -eq "ServerConfiguration-Dev-Lab"}).ExecuteWithResults("EXECUTE dbo.MultiResultSet")

$results = (get-childitem -path "SQLSERVER:\SQL\ECILAB-BOSDEV01\SQLEXPRESS\Databases" | where-object {$_.Name -eq "ServerConfiguration-Dev-Lab"}).ExecuteWithResults("Select * from 'Server.Request'")

$Members = $QueryResults | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name}

$OSParameters = @()
foreach($Member in $Members)
{
    #Write-Host "Member Name: " $Member -ForegroundColor Yellow
    #Write-Host "Member Value: " $QueryResults.$Member -ForegroundColor Yellow
    Set-Variable -Name $Member -Value $QueryResults.$Member -Scope global

    #$(Get-Variable -Name $Member).name
    $OSParameters += Get-Variable -Name $Member 
}
$OSParameters | FT

