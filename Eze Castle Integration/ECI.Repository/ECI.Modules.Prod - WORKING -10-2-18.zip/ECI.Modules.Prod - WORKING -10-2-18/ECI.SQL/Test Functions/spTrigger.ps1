﻿USE [ServerConfiguration-Dev-Lab]
GO
/****** Object:  StoredProcedure [dbo].[spSQLTrigger-Test]    Script Date: 7/29/2018 2:39:13 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[spSQLTrigger-Test]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	exec xp_cmdshell 'powershell ""C:\Scripts\SQLTrigger.ps1""'
END
