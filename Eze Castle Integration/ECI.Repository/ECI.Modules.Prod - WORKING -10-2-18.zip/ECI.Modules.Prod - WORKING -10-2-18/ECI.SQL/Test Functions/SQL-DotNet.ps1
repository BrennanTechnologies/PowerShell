﻿cls

### Parameters
$SQLServer =  "ECILAB-BOSDEV01\SQLEXPRESS"
#$SQLServer =  "ECILAB-BOSDEV01"

$SQLDatabase = "ServerConfiguration-Dev-Lab"
$SQLQuery = "Select * from defServerTemplates"
 
### Create Database Connection
$Connection = New-Object System.Data.SQLClient.SQLConnection
$Connection.ConnectionString = "server=$($SQLServer);database=$($SQLDatabase);trusted_connection=true;"
$Connection.Open()

$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$Command.CommandText = $Query
$Reader = $Command.ExecuteReader()
        
### Datatable
$Datatable = New-Object System.Data.DataTable
$Datatable.Load($Reader)
$Datatable

### Close Database Connection
$Connection.Close()



function Get-SQLDataTable
{
    BEGIN
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = "server=$($Server);database=$($Database);trusted_connection=true;"
        $Connection.Open()
    }

    PROCESS
    {
        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
        
        ### Datatable
        $Datatable = New-Object System.Data.DataTable
        $Datatable.Load($Reader)
        $Datatable
    }
    END
    {
        ### Close Database Connection
        $Connection.Close()
    }
}

#Get-SQLDataTable




function Get-SQLDataSet
{
    BEGIN
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = "server=$($Server);database=$($Database);trusted_connection=true;"
        $Connection.Open()
    }

    PROCESS
    {
        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
        
        ### DataAdapter & DataSet
        $DataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command
        $Dataset = New-Object System.Data.Dataset
        $DataAdapter.Fill($Dataset) | Out-Null
        $DataSet.Tables[0]
        $DataSet.Tables[1]
    }
    END
    {
        ### Close Database Connection
        $Connection.Close()
    }
}

#Get-SQLDataSet




#$ServerInstance = "ECILAB-BOSDEV01\SQLEXPRESS"
#$DatabaseName = "ServerConfiguration"
#$Table = "Config.Definition.ServerTemplates"


#$WriteQuery = "INSERT INTO [ServerConfiguration].[dbo].[Config.Definition.ServerTemplates](ServerTemplateID,ServerTemplateName) VALUES ('ServerTemplateID','ServerTemplateName')"
#$insert = INSERT INTO [ServerConfiguration].[dbo].[Config.Definition.ServerTemplates](ServerTemplateID,ServerTemplateName) VALUES ('{0}','{1}')

function Write-SQLTable
{


$ServerTemplateName = "Testing1"

    #Open
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = "Data Source = ECILAB-BOSDEV01\SQLEXPRESS; Initial Catalog=ServerConfiguration; Integrated Security=SSPI;"
    $connection.Open()

    #Insert
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = "INSERT INTO [ServerConfiguration].[dbo].[Servers](ServerName) VALUES('{0}')" -f $ServerTemplateName
    #$cmd.CommandText = "INSERT INTO Servers(ServerName) VALUES('{0}')" -f $ServerTemplateName
    $cmd.ExecuteNonQuery() | Out-Null

    #Close
    $connection.Close()

}

#Write-SQLTable


