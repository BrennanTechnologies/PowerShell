﻿
###############################################
### EMI Automation Script
### ECI.EMI.Automation.Prod.ps1
###############################################

###--------------------------------------------------
### Get Parameters form Invoke-ServerRequest.ps1
###--------------------------------------------------
Param(
    [Parameter(Mandatory = $True,Position=0)][string]$RequestID,
    [Parameter(Mandatory = $True,Position=1)][string]$Env
)


#~~~~~~~~~~~~~~~~~ Temporary Kludges ~~~~~~~~~~~~~~~~~~~~~~~~~~

#kludge GPID & CWID
#$global:CWID = "611"
#$global:GPID = "GEEMO001"
#$global:ClientDomain = "corp.geemoneymgmt.com"

function cLoBbEr-HostName
{
    Param([Parameter(Mandatory = $True)][string]$HostName)
    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Magenta

    $RNG = Get-Random -Minimum 1000 -Maximum 9999
    
    Write-Host "Original Request HostName  : " $HostName -ForegroundColor Magenta
    
    $HostName = $HostName + "-" + $RNG
    
    Write-Host "New RNG Host Name          : " $HostName -ForegroundColor Magenta
    
    $global:HostName = $HostName
    Return $HostName
}

function Get-ECI.RunAsUser
{
    $User = Whoami
    Write-Host `n('-' * 50)`n  "Running PS Scripts as User: " $User `n('-' * 50)`n  -ForegroundColor Magenta
}
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function Get-ECI.Environment
{
    param([Parameter(Mandatory = $True)] [string]$Env)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    switch ($Env)
    {
        "Dev"          { $Environment = "Development" }
        "Stage"        { $Environment = "Staging"     }
        "Prod"         { $Environment = "Production"  }
        "Development"  { $Environment = "Development" }
        "Staging"      { $Environment = "Staging"     }
        "Production"   { $Environment = "Production"  }
    }
        
    Write-Host "Setting Global Variable ENV: " $Env -ForegroundColor Yellow
    $global:Env = $Env
    $global:Environment = $Environment

    Return $Env
    Return $Environment
}

### --------------------------------------------------
### Set RequestID to Global Variable
### --------------------------------------------------
function Set-ECI.RequestIDtoGlobalVariable
{
    param([Parameter(Mandatory = $True)] [int]$RequestID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Setting Global Variable: " $RequestID -ForegroundColor Yellow
    [int]$global:RequestID = $RequestID
    Return $RequestID
}

### --------------------------------------------------
### Import ECI Modules
### --------------------------------------------------
function Import-ECI.Root.ModuleLoader
{
    Param([Parameter(Mandatory = $True)][string]$Env)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Cyan

    ######################################
    ### Bootstrap Module Loader
    ######################################

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
    
    New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Scope Global

    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\$Env\ECI.Root.ModuleLoader.ps1" -Env $Env
}

### --------------------------------------------------
### Import VMWare Module
### --------------------------------------------------
function Import-VMWareModules
{
    Param(
        [Parameter(Mandatory = $False)][switch]$Local,
        [Parameter(Mandatory = $False)][switch]$Repo
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
          
    # i ran install-module vmware.vimautomation.core
    #AzureRM and MSOnline.  yeah, i suspect you'll need both.  there is also the netapp powershell toolkit
    #Install-Module -Name VMware.PowerCLI -RequiredVersion 6.5.4.7155375
<#
    if($Local)
    {
        $VMModulesPath = "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\"
    }
    elseif($Repo)
    {
        $VMModulesPath = "\\eciscripts.file.core.windows.net\clientimplementation\Development\Vendor.Modules.Dev\vSphere PowerCLI\Modules\"
    }
    else
    {
        $VMModulesPath = "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\"
    }
    ### Add PowerCLI to PS Module Path
    $env:PSModulePath = $env:PSModulePath + ";" +  $VMModulesPath
#>


    $VMModules = "VMware.*"

    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available! Check env:PSModulePath env:PSModulePath" (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
    
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -InvalidCertificateAction ignore -Confirm:$false | Out-Null #<--- MOVE to Connect-VIServer ????
}

### ==================================================
### Invoke ECI.EMI.Automation.VM
### ==================================================
function Invoke-ECI.EMI.Automation.VM
{
    Param(
            [Parameter(Mandatory = $True)][int]$ServerID,
            [Parameter(Mandatory = $True)][string]$HostName,
            [Parameter(Mandatory = $True)][string]$ConfigurationMode,
            [Parameter(Mandatory = $True)][string]$Env,
            [Parameter(Mandatory = $True)][string]$Environment
         )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Cyan
    
    #####################
    ### Provision VM
    #####################
    
    $VMParameters = @{
            ServerID          = $ServerID
            Environment       = $Environment
            ConfigurationMode = $ConfigurationMode
    }

    ### ECI.ConfigServer.Invoke-ProvisionVM.ps1
    ###------------------------------------------------
    $File = "ECI.EMI.Automation.VM"
    $FilePath =  "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment + "\ECI.Modules." + $Env + "\" + $File + "." + $Env + "\" + $File  + "." + $Env + ".ps1"
    Try
    {
        . ($FilePath) @VMParameters
    }
    Catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red        
    }
}

### ==================================================
### Invoke ECI.EMI.Automation.OS
### ==================================================
function Invoke-ECI.EMI.Automation.OS
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Cyan

    #####################c
    ### Configure OS
    #####################
    
    $GLOBAL:ClientDomain = "corp.geemoneymgmt.com"

    $OSParameters = @{
            ServerID           = $ServerID
            HostName           = $HostName
            ConfigurationMode  = $ConfigurationMode
            ServerRole         = $ServerRole
            IPv4Address        = $IPv4Address
            SubnetMask         = $SubnetMask
            DefaultGateway     = $DefaultGateway
            PrimaryDNS         = $PrimaryDNS
            SecondaryDNS       = $SecondaryDNS
            ClientDomain       = $ClientDomain
    }
        
    ### ECI.EMI.Automation.OSConfiguration.Invoke.ps1
    ###------------------------------------------------
    $File = "ECI.EMI.Automation.OS"
    $FilePath =  "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment + "\ECI.Modules." + $Env + "\" + $File + "." + $Env + "\" + $File + ".Invoke"  + "." + $Env + ".ps1"
    Try
    {         
        . ($FilePath) @OSParameters  
    }
    Catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red   
    }
   
}

### ==================================================
### Invoke ECI.EMI.Automation.Role
### ==================================================
function InvokeECI.EMI.Automation.Role
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 100)`n "Executing Function: " $FunctionName `n('-' * 100) -ForegroundColor Cyan
    
    #####################
    ### Configure Roles
    #####################
    
    $RoleParameters = @{
            ServerID     = $ServerID
            HostName     = $HostName
            ServerRole   = $ServerRole
            BuildVersion = $BuildVersion
    }
    
    ### ECI.ConfigServer.Invoke-ConfigureRoles.ps1
    ###------------------------------------------------
    $File = "ECI.EMI.Automation.Role"
    $FilePath =  "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment + "\ECI.Modules." + $Env + "\" + $File + "." + $Env + "\" + $File  + "." + $Env + ".ps1"
    $Scriptblock = 
    Try
    {
        . ($FilePath) @RoleParameters
    }
    Catch
    {
        Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
        Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
        Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red   
    }
}

############
### Main
############
&{ ### Execute the Script

    BEGIN
    {
        Write-Host "RequestID: " $RequestID -ForegroundColor DarkMagenta
        ### Set Variables       
        ###-------------------------------------
        
        $script:AutomationStartTime = Get-Date
        Start-Transcript -OutputDirectory C:\Scripts\ServerRequest\TranscriptLogs
        Get-ECI.Environment -Env $Env
        Get-ECI.RunAsUser
        Set-ECI.RequestIDtoGlobalVariable -RequestID $RequestID

        ### Import Modules   
        ###------------------------------------- 
        Import-ECI.Root.ModuleLoader -Env $Env  # <---- MOVED-TO-INVOKE-SERVERREQUEST.PS1 ?????
        Import-ECI.EMI.Automation.VMWareModules
        #Import-VMWareModules

        ### Get Parameters from SQL        
        ###-------------------------------------
        $global:DevOps_ConnectionString  =  "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;” # <-- Need to Encrypt Password !!!!!!
        Get-ECI.EMI.Automation.SystemConfig -DevOps_ConnectionString $DevOps_ConnectionString 
        Get-ECI.EMI.Automation.BuildVersion
        Get-ECI.EMI.Automation.ServerRequest
        Get-ECI.EMI.Automation.ServerRole
        Get-ECI.EMI.Automation.VMWareTemplate
        Get-ECI.EMI.Automation.OSCustomizationSpec
        Get-ECI.EMI.Automation.VMParameters
        Get-ECI.EMI.Automation.OSParameters
        cLoBbEr-HostName -HostName $HostName
        


        Create-ECI.EMI.Automation.VMName -GPID $GPID -HostName $HostName
    }

    PROCESS
    {
        Create-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -HostName $HostName -ServerStatus "Server Request Recieved"

        ### Get/Set Server Record
        ###-----------------------------
        Check-ECI.EMI.Automation.ServerRecord -GPID $GPID -CWID $CWID -HostName $HostName

        if($ServerExists -eq $False)
        {
            #$global:ConfigurationMode = "Configure"
            Write-Host "Automation Configuration Mode: " $ConfigurationMode -ForegroundColor DarkYellow
            
            $ServerParams = @{
                RequestID     = $RequestID 
                GPID          = $GPID 
                CWID          = $CWID 
                HostName      = $HostName 
                ServerRole    = $ServerRole 
                BuildVersion  = $BuildVersion 
            }
            Create-ECI.EMI.Automation.ServerRecord @ServerParams
            Get-ECI.EMI.Automation.ServerID -RequestID $RequestID
        }
        elseif($ServerExists -eq $True)
        {
            $global:ServerID = $ServerID
            #$global:ConfigurationMode = "Report"
            Write-Host "Automation Configuration Mode: " $ConfigurationMode `n('-' * 50)`n -ForegroundColor DarkYellow
        }
        
        Create-ECI.EMI.Automation.CurrentStateRecord -ServerID (Get-ECI.EMI.Automation.ServerID -RequestID $RequestID)

        ### Provision VM
        ###-----------------------------
        
        $Params = @{
            RequestID         = $RequestID 
            ServerID          = $ServerID 
            HostName          = $HostName 
            VerifyErrorCount  = 0
            Abort             = $False 
            ServerStatus      = "VM Provisioning-Started"

        }
        Update-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -VerifyErrorCount "0" -Abort $False -ServerStatus "VM Provisioning-Started"
        
        $Params = @{
            ServerID          = $ServerID 
            HostName          = $HostName 
            ConfigurationMode = $ConfigurationMode
            Env               = $Env 
            Environment       = $Environment
        }        
        Invoke-ECI.EMI.Automation.VM -ServerID $ServerID -HostName $HostName -ConfigurationMode $ConfigurationMode -Env $Env -Environment $Environment

        $Params = @{
            ServerID          = $ServerID 
            VMName            = $VMName 
            ServerUUID        = $ServerUUID 
            vCenterUUID       = $vCenterUUID 
            vMoRef            = $vMoRef
        }        
        Update-ECI.EMI.Automation.ServerRecord -ServerID $ServerID -VMName $VMName -ServerUUID $ServerUUID -vCenterUUID $vCenterUUID -vMoRef $vMoRef

        $Params = @{
            RequestID         = $RequestID 
            ServerID          = $ServerID 
            HostName          = $HostName 
            VerifyErrorCount  = $VerifyErrorCount 
            Abort             = $False 
            ElapsedTime       = $VMElapsedTime 
            ServerStatus      = "VM Provisioning-Completed"
        }        
        Update-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -VerifyErrorCount $VerifyErrorCount -Abort $False -ElapsedTime $VMElapsedTime -ServerStatus "VM Provisioning-Completed"

        ### Configure OS
        ###-----------------------------        
        $Params = @{
            RequestID         = $RequestID 
            ServerID          = $ServerID 
            HostName          = $HostName 
            VerifyErrorCount  = 0 
            Abort             = $False 
            ServerStatus      = "OS Configuration-Started"
        }
        Update-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -VerifyErrorCount 0 -Abort $False -ServerStatus "OS Configuration-Started"
        
        Invoke-ECI.EMI.Automation.OS
        
        $Params = @{
            RequestID         = $RequestID 
            ServerID          = $ServerID 
            HostName          = $HostName 
            VerifyErrorCount  = $VerifyErrorCount 
            Abort             = $False 
            ElapsedTime       = $OSElapsedTime 
            ServerStatus      = "OS Configuration-Completed"
        }        
        Update-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -VerifyErrorCount $VerifyErrorCount -Abort $False -ElapsedTime $OSElapsedTime -ServerStatus "OS Configuration-Completed"

        ### Configure Role
        ###-----------------------------        
        #Update-ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -Verify $Verify -Abort $Abort -ServerStatus "Configuring Role"
        #Invoke-ECI.EMI.Automation.Role
    }

    END
    {
        ##################################################################
        ### END
        ##################################################################
 
        ### Remove ECI Modules from Guest
        ###-------------------------------------------
        #Delete-ECI.EMI.Automation.ECIModulesonVMGuest
        
        ### Write Status
        ###-------------------------------------------
        
        Write-Host `n('=' * 100)`n `n('*' * 100)`n`n('-' * 100)`n(' ' * 25)  "VM PROVISIONING & CONFIGURATION IS COMPLETE!" `n('-' * 100)`n`n('*' * 100)`n `n('=' * 100)`n -ForegroundColor Green
        Write-Host "SERVER BUILD TAG: "  -ForegroundColor Yellow
        Write-Host "HostName           : " $Hostname
        Write-Host "InstanceLocation   : " $InstanceLocation
        Write-Host "ServerID           : " $ServerID
        Write-Host "GPID               : " $GPID
        Write-Host "CWID               : " $CWID
        Write-Host "ServerRole         : " $ServerRole
        Write-Host "BuildVersion       : " $BuildVersion
        

        ### Write Error Count
        ###-------------------------------------------
        Write-Host `n`n('-' * 50)`n -ForegroundColor Gray

        if($VerifyErrorCount -eq 0)
        {
            Write-Host "Total Verify Errors  : " $VerifyErrorCount -ForegroundColor Green
        }
        elseif($VerifyErrorCount -gt 0)
        {
            Write-Host "Total Verify Errors  : " $VerifyErrorCount -ForegroundColor Red
        }

        if($Abort -eq 0)
        {
            Write-Host "Abort Errors         : " $Abort -ForegroundColor Green
        }
        elseif($Abort -gt 0)
        {
            Write-Host "Abort Errors         : " $Abort -ForegroundColor Red
        }
        
        Write-Host `n`n('-' * 50)`n -ForegroundColor Gray

        ### Get Server Current State from SQL
        ###-------------------------------------------        
        Get-ECI.EMI.Automation.ServerRecord-SQL       -ServerID $ServerID
        Get-ECI.EMI.Automation.ServerCurrentState-SQL -ServerID $ServerID
        Get-ECI.EMI.Automation.ServerDesiredState-SQL -ServerID $ServerID
        Get-ECI.EMI.Automation.ServerConfigLog-SQL    -ServerID $ServerID

        $script:AutomationStopTime = Get-Date
        $global:AutomationTime = ($AutomationStopTime-$AutomationStartTime)
        
        $Params = @{
            RequestID         = $RequestID 
            ServerID          = $ServerID 
            HostName          = $HostName 
            VerifyErrorCount  = $VerifyErrorCount 
            Abort             = $False 
            ElapsedTime       = $AutomationTime 
            ServerStatus      = "Build Complete"
        }        
        Update-ECI.EMI.Automation.ServerStatus -RequestID $RequestID -ServerID $ServerID -HostName $HostName -VerifyErrorCount $VerifyErrorCount -Abort $False -ElapsedTime $AutomationTime -ServerStatus "Build Complete"
        Write-Host `n`n('=' * 75)`n "ECI.EMI.Automation: Total Execution Time:`t" $AutomationTime `n('=' * 75)`n -ForegroundColor Gray
        Write-Host "================= END ALL AUTOMATION SCRIPTS ================= " -ForegroundColor Gray
        
        Stop-Transcript

        ### END AUTOMATION SCRIPTS
    }

}
