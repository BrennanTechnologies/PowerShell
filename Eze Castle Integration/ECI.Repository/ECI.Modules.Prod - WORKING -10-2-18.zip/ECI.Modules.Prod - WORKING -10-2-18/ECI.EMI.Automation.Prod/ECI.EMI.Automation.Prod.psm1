##################################
### EMI Automation Module
### ECI.EMI.Automation.Prod.psm1
##################################

#Set-StrictMode -Version Latest
#Export-ModuleMember -Function * -Alias * -Variable *

#++++++++++++++++++++++++++++++++++
### uNdEr DeVeLoPmEnT
#++++++++++++++++++++++++++++++++++
function Throw-AbortError
{
    
    Write-Host "THROWING ABORT ERROR!!! `nThe scripts encountered an Abort Level Error." -ForegroundColor Red
    
    $t = 30
    Write-Host "Exiting Script in $t seconds..." -ForegroundColor Red
    Start-Sleep -Seconds $t
    #Break 1
    [Environment]::Exit(1)
    #exit

    #Write-AbortErrorLog
    #Write-AbortErrortoSQL
}

function Get-LocalAdminAccount
{
    Param([Parameter(Mandatory = $True)][string]$State)    

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting Local Admin Account: " $State

    if($State = "Template")
    {
        $global:LocalAdminAccount = "Administrator"
        $global:LocalAdminAccountPassword = "cH3r0k33"

    }
    elseif($State = "Configured")
    {
        $global:LocalAdminAccount = "Administrator"
        $global:LocalAdminAccountPassword = "cH3r0k33"
    }
}

### Function: Set HostName & VMName ++$GPID
### --------------------------------------------------
function Create-ECI.EMI.Automation.VMName
{
    Param (
    [Parameter(Mandatory = $True)][string]$GPID,
    [Parameter(Mandatory = $True)][string]$HostName
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    ### GPID + HostName
    ###-------------------
    $global:VMName = $GPID + "_" + $HostName

    ### HostName + GPID
    ###-------------------    
    #$global:VMName = $HostName + "_" + $GPID

    Write-Host "Setting VMName: " $VMName -ForegroundColor Yellow

}

### Function: Set VMGuest Execution Policy
### --------------------------------------------------
function Configure-ECI.EMI.Automation.ExecutionPolicyonVMGuest
{

    Param([Parameter(Mandatory = $True)][string]$VMName)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ScriptText =
    { 
        if ($(Get-ExecutionPolicy) -ne "Bypass")
        {
            Write-Host "`nSetting Execution Policy on VM Guest to Bypass:"
          
            Set-ExecutionPolicy ByPass -Scope LocalMachine

            #REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f
            #Start-Process powershell -ArgumentList '-noprofile -Command Set-ExecutionPolicy ByPass -Scope LocalMachine' -verb RunAs
            #REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f

        }
        else
        {
            Write-Host "`nExecution Policy on VM Guest already set to Bypass"     
        }
    }

    Write-Host "vCenter_Account    : " $vCenter_Account -ForegroundColor Gray
    Write-Host "LocalAdminAccount  : " $LocalAdminAccount -ForegroundColor Gray

    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VMName" -ForegroundColor Yellow
    $Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminPassword 
    #$Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -HostUser $vCenter_Account -HostPassword $vCenter_Password -GuestUser Administrator -GuestPassword cH3r0k33
    
    #if($Invoke.ExitCode -ne 0)
    #{
    #    $Abort = $True
    #    Write-Host "ABORT ERROR: Aborting Script Execution" -ForegroundColor Red
    #    #Send-Alert
    #    Exit
    #}
}

function Install-ECI.EMI.Automation.ECIModulesonVMGuest      # <-------- Need ENVIRONMENT $ENV = DEV/PROD added to Path !!!!!! -----------------------------
{
    Param(
        [Parameter(Mandatory = $True)][string]$Env,
        [Parameter(Mandatory = $True)][string]$Environment
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Copy ALL ECI Modules to Guest
    #$Source = "\\eciscripts.file.core.windows.net\clientimplementation\Production\ECI.Modules.Prod"
    $Source = "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment +"\ECI.Modules." + $Env
    $Destination = "C:\Program Files\WindowsPowerShell\Modules\"

    Write-Host "Installing ECI Modules on Guest:" -ForegroundColor Yellow
    ### Copy Folders
    Get-Item $Source | Copy-VMGuestFile -LocalToGuest -Destination $Destination -VM $VMName -Force -Confirm:$false -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminPassword
}

function Delete-ECI.EMI.Automation.ECIModulesonVMGuest
{
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $ScriptText =
    { 
        $ECIModulePath = "C:\Program Files\WindowsPowerShell\Modules\ECI.Modules*"

        Remove-Item -Path $ECIModulePath -Recurse -Force -Confirm:$false
    }

    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VMName" -ForegroundColor Yellow

    $Invoke = Invoke-VMScript -VM $VMName -ScriptText $ScriptText -ScriptType Powershell -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminPassword  

    #if($Invoke.ExitCode -ne 0)
    #{
    #    $Abort = $True
    #    Write-Host "ABORT ERROR: Aborting Script Execution" -ForegroundColor Red
    #    #Send-Alert
    #    Exit
    #}

}

function Get-ECI.EMI.Automation.LocalAdminAccount
{
    Param(
    [Parameter(Mandatory = $True)][string]$Environment,
    [Parameter(Mandatory = $False)][switch]$PreConfig,
    [Parameter(Mandatory = $False)][switch]$PostConfig
    )    
    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray


    [hashtable]$Creds = @{}

    $DataSetName = "LocalAdmin"
    $ConnectionString =  $DevOps_DBConnectionString
    $Query = �SELECT LocalAdminPassword,PreConfig_LocalAdminAccount,PostConfig_LocalAdminAccount FROM SystemConfig WHERE Environment = '$Environment'�
    #$Query = �SELECT * FROM SystemConfig WHERE Environment = '$Environment'�
    #$Query = �SELECT * FROM SystemConfig�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query  

    if($PreConfig -eq $True)
    {
        $Creds.LocalAdminAccount  =  $PreConfig_LocalAdminAccount
        $global:LocalAdminAccount =  $PreConfig_LocalAdminAccount
    }
    if($PostConfig -eq $True)
    {
        $Creds.LocalAdminAccount  =  $PostConfig_LocalAdminAccount
        $global:LocalAdminAccount =  $PostConfig_LocalAdminAccount
    }

    $Creds.LocalAdminPassword  = $LocalAdminPassword
    $global:LocalAdminPassword = $LocalAdminPassword
    
    Write-Host "Setting Local Admin Account: " $LocalAdminAccount -ForegroundColor Yellow

    Return $Creds
}

#++++++++++++++++++++++++++++++++++



### ===================================================================================================
### Configure Desired State
### ===================================================================================================
###
        function Configure-DesiredState
        {
    [CmdletBinding()]
    Param(
    [Parameter(Mandatory = $True)][int]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$FunctionName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$DesiredState,
    [Parameter(Mandatory = $True)][scriptblock]$GetCurrentState,
    [Parameter(Mandatory = $True)][scriptblock]$SetDesiredState,
    [Parameter(Mandatory = $True)][ValidateSet("Report","Configure")][string]$ConfigurationMode,
    [Parameter(Mandatory = $True)][ValidateSet($True, $False)][string]$AbortTrigger
    )

    ###===============================================
    ### GET CURRENT CONFIGURATION-STATE: 
    ###===============================================
    function Get-CurrentState
    {
        Try-Catch -Scriptblock { Invoke-Command $GetCurrentState } -Quiet
    }

    ###===============================================
    ### COMPARE CURRENT/DESIRED-STATE:
    ###===============================================
    function Compare-DesiredState
    {
        $global:Compare = ($CurrentState -eq $DesiredState)
        Write-ConfigReport "COMPARE: $Compare - FUNCTION: $FunctionName CURRENTSTATE: $CurrentState DESIREDSTATE: $DesiredState"
        if($Compare -eq $True)
        {
            ### CURRENT STATE = DESIRED STATE: True
            ### --------------------------------------
            Write-ConfigReport "The Current-State Matches the Desired-State. Not Running Configuration!"
        }
        elseif($Compare -eq $False)
        {
            ### CURRENT STATE = DESIRED STATE: False
            ### --------------------------------------
            Write-ConfigReport "The Current-State Does Not Match the Desired-State. Running Configuration!"
        }
    }

    ###===============================================
    ### SET DESIRED-STATE:
    ###===============================================
    function Set-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-ConfigReport "Running in Configure Mode. Changing Configuration!"
                [ScriptBlock]$DesiredStateConfiguration = {Invoke-Command $SetDesiredState}
                Try-Catch $DesiredStateConfiguration
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-ConfigReport "Running in Report Mode. Reporting Data Only!"
            }
        }
    }
        
    ###===============================================
    ### VERIFY DESIRED-STATE:
    ###===============================================
    function Verify-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            ### VERIFY: Current State
            ### -----------------------------------------------------
            Get-CurrentState
            $global:VerifyState = $CurrentState

            ### COMPARE: Verify State - Desired State
            ### ----------------------------------------------------- 
            $global:Verify = ($VerifyState -eq $DesiredState) ### <-- True/False
            Write-ConfigReport "COMPARE - VERIFY: $Verify VERIFYSTATE: $VerifyState DESIREDSTATE: $DesiredState"

            ### VERIFY = TRUE
            ### -----------------------------------------------------        
            if($Verify -eq $True)
            {
                ### ABORT = FALSE
                ### --------------------
                $global:Abort = $False
            }
        
            ###  VERIFY = FALSE
            ### -----------------------------------------------------
            elseif($Verify -eq $False)
            {
                ### Increment Verify Error Counter
                $global:VerifyErrorCount ++

                if ($AbortTrigger -eq $True)
                {
                    ### ABORT TRIGGER = TRUE
                    ### --------------------
                    $global:Abort = $True
                    Throw-AbortError
                }
                elseif($AbortTrigger -eq $False)
                {
                    ### ABORT TRIGGER = FALSE
                    ### --------------------
                    $global:Abort = $False
                }
            }
        }
    }

    ###===============================================
    ### REPORT DESIRED-STATE:
    ###===============================================
    function Report-DesiredState
    {    
         ### Update Config Log
        ###-------------------------------------
        Write-Host "UPDATING SERVER CONFIG LOGS   - ServerID: $ServerID HostName: $HostName FunctionName: $FunctionName Verify: $Verify Abort: $Abort" -ForegroundColor Cyan
        
        $Params = @{
            ServerID      = $ServerID 
            HostName      = $HostName 
            FunctionName  = $FunctionName 
            PropertyName  = $PropertyName 
            CurrentState  = $CurrentState 
            Verify        = $Verify 
            Abort         = $Abort
        }
        
        #Write-ConfigLog $Params
        Write-ConfigLog -ServerID $ServerID -HostName $HostName -FunctionName $FunctionName -PropertyName $PropertyName -CurrentState $CurrentState -Verify $Verify -Abort $Abort

        ### Update Desired State
        ###-------------------------------------
        Write-Host "UPDATING SERVER DESIRED STATE - ServerID: $ServerID HostName: $HostName PropertyName: $PropertyName CurrentState: $CurrentState DesiredState: $DesiredState Verify: $Verify Abort: $Abort" -ForegroundColor Cyan
        $Params = @{
            ServerID      = $ServerID 
            HostName      = $HostName 
            PropertyName  = $PropertyName 
            CurrentState  = $CurrentState 
            DesiredState  = $DesiredState 
            Verify        = $Verify 
            Abort         = $Abort
        }
        #Write-DesiredState $Params
        Write-DesiredState -ServerID $ServerID -HostName $HostName -PropertyName $PropertyName -CurrentState $CurrentState -DesiredState $DesiredState -Verify $Verify -Abort $Abort
        
        ### Update Current State
        ###-------------------------------------
        Write-Host "UPDATING SERVER CURRENT STATE - ServerID: $ServerID HostName: $HostName PropertyName: $PropertyName CurrentState: $CurrentState" -ForegroundColor Cyan
        $Params = @{
            ServerID      = $ServerID 
            HostName      = $HostName 
            PropertyName  = $PropertyName 
            CurrentState  = $CurrentState                
        }
        #Write-CurrentState $Params
        Write-CurrentState -ServerID $ServerID -HostName $HostName -PropertyName $PropertyName -CurrentState $CurrentState

        ### IF ABORT = TRUE
        ### --------------------
        if($Abort -eq $True)
        {
            ### ABORT = TRUE: Throw Abort Error
            ### -------------------------------------------------------------------------------------
            Write-ConfigReport "ABORTTRIGGER: " $AbortTrigger "`t`tABORT: " $Abort 
            Throw-AbortError
        }
    }

    ###===============================================
    ###-----------------------------------------------
    ### CONFIGURE DESIRED-STATE
    ###-----------------------------------------------
    ###===============================================
    &{
        BEGIN
        {   }

        PROCESS
        {
            Get-CurrentState
            Compare-DesiredState
            if($Compare -eq $False){Set-DesiredState}
            Verify-DesiredState
            Report-DesiredState
        }

        END
        {   }   
    }
}
###
### ===================================================================================================

function List-AllParameters-deleteme #<-- deleteme?????
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Server  Parameters
    ###----------------------------------------------------------------
    Write-Host `n('-' * 50)`n "Server Parameters  : "                        -ForegroundColor Gray
    Write-Host "ServerID                   : " $ServerID                     -ForegroundColor Gray

    ### Server Request Parameters
    ###----------------------------------------------------------------
    Write-Host `n('-' * 50)`n "ServerRequest Parameters  : "                  -ForegroundColor Gray
    Write-Host "RequestID                  : " $RequestID                     -ForegroundColor Gray
    Write-Host "RequestDateTime            : " $RequestDateTime               -ForegroundColor Gray
    Write-Host "HostName                   : " $HostName                      -ForegroundColor Gray
    Write-Host "ServerRole                 : " $ServerRole                    -ForegroundColor Gray
    Write-Host "IPv4Address                : " $IPv4Address                   -ForegroundColor Gray
    Write-Host "SubnetMask                 : " $SubnetMask                    -ForegroundColor Gray
    Write-Host "DefaultGateway             : " $DefaultGateway                -ForegroundColor Gray
    Write-Host "InstanceLocation           : " $InstanceLocation              -ForegroundColor Gray
    Write-Host "BackupRecovery             : " $BackupRecovery                -ForegroundColor Gray
    Write-Host "DisasterRecovery           : " $DisasterRecovery              -ForegroundColor Gray 

    ### VM Parameters
    ###----------------------------------------------------------------
    Write-Host "VM Parameters              : " `n('-' * 50)`n -ForegroundColor Gray
    Write-Host "VMParameterID              : " $VMParameterID -ForegroundColor Gray
    Write-Host "vCPUCount                  : " $vCPUCount -ForegroundColor Gray
    Write-Host "vMemorySizeGB              : " $vMemorySizeGB -ForegroundColor Gray
    Write-Host "OSVolumeGB                 : " $OSVolumeGB -ForegroundColor Gray
    Write-Host "SwapVolumeGB               : " $SwapVolumeGB -ForegroundColor Gray
    Write-Host "DataVolumeGB               : " $DataVolumeGB -ForegroundColor Gray
    Write-Host "LogVolumeGB                : " $LogVolumeGB -ForegroundColor Gray
    Write-Host "SysVolumeGB                : " $SysVolumeGB -ForegroundColor Gray

    ### OS Parameters
    ###----------------------------------------------------------------
    Write-Host "OS Parameters              : " `n('-' * 50)`n -ForegroundColor Gray
    Write-Host "NetworkInterfacename       : " $NetworkInterfacename -ForegroundColor Gray
    Write-Host "LocalAdministrator         : " $LocalAdministrator -ForegroundColor Gray
    Write-Host "CDROMLetter                : " $CDROMLetter -ForegroundColor Gray
    Write-Host "IPv6Preference             : " $IPv6Preference -ForegroundColor Gray
    Write-Host "WindowsFirewallPreference  : " $WindowsFirewallPreference -ForegroundColor Gray
    Write-Host "IEESCPreference            : " $InternetExplorerESCPreference -ForegroundColor Gray
    Write-Host "RemoteDesktopPreference    : " $RemoteDesktopPreference -ForegroundColor Gray
    Write-Host "RDPResetrictionsPreference : " $RDPResetrictionsPreference -ForegroundColor Gray
    Write-Host "SwapFileBufferSizeMB       : " $SwapFileBufferSizeMB -ForegroundColor Gray
    Write-Host "SwapFileLocation           : " $SwapFileLocation -ForegroundColor Gray
    Write-Host "SwapFileMemoryThreshholdGB : " $SwapFileMemoryThreshholdGB -ForegroundColor Gray
    Write-Host "SwapFileMultiplier         : " $SwapFileMultiplier -ForegroundColor Gray
    Write-Host  `n('-' * 50)`n -ForegroundColor Gray
}


### VMWare Functions
### --------------------------------------------------
function Import-ECI.EMI.Automation.VMWareModules
{
    Param(
        [Parameter(Mandatory = $False)][switch]$Local,
        [Parameter(Mandatory = $False)][switch]$Repo
    )

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
          
    # i ran install-module vmware.vimautomation.core
    #AzureRM and MSOnline.  yeah, i suspect you'll need both.  there is also the netapp powershell toolkit
    #Install-Module -Name VMware.PowerCLI -RequiredVersion 6.5.4.7155375
<#
    if($Local)
    {
        $VMModulesPath = "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\"
    }
    elseif($Repo)
    {
        $VMModulesPath = "\\eciscripts.file.core.windows.net\clientimplementation\Development\Vendor.Modules.Dev\vSphere PowerCLI\Modules\"
    }
    else
    {
        $VMModulesPath = "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\"
    }
    ### Add PowerCLI to PS Module Path
    $env:PSModulePath = $env:PSModulePath + ";" +  $VMModulesPath
#>


    $VMModules = "VMware.*"

    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available! Check env:PSModulePath env:PSModulePath" (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
    
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -InvalidCertificateAction ignore -Confirm:$false | Out-Null #<--- MOVE to Connect-VIServer ????
}

### --------------------------------------------------
function Get-ECI.EMI.Automation.vCenter
{
    Param([Parameter(Mandatory = $True)][string]$InstanceLocation)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    switch ( $InstanceLocation )
    {
        "Lab" { $ECIvCenter = "ecilab-bosvcsa01.ecilab.corp" }
        "BOS" { $ECIvCenter = "bosvc.eci.cloud"      }
        "QTS" { $ECIvCenter = "cloud-qtsvc.eci.corp" }
        "SAC" { $ECIvCenter = "sacvc.eci.cloud"      }
        "LHC" { $ECIvCenter = "lhcvc.eci.cloud"      }
        "LD5" { $ECIvCenter = "ld5vc.eci.cloud"      }
        "HK"  { $ECIvCenter = "hkvc.eci.cloud"       }
        "SG"  { $ECIvCenter = "sgvc.eci.cloud"       }
    }

    $global:ECIvCenter = $ECIvCenter
    Write-Host "Instance Location  : " $InstanceLocation -ForegroundColor Yellow
    Write-Host "vCenter            : " $ECIvCenter -ForegroundColor Yellow
    Return $global:ECIVCenter
}

### --------------------------------------------------
function Connect-ECI.EMI.Automation.VIServer
{
    Param([Parameter(Mandatory = $True)][string]$InstanceLocation)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Show/Hide VMWare Module Progress Bar
    $global:ProgressPreference = "Continue" ### "SilentlyContinue"
    
    ### Hide Certificate Warning Message
    #Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -InvalidCertificateAction ignore -Confirm:$false | Out-Null  
    Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction ignore -Confirm:$false | Out-Null  
    write-host "InstanceLocation   : " $InstanceLocation -ForegroundColor Yellow

    ### Get vCenter InstanceLocation
    ###--------------------------------
    $ECIvCenter = Get-ECI.EMI.Automation.vCenter -InstanceLocation $InstanceLocation

    if($global:DefaultVIServers.Count -gt 0)
    {
        Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
        #Disconnect-VIServer -Server $global:DefaultVIServers -confirm:$false
    }
    else 
    {
        Write-Host "Connecting New Session to VI Server: "  $ECIvCenter -ForegroundColor Gray
        
        ### Connect to vCenter
        ###---------------------------------
        Write-Host "vCenter_Account: " $vCenter_Account

        $global:VISession = Connect-VIServer -Server $ECIvCenter -User $vCenter_Account -Password $vCenter_Password
        
        ### Get  InstanceUUID
        ###---------------------------------
        $global:vCenterUUID = $VISession.InstanceUuid
        Write-Host "vCenterUUID   : " $vCenterUUID -ForegroundColor Magenta
    }
}

### Delete Server Logs
### --------------------------------------------------
function Delete-ECI.EMI.Automation.ServerLogs
{
    Param(
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $False)][switch]$RuninGuest
    )
    ### Delete Log Path
    ###---------------------------
    if($RuninGuest)
    {
        $VMLogPath = "C:\SCripts\VMAutomation\" + $HostName + "\"
    }
    elseif(!($RuninGuest))
    {
        $VMLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomationLogs\" + $HostName + "\"
    }
    
    if(Test-Path -Path $VMLogPath)
    {
        Remove-Item -Path $VMLogPath -Include * -Recurse -Force -Confirm:$false 
    }
}

function Copy-ECI.EMI.Automation.VMLogsfromGuest
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Create Log Folder
    $VMLogDestination = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 

    if(-NOT(Test-Path -Path $VMLogDestination)) {(New-Item -ItemType directory -Path $VMLogDestination -Force | Out-Null)}

    $VMLogSource = "C:\Scripts\_VMAutomationLogs\" + $HostName
    write-host "Copying Log Files - SOURCE: $VMLogSource DESTINATION: $VMLogDestination" -ForegroundColor Gray

    Copy-VMGuestFile -Source $VMLogSource -Destination $VMLogDestination -VM $VMName -GuestToLocal -GuestUser $LocalAdminAccount -GuestPassword $LocalAdminPassword 
    
}

### Write Server Logs to SQL
function Write-ECI.EMI.Automation.VMLogstoSQL
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Writing VM Logs to SQL . . . " -ForegroundColor Yellow
    Write-Host "Writing ConfigLog: " -ForegroundColor DarkGray
    Write-ConfigLog-SQL
    Write-Host "Writing DesiredState: " -ForegroundColor DarkGray
    Write-DesiredState-SQL
    Write-Host "Writing CurrentState: " -ForegroundColor DarkGray
    Write-CurrentState-SQL
}


### Write Server Config Log
### --------------------------------------------------
function Write-ConfigLog
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$FunctionName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$CurrentState,
    [Parameter(Mandatory = $True)][string]$Verify,
    [Parameter(Mandatory = $True)][string]$Abort
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Set Log Name
    ###---------------------------
    $VMLogName = "ConfigLog"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 

    ### Set Log File Name
    ###---------------------------
    $VMLogFile = $VMLogPath + $VMLogName + "_" + $HostName  + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"
    if(-NOT(Test-Path -Path $VMLogFile)) {(New-Item -ItemType file -Path $VMLogFile -Force | Out-Null)}

    Set-Variable -Name $VMLogName -Value $VMLogFile -Option AllScope -Scope global -Force

    ### Export Log Entry
    ###---------------------------
    $VMLogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "FunctionName=" + $FunctionName + "," +  "PropertyName=" + $PropertyName + "," +  "CurrentState=" + $CurrentState + "," +  "Verify=" + $Verify + "," +  "Abort=" + $Abort
    Write-Host "LOG LOGFILE : $VMLogFile" -ForegroundColor DarkGray
    Write-Host "LOG ENTRY   : $VMLogEntry" -ForegroundColor DarkGray
    $VMLogEntry | Out-File -FilePath $VMLogFile -Force -Append
}

### Write Server Config Logs to SQL
### --------------------------------------------------
function Write-ConfigLog-SQL
{
    ### Set Log Name
    ###---------------------------
    $VMLogName = "ConfigLog"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 
    $ConnectionString  = $DevOps_DBConnectionString 

    ### Open Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $VMLastLog = Get-ChildItem -Path ($VMLogPath) | Where-Object {($_ -like $VMLogName + "*")} | Sort-Object LastAccessTime -Descending | Select-Object -First 1
    $VMLastLogFile = $VMLogPath + "\" + $VMLastLog
    $VMLastLogFile = Get-Content -Path $VMLastLogFile
    
    foreach ($Record in $VMLastLogFile)
    {
        $Keys = $Null
        $Values = $Null

        foreach($Column in ($Record.split(",")))
        {
          $Key = $Column.split("=")[0]
          $Value =  "'" + $Column.split("=")[1] + "'"
          $Keys = $Keys + $Key + ","
          $Values = $Values + $Value + ","
        }
        $Keys = $Keys.Substring(0,$Keys.Length-1)
        $Values = $Values.Substring(0,$Values.Length-1)

        $Query = "INSERT INTO ServerConfigLog($Keys) VALUES ($Values)"
        
        ### Show Results
        ###------------------------
        Write-Host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

### Write Server Desired State
### --------------------------------------------------
function Write-DesiredState
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$CurrentState,
    [Parameter(Mandatory = $True)][string]$DesiredState,
    [Parameter(Mandatory = $True)][string]$Verify,
    [Parameter(Mandatory = $True)][string]$Abort,
    [Parameter(Mandatory = $False)][switch]$RuninGuest
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Set Log Name
    ###---------------------------
    $VMLogName = "DesiredStateLog"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 

    ### Set Log File Name
    ###---------------------------
    $VMLogFile = $VMLogPath + $VMLogName + "_" + $HostName  + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"
    if(-NOT(Test-Path -Path $VMLogFile)) {(New-Item -ItemType file -Path $VMLogFile -Force | Out-Null)}

    Set-Variable -Name $VMLogName -Value $VMLogFile -Option AllScope -Scope global -Force

    $VMLogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "PropertyName=" + $PropertyName + "," +  "CurrentState=" + $CurrentState + "," +  "DesiredState=" + $DesiredState + "," +  "Verify=" + $Verify + "," +  "Abort=" + $Abort
    $VMLogEntry | Out-File -FilePath $VMLogFile -Force -Append
}

### Write Server Desired State to SQL
### --------------------------------------------------
function Write-DesiredState-SQL
{
    ### Set Log Name
    ###---------------------------
    $VMLogName = "DesiredState"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 
    $ConnectionString  = $DevOps_DBConnectionString 

    ### Open Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $VMLastLog = Get-ChildItem -Path ($VMLogPath) | Where-Object {($_ -like $VMLogName + "*")} | Sort-Object LastAccessTime -Descending | Select-Object -First 1
    $VMLastLogFile = $VMLogPath + "\" + $VMLastLog
    
    $VMLastLogFile = Get-Content -Path $VMLastLogFile
    
    foreach ($Record in $VMLastLogFile)
    {
        $Keys = $Null
        $Values = $Null

        foreach($Column in ($Record.split(",")))
        {
          $Key = $Column.split("=")[0]
          $Value =  "'" + $Column.split("=")[1] + "'"
          $Keys = $Keys + $Key + ","
          $Values = $Values + $Value + ","
        }
        $Keys = $Keys.Substring(0,$Keys.Length-1)
        $Values = $Values.Substring(0,$Values.Length-1)

        $Query = "INSERT INTO ServerDesiredState($Keys) VALUES ($Values)"
        
        ### Show Results
        ###------------------------        
        write-host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

### Write Server Desired State
### --------------------------------------------------
function Write-CurrentState
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$PropertyName,
    [Parameter(Mandatory = $True)][string]$CurrentState
    )

    ### Set Log Name
    ###---------------------------
    $VMLogName = "CurrentStateLog"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName + "\" 

    ### Set Log File Name
    ###---------------------------
    $VMLogFile = $VMLogPath + $VMLogName + "_" + $HostName + ".txt" #+ "_" + (Get-Date -format "MM-dd-yyyy_hh_mm_ss") + ".txt"
    if(-NOT(Test-Path -Path $VMLogFile)) {(New-Item -ItemType file -Path $VMLogFile -Force | Out-Null)}

    Set-Variable -Name $VMLogName -Value $VMLogFile -Option AllScope -Scope global -Force

    ### Export Log Entry
    ###---------------------------
    $VMLogEntry =   "ServerID=" + $ServerID + "," + "HostName=" + $HostName + "," +  "PropertyName=" + $PropertyName + "," +  "CurrentState=" + $CurrentState
    $VMLogEntry | Out-File -FilePath $VMLogFile -Force -Append
}

### Write Server Current State to SQL
### --------------------------------------------------
function Write-CurrentState-SQL
{
    #Param([Parameter(Mandatory = $True)][string]$ServerID)
    
    ### Set Log Name
    ###---------------------------
    $VMLogName = "CurrentStateLog"
    $VMLogPath = "C:\Scripts\_VMAutomationLogs\" + $HostName  + "\" 
    $ConnectionString = $DevOps_DBConnectionString

    ### Open Database Connection
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    ### Insert Row
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $Connection    

    ### Import Log File
    ###----------------------
    $VMLastLog = Get-ChildItem -Path ($VMLogPath) | Where-Object {($_ -like $VMLogName + "*")} | Sort-Object LastAccessTime -Descending | Select-Object -First 1
    $VMLastLogFile = $VMLogPath + "\" + $VMLastLog
    
    $VMLastLogFile = Get-Content -Path $VMLastLogFile

    foreach ($Record in $VMLastLogFile)
    {
        #$Keys = $Null
        #$Values = $Null

        $ServerID     = ($Record.split(","))[0].split("=")[1]
        $HostName     = ($Record.split(","))[1].split("=")[1]
        $PropertyName = ($Record.split(","))[2].split("=")[1]
        $CurrentState = ($Record.split(","))[3].split("=")[1]
        
        $CurrentStateDateTime = "'" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "'"

        if($CurrentState -eq "False"){$CurrentState = 0}
        if($CurrentState -eq "True"){$CurrentState = 1}
        else {$CurrentState = "'" + $CurrentState + "'"}

        ### FORMAT: UPDATE tblTable SET column1 = value1, column2 = value2...., columnN = valueN WHERE [condition];

        $Query = "UPDATE ServerCurrentState SET $PropertyName = $CurrentState, CurrentStateDateTime =  $CurrentStateDateTime WHERE ServerID = $ServerID"

        ### Show Results
        ###------------------------        
        write-host "Query: " $Query

        $cmd.CommandText = $Query
        $cmd.ExecuteNonQuery() #| Out-Null
    }
    ### Close
    $connection.Close()
}

### Show OS Parameters
### --------------------------------------------------
function Show-ECI.EMI.Automation.OSParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "`nOS Parameters:" `n("-" * 50)
    Write-Host "Step                              : " $Step
    Write-Host "VMName                            : " $VMName
    Write-Host "ServerID                          : " $ServerID
    Write-Host "ServerRole                        : " $ServerRole
    Write-Host "HostName                          : " $HostName
    Write-Host "ClientDomain                      : " $ClientDomain
    Write-Host "IPv4Address                       : " $IPv4Address
    Write-Host "SubnetPrefixLength                : " $SubnetPrefixLength
    Write-Host "DefaultGateway                    : " $DefaultGateway
    Write-Host "PrimaryDNS                        : " $PrimaryDNS
    Write-Host "SecondaryDNS                      : " $SecondaryDNS
    Write-Host "BuildVersion                      : " $BuildVersion
    Write-Host "CDROMLetter                       : " $CDROMLetter
    Write-Host "InternetExplorerESCPreference     : " $InternetExplorerESCPreference
    Write-Host "IPv6Preference                    : " $IPv6Preference
    Write-Host "LocalAdministrator                : " $LocalAdministrator
    Write-Host "NetworkInterfaceName              : " $NetworkInterfaceName
    Write-Host "RDPResetrictionsPreference        : " $RDPResetrictionsPreference
    Write-Host "RemoteDesktopPreference           : " $RemoteDesktopPreference
    Write-Host "SwapFileBufferSizeMB              : " $SwapFileBufferSizeMB
    Write-Host "SwapFileLocation                  : " $SwapFileLocation
    Write-Host "SwapFileMemoryThreshholdGB        : " $SwapFileMemoryThreshholdGB
    Write-Host "SwapFileMultiplier                : " $SwapFileMultiplier
    Write-Host "WindowsFirewallPreference         : " $WindowsFirewallPreference
}

###                                                         <--- why????
### --------------------------------------------------
function Write-ConfigReport 
{
    Param(
    [Parameter(Mandatory = $True, Position = 0)] [string]$Message,
    [Parameter(Mandatory = $False, Position = 1)] [string]$String,
    [Parameter(Mandatory = $False, Position = 2)] [string]$String2,
    [Parameter(Mandatory = $False, Position = 3)] [string]$String3,
    [Parameter(Mandatory = $False, Position = 4)] [string]$String4,
    [Parameter(Mandatory = $False, Position = 5)] [string]$String5,
    [Parameter(Mandatory = $False, Position = 6)] [string]$String6
    )
        function Start-ConfigReport 
    {
        ### Create Timestamp
        $TimeStamp  = Get-Date -format "MM-dd-yyyy_hh_mm_ss"

        ### Create Log Folder
        #$ConfigReportPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomationLogs\" + $VM + "\"
        $global:ConfigReportPath = "C:\Scripts\_VMAutomationLogs\"
        if(-NOT(Test-Path -Path $ConfigReportPath)) {(New-Item -ItemType directory -Path $ConfigReportPath -Force | Out-Null) }
       
        ### Create Log File
        $global:ConfigReportFile = $ConfigReportPath + "ConfigReport" + "_" + $TimeStamp + ".log"
        
        if(-NOT(Test-Path -Path $ConfigReportFile)) {(New-Item -ItemType file -Path $ConfigReportFile -Force | Out-Null) }
    }

    if (((Get-Variable 'ConfigReportFile' -Scope Global -ErrorAction 'Ignore')) -eq $Null) #if (-NOT($LogFile))
    {
        Start-ConfigReport
    }     

    ### Write the Message to the Config Report.
    $Message = $Message + $String + $String2 + $String3 + $String4 + $String5 + $String6
    Write-Host $Message
    $Message | Out-File -filepath $ConfigReportFile -append   # Write the Log File Emtry
}

### --------------------------------------------------
function Write-ServerBuildTag #-redo  <----- deleteme?
{
    Write-Host "Writing ServerBuildTag:"`n("-" * 50)

    ### Create Server Build Tag
    $ServerBuildTagPath = "C:\Scripts\_VMAutomationLogs\ServerBuildTag_" + $VMName #+ "_" + $(get-date -f MM-dd-yyyy_HH_mm_ss) + ".txt"
   
    $ServerBuildTag     = [ordered]@{
        VMGuestName     = (Get-WmiObject Win32_ComputerSystem).Name
        VMGuestOS       = [environment]::OSVersion.Version
        VMGuestDomain   = (Get-WmiObject Win32_ComputerSystem).Domain
        BuildDate       = $(get-date)
        Engineer        = "CBrennan - (cbrennan@eci.com)"

    }
    $ServerBuildTag | Out-File -FilePath $ServerBuildTagPath -Force

    ### Get Module Meta Data
    $Modules = Get-Module | Where-Object {($_.Name -like "ECI.Core.*")}
    foreach($Module in $Modules)
    {
        $ModuleData = [ordered]@{
            Module        = $Module
            ModuleVersion = $Module.Version
        }
        $ModuleData | Out-File -FilePath $ServerBuildTagPath -Append
    
        Write-Host "Module: " $Module
        Write-Host "ModuleVersion: " $Module.Version   
    }

    ### Get Parameters
    Write-Host "Soft Parameters:" 
    $SoftParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $SoftParameters | FT
    
    Write-Host "Hard Parameters:" 
    $HardParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $HardParameters | FT
    
    Write-Host "Windows Features Installed:" 
    ("Windows Features:") | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | FT
}

### Open SQL Server Connection - SQL
### --------------------------------------------------
function Open-SQLConnection
{    
    [OutputType([bool])]
    Param([Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)]$ConnectionString)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    try
    {
        $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $Connection.Open();
        $Connection.Close();

        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $True;
    }
    catch
    {
        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $False;
        $Abort = $True
        Invoke-AbortError
    }
}

### Test SQL Server Connectivity - SQL  delete me!!!!!!!!!!!!!!!!!!!!!!!!!!!
### --------------------------------------------------
function Test-SQLConnection-deleteme  
{    
    [OutputType([bool])]
    Param([Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)]$ConnectionString)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $SQLConnectionString   = "server=ECILAB-BOSDEV01\SQLEXPRESS;database=ServerConfiguration-Dev-Lab;trusted_connection=true;"
    $AzureConnectionString = "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $CWConnectionString   = "server=10.3.3.77;database=ECIPortalDev;User ID=cbrennan_admin;Password=Tolkien4374;"
    try
    {
        $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $Connection.Open();
        $Connection.Close();

        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $True;
    }
    catch
    {
        Write-Host "SQL Connectivity Results: "
        Write-Host "ConnectionString: " $ConnectionString
        Return $False;
        $Abort = $True
        Invoke-AbortError
    }
}

########################################
### Get SQL Data
########################################
function Get-ECI.EMI.Automation.SQLData
{
    [CmdletBinding(SupportsPaging = $true)]

    PARAM(
        [Parameter(Mandatory = $True)] [string]$DataSetName,
        [Parameter(Mandatory = $True)] [string]$ConnectionString,
        [Parameter(Mandatory = $True)] [string]$Query
    )

    BEGIN 
    {
        ### Create Database Connection
        $Connection = New-Object System.Data.SQLClient.SQLConnection
        $Connection.ConnectionString = $ConnectionString 
        $Connection.Open()    

        ### Execute SQL Query
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandText = $Query
        $Reader = $Command.ExecuteReader()
    }
    
    PROCESS
    {
        ### Datatable
        #$Datatable = $DataSetName
        $Datatable = New-Object System.Data.DataTable
        $Datatable.Load($Reader)

        ### Get Columns from the  Datatable
        ###---------------------------------
        $Columns = $Datatable | Get-Member -MemberType Property,NoteProperty | ForEach-Object {$_.Name} | Sort-Object -Property Name

        #$global:Parameters = @()

        $PSObject = New-Object PSObject 

        foreach($Column in $Columns)
        {
            ### Create Variables from Datatable
            Set-Variable -Name $Column -Value $Datatable.$Column -Scope global

            #$PSObject | Add-Member �MemberTypeNoteProperty �Name $Column �Value $Datatable.$Column
            $PSObject | Add-Member -type NoteProperty �Name $Column �Value $Datatable.$Column

            ### Build Parameter Set from Datatable
            #$Parameters += Get-Variable -Name $Column 
            
            ### Build All Parameters Set
            #$global:AllParameters += Get-Variable -Name $Column 
        
        }
        
        Write-Host "Getting Data Set: " $DataSetName -foregroundcolor DarkYellow
        
        Set-Variable -Name $DataSetName -Value $PSObject -Scope global
        
        $Datatable | FL

        #$Parameters | FT
    }

    END 
    {
        ### Close Database Connection
        $Connection.Close()
    }
}


### Get System Config - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.SystemConfig
{
    PARAM([Parameter(Mandatory = $True,Position=0)][string]$DevOps_ConnectionString)

    $FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "SystemConfig"
    $ConnectionString = $DevOps_ConnectionString
    #$ConnectionString =  "Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $Query = �SELECT * FROM SystemConfig�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query


    $global:DevOps_ConnectionString = $DevOps_ConnectionString

    switch ($Env)
    {
        "Dev"   { $global:Portal_DBConnectionString = $DevPortal_DBConnectionString   }
        "Stage" { $global:Portal_DBConnectionString = $StagePortal_DBConnectionString }
        "Prod"  { $global:Portal_DBConnectionString = $ProdPortal_DBConnectionString  }
    }

    switch ($Env)
    {
        "Dev"   { $global:vCenter_Account = $DevvCenter_Account   }
        "Stage" { $global:vCenter_Account = $StagevCenter_Account }
        "Prod"  { $global:vCenter_Account = $ProdvCenter_Account  }
    }

    switch ($Env)
    {
        "Dev"   { $global:vCenter_Password = $DevvCenter_Password   }
        "Stage" { $global:vCenter_Password = $StagevCenter_Password }
        "Prod"  { $global:vCenter_Password = $ProdvCenter_Password  }
    }

    Write-Host "DevOps_DBConnectionString  : " $DevOps_DBConnectionString
    Write-Host "Portal_DBConnectionString  : " $Portal_DBConnectionString
    Write-Host "vCenter_Account            : " $vCenter_Account
    Write-Host "vCenter_Password           : " $vCenter_Password
    
}

### Get Build Version - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.BuildVersion
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerBuildVersion"
    $ConnectionString =  $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionServerBuildVersions WHERE Production = '$True'�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
    
    Write-Host "ServerBuildVersion.BuildVersion: " $ServerBuildVersion.BuildVersion
    
    $global:BuildVersion = $ServerBuildVersion.BuildVersion
    Return $BuildVersion
}

### Get Server Request Parameters - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerRequest
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerRequest"
    $ConnectionString =  $Portal_DBConnectionString
    $Query = �SELECT * FROM ServerRequest WHERE RequestID = '$RequestID'�
   
    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query   

    Write-Host "ServerRequest - RequestId  : $RequestId"     -ForegroundColor Yellow
    Write-Host "ServerRequest - GPID       : $GPID"          -ForegroundColor Yellow
    Write-Host "ServerRequest - CWID       : $CWID"          -ForegroundColor Yellow
    Write-Host "ServerRequest - HostName   : $HostName"`n`n  -ForegroundColor Yellow

    Return $global:RequestId
}

### Get Server Role - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerRole
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "ServerRoleData"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionServerRoles WHERE ServerRole = '$RequestServerRole' AND BuildVersion = '$BuildVersion'�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
    
    $global:ServerRole = $ServerRole
    Return $ServerRole
}

### Get VMWare Template - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.VMWareTemplate
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareTemplate"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionVMTemplates WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
    
    $global:VMTemplateName = $VMTemplateName
    Return $global:VMTemplateName
}



### Get VMWare OSCustomizationSpec - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.OSCustomizationSpec-encrypt
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareOSCustomizationSpec"
    $ConnectionString = $DevOps_DBConnectionString
    #$ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    #$Query = "OPEN SYMMETRIC KEY SQLSymmetricKey  DECRYPTION BY CERTIFICATE SelfSignedCertificate; SELECT *, CONVERT(varchar, DecryptByKey(EncryptedPassword)) AS 'DecryptedPassword' FROM definitionVMOSCustomizationSpec WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'"
    #$Query = "SELECT *, CONVERT(varchar, DecryptByKey(EncryptedPassword)) AS 'DecryptedPassword' FROM definitionVMOSCustomizationSpec WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'"
    #$Query = "SELECT EncryptedPassword, CONVERT(varchar, DecryptByKey(EncryptedPassword)) AS 'DecryptedPassword' FROM definitionVMOSCustomizationSpec;  "
    #$ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�

    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)


    $DataTable

    Write-host "DecryptedPassword: " $DecryptedPassword -ForegroundColor Magenta

    Return $global:OSCustomizationSpecName

    $Connection.Close()
}


function Get-ECI.OSCustomizationSpec-original
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareOSCustomizationSpec"
    $ConnectionString = $DevOps_DBConnectionString

    #OPEN SYMMETRIC KEY SQLSymmetricKey  DECRYPTION BY CERTIFICATE SelfSignedCertificate;  
    #SELECT FirstName, LastName,LoginID,UserPassword,EncryptedPassword,  CONVERT(varchar, DecryptByKey(EncryptedPassword)) AS 'DecryptedPassword'  FROM UserDetails; 

    ### Decrypt AdminPassword 
    $Query = "SELECT *, CONVERT(varchar, DecryptByKey(AdminPassword)) AS 'AdminPassword' FROM definitionVMOSCustomizationSpec WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'" 

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query

    Return $global:OSCustomizationSpecName
}

function Get-ECI.EMI.Automation.OSCustomizationSpec
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMWareOSCustomizationSpec"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = "OPEN SYMMETRIC KEY SQLSymmetricKey  DECRYPTION BY CERTIFICATE SelfSignedCertificate; SELECT *, CONVERT(varchar, DecryptByKey(EncryptedPassword)) AS 'DecryptedPassword' FROM definitionVMOSCustomizationSpec WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'"

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query

    Return $global:OSCustomizationSpecName
}

### Get VM Parameters - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.VMParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "VMParameters"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionVMParameters WHERE serverRole = '$ServerRole' AND BuildVersion = '$BuildVersion'�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Get OS Parameters - SQL
### --------------------------------------------------
function Get-ECI.EMI.Automation.OSParameters
{
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    $DataSetName = "OSParameters"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM definitionOSParameters WHERE ServerRole = '$ServerRole' AND BuildVersion = '$BuildVersion'�

    Get-ECI.EMI.Automation.SQLData -DataSetName $DataSetName -ConnectionString $ConnectionString -Query $Query
}

### Check Server Record - SQL                           <--- Set Configuration Mode!!!!!!!!!!
### --------------------------------------------------
function Check-ECI.EMI.Automation.ServerRecord
{
    Param(
        [Parameter(Mandatory = $True)][string]$GPID,
        [Parameter(Mandatory = $True)][string]$CWID,
        [Parameter(Mandatory = $True)][string]$HostName
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
    
    $ConnectionString = $DevOps_DBConnectionString
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Query = �SELECT * FROM Servers WHERE GPID = '$GPID' AND CWID = '$CWID' AND HostName = '$HostName'�
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $Datatable = New-Object System.Data.DataTable
    $Datatable.Load($Reader)

    ### Check if Server Record Exists
    ###--------------------------------
    if(($Datatable.Rows.Count) -eq 0)
    {
        $global:ServerExists = $False
        $global:ConfigurationMode = "Configure"
        Write-Host `n('-' * 75)`n "This is a New Server Request: Running in Configure Mode!" `n('-' * 75)`n -ForegroundColor Yellow
    }
    elseif(($Datatable.Rows.Count) -gt 0)
    {
        $global:ServerExists = $True
        $global:ConfigurationMode = "Report"
        $global:ServerID = $ServerID
        Write-Host `n('-' * 75)`n "A Matching Server Record already Exists: Running in Report Mode!" `n('-' * 75)`n -ForegroundColor Yellow
        
        Return $global:ServerID
    }

    Write-Host "ServerExists: " $ServerExists -ForegroundColor Gray
    Write-Host "Setting ConfigurationMode: " $ConfigurationMode -ForegroundColor Gray
    Return $global:ConfigurationMode 
}

### Write Server Status - SQL
### --------------------------------------------------
function Create-ECI.EMI.Automation.ServerStatus
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$ServerStatus
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "WRITING SERVER STATUS:  RequestID: $RequestID HostName: $HostName ServerStatus: $ServerStatus" -ForegroundColor Cyan
    
    $ConnectionString = $Portal_DBConnectionString
    $Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,ServerStatus,ElapsedTime,VerifyErrorCount,Abort) VALUES('$RequestID','$ServerID','$HostName','$ServerStatus','$ElapsedTime','$VerifyErrorCount','$Abort')"
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
    
    Write-Host `n('-' * 50)`n "END Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray
}

### Update Server Status - SQL
### --------------------------------------------------
function Update-ECI.EMI.Automation.ServerStatus
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][int]$ServerID,
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$VerifyErrorCount,
    [Parameter(Mandatory = $True)][string]$Abort,
    [Parameter(Mandatory = $False)][string]$ElapsedTime,
    [Parameter(Mandatory = $True)][string]$ServerStatus
    )
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "UPDATE SERVER STATUS - ServerStatus: $ServerStatus RequestID: $RequestID ServerID: $ServerID HostName: $HostName Verify : Verify Abort: $Abort ElsapsedTime: $ElapsedTime" -ForegroundColor Cyan

    $ConnectionString = $Portal_DBConnectionString
    $Query = "INSERT INTO ServerStatus(RequestID,ServerID,HostName,VerifyErrorCount,Abort,ElapsedTime,ServerStatus) VALUES('$RequestID','$ServerID','$HostName','$VerifyErrorCount','$Abort','$ElapsedTime','$ServerStatus')" #-f $RequestID,$ServerID,$HostName,$Verify,$Abort,$ElapsedTime,$ServerStatus
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

### Create Server Record - SQL
### --------------------------------------------------
function Create-ECI.EMI.Automation.ServerRecord
{
    Param(
    [Parameter(Mandatory = $True)][int]$RequestID,
    [Parameter(Mandatory = $True)][string]$GPID,
    [Parameter(Mandatory = $True)][string]$CWID,        
    [Parameter(Mandatory = $True)][string]$HostName,
    [Parameter(Mandatory = $True)][string]$ServerRole,
    [Parameter(Mandatory = $True)][string]$BuildVersion
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ###-------------------------------
    ### Create Server Record
    ###-------------------------------
    Write-Host "CREATING SERVER RECORD:  RequestID: $RequestID GPID: $GPID CWID: $CWID HostName: $HostName ServerRole: $ServerRole BuildVersion: $BuildVersion" -ForegroundColor Cyan

    $ConnectionString = $DevOps_DBConnectionString
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $Query = "INSERT INTO Servers(RequestID,GPID,CWID,HostName,ServerRole,InstanceLocation,IPv4Address,SubnetMask,DefaultGateway,PrimaryDNS,SecondaryDNS,ClientDomain,DomainUserName,BackupRecovery,DisasterRecovery,RequestDateTime,BuildVersion) VALUES('$RequestID','$GPID','$CWID','$HostName','$RequestServerRole','$InstanceLocation','$IPv4Address','$SubnetMask','$DefaultGateway','$PrimaryDNS','$SecondaryDNS','$ClientDomain','$DomainUserName','$BackupRecovery','$DisasterRecovery','$RequestDateTime','$BuildVersion')"
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

### --------------------------------------------------
function Update-ECI.EMI.Automation.ServerRecord
{
    Param(
    [Parameter(Mandatory = $True)][string]$ServerID,
    [Parameter(Mandatory = $True)][string]$VMName,
    [Parameter(Mandatory = $True)][string]$ServerUUID,
    [Parameter(Mandatory = $True)][string]$vCenterUUID,
    [Parameter(Mandatory = $True)][string]$vMoRef
    )

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "UPDATING SERVER RECORD - ServerID: $ServerID  VMName: $VMName ServerUUID: $ServerUUID vCenterUUID: $vCenterUUID vMoRef: $vMoRef   "   -ForegroundColor Gray
    $ConnectionString = $DevOps_DBConnectionString
    $Query = "UPDATE Servers SET VMName = '$VMName',ServerUUID = '$ServerUUID',vCenterUUID = '$vCenterUUID',vMoRef = '$vMoRef'  WHERE ServerID = $ServerID"
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}


### Get Server ID - SQL                                 #<-------  (DATATABLE ROWS/COLUMNS!!!!!!)
### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerID
{
    Param([Parameter(Mandatory = $True)][int]$RequestID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    Write-Host "Getting Server ID for RequestID: " $RequestID
     
    ### Parameters
    ###---------------------------
    $DataSetName = "ServerID"
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT ServerID FROM Servers WHERE RequestID = '$RequestID'�
    
    ### Execute Query
    ###---------------------------
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)
    $Connection.Close()

    ### Return Values
    ###----------------------------
    foreach ($Datarow in $DataTable.Rows)
    {
       #Write-Host "Value: " $DataTable.Columns 
       #Write-Host "Value: " $DataRow[0] 
       Set-Variable -Name $DataTable.Columns -Value $DataRow[0] -Scope Global
    }
    
    $global:ServerID = $ServerID
    Write-Host "Returned - ServerID: " $ServerID -ForegroundColor Yellow
    
    Return $global:ServerID
}

### --------------------------------------------------  2!!!!
function Create-ECI.EMI.Automation.CurrentStateRecord
{
    Param([Parameter(Mandatory = $True)][int]$ServerID)

    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ###-------------------------------
    ### Create Current State Record
    ###-------------------------------
    Write-Host "CREATING CURRENT STATE RECORD:  ServerID: $ServerID HostName: $HostName" -ForegroundColor Cyan

    # Open Database Connection
    $ConnectionString = $DevOps_DBConnectionString
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open()   
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $connection
    $Query = "INSERT INTO ServerCurrentState(ServerID,HostName) VALUES('$ServerID','$HostName')"
    $cmd.CommandText = $Query
    $cmd.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerRecord-SQL
{
    Write-Host "`nGetting Server Record - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow

    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM Servers WHERE ServerID = '$ServerID'�
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $ConnectionString
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table | FL
    $connection.Close()
}

### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerCurrentState-SQL
{
    Write-Host "`nGetting Server Current State - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow

    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM ServerCurrentState WHERE ServerID = '$ServerID'�
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $ConnectionString
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table | FL
    $connection.Close()
}

### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerDesiredState-SQL
{
    Write-Host "`nGetting Server Desired State - ServerID: $ServerID " `n('-' * 50) -ForegroundColor Yellow

    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM ServerDesiredState WHERE ServerID = '$ServerID'�
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $ConnectionString
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table  | FT -AutoSize -Property ServerID,HostName,PropertyName,CurrentState,DesiredState,Verify,Abort
    $connection.Close()
}

### --------------------------------------------------
function Get-ECI.EMI.Automation.ServerConfigLog-SQL
{
    Write-Host "`nGetting Server Config Log - ServerID: $ServerID " `n('-' * 50)`n -ForegroundColor Yellow
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM ServerConfigLog WHERE ServerID = '$ServerID'�
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $ConnectionString
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $result = $command.ExecuteReader()
    $table = new-object �System.Data.DataTable�
    $table.Load($result)
    $table | FT -AutoSize -Property ServerID,HostName,FunctionName,PropertyName,Verify,Abort
    $connection.Close()
}

### --------------------------------------------------
function Get-DecommissionData
{
    Param([Parameter(Mandatory = $True)][int]$ServerID)
    
    $script:FunctionName = $((Get-PSCallStack)[0].Command);Write-Host `n('-' * 50)`n "Executing Function: " $FunctionName `n('-' * 50) -ForegroundColor Gray

    ### Parameters
    ###---------------------------
    #$ConnectionString = �Server=automate1.database.windows.net;Initial Catalog=DevOps;User ID=devops;Password=JKFLKA8899*(*(32faiuynv;�
    $ConnectionString = $DevOps_DBConnectionString
    $Query = �SELECT * FROM Servers WHERE ServerID = '$ServerID'�
    
    ### Execute Query
    ###---------------------------
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $ConnectionString 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $Query
    $Reader = $Command.ExecuteReader()
    $DataTable = New-Object System.Data.DataTable
    $DataTable.Load($Reader)
    
    ### Return Values
    ###----------------------------
    
    $DecomData = @()
    foreach ($Datarow in $DataTable.Rows)
    {
       #Write-Host "Name: " $DataTable.Columns 
       #Write-Host "Value: " $DataRow[0] 
       Set-Variable -Name $DataTable.Columns -Value $DataRow[0] -Scope Global
       $DecomData += ($DataTable.Columns,$DataRow[0])
    }
    Write-Host "DecomData: " $DecomData
}

### --------------------------------------------------
function GetDBSize
{
    use "devops"
    exec sp_spaceused
}


function Start-ECI.EMI.Automation.Sleep
{
    Param( [Parameter(Mandatory = $False,Position=0)][string]$t)

    If(!$t){$t = 60}
    
    Write-Host "START SLEEP: $t seconds"  -ForegroundColor Gray
    Start-Sleep -Seconds $t

}



function ModuleRegistryPath
{
$originalpaths = (Get-ItemProperty -Path �Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment� -Name PSModulePath).PSModulePath

# Add your new path to below after the ;

$newPath=$originalpaths+�;C:\Users\Tom\SkyDrive\PowerShell\�

Set-ItemProperty -Path �Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment� -Name PSModulePath �Value $newPath


}

function Write-ECI.ErrorStack
{
    Write-Host "PSCallStack       :" $((Get-PSCallStack)[0].Command) -ForegroundColor Red
    Write-Host "Exception.Message :" $_.Exception.Message -ForegroundColor Red
    Write-Host "ScriptStackTrace  :" $_.ScriptStackTrace -ForegroundColor Red
}
