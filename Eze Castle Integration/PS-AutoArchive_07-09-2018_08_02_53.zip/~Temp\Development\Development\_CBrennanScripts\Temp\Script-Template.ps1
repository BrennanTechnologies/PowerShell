﻿function Import-Modules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")     {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM")   {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")       {$ModulePath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "W2K16V2")        {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "C:\Scripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}

    $Modules = @()
    $Modules += "CommonFunctions"
    $Modules += "ConfigServer"

    foreach ($Module in $Modules)
    {
        write-host $Module

        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module -ErrorAction SilentlyContinue | out-null}

        ### Import the Module
        $ModuleFilePath = $ModulePath + $Module + "\" + $Module + ".psm1"
        Import-Module -Name $ModuleFilePath -DisableNameChecking #-Verbose
        Get-ModuleMetaData $Module
    }
}

function Do-Something
{

    Write-Host "Do Something"

}

function Execute-Script 
{
   
    BEGIN 
    {
        # Initialize Script
        #--------------------------
        Clear-Host
        Write-Host "`nRunning: BEGIN Block1" -ForegroundColor Blue
        Import-Modules 
        #Start-Transcribing 
    }

    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue
        # Run Functions
        #--------------------------
        #Do-Something
        #Update-ManifestVersion
        #Get-ModuleVersion
    }

    END 
    {
        # Close Script
        #--------------------------
        Write-Log "`nRunning: END Block"  -ForegroundColor Blue
        #Close-LogFile -Quiet
        Measure-Script
        #Stop-Transcribing
    }
}
Execute-Script