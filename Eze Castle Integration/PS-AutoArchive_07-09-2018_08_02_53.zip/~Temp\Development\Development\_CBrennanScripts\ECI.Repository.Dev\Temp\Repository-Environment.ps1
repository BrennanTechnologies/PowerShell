﻿cls

### Set Repository Environments
function Set-Environment($Env)
{

    ### Set Repository Name Space
    if ($Env -eq "Root") {$Environment = "Root"}
    if ($Env -eq "Dev")  {$Environment = "Development"}
    if ($Env -eq "Prod") {$Environment = "Production"}

    if ($Environment -eq "Root")        {$Environment = "Root"}
    if ($Environment -eq "Development") {$Environment = "Development"}
    if ($Environment -eq "Production")  {$Environment = "Production"}


    ### Set Repository Variable
    $Environment        = $Environment
    $NameSpace          = "Eci.Repository.$Environment"
    $RootDrive          = "X"
    $RootPath           = "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment
    $ModulePath         = $RootPath + "\Eci.Modules." + $Env + "\"
    
    ### Create Repository Object
    $EciRepo = @{ 

        Environment     = $Environment
        NameSpace       = $NameSpace
        RootDrive       = $RootDrive
        RootPath        = $RootPath
        ModulePath      = $ModulePath

    }                           
                                    
    $EciRepo = New-Object PSObject -Property $EciRepo  

    Write-Host ('-' * 100)  -ForegroundColor Cyan
    Write-Host "Environment : " $EciRepo.Environment -ForegroundColor Cyan
    Write-Host "NameSpace   : " $EciRepo.NameSpace -ForegroundColor Cyan
    Write-Host "RootDrive   : " $EciRepo.RootDrive -ForegroundColor Cyan
    Write-Host "RootPath    : " $EciRepo.RootPath -ForegroundColor Cyan
    Write-Host "ModulePath  : " $EciRepo.ModulePath -ForegroundColor Cyan
    Write-Host ('-' * 100)  -ForegroundColor Cyan
    
    ### Clear Previos PSModulePath  
    $CleanPath = ($env:PSModulePath.Split(";") | Where-Object { $_ -notlike "*Eci.Modules*"}) -join ';'
    $env:PSModulePath = $CleanPath + ";" + $EciRepo.ModulePath
    #Write-Host "env:PSModulePath :"$env:PSModulePath.Split(";")


    ### Map Drive to the Cloud Repository
    $AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey

    Get-PSDrive -PSProvider FileSystem | Where-Object {$_.DisplayRoot -like "*eciscripts*"} | Remove-PSDrive -Force -ErrorAction SilentlyContinue

    #$NewPSDrive = New-PSDrive -Name $RootDrive -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope global

    #Write-Host "Repositry Drive Mapped: $RootDrive : $RootPath" -ForegroundColor Cyan        

}

Set-Environment Dev
