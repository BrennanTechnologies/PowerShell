﻿cls

Function Test-Restart 
{

    #Restart-Computer -Wait -PSComputerName $CurrentComputerName

}

function Rename-Computer
{
    $CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    $NewComputerName = "BLU-SRV01"
    Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru
}

function OnResume
{
    $CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name 
    $CurrentComputerName | Out-File -FilePath -Path "$ReportPath \NewName.txt" 

}

#Rename-Computer

#Import-Module –Name PSWorkflow
#$Job = Test-Restart -asjob
#Wait-Job 
#$Job
#$script = 
$Script = $MyInvocation.MyCommand.Path


$actionscript = '-NonInteractive -WindowStyle Normal -NoLogo -NoProfile -NoExit -Command "&''$Script''"'
$pstart =  "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
Get-ScheduledTask -TaskName Test | Unregister-ScheduledTask -Confirm:$false
$act = New-ScheduledTaskAction -Execute $pstart -Argument $actionscript
$trig = New-ScheduledTaskTrigger -AtStartup -Once
Register-ScheduledTask -TaskName Test -Action $act -Trigger $trig -RunLevel Highest


#Test-Restart 
#OnResume
