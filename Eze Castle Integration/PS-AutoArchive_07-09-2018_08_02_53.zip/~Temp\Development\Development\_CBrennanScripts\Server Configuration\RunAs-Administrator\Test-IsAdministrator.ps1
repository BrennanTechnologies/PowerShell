﻿cls

function Test-IsAdministrator
{
    # Get the ID and security principal of the current user account
    $CurrentWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $CurrentWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($CurrentWindowsID)

    # Get the security principal for the Administrator role
    $AdminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
 
    # Check to see if we are currently running "as Administrator"
    if ($CurrentWindowsPrincipal.IsInRole($AdminRole))
    {
        ### We are running "as Administrator"
        Write-Host "Currently Running with Elevated Privledges" 
        return $True
    }
    if (-NOT($CurrentWindowsPrincipal.IsInRole($AdminRole)))
    {
        ### We are NOT running "as Administrator"
        Write-Host " NOT! Running with Elevated Privledges" 
        return $False
    }
}

Test-IsAdministrator