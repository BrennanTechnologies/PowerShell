﻿cls


# Get the ID and security principal of the current user account
$CurrentWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$CurrentWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID)

# Get the security principal for the Administrator role
$AdminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
 
# Check to see if we are currently running "as Administrator"
if ($CurrentWindowsPrincipal.IsInRole($AdminRole))
   {
 
   # We are running "as Administrator" - so change the title and background color to indicate this
   
   Write-Host "PowerShell Currently Running with Elevated Privledges"   
   #$Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   #$Host.UI.RawUI.BackgroundColor = "DarkBlue"
   #clear-host
   
   }
else
   {
   # We are not running "as Administrator" - so relaunch as administrator
    Write-Host "Elevating Privledges!"     
   # Create a new process object that starts PowerShell
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
   
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
   
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
   
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);
   
   # Exit from the current, unelevated, process
   #exit
   }
 
# Run your code that needs to be elevated here
Write-Host "Privledges Have Been Elevated!" -ForegroundColor Green
#Write-Host -NoNewLine "Press any key to continue..."
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")