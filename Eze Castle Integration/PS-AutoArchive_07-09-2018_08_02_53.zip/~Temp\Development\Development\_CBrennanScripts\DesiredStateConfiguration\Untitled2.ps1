﻿configuration IPv4
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node localhost
    {

        Service WebFiles
        {
            Name        = "IPV4"
            Source = "x:\files\*" 
            Destination = c:\iis\
        }
    }
}