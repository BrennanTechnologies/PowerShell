﻿cls

<#
Find-Module -Name VMware.PowerCLI

Install-Module -Name VMware.PowerCLI –Scope CurrentUser -AllowClobber


Get-Module -ListAvailable
Get-Module -ListAvailable VMware*

Import-Module VMware.PowerCLI

Get-PowerCLIVersion 


Set-PowerCLIConfiguration -InvalidCertificateAction Prompt Accept Permanently 

Connect-VIServer -Server ecilab-bosvcsa01.ecilab.corp

	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
    Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
#>

<#
$Servers = Get-VMHost -Server ecilab-bosvcsa01.ecilab.corp

foreach ($Server in $Servers)
{
    $Server.Name
    Get-VM -Server $Server.Name
}


#Get-VM -Server 
#>


#Get-VMGuest -VM RGEE-SRV1




#
#Connect-VIServer -Server ecilab-bosvcsa01.ecilab.corp

#$VM = "RGEE-SRV1"
#$Script = "c:\scripts\Test-PowerCLI.ps1"


#Get-VM "RGEE-SRV1"

#Invoke-VMScript -VM $VM -ScriptText "dir" -ScriptType Powershell -GuestCredential $PSCredentials #-GuestUser administrator -GuestPassword Tolkien4374

<#
$VM = "RGEE-SRV1"
$VM = 
Get-VM -Name $VM
Get-VMHost -Name $VM
#>


#

#
#Connect-VIServer -Server ecilab-bosvcsa01.ecilab.corp

$VM = "RGEE-SRV1"
Get-VM -Name $VM
#Get-VMHost -Name $VM

$Script = {IPConfig}

Invoke-VMScript -VM "RGEE-SRV1" -ScriptText $Script -GuestUser "eciadmin@ecilab.net" -GuestPassword "g3n3r0s!ty" -Verbose
