﻿cls

############################
### $GetScriptBlock = {}
############################

### Make SQL Server Connection
###--------------------------------------------
$SQLServer                 = "ConnectDB"
$SQLDB                     = "eci_sb"
$SQLTable                  = "client_office365"
$HybridTable               = "hybrid_users"
$SQLUserName               = "Cloud_integration"
$SQLPassword               = "Ez3C10uD"
$SQLQuery                  = "select * from client_office365"
$SQLConnectionString       = "Data Source=$SQLServer;User ID = $SQLUserName; Password = $SQLPassword;Initial Catalog=$SQLDB;" 

$SQLConnection             = New-Object System.Data.SqlClient.SQLConnection($SQLConnectionString)
$SQLCmd                    = New-Object System.Data.SqlClient.SQLCommand
$SQLCmd.CommandTimeout     = 0
$SQLCmd.Connection         = $SQLConnection
$SQLCmd.CommandText        = $SQLQuery
$SQLConnection.Open();
$SQLReader                 = $SQLCmd.ExecuteReader()
$SQLTable                  = New-Object “System.Data.DataTable”
$SQLTable.Load($SQLReader)
$SQLReader.Close();
$SQLReader.Dispose();
$SQLConnection.Close();


### Get Domains from SQL Table
###--------------------------------------------
$Domains = $SQLTable.InternalDomain | Sort-Object
$Domains.Count

foreach ($Domain in $Domains)
{
    try
    {
        ### Check Domain Exists
        $Domain = Get-ADDomain -Server $Domain -ErrorAction SilentlyContinue
        Write-Host "Connected to Domain: " $Domain -foregroundcolor Green
    }
    catch
    {
        ### Domain Does Not Exists
        Write-Host "ERROR: Connecting to Domain: " $Domain -foregroundcolor Red
        #Write-Host $($Error[0].Exception.Message) -foregroundcolor Red
    } 
    <#
    write-host $Domain $?   
    if ($?)
    {
        ### If Domain Exist
        Write-Host "Connecting to Domain: " $Domain -foregroundcolor Magenta
        $Users = Get-ADUser -Server $Domain.Name -properties ProxyAddresses -Filter "ProxyAddresses -like '*'" 
        #$Users

        foreach ($User in $Users)
        {
            ### Find Users without UPN in ProxyAddresses
            if(!($User.ProxyAddresses -replace "smtp:","").Contains($User.UserPrincipalName))
            {
                Write-Host "No UPN in Proxy: " $User.DistinguishedName -ForegroundColor Yellow
                # ... add UPN to ProxyAddresses ...
            }
        }
    }
    #>

}


