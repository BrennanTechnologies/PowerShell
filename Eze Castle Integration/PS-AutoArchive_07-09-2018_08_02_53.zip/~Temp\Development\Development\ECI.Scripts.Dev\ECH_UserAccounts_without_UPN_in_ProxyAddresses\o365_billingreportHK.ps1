﻿<#
Description - This is the billing script for all HK EHC clients
SD - 5/15/18 - Initial upload
#>

$dateTimeFile = get-date -format "MM-dd-yyyy-hhmm"
$dateTimeSql = Get-Date -Format "yyyy-MM-dd HH:mm"
start-transcript -path "C:\monitorscripts\o365_billingreport\transscripts\o365_billingreportHK$dateTimeFile.txt"
$problems = @()

#Constants
$from = "o365_billingReportHK@ecicloud.com"
$to = "ems.alerts@eci.com"
$cc = "tmacdonald@eci.com"
$smtp = "qts-outlook.ecicloud.com"

#header for email
$b = "<style>"
$b += "BODY{font-family: Verdana, Arial, Helvetica, sans-serif;font-size:10;font-color: #000000;text-align:center;}"
$b += "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$b += "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color: #D2B48C}"
$b += "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color: #FFEFD5}"
$b += "</style>" 

$message = @{

            From = $from
            To = $to 
            CC = $cc           
            SMTPServer = $smtp
                        
            }#email params

import-module activedirectory
import-module lynconlineconnector

#Moves all *.csv from output to output/old
C:
cd /monitorscripts/o365_billingreport/outputHK/
move *.csv C:\monitorscripts\o365_billingreport\outputHK\old
cd /monitorscripts/o365_billingreport/outputHK/old

#Deletes files from old directory older then 60 days 

$Now = Get-Date 
$Days = “60” 
$TargetFolder = “C:\monitorscripts\o365_billingreport\outputHK\old” 
$LastWrite = $Now.AddDays(-$Days) 
$Files = get-childitem *.csv -path $TargetFolder | Where {$_.LastWriteTime -le “$LastWrite”}  

if ($Files)
{
	foreach ($File in $Files) 
	{
	  Remove-Item $File | out-null
	}
} 

$passwd = ConvertTo-SecureString 'J$4e4tyOuP08' -AsPlainText -Force
$partnercreds = New-Object System.Management.Automation.PSCredential ("svc_hybridreporting@eciadminhk.onmicrosoft.com", $passwd)

connect-msolservice -credential $partnercreds
$tenantids=get-msolpartnercontract
$users=@()
#$date=get-date
$sqlserver="connectdb"
$sqldb="eci_sb"
$sqltable="client_office365"
$hybridTable = "hybrid_users"
$sqlusername="Cloud_integration"
$sqlpassword="Ez3C10uD"
$cwidquery="select * from client_office365"
$connectionstring = "Data Source=$sqlserver;User ID = $sqlusername; Password = $sqlpassword;Initial Catalog=$sqldb;" 
$connection1 = new-object system.data.SqlClient.SQLConnection($connectionstring)
$sqlCmd1 = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd1.CommandTimeout = 0
$sqlCmd1.Connection = $connection1
$sqlCmd1.CommandText = $cwidquery
$connection1.Open();
$reader1 = $sqlCmd1.ExecuteReader()
$table = new-object “System.Data.DataTable”
$table.Load($reader1)
$reader1.Close();
$reader1.Dispose();
$connection1.Close();

if($table -eq $null)
{
	write-host "Error connecting to connectdb"
    Send-MailMessage @message -Body "THERE WAS A PROBLEM CONNECTING TO CONNECTDB (client_office365 table), BILLING SCRIPT NOT RUN FOR EHC HK CLIENTS" -BodyAsHtml -Subject "o365 HK Client Billing Report ConnectDB Problems - $date"
	stop-transcript
	exit
}
foreach($tenantid in $tenantids)
{

	$tid=$tenantid.tenantid.guid
	$cwid=$table | where-object{$_.office365_guid -eq $tid}
	$cwid=$cwid.connectwise_id
        if(!$cwid -and $cwid -ne 0)
            {
                $domain=(Get-MsolDomain -TenantId $tid | ?{$_.IsInitial -eq $true}).name
                $tidProbHash = [ordered]@{
                                            'MSOL-Domain' = $domain
                                            'TenantID' = $tid
                                            'Problem' = "There is no corresponding CWID or the client DOESN'T EXIST in the client_office365 table for this Tenant"
                                         }
                $tidProbObj = New-Object -TypeName psobject -Property $tidProbHash
                $problems += $tidProbObj                
            }#if the tenantId doesn't match one in the cw table then record the error and continue through the array
        else
            {                
                $domain = $table | ?{$_.office365_guid -eq $tid}
                $domain = $domain.office365_domain
            }#else pull the domain from the table 

        if($domain.length -le 16 -or !$domain)
            {
                $domain=(Get-MsolDomain -TenantId $tid | ?{$_.IsInitial -eq $true}).name
                $SQLProbHash = [ordered]@{
                                            'MSOL-Domain' = $domain
                                            'TenantID' = $tid
                                            'Problem' = "The domain for this client isn't available in the client_office365 table or can not be queried from MSOL"
                                         }
                $SQLProbObj = New-Object -TypeName psobject -Property $SQLProbHash
                $problems += $SQLProbObj	            
            }#if the domain is missed in the SQL table then get it from MSOL using 16 as length since .onMicrosoft.com is 16 by itself 	
    Write-Host "creating an exchange session for $domain"
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri "https://ps.outlook.com/powershell-liveid?DelegatedOrg=$domain" -Credential $partnercreds -Authentication Basic -AllowRedirection -ErrorAction SilentlyContinue 
        if(!$Session)
            {
                try
                    {
                        $cssession=new-csonlinesession -overrideadmindomain $domain -Credential $partnercreds -ErrorAction SilentlyContinue
                        if($cssession)
                            {
                                import-pssession $cssession
                            }#only import if there's something in the session variable	                    
                    }#try to connect to the lync session to see if this client uses lync online
                catch
                    {
                        if(!$cssession)
                            {
                                $skypestatus = 0
                                                                
                                $csSessProbHash = [ordered]@{
                                                                'MSOL-Domain' = $domain
                                                                'TenantID' = $tid
                                                                'Problem' = "There was an issue creating a CSOnlineSession to check Skype for this client"
                                                            }
                                $csSessProbObj = New-Object -TypeName psobject -Property $csSessProbHash
                                $problems += $csSessProbObj 
                            }#if no session exists just set the variable to 0
                    }#set the $skypestatus variable to 0 if the session can't connect

                $msoluser=get-msoluser -tenantid $tid
                    foreach($line in $msoluser)                        
                        {
                            $psmtp = ($line.ProxyAddresses | ?{$_ -clike "SMTP*"}).replace("SMTP:","")
                            if($cssession -and $cssession.state -ne "Closed")
                                {
                                    $csuser = get-csonlineuser $psmtp
                                        if($csuser.enabled -eq $true) 
		                                    {
			                                    $skypestatus = 1
		                                    }
		                                elseif($csuser.enabled -eq $false)
		                                    {
			                                    $skypestatus = 0
		                                    }

                                }#get the lync status

                            $clientObjectGUID = [guid]([system.convert]::FromBase64String($line.ImmutableId))

                            $user = New-Object –TypeName PSObject
                            $user | Add-Member –MemberType NoteProperty –Name CWID –Value $cwid
		                    $user | Add-Member –MemberType NoteProperty –Name Username –Value $line.userprincipalname
		                    $user | Add-Member –MemberType NoteProperty –Name primarysmtp –Value $psmtp
		                    $user | Add-Member –MemberType NoteProperty –Name mbdatabasename –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name activesyncdevices –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name date –Value $dateTimeSql
		                    $user | Add-Member –MemberType NoteProperty –Name mbsize –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name archmbsize –Value 0		                    
		                    $user | Add-Member –MemberType NoteProperty –Name archmbcount –Value 0
		                    #$user | Add-Member –MemberType NoteProperty –Name finance_run –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name supportlevel –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name retentionpolicy –Value 0
		                    #$user | Add-Member –MemberType NoteProperty –Name dualfactorenabled –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name firstname –Value $line.displayname.split(" ")[0]
		                    $user | Add-Member –MemberType NoteProperty –Name lastname –Value $line.displayname.split(" ")[1]
		                    $user | Add-Member –MemberType NoteProperty –Name msexchmasteraccountsid –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name xenmobiledevices –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name owa –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name SkypeEnabled –Value $skypestatus 
		                    $user | Add-Member –MemberType NoteProperty –Name LicensesAssigned –Value $line.licenses
                            $user | Add-Member –MemberType NoteProperty –Name clientObjectGUID -Value $clientObjectGUID
                            $user | Add-Member -MemberType NoteProperty -Name hiddenFromAddressListsEnabled -Value 0
                            $user | Add-Member -MemberType NoteProperty -Name activesyncEnabled -Value 0
		                    $users+=$user
                            clear-variable skypestatus,clientObjectGUID -ErrorAction SilentlyContinue
                        }#loop through the variable to get the information
                
                Get-PSSession | Remove-PSSession -ErrorAction SilentlyContinue                    

                $exchSessProbHash = [ordered]@{
                                                'MSOL-Domain' = $domain
                                                'TenantID' = $tid
                                                'Problem' = "There was an issue creating a Exchange Powershell Session to check MBox information for this client"
                                              }
                $exchSessProbObj = New-Object -TypeName psobject -Property $exchSessProbHash
                $problems += $exchSessProbObj
                continue
            }#if the session is null then just add the MSOL license information to the array
    
    if($session)
        {
            import-pssession $session -DisableNameChecking
        }#if there's an actual session, import it
    Write-Host "creating a lync session for $domain"

    try
        {
            $cssession=new-csonlinesession -overrideadmindomain $domain -Credential $partnercreds -ErrorAction SilentlyContinue
            if($cssession -and $cssession.state -ne "Closed")
                {
                    import-pssession $cssession
                }#only import if there's something in the session variable	                    
        }#try to connect to the lync session to see if this client uses lync online
    catch
        {
            if(!$cssession)
                {
                    $skypestatus = 0
                    
                    $csSessProbHash = [ordered]@{
                                                    'MSOL-Domain' = $domain
                                                    'TenantID' = $tid
                                                    'Problem' = "There was an issue creating a CSOnlineSession to check Skype for this client"
                                                }
                    $csSessProbObj = New-Object -TypeName psobject -Property $csSessProbHash
                    $problems += $csSessProbObj 
                }#if no session exists just set the variable to 0
        }#set the $skypestatus variable to 0 if the session can't connect
	 
	$mbs=get-mailbox | where-object {$_.userprincipalname -notlike "DiscoverySearchMailbox*"}
        if(!$mbs)
            {
                $msoluser=get-msoluser -tenantid $tid
                    foreach($line in $msoluser)                        
                        {
                            $psmtp = ($line.ProxyAddresses | ?{$_ -clike "SMTP*"}).replace("SMTP:","")
                            if($cssession -and $cssession.state -ne "Closed")
                                {
                                    $csuser = get-csonlineuser $psmtp
                                        if($csuser.enabled -eq $true) 
		                                    {
			                                    $skypestatus = 1
		                                    }
		                                elseif($csuser.enabled -eq $false)
		                                    {
			                                    $skypestatus = 0
		                                    }

                                }#get the lync status

                            $clientObjectGUID = [guid]([system.convert]::FromBase64String($line.ImmutableId))

                            $user = New-Object –TypeName PSObject
                            $user | Add-Member –MemberType NoteProperty –Name CWID –Value $cwid
		                    $user | Add-Member –MemberType NoteProperty –Name Username –Value $line.userprincipalname
		                    $user | Add-Member –MemberType NoteProperty –Name primarysmtp –Value $psmtp
		                    $user | Add-Member –MemberType NoteProperty –Name mbdatabasename –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name activesyncdevices –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name date –Value $dateTimeSql
		                    $user | Add-Member –MemberType NoteProperty –Name mbsize –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name archmbsize –Value 0		                    
		                    $user | Add-Member –MemberType NoteProperty –Name archmbcount –Value 0
		                    #$user | Add-Member –MemberType NoteProperty –Name finance_run –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name supportlevel –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name retentionpolicy –Value 0
		                    #$user | Add-Member –MemberType NoteProperty –Name dualfactorenabled –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name firstname –Value $line.displayname.split(" ")[0]
		                    $user | Add-Member –MemberType NoteProperty –Name lastname –Value $line.displayname.split(" ")[1]
		                    $user | Add-Member –MemberType NoteProperty –Name msexchmasteraccountsid –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name xenmobiledevices –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name owa –Value 0
		                    $user | Add-Member –MemberType NoteProperty –Name SkypeEnabled –Value $skypestatus 
		                    $user | Add-Member –MemberType NoteProperty –Name LicensesAssigned –Value $line.licenses
                            $user | Add-Member –MemberType NoteProperty –Name clientObjectGUID –Value $clientObjectGUID
                            $user | Add-Member -MemberType NoteProperty -Name hiddenFromAddressListsEnabled -Value 0
                            $user | Add-Member -MemberType NoteProperty -Name activesyncEnabled -Value 0
		                    $users+=$user
                            clear-variable skypestatus,clientObjectGUID -ErrorAction SilentlyContinue
                        }#loop through the variable to get the information
                
                Get-PSSession | Remove-PSSession -ErrorAction SilentlyContinue                    

                $mbSessProbHash = [ordered]@{
                                                'MSOL-Domain' = $domain
                                                'TenantID' = $tid
                                                'Problem' = "There were no mailboxes found for this client"
                                            }
                $mbSessProbObj = New-Object -TypeName psobject -Property $mbSessProbHash
                $problems += $mbSessProbObj
                continue
            }#if there are no mailboxes then get-msoluser for the licensing information

	foreach($mb in $mbs)
	{
        Write-Host "getting information for $mb"	
		$msoluser=get-msoluser -tenantid $tid -userprincipalname $mb.userprincipalname
        $clientObjectGUID = [guid]([system.convert]::FromBase64String($msoluser.ImmutableId))
		$licenses=$msoluser.licenses
		$firstname=$mb.name.split(" ")[0]
		$lastname=$mb.name.split(" ")[1]
		$activesyncdevices=@((get-mobiledevice -mailbox $mb.primarysmtpaddress).friendlyname)
            if(!$activesyncdevices)
                {
                    $activesyncDeviceCount = 0
                }#if no as devices, set the count to 0
            else
                {
                    $activesyncDeviceCount = $activesyncdevices.Count
                }#else set the actual count
		$casmailbox=get-casmailbox $mb.primarysmtpaddress	
		$mailstat=get-mailboxstatistics -identity $mb.primarysmtpaddress
		if($casmailbox.owaenabled -eq $true)
		{
			$owa=1
		} 
		elseif($casmailbox.owaenabled -eq $false )
		{
			$owa=0
		}
        if($casmailbox.activesyncenabled -eq $true)
            {
                $activesyncEnabled = "1"
            }
        elseif($casmailbox.activesyncenabled -eq $false)
            {
                $activesyncEnabled = "0"
            }
		if($mb.ArchiveStatus -eq "Active")
		{
			$archivestats=Get-MailboxStatistics -Identity $mb.primarysmtpaddress -Archive
			$archmbsize=$archivestats.totalitemsize.value
			$archmbcount=1
            $tempArchSplit = $archmbsize.ToString().Split(" ")
                switch($tempArchSplit[1])
                    {
                        "KB" {$archMBSizeInMb = ([math]::Round(([math]::Round($tempArchSplit[0],2) / 1024),2))}
                        "GB" {$archMBSizeInMb = ([math]::Round(([math]::Round($tempArchSplit[0],2) * 1024),2))}
                        "MB" {$archMBSizeInMb = [math]::Round($tempArchSplit[0],2)}
                        
                    }#switch through kb, mb, gb
			clear-variable archivestats
		}
		else
		{
			$archmbsize=0
			$archmbcount=0
		}

        if($cssession -and $cssession.state -ne "Closed")
            {
                $csuser=get-csonlineuser $mb.primarysmtpaddress
		
		        if($csuser.enabled -eq $true) 
		            {
			            $skypestatus = 1
		            }
		        elseif($csuser.enabled -eq $false)
		            {
			            $skypestatus = 0
		            }
            }#only run these commands if there's a cssession
        
        if($mailstat.totalitemsize.value)
            {
                $tempMBSplit = $mailstat.totalitemsize.value.ToString().Split(" ")
                    switch($tempMBSplit[1])
                        {
                            "KB" {$mbSizeInMb = ([math]::Round(([math]::Round($tempMBSplit[0],2) / 1024),2))}
                            "GB" {$mbSizeInMb = ([math]::Round(([math]::Round($tempMBSplit[0],2) * 1024),2))}
                            "MB" {$mbSizeInMb = [math]::Round($tempMBSplit[0],2)}
                        
                        }#switch through kb, mb, gb
            }#split the value, find kb or gb (leave mb alone), and convert/do math


		$user = New-Object –TypeName PSObject
        $user | Add-Member –MemberType NoteProperty –Name CWID –Value $cwid
		$user | Add-Member –MemberType NoteProperty –Name Username –Value $mb.name
		$user | Add-Member –MemberType NoteProperty –Name primarysmtp –Value $mb.PrimarySmtpAddress
		$user | Add-Member –MemberType NoteProperty –Name mbdatabasename –Value $mb.database
		$user | Add-Member –MemberType NoteProperty –Name activesyncdevices –Value $activesyncDeviceCount
		$user | Add-Member –MemberType NoteProperty –Name date –Value $dateTimeSql
		$user | Add-Member –MemberType NoteProperty –Name mbsize_inMB –Value $mbSizeInMb
		$user | Add-Member –MemberType NoteProperty –Name archmbsize_inMB –Value $archMBSizeInMb
		$user | Add-Member –MemberType NoteProperty –Name UPN –Value $msoluser.userprincipalname
		$user | Add-Member –MemberType NoteProperty –Name archmbcount –Value $archmbcount
		#$user | Add-Member –MemberType NoteProperty –Name finance_run –Value 0
		$user | Add-Member –MemberType NoteProperty –Name supportlevel –Value $mb.extensionattribute3
		$user | Add-Member –MemberType NoteProperty –Name retentionpolicy –Value $mb.RetentionPolicy
		#$user | Add-Member –MemberType NoteProperty –Name dualfactorenabled –Value 0
		$user | Add-Member –MemberType NoteProperty –Name firstname –Value $firstname
		$user | Add-Member –MemberType NoteProperty –Name lastname –Value $lastname
		$user | Add-Member –MemberType NoteProperty –Name msexchmasteraccountsid –Value $mb.guid
		$user | Add-Member –MemberType NoteProperty –Name xenmobiledevices –Value 0
		$user | Add-Member –MemberType NoteProperty –Name owa –Value $owa
		$user | Add-Member –MemberType NoteProperty –Name SkypeEnabled –Value $skypestatus 
		$user | Add-Member –MemberType NoteProperty –Name LicensesAssigned –Value $licenses
        $user | Add-Member –MemberType NoteProperty –Name clientObjectGUID –Value $clientObjectGUID
        $user | Add-Member -MemberType NoteProperty -Name hiddenFromAddressListsEnabled -Value $mb.HiddenFromAddressListsEnabled
        $user | Add-Member -MemberType NoteProperty -Name activesyncEnabled -Value $activesyncEnabled
		$users+=$user
		clear-variable activesyncdevices,mailstat,archmbsize,archmbcount,firstname,lastname,owa,skypestatus,licenses,archMBSizeInMb,mbSizeInMb,activesyncEnabled,msoluser,clientObjectGUID -ErrorAction SilentlyContinue
	}
    Write-Host "removing session for $domain"
	clear-variable cwid,mbs,domain,tid,cwidquery    
	get-pssession | remove-pssession -ErrorAction SilentlyContinue

}
stop-transcript
Get-PSSession | Remove-PSSession

if($users -eq $null)
{
	write-host "Error connecting to connectdb"
    Send-MailMessage @message -Body "THERE WERE NO USERS IN THE `$users VARIABLE, BILLING SCRIPT NEEDS TO BE RE-RUN FOR HK EHC CLIENTS" -BodyAsHtml -Subject "o365 HK Client Billing Report users Variable Problems - $date"
	stop-transcript
	exit
}

#export the array to a file
$users | ft -Property * -AutoSize | Out-String -Width 4096 | Out-File "C:\monitorscripts\o365_billingreport\outputHK\o365BillingHK$dateTimeFile.csv"

foreach($line in $users)
    {
        $addCwid = $line.cwid
        $addUserName = $line.username
        $addPrimarySmtp = $line.primarysmtp
        $addMbDataBaseName = $line.mbdatabasename
        $addActiveSyncDevices = $line.activesyncdevices
        $addDate = $line.date
        [decimal]$addMbSizeInMB = $line.mbsize_inmb
        [decimal]$addArchSizeMB = $line.archmbsize_inmb
        $addUpn = $line.upn
        $addArchMbCount = $line.archmbcount
        #$addFinanceRun = $line.finance_run
        $addSupportLevel = $line.supportlevel
        $addRetentionPolicy = $line.retentionpolicy
        #$addDualFactorEnabled = $line.dualfactorenabled
        $addFirstName = $line.firstname
        $addLastName = $line.lastname
        $addMsExchMasterAccountSid = $line.msexchmasteraccountsid
        $addXenMobileDevices = $line.xenmobiledevices
        $addOwa = $line.owa
        $addSkypeEnabled = $line.skypeenabled
        $addLicensesAssigned = $line.licensesassigned.accountskuid
        $addClientObjectGUID = $line.clientObjectGUID
        $addHiddenFromAddressListsEnabled = $line.hiddenFromAddressListsEnabled
        $addActivesyncEnabled = $line.activesyncEnabled

        Write-Host "cwid - $addCwid"
        Write-Host "username - $addUserName"
        Write-Host "psmtp - $addPrimarySmtp"
        Write-Host "mbdb - $addMbDataBaseName"
        Write-Host "as dev - $addActiveSyncDevices"
        Write-Host "date - $addDate"
        Write-Host "mb size - $addMbSizeInMB"
        Write-Host "arch size - $addArchSizeMB"
        Write-Host "upn - $addUpn"
        Write-Host "arch mb count - $addArchMbCount"
        #Write-Host "finance run - $addFinanceRun"
        Write-Host "support level - $addSupportLevel"
        Write-Host "retention policy - $addRetentionPolicy"
        #Write-Host "2fa status - $addDualFactorEnabled"
        Write-Host "first name - $addFirstName"
        Write-Host "last name - $addLastName"
        Write-Host "msexch sid - $addMsExchMasterAccountSid"
        Write-Host "xm device - $addXenMobileDevices"
        Write-Host "owa - $addOwa"
        Write-Host "skype enabled - $addSkypeEnabled"
        Write-Host "licenses - $addLicensesAssigned"
        Write-Host "clientObjectGUID - $addClientObjectGUID"
        Write-Host "hiddenFromAddressListsEnabled - $addHiddenFromAddressListsEnabled"
        Write-Host "ActivesyncEnabled - $addActivesyncEnabled"        
        
        $query1 = "INSERT into $hybridTable (cw_company_recid, username, primarysmtp, mbdatabasename, activesyncdevices, date, mbsize, archmbsize, upn, archmbcount, supportlevel, retentionpolicy, firstname, lastname, msexchmasteraccountsid, xenmobiledevices, owa, skypeenabled, licensesassigned, clientObjectGUID, hiddenFromAddressListsEnabled, activesycenabled) VALUES ('$addCwid', '$addUserName', '$addPrimarySmtp', '$addMbDataBaseName', '$addActiveSyncDevices', '$addDate', '$addMbSizeInMB', '$addArchSizeMB', '$addUpn', '$addArchMbCount', '$addSupportLevel', '$addRetentionPolicy', '$addFirstName', '$addLastName', '$addMsExchMasterAccountSid', '$addXenMobileDevices', '$addOwa', '$addSkypeEnabled', '$addLicensesAssigned', '$addClientObjectGUID', '$addHiddenFromAddressListsEnabled', '$addActivesyncEnabled')"
        $connection2 = new-object system.data.SqlClient.SQLConnection($connectionstring)
        $sqlCmd2 = New-Object System.Data.SqlClient.SqlCommand
        $SqlCmd2.CommandTimeout = 0
        $sqlCmd2.Connection = $connection2
        $sqlCmd2.CommandText = $query1
        $connection2.Open();
        $sqlCmd2.ExecuteNonQuery();
        $connection2.Close();
        
        Clear-Variable addCwid,addUserName,addPrimarySmtp,addMbDataBaseName,addActiveSyncDevices,addDate,addMbSizeInMB,addArchSizeMB,addUpn,addArchMbCount,addSupportLevel,addRetentionPolicy,addFirstName,addLastName,addMsExchMasterAccountSid,addXenMobileDevices,addOwa,addSkypeEnabled,addLicensesAssigned,addClientObjectGUID,addHiddenFromAddressListsEnabled,addActivesyncEnabled
    }#set the variables and insert into the table

if($problems)
    {
        $body = $problems | ConvertTo-Html -Head $b
        Send-MailMessage @message -Body ($body | Out-String) -BodyAsHtml -Subject "o365 HK Client Billing Report Problems - $date"
    }#alert if there are problems
