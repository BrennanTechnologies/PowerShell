﻿function Import-RemoteSession
{
	$Compter = "209.231.73.77"
	New-PSSession -ComputerName
}

function Import-RemoteSession2
{
	### Check for Existing Session
	$ExchangeSession = Get-PSSession | where { $_.ConfigurationName -eq "Microsoft.Exchange" -and $_.State -eq 'Opened' }
	
	if (-not $ExchangeSession)
	{
		write-host "Creating New Session"
		### Create Session to Import Exchange Tools
		$ExchangeCAS = (HostName).split("-")[0] + "-htcas01.ecicloud.com"
		$ExchangeSession = New-PSSession -Name ExchangeSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://$ExchangeCAS/PowerShell/ -Authentication Kerberos
		
		Import-PSSession $ExchangeSession -AllowClobber #-ea "silentlycontinue"  
	}
	else
	{
		write-host "Using Current Session: " $ExchangeSession
	}
}



#Import-RemoteSession