﻿$RepositoryDrive = "X"
$RepositoryPath = "\\eciscripts.file.core.windows.net\clientimplementation"

### Map Drive to the Cloud Repository
$AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey

$NewPSDribve = New-PSDrive -Name $RepositoryDrive -PSProvider FileSystem -Root $RepositoryPath -Credential $Credentials -Persist -Scope global
Write-Host "Repositry Drive Drive Letter Mapped: $RepositoryDrive" -ForegroundColor Cyan        
        
### Add the Repository to the PS Module Path
if(-NOT($env:PSModulePath.Contains($RepositoryPath))) {$env:PSModulePath = $RepositoryPath + ";" + $env:PSModulePath}