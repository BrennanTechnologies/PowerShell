﻿function Run-Elevated ($scriptblock)
{
  # TODO: make -NoExit a parameter
  # TODO: just open PS (no -Command parameter) if $scriptblock -eq ''
  $Shell = new-object -com 'Shell.Application'
  #$Shell.ShellExecute('powershell', "-NoExit -Command $scriptblock", '', 'runas')
  $Shell.ShellExecute('powershell', "-Command $scriptblock", '', 'runas')
}

$scriptblock = {write-host "Elevated!"}
Run-Elevated $scriptblock