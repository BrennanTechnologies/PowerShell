﻿PowerShellGet

“PowerShellGet module contains cmdlets for discovering, installing, updating and publishing the PowerShell artifacts like Modules, DSC Resources, Role Capabilities and Scripts from the https://www.PowerShellGallery.com and other private repositories.” -JuanPablo Jofre: The PowerShell Gallery

Find-Command	
Finds PowerShell commands in modules.

Find-DscResource	
Finds a DSC resource.

Find-Module	
Finds modules from an online gallery that match specified criteria.

Find-RoleCapability	
Finds role capabilities in modules.

Find-Script	
Finds a script.

Get-InstalledModule	
Gets installed modules on a computer.

Get-InstalledScript	
Gets an installed script.

Get-PSRepository	
Gets PowerShell repositories.

Install-Module	
Downloads one or more modules from an online gallery, and installs them on the local computer.

Install-Script	
Installs a script.

New-ScriptFileInfo	
Creates a script file with metadata.

Publish-Module	
Publishes a specified module from the local computer to an online gallery.

Publish-Script	
Publishes a script from the local computer to an online gallery.

Register-PSRepository	
Registers a PowerShell repository.

Save-Module	
Saves a module locally without installing it.

Save-Script	
Saves a script.

Set-PSRepository	
Sets values for a registered repository.

Test-ScriptFileInfo	
Validates a comment block for a script.

Uninstall-Module	
Uninstalls a module.

Uninstall-Script	
Uninstalls a script file.

Unregister-PSRepository	
Unregisters a repository.

Update-Module	
Downloads and installs the newest version of specified modules from an online gallery to the local computer.

Update-ModuleManifest	
Updates a module manifest file.

Update-Script	
Updates a script.

Update-ScriptFileInfo	
Updates information for a script.