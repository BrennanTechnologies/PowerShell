﻿Import-Module PowerShellGet

$RepositoryPath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"

$Repository = @{
    Name = 'MyRepository'
    SourceLocation = $RepositoryPath
    PublishLocation = $RepositoryPath
    InstallationPolicy = 'Trusted'
}
Register-PSRepository @Repository


Publish-Module -Name MyModule -Repository MyRepository -Verbose

Find-Module -Repository MyRepository


Install-Module -Name MyModule -Repository MyRepository -Scope CurrentUser

Uninstall-Module -Name MyModule