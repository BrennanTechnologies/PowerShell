﻿cls

<#
Find-Module -Name VMware.PowerCLI

Install-Module -Name VMware.PowerCLI –Scope CurrentUser -AllowClobber


Get-Module -ListAvailable
Get-Module -ListAvailable VMware*

Import-Module VMware.PowerCLI

Get-PowerCLIVersion 


Set-PowerCLIConfiguration -InvalidCertificateAction Prompt Accept Permanently 

Connect-VIServer -Server ecilab-bosvcsa01.ecilab.corp

	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
    Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
#>

<#
$Servers = Get-VMHost -Server ecilab-bosvcsa01.ecilab.corp

foreach ($Server in $Servers)
{
    $Server.Name
    Get-VM -Server $Server.Name
}


#Get-VM -Server 
#>


#Get-VMGuest -VM RGEE-SRV1




function Set-PSCredentials
{
    #$UserName = "cbrennan@eciadmin.onmicrosoft.com"
    $UserName = "Administrator"

    $ScriptPath  = split-path $MyInvocation.PSCommandPath -Parent
    
    $PasswordFile = $ScriptPath + "\Password.txt"
    write-host "Password File: $PasswordFile" -ForegroundColor Cyan

    if(-not (Test-Path $PasswordFile))
    {
        Read-Host "Enter Password To Be Encrypted" -AsSecureString |  ConvertFrom-SecureString | Out-File $PasswordFile
        write-host "Created Encrypted Password File: " $PasswordFile -ForegroundColor Green
    }
    elseif(Test-Path $PasswordFile)
    {
        write-host "Using Existing Password File: " $PasswordFile -ForegroundColor Green
    }

    $PSCredentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, (Get-Content $PasswordFile | ConvertTo-SecureString)
}

#Set-PSCredentials


$VM = "RGEE-SRV1"
$Script = "c:\scripts\Test-PowerCLI.ps1"
$Script = '&"$env:ProgramFiles\Common Files\Microsoft Shared\MSInfo\msinfo32.exe" /report "$env:Tmp\inforeport"'

#Get-VMGuest -VM $VM
#Invoke-VMScript -VM $VM -ScriptText "dir" -ScriptType Powershell -GuestCredential $PSCredentials #-GuestUser administrator -GuestPassword Tolkien4374
Invoke-VMScript -VM $VM -ScriptText "Dir" -GuestUser "CBrennanTest" -GuestPassword "Tolkien4374"
#Restart-VMGuest