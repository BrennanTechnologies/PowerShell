﻿
function Configure-WindowsFirewallProfile
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameters
    ### --------------------------------------
    if($WindowesFireWallProfile -eq "Disable") {$WindowesFireWallProfileValue = "False"}
    elseif($WindowesFireWallProfile -eq "Enable") {$WindowesFireWallProfileValue = "True"}

    ###################################
    ### DESIRED STATE PARAMETERS
    ###################################
    $DesiredState      = $WindowesFireWallProfileValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ###################################
    ### GET CURRENT CONFIGURATION STATE: 
    ###################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = Get-NetFirewallProfile -Name Domain
    }

    ###################################
    ### SET DESIRED-STATE:
    ###################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-NetFirewallProfile -Profile $NetFirewallProfileName -Enabled $WindowesFireWallProfileValue
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}
