﻿cls

\\tsclient\Z\CBrennanScripts\Reboot-Resume\Reboot-Resume.ps1 -Step B