﻿cls
$ServerName = "BLU-MGMT01"

[int]$Counter = $ServerName.Substring($ServerName.get_Length()-2)
$Counter
$Counter++
$Counter

$Counter.ToString("00")


$Sub = $ServerName.Substring(0,$ServerName.Length-1)
$Sub



exit

$Server = (Get-ADComputer -Identity $ServerName).Name

if ($Server) 
{
    $Counter++

    Write-Host "This name exists!"
    $NewServerName = $ServerName + $Counter++

    Write-Host "New Name: $NewServerName" 
}

else
{
    $things_wrong++
    $things_wrong++
    $things_wrong++
    $things_wrong++
    $things_wrong++
}

Write-Host $things_wrong