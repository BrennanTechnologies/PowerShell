﻿cls

$OSVersion = (Get-CimInstance Win32_OperatingSystem).version
$MajorVer = $OSVersion.Split(".")[0]
$MinorVer = $OSVersion.Split(".")[1]

write-host "OS Version:" $OSVersion 

#WRITE-HOST 
Get-PSSession -ComputerName 'ComputerName' -ApplicationName 'ApplicationName' -ConfigurationName 'ConfigurationName' -Name 'Name' -Credential $Credential -Authentication Default -CertificateThumbprint 'CertificateThumbprint' -Port $Port -UseSSL -ThrottleLimit $ThrottleLimit -State All -SessionOption $SessionOption 



<#
switch ( $OSVersion )
{
    0 { $result = 'Sunday'    }
    1 { $result = 'Monday'    }
    2 { $result = 'Tuesday'   }
    3 { $result = 'Wednesday' }
    4 { $result = 'Thursday'  }
    5 { $result = 'Friday'    }
    6 { $result = 'Saturday'  }
}

#>
<#
Operating system	Version number
"Windows 10"             = 10.0
"Windows Server 2016"    = 10.0
"Windows 8.1"            = 6.3
"Windows Server 2012 R2" = 6.3
"Windows 8"               =   6.2
"Windows Server 2012"       = 6.2
"Windows 7"                 = 6.1
"Windows Server 2008 R2"    = 6.1
"Windows Server 2008"       = 6.0
"Windows Vista"             = 6.0
"Windows Server 2003 R2"    = 5.2
"Windows Server 2003"       = 5.2
"Windows XP 64-Bit Edition" = 5.2
"Windows XP"	5.1
"Windows 2000"	5.0

#>