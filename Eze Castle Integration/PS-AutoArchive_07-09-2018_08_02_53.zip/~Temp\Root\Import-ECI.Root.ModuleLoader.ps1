﻿& {
    ### Set Execution Policy to ByPass
    Write-Host "Setting Execution Policy: ByPass"
    Set-ExecutionPolicy Bypass

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
            
    ((Get-PSDrive | Where {((Get-PSDrive).DisplayRoot) -like "\\eci*"}) | Remove-PSDrive -Force ) | Out-Null
    $PSDrive         = New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
}

function ManuallyMapPersistentDrive
{
    ### Manually Map a Persistent Drive
    $RootDrive = New-PSDrive -Name X -PSProvider FileSystem -Root "\\eciscripts.file.core.windows.net\clientimplementation" -Credential $Credentials -Persist -Persist -Scope Global
}

function ModifyPSProfileToAutoLoadECIModules
{
    ### Modify User Profile to Auto Load ECI Modules
    if(-NOT(Test-Path ((Split-Path $Profile -Parent) + "\Import-ECI.Root.ModuleLoader.ps1"))){Copy-Item -Path "$RootPath\Import-ECI.Root.ModuleLoader.ps1" -Destination (Split-Path $Profile -Parent)}
    if(-NOT(Test-Path $Profile)){New-Item -path $Profile -type file –force | Out-Null}
    if(-NOT(Select-String -Path $Profile -pattern "Import-ECI.Root.ModuleLoader.ps1")){Add-Content -Path $Profile -Value '. ((Split-Path $PROFILE -Parent) + "\Import-ECI.Root.ModuleLoader.ps1")'}
}
#ModifyPSProfileToAutoLoadECIModules