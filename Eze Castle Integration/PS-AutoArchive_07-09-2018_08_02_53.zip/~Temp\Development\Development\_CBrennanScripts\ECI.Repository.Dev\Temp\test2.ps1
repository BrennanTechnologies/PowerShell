﻿cls
get-variable * | remove-variable -ErrorAction SilentlyContinue | Out-Null

$PreferedDrive = "Z"
$LBound        = "A"
$UBound        = "H"

$PSDrives = @(1,2,4,9)

FOR ([byte]$NextDrive = 1; $NextDrive -le 5; $NextDrive++)  
{ 
    [int]$PreferedDrive = $NextDrive
    $Free = $PSDrives.Contains($PreferedDrive)              
    write-host "PreferedDrive: " $PreferedDrive -ForegroundColor Yellow
    write-host "Free: "$Free -ForegroundColor Yellow

    <#
    DO
    {
        [int]$PreferedDrive = $NextDrive
        $Free = $PSDrives.Contains($PreferedDrive)             
                
        write-host "PreferedDrive: " $PreferedDrive -ForegroundColor Cyan
        write-host "Free: "$Free -ForegroundColor Cyan

    }
    UNTIL ($Free -eq $False)
    #>                

}


 
<#
        FOR ([byte]$NextDrive = [char]$LBound; $NextDrive -le [char]$UBound; $NextDrive++)  
        { 


            DO
            {
               $PreferedDrive = [char]$NextDrive
               $Free = $PSDrives.Contains($PreferedDrive)              
                
                write-host "PreferedDrive: " $PreferedDrive -ForegroundColor Cyan
                write-host "Free: "$Free -ForegroundColor Cyan

            }
            UNTIL ($Free -eq $False)
        }
#>

Write-Host "PreferedDrive: " $PreferedDrive -ForegroundColor Magenta
