﻿cls

Workflow Reboot-RemoteComputer
{
    #Invoke-Command -ScriptBlock {Restart-Computer -Wait} -ComputerName $CurrentComputerName
    
}


function Do-Something
{
    ### Verify the New Computer Name
    $NewComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    write-Host "New Computer Name: $NewComputerName " 
    $NewComputerName | Out-File -FilePath -Path "$ReportPath \NewName.txt"
}



function Rename-LocalComputer
{
    #$CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    $CurrentComputerName = "10.61.1.101"
    write-Host "Current Computer Name: $CurrentComputerName "

    ### Record the Current Computer Name
    $RempteIP = "10.61.1.101"
    $TargetComputer = "W2K16V2.ECILAB.NET"

    $NewComputerName = "BLU-SRV01"

    $ScriptBlock = 
    {
    #$CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    
    write-Host "Target Computer Name: $TargetComputer" 
    $TargetComputer | Out-File -FilePath -Path "$ReportPath \Target.txt"
    
    ### Rename Computer
    write-host "Renaming Local Computer to $NewComputerName"
    Rename-Computer –ComputerName  $TargetComputer –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru

    ### Verify the New Computer Name
    #$NewComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    #write-Host "New Computer Name: $NewComputerName " 
    #$NewComputerName | Out-File -FilePath -Path "$ReportPath \NewName.txt"
    }

    Invoke-Command -ScriptBlock $ScriptBlock -ComputerName $TargetComputer

}

Rename-LocalComputer
#Reboot-RemoteComputer
#Do-Something
