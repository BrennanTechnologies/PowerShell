﻿workflow Rename-Computer
{
    ScriptBlock = {

    ### Record the Current Computer Name
    $CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    write-Host "Current Computer Name: $CurrentComputerName " 
    $CurrentComputerName | Out-File -FilePath -Path "$ReportPath \CurrentName.txt"
    
    ### Rename Computer
    write-host "Renaming Local Computer"
    Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru

    Restart-Computer -Wait

    ### Verify the New Computer Name
    $NewComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    write-Host "New Computer Name: $NewComputerName " 
    $NewComputerName | Out-File -FilePath -Path "$ReportPath \NewName.txt"
    }

    InvokeCommand -ScriptBlock $ScriptBlock -ComputerName $CurrentComputerName
}

Rename-Computer





function Rename-LocalComputer
{

    $CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
    $NewComputerName = "BLU-SRV01"

    ### Rename Computer
    write-host "Renaming Local Computer"
    Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru
            
    ### Reboot Computer
    #Restart-Computer -Wait -PSComputerName CurrentComputerName
    

    ### Verify Computer Name
    write-Host "The computer is now named: $CurrentComputerName"

}

