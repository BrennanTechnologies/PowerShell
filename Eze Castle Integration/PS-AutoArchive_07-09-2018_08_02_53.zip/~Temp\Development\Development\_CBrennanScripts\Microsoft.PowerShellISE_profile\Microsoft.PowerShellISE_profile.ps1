### Set the Location
if($env:USERDNSDOMAIN -eq "ECILAB.NET")   {$Location = "\\tsclient\P\CBrennanScripts\CBrennanModule\CBrennanModule\CBrennanModule.psm1"}
if($env:USERDNSDOMAIN -eq "ECICLOUD.COM") {$Location = "\\tsclient\P\CBrennanScripts\CBrennanModule\CBrennanModule\CBrennanModule.psm1"}
if($env:USERDNSDOMAIN -eq "ECI.CORP")     {$Location = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\CBrennanModule\CBrennanModule\CBrennanModule.psm1"}


Set-Location $Location

if ($psISE)
{
    
}