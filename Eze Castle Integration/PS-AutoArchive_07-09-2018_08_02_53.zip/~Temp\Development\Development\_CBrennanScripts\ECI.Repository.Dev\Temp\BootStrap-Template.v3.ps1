﻿cls
#get-variable * | Remove-Variable

function BootStrap-Script
{
    $RepositoryPath = "\\eciscripts.file.core.windows.net\clientimplementation"

    ### Look for Repository in the Current Drive Mappings
    $Repository = Get-PSDrive -PSProvider FileSystem | Where-Object {$_.DisplayRoot -eq $RepositoryPath}

    ### If Repository Map Exists - Get Drive Letter being Used
    if($Repository)
    {
        $RepositoryDrive = $Repository.Root
        write-host "Repository Drive Exists: " $RepositoryDrive -ForegroundColor Green

    }
    
    ### If No Repository Map Exists - Map a Drive
    elseif(-NOT($Repository))
    {
        Write-Host "No Repository Mapped - Looking for Available Drives" -ForegroundColor Yellow
        
        ### Get Existing Drives in Use
        $PreferedDrive = "Z"
        $LBound        = "G"
        $UBound        = "Z"
                  
        function Test-Drive ($PreferedDrive)
        {
            $PSDrives = (Get-PSDrive -PSProvider FileSystem).Name
            if ($PSDrives.Contains($PreferedDrive))
            {
                $TestDrive = $True
            }
        }

        #$PSDrives = (Get-PSDrive -PSProvider FileSystem).Name

        write-host "PreferedDrive: " $PreferedDrive
        DO
        {
            Test-Drive $PreferedDrive
        }
        UNTIL ($TestDrive -eq $False)
        exit


        if(-NOT($PSDrives.Contains($PreferedDrive)))
        {
            $RepositoryDrive = $PreferedDrive
            Write-Host "Prefered Drive Available: $RepositoryDrive" -ForegroundColor Green
        }

        elseif($PSDrives.Contains($PreferedDrive))
        {
           Write-Host "Prefered Drive in Use - Incrementing Drive Letter $PreferedDrive" -ForegroundColor Yellow

            DO 
            {
                DO
                {
                    $PreferedDrive   = [byte][char]$PreferedDrive
                    $NextDrive       = [char]++$PreferedDrive
                    $RepositoryDrive = [char]$NextDrive
                }
                UNTIL ((($PSDrives.Contains($RepositoryDrive)) -ne $True))
            }
            WHILE ($RepositoryDrive -ge $LBound -and $RepositoryDrive -le $UBound)
        }
        
        ### Map Drive to the Cloud Repository
        $AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
        $Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
        $NewPSDribve = New-PSDrive -Name $RepositoryDrive -PSProvider FileSystem -Root $RepositoryPath -Credential $Credentials -Persist -Scope global
        Write-Host "Repositry Drive Drive Letter Mapped: $RepositoryDrive" -ForegroundColor Cyan        
        
        ### Add the Repository to the PS Module Path
        if(-NOT($env:PSModulePath.Contains($RepositoryPath))) {$env:PSModulePath = $RepositoryPath + ";" + $env:PSModulePath}
    }
}

BootStrap-Script

