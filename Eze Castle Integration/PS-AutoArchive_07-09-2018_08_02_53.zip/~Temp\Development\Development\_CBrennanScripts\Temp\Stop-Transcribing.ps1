﻿cls
Start-Transcript

Function Stop-Transcribing
{
[CmdletBinding(SupportsShouldProcess=$True)]
param()

write-verbose "Set Boolean value to false by default"
#$IsTranscribing = $false

write-Information "Testing to see if powershell is transcribing.  If so, we will stop and re-start transcription"

write-verbose "Test to see if transcribing is in progress" 
$stopTest = try {Stop-transcript -ErrorAction stop} catch {}                                                      
 
if (!$stopTest)
{
    write-verbose "No Transcription was started, we do nothing."
}                                     

if ($stopTest -and $stoptest.Contains("not been started"))
{
    write-verbose "No Transcription was started, we do nothing."
}   
 
if ($stopTest -and $stoptest.Contains("output file"))
{
    Stop-transcript

	<#
    Write-host "A running transcript was found, resuming..."
	Start-Transcript -path $stoptest.Split(" ")[$stoptest.Split(" ").count-1] -append  | out-null
	Write-Information "Stopped and restarted the transcription as part of the TEST-TRANSCRIBING function"                             
	$IsTranscribing = $True
#>

}                              
#Write-host "Returning the value of $IsTranscribing to the calling script" 
#Return $IsTranscribing

}

Stop-Transcribing #-Verbose
