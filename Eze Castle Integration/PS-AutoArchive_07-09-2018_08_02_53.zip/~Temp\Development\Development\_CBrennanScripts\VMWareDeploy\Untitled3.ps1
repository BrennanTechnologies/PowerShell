﻿function Connect-ECIVIServer
{

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Write-Host "Setting PowerCLIConfiguration: -InvalidCertificateAction Ignore" -ForegroundColor Gray
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false <#-ParticipateInCEIP:$false#> | Out-Null

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Gray
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    $VISession = Connect-VIServer -Server  $VIServer  -User ezebos\cbrennan -Password Tolkien4374
    }

    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

Get-ResourcePool

Get-Datastore