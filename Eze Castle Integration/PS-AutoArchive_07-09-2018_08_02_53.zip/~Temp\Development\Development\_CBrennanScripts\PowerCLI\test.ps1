﻿cls

#Connect-VIServer -Server ecilab-bosvcsa01.ecilab.corp

$VM = "RGEE-SRV1"
$vm = Get-VM -Name $VM

<#
    # Folder read access
    $datastore,$file = $VM.ExtensionData.Config.Files.VmPathName.Split(']')
    $datastoreName = $datastore.Trim('[')
    $fileName = $file.Split('/')[1]
    $file = $file.TrimStart(' ')
    $ds = Get-Datastore -Name $datastoreName

    New-PSDrive -Location $ds -Name DS -PSProvider VimDatastore -Root '\' 
    
    Set-Location -Path "DS:\RGEE-SRV1"    
    

    Copy-DatastoreItem -Item "DS:\RGEE-SRV1\vmware-1.log" -Destination $env:Temp\test
#>

<#
    Remove-PSDrive -Name DS

    $path = $env:Temp + '\' + $fileName
    
    $condRead = Test-Path -Path $path
    if($condRead){
      Remove-Item -Path $path -Confirm:$false
    }
#>

#Test-NetConnection -Port 902 -ComputerName "208.231.73.100"
Test-NetConnection -Port 22 -ComputerName "ecilab-bosvcsa01.ecilab.corp"
Test-NetConnection -Port 902 -ComputerName "ecilab-bosvcsa01.ecilab.corp"

<#
    # Port 902 open
    $socket = New-Object Net.Sockets.TcpClient
    $socket.Connect($VM.Host.Name,902)
    if($socket.Connected){
      $condPort = $True
      $socket.Close()
    }

#>