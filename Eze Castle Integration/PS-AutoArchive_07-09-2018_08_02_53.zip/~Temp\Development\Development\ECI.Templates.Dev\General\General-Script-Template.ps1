﻿6
### Define Functions
### --------------------------

function Do-Something
{
    $ScriptBlock = 
    {
        Write-Log "Do-Something"
    }
    Try-Catch $ScriptBlock
}        

function Do-Foo
{
    $ScriptBlock = 
    {
        Write-Log "Do-Foo"
    }

    Try
    {
        Invoke-Command -ScriptBlock $ScriptBlock
    }
    Catch
    {
        Trap-Error
    }
}

function Throw-Errors
{
    ### Create a Terminating Error
    Throw "Throw Terminating Error"
            
    ### Create a Non-Termination Error
    Write-Error "Throw Non-Terminating Error"
}


& { ### Uses the Call Operator "&" to Automatically Run

    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Clear-Host
        Start-Logs
        Write-Log "`nRunning: BEGIN Block" -ForegroundColor  Blue
        #Start-Transcribing 
    }

    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue
      
        ### Execute Functions
        ### --------------------------
        Do-Something
        #Do-Foo
        #Throw-Errors
        #Write-Host "PSCommandPath: " $PSCommandPath
        #Write-Host "PSScriptRoot: "  $PSRootPath
    }

    END 
    {
        ### Close Script
        ###--------------------------
        #Write-Log "`nRunning: END Block"  -ForegroundColor Blue
        #Close-LogFile -Quiet
        #Measure-Script
        #Stop-Transcribing
    }
}





