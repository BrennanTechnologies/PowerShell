﻿function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\VMAutomation\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

function Imported-ParametersFromAPIToGuest
{
    Write-Host "`nParameters Imported to $env:COMPUTERNAME `n" ('-' * 50)
    Write-Host "Step                  : " $Step
    Write-Host "VM                    : " $VM
    Write-Host "ServerBuildType       : " $ServerBuildType
    Write-Host "GuestComputerName     : " $GuestComputerName
    Write-Host "DomainName            : " $DomainName
    Write-Host "IPv4Address           : " $IPv4Address
    Write-Host "SubnetPrefixLength    : " $SubnetPrefixLength
    Write-Host "DefaultGateway        : " $DefaultGateway
    Write-Host "DNS1                  : " $DNS1
    Write-Host "DNS2                  : " $DNS2
    Write-Host ('-' * 50)
}

& { ### Uses the Call Operator "&" to Automatically Run

    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        Write-Host "`nBEGINBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Imported-ParametersFromAPIToGuest
        Get-ServerBuildType -ServerBuildType $ServerBuildType
        #Get-VMGuestConfiguration
        
    }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "PROCESSBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
<#
        $Steps = 5
        for ($i=1; $i -le $Steps; $i++)
        {
            if ($Step -eq $i)
            {
                Write-Host "Executing ConfigServer Functions: -Step: " $Step
                Invoke-Command {$ScriptBock + $Step}
            }
        }
#>
        if ($Step -eq "1")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step

            Configure-NetworkInterface
            #Configure-IPv6
            #Configure-IPv4 # Set by Invoke-ServerBuildTemplate <-- Change to "Verify-IPv4" function
            #Verify-IPv4
            #Configure-WindowsFirewallProfile
            #Configure-WindowsFirewallRules
            #Configure-CDROM 
            #Configure-ECIFolders
            #Configure-RemoteDesktop
            #Configure-InternetExplorerESC
            #Configure-PageFile
            $RebootPending = $False
        }

        if ($Step -eq "2")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Configure-WindowsFeatures 
            
        }
        if ($Step -eq "3")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Configure-WindowsFeatures
        }
        if ($Step -eq "4")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-LocalAdministrator
        }
        if ($Step -eq "5")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-LocalAdministrator
        }
        if ($Step -eq "6")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-GuestComputer
        }
        if ($Step -eq "7")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-GuestComputer
        }        
        if ($Step -eq "8")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Join-Domain
        }
        if ($Step -eq "9")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Join-Domain
        }
        if ($Step -eq "10")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            #Configure-WindowsUpdates 
            #Install-WindowsUpdates
        }
        if ($Step -eq "11")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            #Resume-Install-WindowsUpdates
        }
        
        Write-Host "CONFIGURATION COMPLETE - VM: $VM Date: $(Get-Date) `n" ("=" * 50)-ForegroundColor Yellow    
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "ENDBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Close-LogFile
        Stop-Transcript
    }
}
