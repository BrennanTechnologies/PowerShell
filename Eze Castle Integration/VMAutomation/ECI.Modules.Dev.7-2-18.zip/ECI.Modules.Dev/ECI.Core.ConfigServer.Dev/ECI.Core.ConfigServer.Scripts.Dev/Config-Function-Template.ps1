﻿cls
$script:VM = "RGEE-SRV1"
$script:NewInterfacename = "Etherx"
$script:IPv6Preference = "Disable"
$NewCDLetter = "R:"
$InternetExplorerESC = "Enable"
$ECIFolders = @()
$ECIFolders += "C:\Scripts"
$ECIFolders += "D:\Kits"
$ECIFolders += "D:\Test"

$RemoteDesktopPreference = "Enable"
$WindowesFireWallProfile = "Disable"

$PageFileSize                = "1.5"
$PageFileLocation            = "D"

### Windows Features
### -----------------------------------------
$WindowsFeatures  = @()
$WindowsFeatures += "NET-Framework-Features"
$WindowsFeatures += "NET-Framework-Core"
$WindowsFeatures += "GPMC"
$WindowsFeatures += "Telnet-Client"
$WindowsFeatures += "TFTP-Client"

function Configure-DesiredState
{
    Param(
    [Parameter(Mandatory = $True)][scriptblock]$GetCurrentState,
    [Parameter(Mandatory = $True)][scriptblock]$SetDesiredState,
    [Parameter(Mandatory = $True)][ValidateSet("Report","Configure")][string]$ConfigurationMode,
    [Parameter(Mandatory = $True)][ValidateSet($True, $False)][string]$AbortTrigger
    )

    ##################################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##################################################
    function Get-CurrentState
    {
        Try-Catch -Scriptblock { Invoke-Command $GetCurrentState } -Quiet
    }

    ##################################################
    ### COMPARE-CURRENT/DESIRED STATE:
    ##################################################
    function Compare-DesiredState
    {
        $script:Compare = ($CurrentState -eq $DesiredState)
        Write-Config "COMPARE: $Compare - FUNCTION: $Function CURRENTSTATE: $CurrentState DESIREDSTATE: $DesiredState"
        if($Compare -eq $True)
        {
            ### CURRENT STATE = DESIRED STATE: True
            ### --------------------------------------
            Write-Config "The Current-State Matches the Desired-State. Not Running Configuration!"
        }
        elseif($Compare -eq $False)
        {
            ### CURRENT STATE = DESIRED STATE: False
            ### --------------------------------------
            Write-Config "The Current-State Does Not Match the Desired-State. Running Configuration!"
        }
    }

    ##################################################
    ### SET DESIRED-STATE:
    ##################################################
    function Set-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            Write-Host "State: " $State -ForegroundColor Magenta

            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                [ScriptBlock]$DesiredStateConfiguration = {Invoke-Command $SetDesiredState}
                Try-Catch $DesiredStateConfiguration
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
        }
    }
        
    ##################################################
    ### VERIFY DESIRED STATE:
    ##################################################
    function Verify-DesiredState
    {
        foreach ($State in $DesiredState)
        {
            ### VERIFY: Current State
            ### -----------------------------------------------------
            Get-CurrentState
            $VerifyState = $CurrentState

            ### COMPARE: Verify State - Desired State
            ### ----------------------------------------------------- 
            $script:Verify = ($VerifyState -eq $DesiredState) ### <-- True/False
            Write-Config "VERIFY: $Verify VERIFYSTATE: $VerifyState DESIREDSTATE: $DesiredState"

            ### VERIFY = TRUE
            ### -----------------------------------------------------        
            if($Verify -eq $True)
            {
                ### ABORT = FALSE
                ### --------------------
                $global:Abort = $False
            }
        
            ###  VERIFY = FALSE
            ### -----------------------------------------------------
            elseif($Verify -eq $False)
            {
                if ($AbortTrigger -eq $True)
                {
                    ### ABORT TRIGGER = TRUE
                    ### --------------------
                    $global:Abort = $True
                }
                elseif($AbortTrigger -eq $False)
                {
                    ### ABORT TRIGGER = FALSE
                    ### --------------------
                    $global:Abort = $False
                }
            }
        }
    }

    ##################################################
    ### REPORT:
    ##################################################
    function Report-DesiredState
    {
        Write-Config "REPORT: COOKIE - VM: $VM FUNCTION: $Function VERIFY: $Verify ABORT: $Abort"
        Write-Cookie $VM $Function $Verify $Abort
        #Write-SQL $VM $Function $Verify $Abort

        ### IF ABORT = TRUE
        ### --------------------
        if($Abort -eq $True)
        {
            ### Send Alert and Exit the Script
            ### -------------------------------------------------------------------------------------
            Write-Config "ABORTTRIGGER: " $AbortTrigger "`t`tABORT: " $Abort "`nExiting Script!!!!"
            #Send-Alert
            #Exit
        }
    }

    ############################################################################
    ### CONFIGURE DESIRED STATE
    ############################################################################
    &{
        BEGIN
        {   }

        PROCESS
        {
            Get-CurrentState
            Compare-DesiredState
            if($Compare -eq $False){Set-DesiredState}
            Verify-DesiredState
            Report-DesiredState
        }

        END
        {   }   
    }
}

function Configure-NetworkInterface
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $NewInterfacename
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Rename-NetAdapter (Get-NetAdapter -Name $CurrentState).Name -NewName $DesiredState
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-IPv6
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if     ($IPv6Preference -eq "Enable") {$IPv6Preference = $True}
    elseif ($IPv6Preference -eq "Disable"){$IPv6Preference = $False}
    else   {$script:IPv6Preference  = $Null}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $IPv6Preference
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Get Current Interface
        $CurrentInterface     = Get-NetAdapter –Physical | Where-Object Status -eq 'Up'
        $script:CurrentInterfaceName = $CurrentInterface.Name
    
        ### Get IPv6 State
        $IPv6State   = Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
        $script:CurrentState = $IPv6State.Enabled ### Return True/False
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################

    [scriptblock]$script:SetDesiredState =
    {
        if ($DesiredState -eq $True)
        {
            ### Enable IPv6
            Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
        elseif ($DesiredState -eq $False)
        {
            ### Disable IPv6
            Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
        }
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-CDROM
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must End with Colon ":"
    $LastChar = $NewCDLetter.substring($NewCDLetter.length-1) 
    if ($LastChar -ne ":"){$NewCDLetter = $NewCDLetter + ":"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $NewCDLetter
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:ComputerName = (Get-WmiObject Win32_ComputerSystem).Name
        $script:CurrentState = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $ComputerName).Drive
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $ComputerName -Filter "DriveLetter='$CurrentState'"
        Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter = $DesiredState} | Out-Null
    }


    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-ECIFolders
{
    $Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $ECIFolders
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    foreach($State in $DesiredState)
    {
        $DesiredState = $State
        
        ##################################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##################################################
        [scriptblock]$script:GetCurrentState =
        {
            if(Test-Path -Path $DesiredState){$script:CurrentState = $DesiredState}
            else{$script:CurrentState = $False}
        }

        ##################################################
        ### SET DESIRED-STATE:
        ##################################################
        [scriptblock]$script:SetDesiredState =
        {
            New-Item -ItemType Directory -Path $State -Force | Out-Null
        }
    
       Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
    }
}

function Configure-RemoteDesktop
{
    $Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if($RemoteDesktopPreference -eq "Disable"){$RemoteDesktopPreferenceValue = "1"}
    elseif($RemoteDesktopPreference -eq "Enable"){$RemoteDesktopPreferenceValue = "0"}
    else{$RemoteDesktopPreferenceValue = $Null}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $RemoteDesktopPreferenceValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##################################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##################################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections").fDenyTSConnections
    }

    ##################################################
    ### SET DESIRED-STATE:
    ##################################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -Value $RemoteDesktopPreferenceValue
        
        if($RemoteDesktopPreferenceValue -eq "0")
        {
            Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
        }
        elseif($RemoteDesktopPreferenceValue -eq "1")
        {
            Disable-NetFirewallRule -DisplayGroup "Remote Desktop"
        }
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-WindowsFirewallProfile
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameters
    ### --------------------------------------
    if($WindowesFireWallProfile -eq "Disable") {$WindowesFireWallProfileValue = "False"}
    elseif($WindowesFireWallProfile -eq "Enable") {$WindowesFireWallProfileValue = "True"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $WindowesFireWallProfileValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-NetFirewallProfile -Name Domain).Enabled
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        Set-NetFirewallProfile -Profile Domain -Enabled $WindowesFireWallProfileValue
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-PageFile
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    ### Drive Letter Must NOT End with Colon ":"
    $LastChar = $PageFileLocation.substring($PageFileLocation.length-1) 
    if ($LastChar -eq ":"){$PageFileLocation = $PageFileLocation.Split(":")[0]}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False
    
    $DesiredState = @()
    $DesiredState += $PageFileSize
    $DesiredState += $PageFileLocation



    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        ### Calculate Desired Page File Size
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $DesiredPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if($Memory -lt "4") {$NewPageFileSize = "4"} ### Set a Minimun 4GB PageFile Size
        $DesiredState = ($DesiredPageFileSize * 1000) 
        $PageFile = Get-WmiObject -Class Win32_PageFileUsage -Computer "LocalHost"
        $CurrentState = $PageFile.MaximumSize
        $Size = ($CurrentState -eq $DesiredState)

        ### PageFile Location
        $script:DesiredState = $PageFileLocation
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $CurrentState = ($PageFile.Name).Split(":")[0]
        $Location =  ($CurrentState -eq $DesiredState)
    
        ### Set $CurrentState
        $script:CurrentState = $True
        $script:DesiredState = $True  
        if (($Size -eq $False) -OR ($Location -eq $False))
        {
            $script:CurrentState = $False
        }
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        $script:DesiredState = $PageFileSize
        
        # Disable Automatically Managed PageFile Setting
        $ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
        if ($ComputerSystem.AutomaticManagedPagefile -eq "True") 
        {
            Set-CimInstance -Property @{ AutomaticManagedPageFile = $False }
        }
        Write-Host "AutomaticManagedPagefile : " $(Get-CimInstance -ClassName Win32_ComputerSystem).AutomaticManagedPagefile 
        
        ### Delete Existing PageFile
        ### ---------------------------------
        $PageFile = Get-CimInstance -ClassName Win32_PageFileSetting
        $PageFile | Remove-CimInstance   


        ### Calculate Page File Size
        ### ---------------------------------
        $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
        $NewPageFileSize = [Math]::Round(($Memory * $PageFileSize)) # Memory Size Plus 20% - Round Up
        if ($Memory -lt "4") {$NewPageFileSize = "4"}
        [int]$NewPageFileSize = ($NewPageFileSize * 1000)
        [int]$InitialSize = ($NewPageFileSize * 1)
        [int]$MaximumSize = ($NewPageFileSize * 1.1)

        ### Create New Page File
        ### -------------------------------------------------------------------------------
        [scriptblock]$CreatePageFile =
        {
            if(-NOT(Get-CimInstance -ClassName Win32_PageFileSetting))
            {
                $PageFileName = $PageFileLocation + ":\pagefile.sys"
                Write-Host "Creating New Page File: PageFileLocation: $PageFileName InitialSize: $InitialSize MaximumSize: $MaximumSize " 
                New-CimInstance -ClassName Win32_PageFileSetting -Property  @{ Name= $PageFileName } | Out-Null
                Get-CimInstance -ClassName Win32_PageFileSetting | Set-CimInstance -Property @{InitialSize = $InitialSize; MaximumSize = $MaximumSize;} | Out-Null
                }
            else
            {
                Write-Config "PageFile Exists. Cant Configure!"
            }
        }

        ### Check Avilable Disk Space
        ### ---------------------------------
        $FreeSpace = (Get-PSDrive $PageFileLocation).Free

        #[int]$FreeSpace = $FreeSpace

        if($FreeSpace -gt $NewPageFileSize)
        {
            Write-Config "Free Space Available. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize"
            Invoke-Command -ScriptBlock $CreatePageFile
        }
        elseif($FreeSpace -le $NewPageFileSize)
        {
            Write-Config "Not Enough Avialable Space. Drive: $Drive FreeSpace: $FreeSpace NewPageFileSize: $NewPageFileSize `nNot Configuring!"
        }
        

    }
    
    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Configure-InternetExplorerESC 
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if($InternetExplorerESC -eq "Disable")   {$InternetExplorerESCValue = "0"}
    elseif($InternetExplorerESC -eq "Enable"){$InternetExplorerESCValue = "1"}

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState = $InternetExplorerESCValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    $Keys = @()
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"

    foreach($Key in $Keys)
    {
        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $script:CurrentState = (Get-ItemProperty -Path $Key -Name "IsInstalled").IsInstalled
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
       [scriptblock]$script:SetDesiredState =
        {
            Set-ItemProperty -Path $Key  -Name "IsInstalled" -Value $DesiredState -Force
            if(Get-Process -Name Explorer)
            {
                Stop-Process -Name Explorer
            }
        }

        Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
    }
}

function Configure-WindowsFeatures
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    foreach ($Feature in $WindowsFeatures)
    {
        $DesiredState = $Feature
        write-host "DeiredState: " $DesiredState

        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $script:CurrentState = ((Get-WindowsFeature -Name $Feature) | Where-Object {$_.Installed -eq $True}).Name
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
        [scriptblock]$script:SetDesiredState =
        {
            Install-WindowsFeature -name $Feature
        }
    
        Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
    }
}

function Join-Domain
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $DomainName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Import Credentials
        ### ----------------------------------------
        #$PSCrdentials = (Import-AESEncryptionKey)
        #Import-AESEncryptionKey

        $UserName = "GEEMONEYMGMT\ECIADMIN"
        $SecPasswd = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($UserName, $SecPasswd)

        Add-Computer -ComputerName $VM -DomainName $DomainName -Credential $PSCredentials -Force -Passthru -Verbose
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function Update-Windows
{
    Install-Module PSWindowsUpdate
    Add-WUServiceManager -ServiceID 7971f918-a847-4430-9279-4a52d1efe18d -Silent -Confirm:$False
    Get-WUInstall –MicrosoftUpdate –AcceptAll
}

function Configure-Template
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $NewInterfacename
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}

function IsAdmin
{
    $User = [Security.Principal.WindowsIdentity]::GetCurrent()
    $Role = (New-Object Security.Principal.WindowsPrincipal $User).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    Return $Role
}

#Configure-NetworkInterface
#Configure-IPv6
#Configure-CDROM
#Configure-ECIFolders
#Configure-RemoteDesktop
#Configure-WindowsFirewallProfile
#Configure-PageFile
#Configure-InternetExplorerESC
#Configure-WindowsFeatures
#Update-Windows
IsAdmin


