﻿function Configure-InternetExplorerESC 
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Modify Parameter Values
    ### --------------------------------------
    if($InternetExplorerESC -eq "Disable")   {$InternetExplorerESCValue = "0"}
    elseif($InternetExplorerESC -eq "Enable"){$InternetExplorerESCValue = "1"}

    ###################################
    ### DESIRED STATE PARAMETERS
    ###################################sValue
    $DesiredState = $InternetExplorerESCValue
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    $Keys = @()
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $Keys += "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"

    foreach($Key in $Keys)
    {
        ###################################
        ### GET CURRENT CONFIGURATION STATE: 
        ###################################
        [scriptblock]$script:GetCurrentState =
        {

            {
                $CurrentState = (Get-ItemProperty -Path $Key -Name "IsInstalled").IsInstalled
            }
        }

        ###################################
        ### SET DESIRED-STATE:
        ###################################
       [scriptblock]$script:SetDesiredState =
        {
            Set-ItemProperty -Path $UserKey  -Name "IsInstalled" -Value $DesiredState -Force
            if(Get-Process -Name Explorer)
            {
                Stop-Process -Name Explorer
            }
        }

    }
}