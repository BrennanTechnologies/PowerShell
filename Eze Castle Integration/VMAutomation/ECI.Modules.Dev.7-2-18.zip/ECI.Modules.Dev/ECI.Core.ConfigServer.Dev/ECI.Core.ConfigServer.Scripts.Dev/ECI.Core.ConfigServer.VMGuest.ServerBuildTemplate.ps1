﻿function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\VMAutomation\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

& { ### Uses the Call Operator "&" to Automatically Run

    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        Write-Host "`nBEGINBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Import-SoftParametersFromAPI
        Write-Cookie -VM $VM -Remove
        Get-ServerBuildType -ServerBuildType $ServerBuildType
        #Get-VMGuestConfiguration
        
    }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "`n" ("=" * 75) "`nPROCESSBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 75)
<#
        $Steps = 5
        for ($i=1; $i -le $Steps; $i++)
        {
            if ($Step -eq $i)
            {
                Write-Host "Executing ConfigServer Functions: -Step: " $Step
                Invoke-Command {$ScriptBock + $Step}
            }
        }
#>
        if ($Step -eq "1")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step

            Configure-NetworkInterface -ConfigurationMode Configure
            Configure-IPv6 -ConfigurationMode Configure
            #Configure-IPv4 # Set by Invoke-ServerBuildTemplate <-- Change to "Verify-IPv4" function
            #Verify-IPv4
            Configure-WindowsFirewallProfile -ConfigurationMode Configure
            #Configure-WindowsFirewallRules
            Configure-CDROM -ConfigurationMode Configure
            #Configure-ECIFolders
            #Configure-RemoteDesktop
            #Configure-InternetExplorerESC
            #Configure-PageFile
            $RebootPending = $False
        }

        if ($Step -eq "2")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Configure-WindowsFeatures 
            
        }
        if ($Step -eq "3")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Configure-WindowsFeatures
        }
        if ($Step -eq "4")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-LocalAdministrator
        }
        if ($Step -eq "5")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-LocalAdministrator
        }
        if ($Step -eq "6")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-GuestComputer
        }
        if ($Step -eq "7")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Rename-GuestComputer
        }        
        if ($Step -eq "8")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Join-Domain
        }
        if ($Step -eq "9")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Resume-Join-Domain
        }
        if ($Step -eq "10")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            #Configure-WindowsUpdates 
            #Install-WindowsUpdates
        }
        if ($Step -eq "11")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            #Resume-Install-WindowsUpdates
        }
        
        Write-Host "`n" ("=" * 75) "`nCONFIGURATION COMPLETE - VM: $VM Date: $(Get-Date) `n" ("=" * 75)
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "ENDBLOCK: $((Get-PSCallStack)[0].Command) STEP-$Step `n" ("=" * 50)
        Write-ServerBuildTag
        Close-LogFile
        Stop-Transcript
    }
}
