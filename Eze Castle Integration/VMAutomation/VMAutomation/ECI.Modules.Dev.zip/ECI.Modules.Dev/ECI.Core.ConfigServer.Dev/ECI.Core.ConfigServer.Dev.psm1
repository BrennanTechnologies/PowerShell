﻿<# TODO
----------------------------------------------------------------------------------------------------
1. Install VMWare Tools.
2. Set the Screen Resolution to 1024 x 768

- Install all Windows Updates available
4. Set Network Information 
    - CHECK “Internet Protocol Version 6 (TCP/IPv6)”
    - Enter the IP address, Subnet mask, Default gateway, and DNS server information. 

- Set up NIC teaming on network infrastructures that can support fault-tolerant LAN switching. This can only be done with the server has two NICs and software that can support It. 

- FOR VIRTUAL SERVERS: Create additional disk partitions based on the server function (refer to the appropriate standard for that function) 

5. Activate Windows

6. Install all Windows Updates available
    - ‘Update & Security’
    - Verify that the Windows Updates Settings says DownloadOnly 
    - After the updates are installed the server will reboot.

7. Check Device Manager for any missing drivers and install them accordingly

8. Configure Disks 
    - DCDROM -- R:
    - Create PrimaryDisk Partion D: Label "SWAP"

     Right-click the CD-ROM drive and choose “Change Drive Letter and Paths”  Click “Change” and choose “R” from the drop-down list. Click OK twice 

    - Create a primary disk partition (D:) for the Swap & Kits drive from Disk Management 
        - Label the Swap drive “Swap” or “Swap and Kits”.
        Copy the contents of the Server 2016 DVD to the D:\Kits folder 
        - Disable Files/Folder Compression
        - In the Registry Editor, locate the following key:HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem If the NtfsDisableCompression DWORD Does Not Exist, create it, if it does then skip the following bullet points: 

9. Configure Paging (Swap) File

10a. - Create a folder called “Scripts” in the root of the C: drive to store all non-logon scripts 
10b. - Create a folder called “Kits” in the root of the D: drive to store all installation files
10c. Copy the contents of the Server 2016 DVD to the D:\Kits folder

11. Configure Remote Desktop
    - Choose “Allow Remote connections to this computer” Make sure that the “Allow Connections only from Computers running Desktop with Network Level Authentication (Recommended)” is not checked. 

12. Disable “Restrict each user to a single session”
     - Type “GPEDIT.MSC” and on the Local Group Policy Editor navigate to “Computer Configuration\ Administrative Templates\ Windows Components\ Remote Desktop Services\ Remote Desktop Session Host\ Connections” 
        Double click “Restrict Remote Desktop user to a single Remote Desktop session” 
        Check “Not configured” or “Disable” and click “OK” 
        FOR VIRTUAL CITRIX SERVERS: Check the “Restrict each user to a single session” and click “OK”. Check with your CTM 

13. Disable Automatic Reboot 



14. Disable IE IE Enhance Security Configuration

15. Rename Administrator to ECIAdmin
    - Open the “eciadmin” user properties and make sure the password is set to never expire 

16. Rename Server and Join to Domain 

17?  - Install-WindowsFeature RSAT 
     - Install-WindowsFeature Telnet-Client



----------------------------------------------------------------------------------------------------
#>

function Start-VMLogs
{
    ### Create Timestamp
    $global:TimeStamp  = Get-Date -format "MM_dd_yyyy_hhmmss"

    ### Create Log Folder
    $ConfigLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\"
    if(-NOT(Test-Path -Path $ConfigLogPath)) {(New-Item -ItemType directory -Path $ConfigLogPath | out-null);Write-Host "Creating ConfigLogPath: " $ConfigLogPath }

    ### Create Log File
    $global:ConfigLogFile = $ConfigLogPath + "ConfigReport_" + $VM + "_" + $TimeStamp + ".log"

}

function Write-Config
{
    Param(
    [Parameter(Mandatory = $True, Position = 0)] [string]$Message,
    [Parameter(Mandatory = $False, Position = 1)] [string]$String,
    [Parameter(Mandatory = $False, Position = 2)] [string]$String2,
    [Parameter(Mandatory = $False, Position = 3)] [string]$String3,
    [Parameter(Mandatory = $False, Position = 4)] [string]$String4,
    [Parameter(Mandatory = $False, Position = 5)] [string]$String5,
    [Parameter(Mandatory = $False, Position = 6)] [string]$String6
    )

    if (((Get-Variable 'ConfigLogFile' -Scope Global -ErrorAction 'Ignore')) -eq $Null)    #if (-NOT($LogFile))
    {
        #Write-Host "No Logfile exists. Starting Log Files:" -ForegroundColor Gray
        Start-VMLogs
    }     

    ### Write the Message to the Config Report.
    $Message = $Message + $String + $String2 + $String3 + $String4 + $String5 + $String6
    #Write-Host "ConfigLogFile: " $ConfigLogFile
    Write-Host $Message
    $Message | Out-File -filepath $ConfigLogFile -append   # Write the Log File Emtry
}

function Verify-Config
{

    ### Verify New CD-ROM Letter
    
    $Verify = Invoke-Command {(Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:computername).Drive}
    
    if ($VerifiedValue -eq $NewValue)
    {
        Write-Config "VERIFIED:`t- CurrentValue: $VerifiedCDLetter NewValue: $NewCDLetter"
    }
    elseif($VerifiedValue -ne $NewValue)
    {
        Write-Config "MISMATCH - CurrentValue: $VerifiedCDLetter NewValue: $NewCDLetter"
    }

}

function Import-Modules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")   {$Module = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM") {$Module = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")     {$Module = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "W2K16V2")      {$Module = "\\tsclient\Z\CBrennanScripts\Modules\"}
    
    $Modules = @()
    #$Modules += "CommonFunctions"
    $Modules += "ConfigServer"

    foreach ($Module in $Modules)
    {
        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module}

        ### Import the Module
        $ModulePath = $ModulePath + $Module + "\" + $Module + ".psm1"
        Import-Module -Name $ModulePath -DisableNameChecking #-Verbose

        ### Test the Module - Exit Script on Failure
        if( (Get-Module -Name $Module)){Write-Host "Loading Custom Module: $Module" -ForegroundColor Green}
        if(!(Get-Module -Name $Module)){Write-Host "The Custom Module $Module WAS NOT Loaded! `nFunctions Wont Work! `nExiting Script!" -ForegroundColor Red;exit}
    }
}

function Import-Parameters
{
    $ScriptBlock = 
    {
        ### Hard Code the Parameter File
        $ParameterFile = "Parameters.csv"

        ### Set Parameter File Path 
        $ParametersFilePath =  $ScriptPath + "\" + $ParameterFile

        ### Check if Parameter File Exits
        write-log "Checking for Parameter File: $ParameterFile"

        if(-not (Test-Path $ParametersFilePath))
        {
            write-log "Parameter File Missing: $ParameterFile" -Foregroundcolor Red
            write-log "Exiting Script!" -Foregroundcolor Red
            Exit
        }
        else
        {
            write-log "Parameter File Exists. Importing: $ParameterFile" -Foregroundcolor Green
        }

        ###########################
        ### Initialize Parameters
        ###########################

        ### Import from CSV file
        $script:Parameters = Import-CSV -path $ParametersFilePath 

        foreach ($Parameter in $Parameters)
        {
            # Set Variable Scope to "Script" for Functions
            Set-Variable -Name $Parameter.NewParameter -Value $Parameter.NewValue -scope global
                
            # Verify Variables
            $Verify = Get-Variable -Name $Parameter.NewParameter
            #$Parameter.NewParameter
            #$Parameter.NewValue
        }            
    }

    Try-Catch $ScriptBlock
}

function Test-VMGuestConnection
{
    Write-Host "Getting Guest Data:" -ForegroundColor Cyan
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestComputerName = $env:COMPUTERNAME
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Log "GuestComputerName : " $env:COMPUTERNAME
    Write-Log "GuestOSVer        : " $GuestOSVer 
    Write-Log "GuestIPv4Addr     : " $GuestIPv4Addr
}

function Get-VMGuestData
{
    Write-Host "Getting Guest Data:" -ForegroundColor Cyan
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Host ("-" * 50)
    Write-Host "VM GUEST DATA:"
    Write-Host "GuestComputerName : " $env:COMPUTERNAME
    Write-Host "GuestOSVer        : " $GuestOSVer 
    Write-Host "GuestIPv4Addr     : " $GuestIPv4Addr
    Write-Host ("-" * 50)
}

function CopyFile-ToGuestVM
{
    # Hard Code & Copy Conf File - Until above gets fixed!
    $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\tools.conf"
    $Dest = "C:\ProgramData\VMware\VMware Tools"

    #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
    Write-Host "Copying File: SRC: $Src DEST: $Dest"
    Copy-Item -Path $Src -Destination $Dest -Force

}

function Get-VMToolsStatus
{

    Restart-VM -VM $dbvm2 -Confirm :$false
    Sleep 10
    while (((get-vm $dbvm2 ).ExtensionData.Guest.ToolsRunningStatus ) -ne "guestToolsRunning" ) {
    Write-Host "....." -ForegroundColor Yellow
    Sleep 5
    }
 
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    while ( $? -eq $false ) {
    Get-Date -Format HH :mm :ss
    sleep 2
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    }
}

function Configure-GuestVMDebuging
{
    Param([Parameter(Mandatory = $True,  Position = 0)] [string]$Mode = "Enable")

    $global:VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools\Tools.conf"

    function Create-VMToolsConfigFile    {        ### Create Log Folder        $DebugLogPath = "C:\Temp\VMTools"        if(-NOT(Test-Path -Path $DebugLogPath)) {New-Item -ItemType directory -Path $DebugLogPath | out-null}        ### Create VM Tools Guest Config File        $TextBlock = {
        [logging]        log = true        vmtoolsd.level = debug        vmtoolsd.handler = file
        vmtoolsd.data = c:/temp/vmtoolsd.log        }        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}

        #$TextBlock | 
        #$TextBlock | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII #UTF8 #ASCII #String #Unicode
        #Set-Content -Value $TextBlock -Path $VMGuestConfigFile #-Force


        # Hard Code & Copy Conf File - Until above gets fixed!
        $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\Tools.conf"
        $VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools"

        #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
        Copy-Item -Path $Src -Destination $VMGuestConfigFile -Force

    }

    if($Mode -eq "Enable")    {        Write-Host "Enabling Debug Logging a Guest VM"        Create-VMToolsConfigFile    }    elseif($Mode -eq "Disable")    {        Write-Host "Disbling Debug Logging a Guest VM"        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}            }}

function Restart-VMGuestService
{
    write-host "VMTools Status: " (Get-Service -Name VMTools).Status

    ### Restart the VMTools Service
    if((Get-Service -Name VMTools).Status -eq "Running")
    {
        Write-Host "Re-Starting VMTools:"
        Get-Service -Name VMTools | Restart-Service -Force
        Wait-Tools -VM $VM -TimeoutSeconds 60
    }
    else
    {
        Write-Host "Starting VMTools:"
        #Get-Service -Name VMTools | Start-Service -Name VMTools
    }
}

function Restart-GuestVMTools
{


}

function Configure-PageFile
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Start-ConfigReport
{
    $script:ConfigReportFile = $ReportPath + "\ConfigReport_" + $ScriptName + "_" + $TimeStamp + ".log"

    ### Write Config Report Header
    Write-Config "Server Configuration Report:"
    Write-Config  ('-' * 50) 
    $ConfigReport = @()
    $ReportHeader = @{
        New_Server_Name = $NewServerName
        Build_Date = (Get-Date)
        New_Domain = $NewDomain
        Target_Server = $env:COMPUTERNAME
        Target_Domain = $env:USERDNSDOMAIN
    }

    $PSObject      = New-Object PSObject -Property $ReportHeader
    $ConfigReport += $PSObject 
    $ConfigReport | Format-List
    $ConfigReport | Format-List | Out-File  -filepath $ConfigReportFile -append 
    
    ### Write Input Parameters
    Write-Config "Input Parameters:"
    Write-Config  ('-' * 50) 

    $Params = @()
    foreach ($Parameter in $Parameters)
    {
        $NewParams = [ordered]@{
        NewParameter = $Parameter.NewParameter
        NewValue     = $Parameter.NewValue
        }

        ### Build Parameter Report Header
        $PSObject      = New-Object PSObject -Property $NewParams
        $Params       += $PSObject 
    }  
    $Params | Format-Table -AutoSize
    $Params | Format-Table -AutoSize | Out-File  -filepath $ConfigReportFile -append 
}

function Restart-LocalComputer
{
    Write-Log "Restarting Computer"
    Start-Sleep -s 15
    Restart-Computer -Force
}

function Resume-AfterRestart
{
    Write-Host "Resuming after Reboot..."

}

function Reboot-Computer-old
{
    ### Reboot Computer
    Restart-Computer -Wait -PSComputerName $CurrentComputerName

        ### Verify the New Computer Name
        $NewComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
        #Write-Host "New Computer Name: $NewComputerName" 
        $NewComputerName | Out-File -FilePath -Path "$ReportPath \Test.txt"
}

function Rename-Computer
{
    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

        $CurrentComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
        
        ### CheckCurrent Computer Name
        if($CurrentComputerName -ne $NewComputerName)
        {
            ### Rename Computer
            write-host "Renaming Local Computer"
            Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru
            
            ### Reboot Computer
            #Restart-Computer -Wait -PSComputerName CurrentComputerName

            ### Verify Computer Name
            write-Host "The computer is now named: $CurrentComputerName"
        }

        elseif($CurrentComputerName -eq $NewComputerName)
        {
            ### Names are the Same
            write-host "Computer Names are the same. Not Renaming."
        }
        
        ### Verify
        $VerifyComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
        if ($VerifyComputerName -eq $NewComputerName)
        {
            Write-Config "VERIFIED: VerifyComputerName: $VerifyComputerName NewComputerName: $NewComputerName"
        }
        elseif($VerifyComputerName -ne $NewComputerName)
        {
            Write-Config "VERIFY ERROR: VerifyComputerName: $VerifyComputerName NewComputerName: $NewComputerName" 
        }

    }

    Try-Catch $ScriptBlock
}

function Set-RegKey
{
    Write-Host "Setting RunOnce Reg Key"
    #$ScriptPath  = $MyInvocation.PSCommandPath
    $ScriptPath  = $((Get-PSCallStack)[-1].Command)
    Write-Host "ScriptPath: " $ScriptPath
   
    
    $RegRunKey     = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
    $RegRunOnceKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    #$ResumePSCommand = "C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -noexit -file C:\Scripts\Reboot-Resume\Reboot-Resume.ps1 -Step 3"
    $ResumePSCommand = "C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -noexit -file C:\Scripts\Modules\ConfigServer\ConfigServer-Template.ps1 -Step 2"
    Set-ItemProperty -Path $RegRunOnceKey -Name "ResumePS" -Value $ResumePSCommand 
}

function Reboot-Resume
{
    write-host "Reboot-Resume"
    Read-Host -Prompt "Rebooting. Press ENTER to continue ..."
    #Restart-Computer -ComputerName .
}

function Configure-NetworkInterface
{
        Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

        $ScriptBlock = 
        {
            ### Get NIC that is currently in use.
            $ExistingInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name

            #### Check if Interface Name Exists before Renaming
            if ($ExistingInterfaceName -ne $NewInterfacename )
             {
                Rename-NetAdapter (Get-NetAdapter -Name $ExistingInterfaceName).Name -NewName $NewInterfaceName
                                    
                ### Verify
                $VerifyInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
                if($VerifyInterfaceName -eq $NewInterfacename)
                {
                    Write-Config "VERIFIED: Interface $ExistingInterfaceName renamed to $VerifyInterfaceName"
                }
            }

            elseif($ExistingInterfaceName -eq $NewInterfacename)
            {
                Write-Config "Not Renaming interface. Adapter is already named $ExistingInterfaceName"
            }
            elseif($ExistingInterfaceName -ne $NewInterfacename)
            {
                Write-Config "Interface Not Renamed -  ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
            }
        }

    Try-Catch $ScriptBlock
}

function Configure-CDROM
{
    Write-Config "Executing Function1: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Drive Letter Must End with Colon ":"
        $LastChar = $NewCDLetter.substring($NewCDLetter.length-1) 
        if ($LastChar -ne ":"){$NewCDLetter = $NewCDLetter + ":"}

        ### Get the Current CD-ROM Letter & Volume
        $CurrentCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive

        if ($CurrentCDLetter -ne $NewCDLetter)
        {
            ### Get the CD Volume Object
            $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $env:computername -Filter "DriveLetter='$CurrentCDLetter'" -ErrorAction Stop            
 
            ### Change the CD-ROM Letter of the CD Volume Object
            Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter=$NewCDLetter} | Out-Null

            ### Verify New CD-ROM Letter
            $VerifiedCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:computername).Drive
            if ($VerifiedCDLetter -eq $NewCDLetter)
            {
                Write-Config "VERIFIED:`t CD-ROM Renamed - CurrentCDLetter: $VerifiedCDLetter renamed to VerifiedCDLetter: $VerifiedCDLetter"
            }
            elseif($VerifiedCDLetter -ne $NewCDLetter)
            {
                Write-Config "Mismatch - CurrentCDLetter: $VerifiedCDLetter doesnt match NewCDLetter: $NewCDLetter"
            }
        }
        else
        {
            Write-Config "Not Renaming CD-Rom. Drive Letters are the same: CurrentCDLetter: $CurrentCDLetter"
        }
    }

    Try-Catch $ScriptBlock
}

function Configure-IPv4
{
    $ScriptBlock = 
    {
        ### Cast the variables as IP address
        [IPAddress]$NewIPv4Address     = $NewIPv4Address.Trim()
        [IPAddress]$NewDefaultGateway  = $NewDefaultGateway.Trim()

        ### Get the Current NIC
        $CurrentInterface  = (Get-NetAdapter –Physical | where Status -eq 'Up').Name


        ### Determine if IPv4 Address is Static
        $DhcpStatus = (Get-NetIPInterface -AddressFamily IPv4 -InterfaceAlias $CurrentInterface).DHCP
            
        ### If DHCP is Enabled, Create New IPv4 Address, Else Set IPv4 Addres
        if ($DhcpStatus -eq "Enabled")
        {
            ### Set the IPv4 Settings
            write-log "`n`nSetting Adapter IP Address and Default Gateway"  -ForegroundColor Yellow
            New-NetIPAddress $NewIPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $NewPrefixLength -DefaultGateway $NewDefaultGateway | Out-Null
        }
        elseif ($DhcpStatus -eq "Disabled")
        {
            Set-NetIPAddress
        }


        ### Get the Current IP Address
        $CurrentIPAddress = (Get-NetIPAddress -InterfaceAlias $CurrentInterface -AddressFamily IPv4).IPv4Address

        ### Checking if the current IP Address is already the same if the New IP Address
        if($CurrentIPAddress -ne $NewIPv4Address) 
        {
            write-log "The New IP Address is Different - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow

            #$ISDHCPEnabled = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration  -Filter "IPEnabled=TRUE").DHCPEnabled

            # Remove the static ip
            #Remove-NetIPAddress -InterfaceAlias $CurrentInterface

            # Remove the default gateway
            #Remove-NetRoute -InterfaceAlias $CurrentInterface

            ### Change the IPv4 Settings
            write-log "`n`nSetting Adapter IP Address and Default Gateway"  -ForegroundColor Yellow
            New-NetIPAddress $NewIPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $NewPrefixLength -DefaultGateway $NewDefaultGateway | Out-Null

            ### Verify Settings
            $VerifyIP = (Get-NetIPAddress -InterfaceAlias $NewInterfaceName -AddressFamily IPv4).IPv4Address

            if($VerifyIP -eq $NewIPv4Address){Write-Log "IP Address set to this new value: " $VerifyIP}
            else {Write-Log "Mismatch - VerifyIP: $VerifyIP NewIPv4Address: $NewIPv4Address"}
        }
        elseif($CurrentIPAddress -eq $NewIPv4Address) 
        {
            ### Do nothing if the New iP Address is the same as the Existing IP Address 
            write-log "The IP Address is the Same - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow
        }
    }

    Try-Catch $ScriptBlock
}

function Configure-IPv6
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Set IPv6
        ###---------------------------------------------------------------------------
        
        ### Get Current Interface
        $CurrentInterface     = Get-NetAdapter –Physical | where status -eq 'up'
        $CurrentInterfaceName = $CurrentInterface.Name
    
        ### Get IPv6 State
        $IPv6State   = Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
        $IPv6Enabled = $IPv6State.Enabled

        ### Comapre IPv6 State with IPv6 Preference
        if (($Ipv6Preference -eq "Enable") -OR ($Ipv6Preference -eq "Disable"))
        {
            write-log "Configuring IPv6: -InterfaceAlias: $CurrentInterfaceName -Ipv6Enabled: $IPv6Enabled -IPv6Preference: $Ipv6Preference"

            if ((-not($IPv6Enabled)) -AND ($Ipv6Preference -eq "Enable"))
            {
                ### Enable IPv6
                Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID ms_tcpip6
            }
            elseif (($IPv6Enabled) -AND ($Ipv6Preference -eq "Disable"))
            {
                ### Disbale IPv6
                Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID ms_tcpip6
            }
            elseif ((($IPv6Enabled) -AND ($Ipv6Preference -eq "Enable")) -OR (-not($IPv6Enabled) -AND ($Ipv6Preference -eq "Disable")))
            {
                ### Do nothing
                write-log "IPV6 Setting are correct. Continuing."
            }
        }
        elseif ((-not($Ipv6Preference -eq "Enable")) -OR (-not($Ipv6Preference -eq "Disable")))
        {
            write-log "Ipv6Preference specified in parameters was: $Ipv6Preference. Must be set to Enable or Disable." 

        }
        
        ### Verify IPv6 Preference was set
        ###-----------------------------------------------
        $VerifyIPv6Enabled = (Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)").Enabled

        if ((($VerifyIPv6Enabled) -AND ($Ipv6Preference -eq "Enable")) -OR  (-NOT($VerifyIPv6Enabled) -AND ($Ipv6Preference -eq "Disable")))
        {
            ### Verified
            write-config "VERIFIED IPv6: -InterfaceAlias: $CurrentInterfaceName -Ipv6Enabled: $VerifyIPv6Enabled -IPv6Preference: $Ipv6Preference"
        }
        elseif ((-not($VerifyIPv6Enabled) -AND ($Ipv6Preference -eq "Enable")) -OR  (($VerifyIPv6Enabled) -AND ($Ipv6Preference -eq "Disable")))
        {
            ### Not Verified
            write-config "NOT VERIFIED IPv6: -InterfaceAlias: $CurrentInterfaceName -Ipv6Enabled: $VerifyIPv6Enabled -IPv6Preference: $Ipv6Preference"
        }
    }

    Try-Catch $ScriptBlock
}

function Configure-PageFile
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Add-WindowsFeatures
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### List Features to Install
        Write-Log "The following Features will be installed:" -foregroundcolor Cyan
        foreach ($Feature in $WindowsFeatures)
        {
            Write-Log $Feature -foregroundcolor Gray
        }

        ### Instal Features
        foreach ($Feature in $WindowsFeatures)
        {
            Install-WindowsFeature -name $Feature
        } 

        ### Verify Features

        foreach ($Feature in $WindowsFeatures)
        {
            $Feature = Get-WindowsFeature -name $Feature 
            if($Feature.Installed -eq "True")
            {
                Write-config "Windows Feature Installed: " $Feature.Name "`tInstalled: " $Feature.Installed
            }
            if($Feature.Installed -ne "True")
            {
                Write-Config "Windows Feature NOT Installed: " $Feature.Name "`tInstalled: " $Feature.Installed
            }
        }
    }
    
    Try-Catch $ScriptBlock
}

function Update-Windows
{
    $ScriptBlock = {
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }

        Get-WUInstall  -IgnoreReboot 
        Get-WUInstall -ListOnly | FT Title, KB #, ComputerName, Size  
    }
    Try-Catch $ScriptBlock
}

function Dev-Update-Windows
{
    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[-1].Command) `n('-' * 50)
### Windows Server 2016 Update settings
<#
– 2 = Notify before download.
– 3 = Automatically download and notify of installation.
– 4 = Automatically download and schedule installation. Only valid if values exist for ScheduledInstallDay and ScheduledInstallTime.
– 5 = Automatic Updates is required and users can configure it.
#>
#HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

$WindowsUpdateAU = HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

Set-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU -Name AUOptions -Value 3

        
        write-host "PSVersion: " $PSVersionTable.PSVersion
        <#
        if ($PSVersionTable.PSVersion -gt "5")
        {
            write-host "PSVersion: " $PSVersionTable.PSVersion
        }
        #>
        
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
                
        if ($PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate is already loaded." -ForegroundColor Green

        }

        write-host "PSWindowsUpdateModuleisLoaded: " $PSWindowsUpdateModuleisLoaded

        <#
        ### Get Microsoft Updates
        ### -----------------------------------
        $UpdateSession = new-object -com "Microsoft.Update.Session"
        $Criteria="IsInstalled=0 and IsHidden=0"
        $Updates=$UpdateSession.CreateupdateSearcher().Search($Criteria).Updates
        $Updates | Format-Table -property Title
        #>

        <#
        ### Get WSUSUpdates
        ### -----------------------------------
        $UpdateServer = "BLU-MGMT01.ecilab.net"
        
        Get-WSUSServer -Name "10.70.0.8" -Port 8530 
        Get-WSUSServer -Name "BLU-MGMT01.ecilab.net" -Port 8530

        Get-WsusUpdate -UpdateServer "BLU-MGMT01.ecilab.net"
         Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        #Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        
        #https://blogs.technet.microsoft.com/heyscriptingguy/2012/01/19/use-powershell-to-find-missing-updates-on-wsus-client-computers/
        #>


        <#
        $WindowsUpdateModuleisAvailable = (Get-Module -ListAvailable WindowsUpdate)
        if ($WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module is available" -ForegroundColor Green
            #Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            #Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
        if (!$WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module not available" -ForegroundColor Red
        }
        #>

    }
    
    Try-Catch $ScriptBlock
}

function Set-FirewallRules
{
    $ScriptBlock = 
    {
        $Parameters = @{
            DisplayName = "Allow RDP from 10.0.0.0/24"
            LocalPort = 3390
            Direction="Inbound"
            Protocol ="TCP" 
            Action = "Allow"
                
            # Get the Remote Address from the $ParamaterFile
            RemoteAddress = $AllowRDPSubnet
        }

        ## Checking if the Rule Exists
        write-host "Checking if rule exists: " $Parameters.DisplayName
        $Rules = Get-NetFirewallRule -DisplayName *
            
        if (-not $Rules.DisplayName.Contains($Parameters.DisplayName)) 
        {
            ### Create New Firewall Rule
            Write-Log "This rule Does not exist. Creating New Firewall Rule"
            New-NetFirewallRule -DisplayName $Parameters.DisplayName -Action $Parameters.Action -Direction $Parameters.Direction `
            –LocalPort $Parameters.LocalPort -Protocol $Parameters.Protocol -RemoteAddress $Parameters.RemoteAddress| Out-Null
        }
        else
        {
            write-host "This rule already exists. Not Creating"
        }

        ### Show the Firewall Settings
        write-log "Checking the Firewall Settings"
        $FirewallRule = Get-NetFirewallRule -DisplayName $Parameters.DisplayName
        write-host "DisplayName: " $FirewallRule.DisplayName "Action: " $FirewallRule.Action "Enabled: " $FirewallRule.Enabled
    }
    Try-Catch $ScriptBlock
}

function Rename-LocalAdministrator
{

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        Write-Host "Getting Local Adminitrator Account for: " $ComputerName -ForegroundColor Magenta
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal

        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name
        Write-Log "The current Local Administrator Account is: $CurrentAdminName"  -ForegroundColor Magenta

        ### Check if Local Admin is already renamed
        if($CurrentAdminName -eq $NewLocalAdminName)
        {
            write-host "Local Admin Names are the same: Current Admin: $CurrentAdminName New Admin: $NewLocalAdminName" -ForegroundColor Yellow
        }
        elseif($CurrentAdminName -ne $NewAdminName)
        {
            write-host "Renaming Local Admin Account: Current Admin: $CurrentAdminName New Admin: $NewLocalAdminName" -ForegroundColor Yellow
            Rename-LocalUser -Name $CurrentAdminName -NewName $NewLocalAdminName

        }


    }
    Try-Catch $ScriptBlock
}

function OldRename-LocalAdministrator
{

    $ScriptBlock = 
    {

        function Get-CurrentAdmin
        {
            ### Find the Current Local Administrator Account
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
            $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
            $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
            $Searcher.QueryFilter = $UserPrincipal

            ### The Administrator account is the only account that has a SID that ends with “-500”
            $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
            $script:CurrentAdminName = $Account.Name
            Write-Log "The current Local Administrator Account is: $CurrentAdminName"
        }

        function Rename-Admin
        {
            ### Get the Current Local Admin Account
            $User= Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | Where {$_.Name -eq $CurrentAdminName}

            ### Rename the Current Local Admin Account
            write-host "Renaming $CurrentAdminName to $NewAdminName "
            $user.Rename($NewAdminName) | Out-Null
        }

        function Check-CurrentAdmin
        {
            ### Check if Local Admin is already renamed

            if($CurrentAdminName -eq $NewAdminName)
            {
                write-host "CurrentAdminName is the same as NewAdminName"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
            }
            elseif($CurrentAdminName -ne $NewAdminName)
            {
                write-host "Renaming Local Admin Account"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
                Rename-Admin
            }
        }

        function Verify-NewAdmin
        {
            write-host "Verifying new Admin Account Name"
            Get-CurrentAdmin
        }

        Get-CurrentAdmin
        Check-CurrentAdmin
        Verify-NewAdmin

    }

    Try-Catch $ScriptBlock
}

function Join-Domain
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {

    Set-PSCredentials
    
    -Credential $PSCredentials

    Add-Computer -DomainName $ADDomain -Credential $Credential #-restart –force

<#
            'Join Workgroup
            'If in a domain, we need to remove it first before joining a workgroup
            if InDomain then 
                confirm = msgbox(L_Msg024_Text & vbCRLF & L_Msg025_Text,VBYesNo,L_Msg004_Text) 
                if confirm=vbYes then 
                    wscript.StdOut.Write L_Msg026_Text
                    domainuser = Wscript.StdIn.ReadLine

                    wscript.echo
                    wscript.echo L_Msg027_Text
                    
                    targetstr = "netdom remove %computername% /domain:" & NewGroupName & " /userd:" & domainuser & " /passwordd:*"

#>
    }

    Try-Catch $ScriptBlock
}

function Create-KitsFolder
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    
    $ScriptBlock = 
    {
        $Path = "D:\Kits"
        New-Item -ItemType directory -Path $Path -Force | Out-Null

        ### Verify
        if(Test-Path $Path)
        {
            Write-Config "VERIFIED: Folder Created - $Path"
        }
    }
    Try-Catch $ScriptBlock
}

function Create-ScriptsFolder
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        $Path = "C:\Scripts"
        New-Item -ItemType directory -Path $Path -Force | Out-Null

        ### Verify
        if(Test-Path $Path)
        {
            Write-Config "VERIFIED: Folder Created - $Path"
        }
    }
    Try-Catch $ScriptBlock
}

function Enable-RemoteDesktop
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Enable Remote Desktop
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections" -Value 0
        Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

        ### Verify
        $fDenyTSConnections = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections").fDenyTSConnections
        if($fDenyTSConnections = "0")
        {
            Write-Config "VERIFIED: fDenyTSConnections = $fDenyTSConnections"
        }
        elseif($fDenyTSConnections = "1")
        {
            Write-Config "INVALID: fDenyTSConnections = $fDenyTSConnections"
        }
        
    }
    Try-Catch $ScriptBlock
}

function Configure-InternetExplorerESC 
{

    write-host "InternetExplorerESC: " $InternetExplorerESC
    WRITE-HOST "InternetExplorerESCValue: " $InternetExplorerESCValue
    WRITE-HOST "VerifyAdminKey : " $VerifyAdminKey 
    WRITE-HOST "VerifyuSERKey : " $VerifyuSERKey 

    if($InternetExplorerESC = "Disable")
    {
        $InternetExplorerESCValue = "0"
    }
    elseif($InternetExplorerESC = "Enable")
    {
        $InternetExplorerESCValue = "1"
    }
                
    ### Enable Internet Explorer Enhanced Security Configuration
    $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $UserKey  = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
    Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
    Set-ItemProperty -Path $UserKey  -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
    Stop-Process -Name Explorer
    
    ### Verify Configuration
    $VerifyAdminKey = (Get-ItemProperty -Path $AdminKey -Name "IsInstalled").IsInstalled
    $VerifyUserKey  = (Get-ItemProperty -Path $UserKey  -Name "IsInstalled").IsInstalled
    
###
    
    if (($VerifyAdminKey -eq $InternetExplorerESCValue) -AND ($VerifyUserKey -eq $InternetExplorerESCValue))
    {Write-Config "VERIFY SUCCEDED: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

    elseif (($VerifyAdminKey -ne $InternetExplorerESCValue) -OR ($VerifyUserKey -ne $InternetExplorerESCValue))
    {Write-Config "VERIFY FAILURE: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

}

function Invoke-Test
{
    $ScriptBlock = {

    }

    Invoke-VMScript -ScriptText $ScriptBlock

}

function Function-Template
{

    Write-Config "Executing Function1: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {


    }

    Try-Catch $ScriptBlock

    ### Verify Configuration
    Verify-Configuration $VerifyValue $ParameterValue


}

function Get-BuildType
{

    Param(
    [Parameter(Mandatory = $True)] [string]$BuildType
    #[Parameter(Mandatory = $True)] [string]$Step
    )

    Write-Host "BuildType: $BuildType" -ForegroundColor Cyan

    ### Set Parameters for ALL Server Build Types
    $global:BuildDate = Get-Date -Format g

    ### Set Parameters for Server Build Types

    Switch ($BuildType)
    {
         ### Windows Server 2016 Builds
         ###-----------------------------------

         2016_Std_Base 
         {
            ### Server Template "Hard" Parameters
            ### -----------------------------------------
            $global:NewInterfacename     = "Ethernet1"
            $global:NewLocalAdminName    = "ECIAdmin"
            $global:NewCDLetter          = "R:"
            $global:Ipv6Preference       = "Enable"
            $global:WindowesFireWall     = "Enable"
            $global:AutomaticReboot      = "Disable"
            $global:RemoteDesktop        = "Enable"
            $global:ResitrctRDPSessions  = "Disable"
            $global:PageFileLabel        = "SWAP\KITS"
            $global:PageFileLocation     = "D:\"
            $global:InternetExplorerESC  = "Enable"

            Write-Host "Server Template *Hard* Parameters: `n" ("-" * 50)
            Write-Host "NewInterfacename     : " $NewInterfacename
            Write-Host "NewLocalAdminName    : " $NewLocalAdminName
            Write-Host "NewCDLetter          : " $NewCDLetter
            Write-Host "Ipv6Preference       : " $Ipv6Preference
            Write-Host "WindowesFireWall     : " $WindowesFireWall
            Write-Host "AutomaticReboot      : " $AutomaticReboot
            Write-Host "RemoteDesktop        : " $RemoteDesktop
            Write-Host "ResitrctRDPSessions  : " $ResitrctRDPSessions
            Write-Host "PageFileLabel        : " $PageFileLabel
            Write-Host "PageFileLocation     : " $PageFileLocation
            
            ### Windows Features
            ### -----------------------------------------
            $WindowsFeatures  = @()
            $WindowsFeatures += "NET-Framework-Features"
            $WindowsFeatures += "NET-Framework-Core"
            $WindowsFeatures += "GPMC"
            $WindowsFeatures += "Telnet-Client"
            #$WindowsFeatures += "RSAT"
            $global:WindowsFeatures = $WindowsFeatures
         
            # Server Build Functions
            #--------------------------
            
            if ($Step -eq "xyz")
            {
                #Do-Something1
                #Rename-Computer
                #Set-RegKey
                #Pause-Script
                #Reboot-Resume
                #Update-Windows
            }

            if ($Step -eq "xyz")
            {
                #Do-Something2
                Invoke-Test
                
                #Pause-Script
                #Verify-ComputerRename
                #Rename-Interface
                #Set-IPv4
                #Set-IPv6
                #Set-SwapFile
                #Add-WindowsFeatures
                #Update-Windows
                #Set-WindowsFirewall
                #Add-WindowsFeatures
                #Rename-LocalAdministrator
                #Join-Domain

                #Disable-AutomaticReboot
                #Create-KitsFolder
                #Create-ScriptsFolder
                #Enable-RemoteDesktop
                #Disable-InternetExplorerESC 

                ### Optional
                #Screen Resolution to 1024 x 768    
                #Set-TimeZone

            }
           
            if ($Step -eq "xyz")
            {
                #Set-RegKey
                #Reboot-Resume
                #Continue
            }
               
        }

         2016_DC{}

         2016_File{}
            
         2016_Citrix{}

         ### Windows Server 2012 R2 Builds
         ###-----------------------------------
         2012R2_Std_Base {}

         2012R2_File{}

         2012R2_DC{}

         2012R2_Citrix{}

    }
}
