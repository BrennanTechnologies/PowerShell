﻿#####################################################
### Function: Import-Script Parameters To Guest VM
#####################################################
function Import-ScriptParametersToGuestVM
{


    ### Import API Parameters


    ### imorpt Script Parameters

}

#####################################################
### Function: Import-API Parameters To Guest VM
#####################################################
function Set-AutomationFolder
{
    $AutomationFolder = "C:\Automation"
    if(-NOT(Test-Path -Path $AutomationFolder)) {New-Item -ItemType directory -Path $AutomationFolder | out-null}
}

#######################################
### Write Parameters from API
#######################################
function Write-ParametersFromAPI
{
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Path = $ParameterFile
    $Destination = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\$ComputerName"
    
    if(-NOT(Test-Path -Path $Destination)) {New-Item -ItemType directory -Path $Destination | Out-Null}

    Copy-Item -Path $Path -Destination $Destination
}


&{

    BEGIN
    {
        #$Step = "1" #<--- Pass Parameter from VMHost
        Start-Transcript
        Write-Host "BEGIN-STEP: $Step"
        Get-BuildType -BuildType 2016_Std_Base
        #Import-APIParametersToGuestVM
        #Import-APIParameters
        #Set-AutomationFolder
        #Write-ParametersFromAPI
        #Write-Host "VM: " $VM
    }
    PROCESS
    {
        Write-Host "PROCESS-STEP: $Step"
        Configure-CDROM 
        Configure-NetworkInterface
        #Configure-IPv4
    }
    END
    {
        Write-Host "END-STEP: $Step"
        Stop-Transcript
    }

}

