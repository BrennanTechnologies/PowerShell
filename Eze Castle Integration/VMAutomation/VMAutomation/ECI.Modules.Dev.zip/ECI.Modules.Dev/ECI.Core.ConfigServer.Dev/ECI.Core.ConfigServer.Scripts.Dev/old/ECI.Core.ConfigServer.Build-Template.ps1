﻿<#
### Parameter File
$ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"

### Dev Server
$DevHost = "ECILAB-BOSAPP1.ecilab.corp"

### VI Servere
$VIServer = "ecilab-bosvcsa01.ecilab.corp"
$VICreds  = "" # -User cbrennan_admin@ecilab.corp -Password W3lcome123!

### Host VM
$HOSTVM = ""
$HostCreds = # -HostUser ezebos\cbrennan -HostPassword Tolkien4374
     
### Guest VM

$global:VM = "RGEE-SRV1" # <-- Param from API???

$GuestCreds = "" # -GuestUser administrator -GuestPassword Tolkien4374
#>

#######################################
### Import VMWare Modules
#######################################
function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: $VMModules"
    }
    <#
    PS C:\Users\cbrennan_admin> Get-Module vm*

    ModuleType Version    Name                                ExportedCommands                                                                                                                   
    ---------- -------    ----                                ----------------                                                                                                                   
    Script     10.0.0.... VMware.VimAutomation.Cis.Core       {Connect-CisServer, Disconnect-CisServer, Get-CisService}                                                                          
    Script     10.0.0.... VMware.VimAutomation.Common                                                                                                                                            
    Script     10.0.0.... VMware.VimAutomation.Core           {Add-PassthroughDevice, Add-VirtualSwitchPhysicalNetworkAdapter, Add-VMHost, Add-VMHostNtpServer...}                               
    Script     10.0.0.... VMware.VimAutomation.Sdk            {Get-InstallPath, Get-PSVersion}  
    #>
}

#######################################
### Function: Connect to ECI VI Server
#######################################
function Connect-ECIVIServer
{

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false #| Out-Null

    <#
    Connecting New Session to VI Server:  ecilab-bosvcsa01.ecilab.corp
    WARNING: There were one or more problems with the server certificate for the server ecilab-bosvcsa01.ecilab.corp:443:

    * The X509 chain could not be built up to the root certificate.

    Certificate: [Subject]
      C=US, CN=ecilab-bosvcsa01.ecilab.corp

    [Issuer]
      O=ecilab-bosvcsa01.ecilab.corp, C=US, DC=local, DC=vsphere, CN=CA

    [Serial Number]
      00E95976D6B9344236

    [Not Before]
      6/22/2015 3:34:28 PM

    [Not After]
      6/16/2025 3:34:27 PM

    [Thumbprint]
      38A7F51B30A4CFAC6A136D0585D77322106CC69E



The server certificate is not valid.
    
WARNING: THE DEFAULT BEHAVIOR UPON INVALID SERVER CERTIFICATE WILL CHANGE IN A FUTURE RELEASE. To ensure scripts are not affected by the change, use Set-PowerCLIConfigura
tion to set a value for the InvalidCertificateAction option.
#>

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Yellow
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Yellow
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    $VISession = Connect-VIServer -Server  $VIServer  -User ezebos\cbrennan -Password Tolkien4374
    }


    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

#######################################
### Import Parameters from API
#######################################
function Import-ParametersFromAPI
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    Write-Host "Importing Parameters from API (or .CSV):" -ForegroundColor Magenta
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Varibles = @()
    foreach ($Parameter in (Import-CSV -path $ParameterFile))
    {
        # Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -scope global
                
        # Verify Variables
        $Varibles += Get-Variable -Name $Parameter.Name
    }  
    
    $Varibles | ft
}

#######################################
### Import Bootstap Module
#######################################
$BootStrapModuleLoader = {

        ### Set VM Execution Policy to ByPass
        Set-ExecutionPolicy Bypass

        ### Connect a Non-Persistent Drive - then Import the ECI.ModuleLoader
        ### ----------------------------------------------------------------------
        $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
        $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
        $global:RootPath = "\\eciscripts.file.core.windows.net\clientimplementation"
        net use * /del
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

        ### Import the Module Loader - Dot Source
        ### ----------------------------------------------------------------------
        . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.ModuleLoader.ps1"
        #. "X:\Root\ECI.ModuleLoader.ps1"

} # END BootStrapModuleLoader

#######################################
### Function: Get Guest VM
#######################################
function Get-GuestVM
{
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}

#######################################
### Function: Restart Guest VM
#######################################
function Reboot-GuestOS
{
    #######################################
    ### Restart Guest VM Computer
    #######################################
    Write-Host "Rebooting Server: $VM" -ForegroundColor Yellow
    Restart-VMGuest -VM $VM -Server $VIServer | Wait-Tools | Out-Null
}

#######################################
### Function: Resume Guest VM
#######################################
function Resume-GuestOS
{
    #######################################
    ### Resume after Restart
    #######################################
    Write-Host "Waiting for Server to Resume: $VM" -ForegroundColor Yellow

    ### Pasuse Script
    ### ---------------------------
    ### Pause to let the Reboot command Start, otherwise the Wait-Tools will respond immediately
    $t = 15 ### Timer for Dev
    #$t = 60 ### Timer for Prod
    Write-Host "Sleeping Script for $t secs ..." -ForegroundColor Gray
    Start-Sleep -Seconds $t

    ### Wait for VM Tools
    ### ---------------------------
    $t = 60 ### Timer for Dev
    #$t = 240 ### Timer for Prod
    Write-Host "Waiting for VMTools to Respond for $t secs ..." -ForegroundColor Gray
    Wait-Tools -VM $VM -TimeoutSeconds $t -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null

    ### Resume Script
    ### ---------------------------
    Write-Host "Resuming after Restart: $VM" -ForegroundColor Yellow

    ### Test VMGuest Connectivity
    ### ---------------------------
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}


##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-ECIVMScript
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host "BEGIN: Invoke-ECIVMScript -Step: $Step" `n('-' * 50) -ForegroundColor Magenta
    
    $ScriptText = {
        
        ### Import BootStrap Module Loader
        ### -------------------------------------------
        #BootStrapModuleLoader#

        ### Pass in Paramters from API/VMHost
        ### ----------------------------------------------------------------------
        $global:Step             = "#Step#"    
        $global:VM               = "#VM#"    
        $global:ComputerName     = "#ComputerName#"
        $global:DomainName       = "#DomainName#"
        $global:IPv4Address      = "#IPv4Addres#"
        $global:SubnetPrefix     = "#SubnetPrefix#"
        $global:DefaultGateway   = "#DefaultGateway#"
        $global:DNS1             = "#DNS1#"
        $global:DNS2             = "#DNS2#"

        Write-Host "`nImported Parameters:`n"('-' * 50)
        Write-Host "Step           : " $Step
        Write-Host "VM             : " $VM
        Write-Host "ComputerName   : " $ComputerName
        Write-Host "DomainName     : " $DomainName
        Write-Host "IPv4Address    : " $IPv4Address
        Write-Host "SubnetPrefix   : " $SubnetPrefix
        Write-Host "DefaultGateway : " $DefaultGateway
        Write-Host "DNS1           : " $DNS1
        Write-Host "DNS2           : " $DNS2
        Write-Host ('-' * 50)
        
        ### Execute Scripts
        ### ----------------------------------------------------------------------
        #. "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.Build-Step1.ps1"

        Write-Host "Step: " $Step
        net use 
        get-psdrive
        <#
            if ($Step -eq "1")
            {
                . "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.Build-Step1.ps1"
            }
            if ($Step -eq "2")
            {
                . "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.Build-Step2.ps1"
            }
            if ($Step -eq "3")
            {
            }
        #>
    }

    function Invoke-ScriptTextBlock
    {
        ### Replace Variables with Literal Values for the Invoke-VMScript 
        ### ----------------------------------------------------------------
        $Params = @{
        "#Step#"            = $Step
        "#VM#"              = $VM
        "#ComputerName#"    = $ComputerName
        "#DomainName#"      = $DomainName
        "#IPv4Addres#"      = $IPv4Address
        "#SubnetPrefix#"    = $SubnetPrefix
        "#DefaultGateway#"  = $DefaultGateway
        "#DNS1#"            = $DNS1
        "#DNS2#"            = $DNS2
        }

        ### Inject Variables into ScriptText Block
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
        }

        ### Inject BootStrap Module Loader into VM Host
        #$ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

        ### Debugging: Write ScriptText Block to Screen
        write-host "ScriptText:"
        $ScriptText

        ### Inovke VMScript    
        Write-Host "Invoking ScriptText: $ScriptTextName" -ForegroundColor Cyan
        $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword Tolkien4374 -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

        ### Check Exit Code for any Errors
        Write-Host $Invoke.ScriptOutput

        if (($Invoke.ExitCode) -eq 0)
        {
            Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
        }
        elseif (($Invoke.ExitCode) -ne 0)
        {
            Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
        }
    }
    Invoke-ScriptTextBlock
}

##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-1
{
    $Step = "1"

    Write-Host "BEGIN: Invoke-1: $Step" `n('-' * 50) -ForegroundColor Magenta
    
    $ScriptText = {
        
        ### Import BootStrap Module Loader
        ### -------------------------------------------
        #BootStrapModuleLoader#

        ### Pass in Paramters from API/VMHost
        ### ----------------------------------------------------------------------
        $global:VM               = "#VM#"    
        $global:ComputerName     = "#ComputerName#"
        $global:DomainName       = "#DomainName#"
        $global:IPv4Address      = "#IPv4Addres#"
        $global:SubnetPrefix     = "#SubnetPrefix#"
        $global:DefaultGateway   = "#DefaultGateway#"
        $global:DNS1             = "#DNS1#"
        $global:DNS2             = "#DNS2#"

        Write-Host "`nImported Parameters:`n"('-' * 50)
        Write-Host "VM             : " $VM
        Write-Host "ComputerName   : " $ComputerName
        Write-Host "DomainName     : " $DomainName
        Write-Host "IPv4Address    : " $IPv4Address
        Write-Host "SubnetPrefix   : " $SubnetPrefix
        Write-Host "DefaultGateway : " $DefaultGateway
        Write-Host "DNS1           : " $DNS1
        Write-Host "DNS2           : " $DNS2
        Write-Host ('-' * 50)
        
        ### Execute Scripts
        ### ----------------------------------------------------------------------
        #. "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.Build-Step1.ps1"

        Write-Host "Step: " $Step

    }

    function Invoke-ScriptTextBlock
    {
        ### Replace Variables with Literal Values for the Invoke-VMScript 
        ### ----------------------------------------------------------------
        $Params = @{
        "#VM#"              = $VM
        "#ComputerName#"    = $ComputerName
        "#DomainName#"      = $DomainName
        "#IPv4Addres#"      = $IPv4Address
        "#SubnetPrefix#"    = $SubnetPrefix
        "#DefaultGateway#"  = $DefaultGateway
        "#DNS1#"            = $DNS1
        "#DNS2#"            = $DNS2
        }

        ### Inject Variables into ScriptText Block
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
        }

        ### Inject BootStrap Module Loader into VM Host
        $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

        ### Debugging: Write ScriptText Block to Screen
        write-host "ScriptText:"
        $ScriptText

        ### Inovke VMScript    
        Write-Host "Invoking ScriptText: $ScriptTextName" -ForegroundColor Cyan
        $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword Tolkien4374 -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

        ### Check Exit Code for any Errors
        Write-Host $Invoke.ScriptOutput

        if (($Invoke.ExitCode) -eq 0)
        {
            Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
        }
        elseif (($Invoke.ExitCode) -ne 0)
        {
            Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
        }
    }
    Invoke-ScriptTextBlock
}
##############################################################################
### Execute the Script
##############################################################################
&{ 

    BEGIN
    {
        Clear-Host
        Write-Host "BEGIN: ConfigServer-BuildTemplate" -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue" ### Hide VMWare Module Progress Bar
        Import-VMWareModules
        Connect-ECIVIServer
        Import-ParametersFromAPI
        
    }

    PROCESS
    {
        Write-Host "PROCESS: ConfigServer-BuildTemplate" -ForegroundColor Yellow
        #Get-GuestVM
        #Stage-VMConfigFiles

        
        Invoke-t1
        #Invoke-ECIVMScript -Step 1
        #Reboot-GuestOS
        #Resume-GuestOS
        #Invoke-ECIVMScript -Step 2

    }

    END
    {
        Write-Host "END: ConfigServer-BuildTemplate" -ForegroundColor Yellow
        #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
    }

}
