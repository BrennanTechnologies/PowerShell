﻿function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\VMAutomation\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | out-null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

function Import-ParametersFromAPIToGuest
{
    Write-Host "`nParameters Imported to $env:COMPUTERNAME `n"('-' * 50)
    Write-Host "Step           : " $Step
    Write-Host "VM             : " $VM
    Write-Host "ComputerName   : " $NewComputerName
    Write-Host "DomainName     : " $DomainName
    Write-Host "IPv4Address    : " $IPv4Address
    Write-Host "SubnetPrefix   : " $SubnetPrefix
    Write-Host "DefaultGateway : " $DefaultGateway
    Write-Host "DNS1           : " $DNS1
    Write-Host "DNS2           : " $DNS2
    Write-Host ('-' * 50)
}

& { ### Uses the Call Operator "&" to Automatically Run

    BEGIN 
    {
        ### Initialize Script
        ###--------------------------
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        Write-Host "BEGINBLOCK-STEP: " $Step
        Import-ParametersFromAPIToGuest
        Get-BuildType -BuildType 2016_Std_Base
        
        #Import-APIParameters
        #Set-AutomationFolder
        #Write-ParametersFromAPI
        #Write-Host "VM: " $VM
    }
    
    PROCESS 
    {
        ### Execute Module Functions
        ###--------------------------
        Write-Host "PROCESSBLOCK-STEP: $Step"
        
        if ($Step -eq "1")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            #Configure-CDROM 
            #Configure-NetworkInterface
            #Configure-IPv6
            write-host "tEST InternetExplorerESC: " $InternetExplorerESC
            Configure-InternetExplorerESC
            #Configure-WindowsFirewall 
            #Configure-WindowsFirewallRules
            #Configure-CDROM 
            #Configure-ECIFolders 
            #Configure-RemoteDesktop
            #Configure-AutomaticReboot
            #Configure-WindowsUpdates 
        }
        if ($Step -eq "2")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Configure-WindowsFeatures 
        }
        if ($Step -eq "3")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Configure-IPv4
        }        
        if ($Step -eq "4")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Configure-SwapFile
        }
        if ($Step -eq "5")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-Computer
        }
        if ($Step -eq "6")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Rename-LocalAdministrator #<-- Need code to Re-Authenticate with new ECIAdmin Credentials
        }
        if ($Step -eq "7")
        {
            Write-Host "Executing ConfigServer Functions: -Step: " $Step
            Join-Domain
        }        
    }

    END 
    {
        ### Close Script
        ###--------------------------
        Write-Host "ENDBLOCK-STEP: $Step"
        Stop-Transcript
    }
}
