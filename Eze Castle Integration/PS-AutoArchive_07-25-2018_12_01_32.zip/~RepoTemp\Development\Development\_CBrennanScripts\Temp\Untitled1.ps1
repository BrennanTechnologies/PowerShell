﻿cls

get-variable * | Remove-Variable | out-null


$domain = "ecicloud.com"
$username = "CN=grarchiving schoenermgmt,OU=Service Accounts,OU=SchoenerMgmt,OU=Clients,DC=ecicloud,DC=com"

#$ADAccounts = Get-ADUser -Server $Domain -Identity $UserName -Properties * #Name,proxyAddresses,UserPrincipalName,samAccountName,GivenName,Surname,EmailAddress,Mail,Displayname,DistinguishedName -ErrorAction silentlycontinue 

#$ADAccounts = Get-ADUser -Server $Domain -Filter {proxyAddresses -ne $Null} -Properties *
#$ADAccounts = Get-ADUser -Server $Domain -SearchBase "OU=Users,OU=SchoenerMgmt,OU=Clients,DC=ecicloud,DC=com" -Filter * -Properties * | where {($_.proxyAddresses).count -eq "0"}
$ADAccounts = Get-ADUser -Server $Domain -SearchBase "OU=Clients,DC=ecicloud,DC=com" -Filter * -Properties * | where {($_.proxyAddresses).count -eq "0"}

#Name,SamAccountName,DistinguishedName,proxyAddresses,UserPrincipalName # | where {$_.proxyAddresses -eq $null}

foreach ($ADAccount in $ADAccounts)
{

    Write-host "Account: " ($ADAccount.proxyAddresses).count
}