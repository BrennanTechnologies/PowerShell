﻿cls

### Set Repository Environments

### Root
$RepoName               = "Eze.Repository.Root"
$RepoRootDrive          = "X"
$RepoRootPath           = "\\eciscripts.file.core.windows.net\clientimplementation"

### Dev
$RepoName               = "Eze.Repository.Dev"
$RepoDevDrive           = "Y"
$RepoDevPath            = "\\eciscripts.file.core.windows.net\clientimplementation\Development"
$RepoDevModulePath      = $RepoDevPath + "\Development\Eze.Modules.Dev"

### Prod
$RepoName               = "Eze.Repository.Prod"
$RepoProdDrive          = "Z"
$RepoProdPath           = "\\eciscripts.file.core.windows.net\clientimplementation\Production"
$RepoProdModulePath     = $RepoProdPath + "\Production\Eze.Modules.Prod"

$EzeRepo = @{ 

    ### Root
    RepoName            = $RepoName
    RepoRootDrive       = $RepoRootDrive
    RepoRootPath        = $RepoRootPath
    ### Dev
    RepoDevName         = $RepoDevName                 
    RepoDevDrive        = $RepoDevDrive              
    RepoDevPath         = $RepoDevPath
    RepoDevModulePath   = $RepoDevModulePath
    ### Prod
    RepoProdName        = $RepoProdName                 
    RepoProdDrive       = $RepoProdDrive              
    RepoProdPath        = $RepoProdPath
    RepoProdModulePath  = $RepoProdModulePath           
}                           
                                    
$EzeRepo = New-Object PSObject -Property $EzeRepo                         

$EzeRepo.RepoDevDrive


### Load Development Environment
### ----------------------------------

### Map Dev Drive      
$NewPSDrive = New-PSDrive -Name $RepoDevDrive  -PSProvider FileSystem -Root $RepoDevPath -Credential $Credentials -Persist -Scope global

### Add the Repository to the PS Module Path
if(-NOT($env:PSModulePath.Contains($RepoDevModulePath))) {$env:PSModulePath = $RepoDevModulePath + ";" + $env:PSModulePath}


exit


### Add the Repository to the PS Module Path
if(-NOT($env:PSModulePath.Contains($RepositoryModulePath))) {$env:PSModulePath = $RepositoryModulePath + ";" + $env:PSModulePath}

### Map Drive to the Cloud Repository
$AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey

#$NewPSDrive = New-PSDrive -Name $RepositoryDrive -PSProvider FileSystem -Root $RepositoryPath -Credential $Credentials -Persist -Scope global
$NewPSDrive = New-PSDrive -Name $RepositoryDrive -PSProvider FileSystem -Root $RepositoryPath -Credential $Credentials -Persist -Scope global

Write-Host "Repositry Drive Mapped: $RepositoryDrive" -ForegroundColor Cyan        
        


#Write-Host "Importing Module: PowerShellGet" -ForegroundColor Cyan        
#Import-Module PowerShellGet


$EzeRepository = @{
    Name = 'EzeRepository'
    SourceLocation = $RepositoryPath
    PublishLocation = $RepositoryPath
    InstallationPolicy = 'Trusted'
}

#Write-Host "Registering Repository: " $EzeRepository.Name -ForegroundColor Cyan        
#Register-PSRepository @EzeRepository

#Write-Host "Getting Repositories: "-ForegroundColor Cyan 
#Get-PSRepository


#Publish-Module -Name CommonFunctions -Repository $EzeRepository.Name -Verbose

#Write-Host "Getting Modules: $EzeRepository.Name"-ForegroundColor Cyan 
#Find-Module -Repository $EzeRepository.Name

Get-Module -ListAvailable
Get-Module -Name Eze.CommonFunctions
Get-Module -Name Citrix.Common.Commands
Get-Module -Name Lync
Import-Module -Name Eze.CommonFunctions
Import-Module -Name Citrix.Common.Commands