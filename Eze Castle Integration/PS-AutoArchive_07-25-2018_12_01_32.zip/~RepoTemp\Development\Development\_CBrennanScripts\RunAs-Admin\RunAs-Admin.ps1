﻿cls
#Start-Transcript

function Use-RunAs
    {    
    # Check if script is running as Adminstrator and if not use RunAs 
    # Use Check Switch to check if admin 

    param([Switch]$Check) 

    $IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()` 
    ).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") 

    if ($Check) { return $IsAdmin }     

    if ($MyInvocation.ScriptName -ne "") 
    {  
        if (-not $IsAdmin)  
        {  
            try 
            {  
                $arg = "-file `"$($MyInvocation.ScriptName)`"" 
                Start-Process "$psHome\powershell.exe" -Verb Runas -ArgumentList $arg -ErrorAction 'stop'  
            } 
            catch 
            { 
                Write-Warning "Error - Failed to restart script with runas"  
                break               
            } 
            exit # Quit this session of powershell 
        }  
    }  
    else  
        {  
            Write-Warning "Error - Script must be saved as a .ps1 file first"  
            break  
        }
    } 

    Use-RunAs


function test
{

    If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
    {
      # Relaunch as an elevated process:

      Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
      exit
    }
    # Now running elevated so launch the script:

    Write-Host "Now Running with Elevated Privlidges"

    #& "d:\long path name\script name.ps1" "Long Argument 1" "Long Argument 2"
    }



function Elevate-Privs1
    {
    # Get the ID and security principal of the current user account
    $WindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $WindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($WindowsID)
 
    # Get the security principal for the Administrator role
    $AdminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator

 
    # Check to see if we are currently running "as Administrator"
    if ($WindowsPrincipal.IsInRole($AdminRole))
    {
       # We are running "as Administrator" - so change the title and background color to indicate this
       Write-Host "Currently Running as Administrator." -ForegroundColor Green

       $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
       $Host.UI.RawUI.BackgroundColor = "DarkBlue"
       clear-host
    }
    else
    {
       # We are not running "as Administrator" - so relaunch as administrator
       Write-Host "Not Running as Administrator." -ForegroundColor Yellow

       # Create a new process object that starts PowerShell
       $NewProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
   
       # Specify the current script path and name as a parameter
       $NewProcess.Arguments = $myInvocation.MyCommand.Definition;
   
       # Indicate that the process should be elevated
       $NewProcess.Verb = "runas";
   
       # Start the new process
       [System.Diagnostics.Process]::Start($NewProcess);
   
       # Exit from the current, unelevated, process
       #exit
    }
 
    # Run your code that needs to be elevated here
    Write-Host -NoNewLine "Press any key to continue..."
    Start-Sleep -Seconds 10000
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

}


#Stop-Transcript