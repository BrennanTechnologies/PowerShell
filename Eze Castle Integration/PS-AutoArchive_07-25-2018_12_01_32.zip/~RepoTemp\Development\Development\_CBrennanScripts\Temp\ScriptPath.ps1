﻿cls

$script:ScriptPath  = split-path -parent $MyInvocation.MyCommand.Definition 
#$ScriptPath = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)
#$ScriptPath

$LogPath = $ScriptPath + "\Logs" 
$LogPath


New-Item -ItemType directory -Path $LogPath