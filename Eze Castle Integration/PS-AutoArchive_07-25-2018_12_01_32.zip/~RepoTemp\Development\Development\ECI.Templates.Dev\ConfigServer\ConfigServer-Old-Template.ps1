﻿
function Import-ParameterFile
{



}

function Log-Config
{
    ### Log Parameter Settings
    ###------------------------------------------------
    Write-Config ('-' * 50) "`nINPUT PARAMETERS: `n" ('-' * 50)  -foregroundcolor Gray
    Write-Config "ServerTemplate:`t`t " $ServerTemplate -foregroundcolor Gray
    Write-Config "NewComputerName:`t " $NewComputerName -foregroundcolor Gray
    Write-Config "NewIPv4Address:`t`t " $NewIPv4Address -foregroundcolor Gray
    Write-Config "NewPrefixLength:`t " $NewPrefixLength -foregroundcolor Gray
    Write-Config "NewDefaultGateway:`t " $NewDefaultGateway -foregroundcolor Gray
    Write-Config "NewPrimaryDNS:`t`t " $NewPrimaryDNS -foregroundcolor Gray
    Write-Config "NewSecondaryDNS:`t " $NewSecondaryDNS -foregroundcolor Gray
    Write-Config "NewDomain:`t`t`t " $NewDomain -foregroundcolor Gray
    Write-Config  ('-' * 50)  -foregroundcolor Gray
}

function Get-TargetInfo
{
    ### Get Target VM Information
    ###------------------------------------------------
   
    $TargetName = (Get-CIMInstance CIM_ComputerSystem).Name
    $VM         = "Get-VM"
    $VMHost     = "Get-VMHost"
    $GuestOS    = "Get-VMHost"
    Write-Config "TARGET INFO: `n" ('-' * 50) -foregroundcolor Gray
    Write-Config "TargetName:`t`t" $TargetName -foregroundcolor Gray
    Write-Config "VMHost:`t`t`t"  $VMHost -foregroundcolor Gray
    Write-Config "GuestOS:`t`t"  $GuestOS -foregroundcolor Gray
    Write-Config  ('-' * 50)  -foregroundcolor Gray


}

function Get-BuildParameters
{

    ### Server Specific "Soft" Parameters
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:NewComputerName    = "BLU-SRVTEST01"
    $global:NewIPv4Address     = "10.61.1.111"
    $global:NewPrefixLength    = "24"
    $global:NewDefaultGateway  = "10.61.1.250"
    $global:NewPrimaryDNS      = "10.61.1.1"
    $global:NewSecondaryDNS    = "10.61.1.2"
    $global:NewDomain          = "ECILAB"

    <#
    USAGE:

    ### Choose a Server Build Template
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:ServerTemplate     = "2016_DC"
    $global:ServerTemplate     = "2016_File"
    $global:ServerTemplate     = "2016_Citrix"
    $global:ServerTemplate     = "2012R2_Std_Base"
    $global:ServerTemplate     = "2012R2_DC"
    $global:ServerTemplate     = "2012R2_File"
    $global:ServerTemplate     = "2012R2_Citrix"
    #>
}

function Execute-Script 
{
    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue

        # Run Functions
        #--------------------------
        Build-Server -ServerTemplate $ServerTemplate  -Step 1 # Requires $ServerTemplate is set in the "Set-BuildParameters" function above.
    }
}

Execute-Script