﻿Param
(
    [Parameter(Mandatory = $False)]
    [String]$Env = "DEV"
)

### Set Repository Environments
#function Set-ECIEnvironment
&{
    [Alias("Set-ECIENV")]
    [Alias("Set-Env")]
    [Alias("SetEnv")]
    [ValidateSet("Dev","Prod")]
    
    Param(
    [Parameter(Mandatory = $False)] [string]$Env = "Dev")

    ### Set Ececution Policy
    ### ------------------------------------
    Set-ExecutionPolicy ByPass -Scope CurrentUser
    
    
    ### Set Repository Name Space
    ###-------------------------------------
    if ($Env -eq "Dev")          {$Environment = "Development"}
    if ($Env -eq "Prod")         {$Environment = "Production"}
    if ($Env -eq "Development")  {$Environment = "Development"}
    if ($Env -eq "Production")   {$Environment = "Production"}

    ### Set Repository Variables
    ###-------------------------------------
        $global:Env             = $Env.ToUpper()
        $global:Environment     = $Environment.ToUpper()
        $global:NameSpace       = "ECI.Repository.$Environment"
        $global:RootDrive       = "X"
        $global:RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
        $global:EnvDrive        = "Y"
        $global:EnvPath         = "\\eciscripts.file.core.windows.net\clientimplementation\" + $Environment
        $global:ModulePath      = $EnvDrive + ":\" + "ECI.Modules." + $Env + "\" ### DO NOT use \\UNC Path in $env:PSModulePath - USE Mapped Drive

    ### Create Repository Object
    ###----------------------------------------------------------------------------------
    $ECI = @{ 
        Environment      = $Environment
        NameSpace        = $NameSpace
        RootDrive        = $RootDrive
        RootPath         = $RootPath
        EnvDrive         = $EnvDrive
        EnvPath          = $EnvPath        
        ModulePath       = $ModulePath
    }                           
    $ECI = New-Object PSObject -Property $ECI  

    ### Write Console Header
    ###----------------------------------------------------------------------------------
    Write-Host ('*' * 15)($ECI.Environment).ToUpper()('*' * 15) -ForegroundColor Cyan
    Write-Host ('-' * 100)  -ForegroundColor Cyan
    Write-Host "Environment    : " $ECI.Environment -ForegroundColor Cyan
    #Write-Host "NameSpace      : " $ECI.NameSpace -ForegroundColor Cyan
    #Write-Host "RootDrive      : " $ECI.RootDrive -ForegroundColor Cyan
    #Write-Host "RootPath       : " $ECI.RootPath -ForegroundColor Cyan
    Write-Host "RootDrive/Path : " $ECI.RootDrive "=" $ECI.RootPath -ForegroundColor Cyan
    #Write-Host "EnvDrive       : " $ECI.EnvDrive -ForegroundColor Cyan
    #Write-Host "EnvPath        : " $ECI.EnvPath -ForegroundColor Cyan
    Write-Host "EnvDrive/Path  : " $ECI.EnvDrive "=" $ECI.EnvPath  -ForegroundColor Cyan
    Write-Host "ModulePath     : " $ECI.ModulePath -ForegroundColor Cyan
    #Write-Host "PSScriptRoot   : " $PSScriptRoot -ForegroundColor Cyan
    Write-Host ('-' * 100)  -ForegroundColor Cyan
    
    ### Clear PSModulePath  
    ###--------------------------------------
    ### Orginal State of Path Varibale Plus
    # $CleanPath = ($env:PSModulePath.Split(";") | Where-Object { $_ -notlike "*Eci.Modules*"}) -join ';'  # Orginal State of Path Varibale Plus
    
    ### Out-of-Box Path Varibale Plus
    $CleanPath = "C:\Users\$env:UserName\Documents\WindowsPowerShell\Modules;C:\Program Files\WindowsPowerShell\Modules;C:\Windows\system32\WindowsPowerShell\v1.0\Modules\" # Out-of-Box Path Varibale Plus
    
    ### Add ECI.ModulePath
    $ENV:PSModulePath = $ECI.ModulePath + ";" + $CleanPath

    ### Create Credentials
    ###--------------------------------------
    $AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    
    ### Remove Environmental Drives
    ###--------------------------------------
    $PSEnvDrives  = Get-PSDrive -PSProvider FileSystem | Where-Object {($_.DisplayRoot -like "*eciscripts*")}
    if($PSEnvDrives)
    {
        foreach($PSEnvDrive in $PSEnvDrives)
        {
            #Write-Host "Removing Drive: $PSEnvDrive" -ForegroundColor Yellow
            Remove-PSDrive -Name $PSEnvDrive -PSProvider FileSystem -Force
        }
    }
    
    ### Map Environmental Drives
    ###--------------------------------------
    # Write-Host "Mapping Root Drive: $RootDrive $RootPath" -ForegroundColor Yellow
    $global:PSRootDrive = New-PSDrive -Name $ECI.RootDrive -PSProvider FileSystem -Root $ECI.RootPath -Credential $Credentials -Scope global -ErrorAction SilentlyContinue -Persist | Out-Null

    # Write-Host "Mapping Environment Drive: EnvDrive $EnvPath" -ForegroundColor Yellow
    $global:PSEnvDrive  = New-PSDrive -Name $ECI.EnvDrive  -PSProvider FileSystem -Root $ECI.EnvPath  -Credential $Credentials -Scope global -Persist -ErrorAction SilentlyContinue | Out-Null

    ### Unload Previously Loaded modules
    ###--------------------------------------
    $LoadedECIModules = Get-Module | Where-Object {($_.Name -like "ECI.*")}
    foreach ($LoadedECIModule in $LoadedECIModules)
    {
        Write-Host "Unloading ECI Module: " $LoadedECIModule -ForegroundColor Yellow
        Remove-Module -Name $LoadedECIModule.Name
    }

    ### Import ECI Core Modules
    ###--------------------------------------
    $ECIModules = Get-Module -ListAvailable -Name ECI.Core*
    foreach ($ECIModule in $ECIModules)
    {
        Write-Host "Importing Module: $ECIModule" -ForegroundColor Green
        Import-Module -Name $ECIModule -DisableNameChecking -Global -Force #-Prefix ECI
    
    }
    
    ### Set Propmpt & Location 
    ###--------------------------------------
    Set-Location ($EnvDrive + ":\")
    function global:Prompt {"[ECI-$Env] $(Get-Location) > "}

}

#Set-ECIEnvironment $Env


