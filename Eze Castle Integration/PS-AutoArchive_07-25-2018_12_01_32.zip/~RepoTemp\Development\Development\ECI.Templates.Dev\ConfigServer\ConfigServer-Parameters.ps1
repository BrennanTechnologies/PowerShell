﻿### Server Build Parameters
### --------------------------------------


### Server Specific "Soft" Parameters
###------------------------------------------------
$global:BuildType          = "2016_Std_Base"
$global:NewComputerName    = "BLU-SRVTEST01"
$global:NewIPv4Address     = "10.61.1.111"
$global:NewPrefixLength    = "24"
$global:NewDefaultGateway  = "10.61.1.250"
$global:NewPrimaryDNS      = "10.61.1.1"
$global:NewSecondaryDNS    = "10.61.1.2"
$global:NewDomain          = "ECILAB"


### BuildType
2016_Std_Base 
{
    ### Server BuildType "Hard" Parameters
    $global:NewInterfacename    = "Ethernet01"
    $global:Ipv6Preference      = "Enable"
    $global:NewCDLetter         = "R:"
    $global:NewLocalAdminName   = "ECIAdmin1"

    ### BuildType: 2016_Std_Base - Windows Features
    $WindowsFeatures  = @()
    $WindowsFeatures += "NET-Framework-Features"
    $WindowsFeatures += "NET-Framework-Core"
    $WindowsFeatures += "GPMC"
    $WindowsFeatures += "RSAT"
    $WindowsFeatures += "Telnet-Client"
    $global:WindowsFeatures = $WindowsFeatures
}

### BuildType
2016_DC 
{
    ### Server BuildType "Hard" Parameters
    $global:NewInterfacename    = "Ethernet01"
    $global:Ipv6Preference      = "Enable"
    $global:NewCDLetter         = "R:"
    $global:NewLocalAdminName   = "ECIAdmin1"

    ### BuildType: 2016_Std_DC - Windows Features
    $WindowsFeatures  = @()
    $WindowsFeatures += "ActiveDirectory"
    $WindowsFeatures += "NET-Framework-Features"
    $WindowsFeatures += "NET-Framework-Core"
    $WindowsFeatures += "GPMC"
    $WindowsFeatures += "RSAT"
    $WindowsFeatures += "Telnet-Client"
    $global:WindowsFeatures = $WindowsFeatures
}