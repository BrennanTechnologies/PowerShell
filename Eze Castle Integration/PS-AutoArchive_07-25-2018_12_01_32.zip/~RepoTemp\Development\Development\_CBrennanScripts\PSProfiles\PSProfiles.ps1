﻿### PowerShell Profiles
    <#    
    ### Current User, Current Host - console
    "$Home\[My ]Documents\WindowsPowerShell\Profile.ps1"

    ### Current User, All Hosts   
    "$Home\[My ]Documents\Profile.ps1"

    ### All Users, Current Host - console   
    "$PsHome\Microsoft.PowerShell_profile.ps1"

    ##All Users, All Hosts      
    "$PsHome\Profile.ps1"

    ##Current user, Current Host - ISE
    "$Home\[My ]Documents\WindowsPowerShell\Microsoft.PowerShellISE_profile.ps1"

    ## All users, Current Host - ISE  
    "$PsHome\Microsoft.PowerShellISE_profile.ps1"
    #>    
    <#
    ###Current user, PowerShell ISE
    $PROFILE.CurrentUserCurrentHost # or $PROFILE
    ### All users, PowerShell ISE
    $PROFILE.AllUsersCurrentHost
    ### Current user, All hosts	
    $PROFILE.CurrentUserAllHosts
    ### All users, All hosts	
    $PROFILE.AllUsersAllHosts
    #>