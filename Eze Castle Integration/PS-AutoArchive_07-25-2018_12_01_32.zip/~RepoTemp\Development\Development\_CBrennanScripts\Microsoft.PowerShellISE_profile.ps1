### Microsoft.PowerShellISE_profile.ps1

### Dot Source Auto Run Import-ECI.Root.ModuleLoader.ps1
. ((Split-Path $PROFILE -Parent) + "\Import-ECI.Root.ModuleLoader.ps1")