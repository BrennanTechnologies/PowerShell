<#
#Set-ExecutionPolicy unrestricted

# DISCLAIMER: There are no warranties or support provided for this script. Use at you're own discretion.
# Andy Syrewicze and/or Altaro Software are not liable for any
# damage or problems that misuse of this script may cause.
 
# Script is Written by Andy Syrewicze - Tech. Evangelist with Altaro Software and is free to use as needed within your organization.
# Edited by Roger McCarrick - May 18 2017
# Ben Coughtry wrote the error checking function "errorCheck"
 
# This Script is Primarily a Deployment Script. It will import a csv file with a list of variables for each VM.
# It will deploy each VM from template from your vSphere environment and apply a customization specification.
# If the VM is a DC it will install and configure Active Directory Domain Services
# All other VMs will be joined to the domain. That domain is either on the new DC or already exists.
 
# Script was designed for PowerShell/PowerCLI Beginners who have not yet begun to work with functions and more advanced PowerShell features. 
# The below script first lists all user definable varibles and then executes the script's actions in an easy to follow sequential order. 
# The below script first lists all user definable varibles and then executes the script's actions in an easy to follow sequential order. 
 
# Assumptions
# - You Have vCenter inside your environment
# - You have pre-configured templates and customization specifications inside of vCenter
# - Your PowerShell execution policy allows the execution of this script

# Input paramters definition.  File path supplied when calling this script represents CSV file of VMs to be built
#>
	
	
Param(
        [parameter(Mandatory=$true, HelpMessage="Full File path of CSV")]
        [string]$csvFilePath
        )
		
# Get start date. Will use it at the end to see how long it takes for the script to run.
################################################### - User-Definable Variables-In-This-Section - ###################################################
$SDATE = Get-Date

# Disconnect from all VCenters
Write-Host -foreground "White" " Disonnecting from all current VCenters "
Disconnect-VIServer * -Force  -confirm:$false -ErrorAction SilentlyContinue | Out-Null

# Set the names of the template and customization file 
#$VMTemplate = "W2K16v2-Automation"
$VMTemplate = "W2K16v2"
$VMCustomSpec	= "Server-2016R2-ProductKey-SID"
$DomainMode = "7"
$ForestMode = "7"

#########################################################################################
#   FUNCTION DEFINITION - This function performs error checking of inputs given by CSV  #
#########################################################################################
function errorCheck([array]$vmList){

    $vmList | Export-Csv .\ArrayBeforeErrorCheck.csvc
    
    Write-Host "`r`n=========================================================================="
    Write-Host "`r`n...Error checking input CSV..."
    $csvErrorsFoundBool = "No"                #Boolean value representing if csv contains input errors that will prevent script from completing
    $csvErrorCount = 0                        #Count of errors found
    $csvWarningsFound = "No"                  #Boolean value representing if csv contains input warnings that will not prevent script from completing
    $csvErrors = @()                          #Array definition to be populated with errors found


    # Make sure all GPID entries match each other, report error if any are different
    $gpids = $vmList | Group {$_.GPID}
    $gpidCount = $gpids | measure
    if($gpidCount.Count -gt 1)
    {
        $csvErrorsFoundBool = "Yes"
        $csvErrorCount ++
        $csvErrors += "  $csvErrorCount - ERROR - GPID of each VM should match however VMs with differing GPIDs were found"
    }

    
    # Make sure all VM Names are unique and not blank, report error on any duplicates or blanks
    $vmNames = $vmList | Group {$_.VMNAME}
    foreach($vmName in $vmNames){
        if($vmName.Count -gt 1 -or !$vmName.Name){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine Name '"+$vmName.Name+"' VM Name is either blank or appears more than once"
        }
    }


    # Make sure there is only 1x Virtual Machine with Role "DC-Pri".  This will be the first DC built from which a domaim forest will be created.
    [array]$vmDC1s = $vmList | Where-Object {$_.SRVROLE -eq "DC-Pri"}
    if($vmDC1s.Count -eq 0){
        $csvWarningsFound = "Yes"
        $csvErrorCount++
        $csvErrors += "  $csvErrorCount - WARNING - no primary DC has been defined. AD forest MUST already exist and DNS configured"
    }
    elseif($vmDC1s.count -eq 1){
        $csvWarningsFound = "Yes"
        $csvErrorCount++
        $csvErrors += "  $csvErrorCount - WARNING - server with DC-Pri role found. AD forest will be created from this VM and MUST NOT already exist"
    }
    elseif($vmDC1s.count -gt 1){
       $csvErrorsFoundBool = "Yes"
       $csvErrorCount ++
       $csvErrors += "  $csvErrorCount - ERROR - There must be only 1 server with DC-Pri role (Primary Domain Controller) but there can be many DC-Sec servers"
    }
   

    # Make sure all VM IPs are unique, report error on any duplicates.  Blanks are OK here because VMs built on Azure will not get IPs from this csv.
    $vmIps = $vmList | Group {$_.IPAddress}
    foreach($Ip in $vmIps){
        if($Ip.Count -gt 1 -and $Ip.Name){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine IP '"+$Ip.Name+"' appears more than once"
        }
    }
    

    # Loop through VMs to find additional errors or missing mandatory variables
    $i = 0        #VM interation variable as we loop through VMs in CSV
    while($i -lt $vmList.count){
        $vm = $vmList[$i]

        
        # Make sure VM's Product is either Azure or EciCloud and reject anything else
        if($vm.PRODUCT -ne "AZURE" -and $vm.PRODUCT -ne "ECICLOUD"){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' must be for Product AZURE or ECICLOUD"
        }
        
 
        # Make sure VM's GPID is AlphaNumeric and contains exactly 8 characters
        if($vm.GPID -match "\W+" -or $vm.GPID.Length -ne 8){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' has GPID must contain exactly 8x alphanumeric characters"
        }
        
        
        # Make sure that IF vm is set to join a domain, that a domain name is specified
        if($vm.JOINDOM -eq "TRUE" -and !$vm.CUSTADNAME){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' is set to join a domain but no domain name was specified"
        }


        # Make sure domain name is properly formatted FQDN ("___.___")
        if($vm.JOINDOM -eq "TRUE"){
            $fqdn = $vm.CUSTADNAME.Split(".")
            if($fqdn.count -lt 2 -or (!$fqdn[0] -or !$fqdn[1])){
                $csvErrorsFoundBool = "Yes"
                $csvErrorCount++
                $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' has invalid Domain Name.  Must be at least (__.__)"
            }
        }
        
        
        # Make sure VM Type is a valid entry for ECICLOUD VMs
        [array]$serverTypes = "IN01002","IN01004","IN02004","IN02008","IN04008","IN04016","IN04032","IN06016","IN06048","IN08032","IN08064"
        if($vm.PRODUCT -match "ECICLOUD" -and $serverTypes -notcontains $vm.VMTYPE){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' has invalid VMTYPE"
        }


        # Make sure Location is a valid entry for AZURE VMs.  This is a mandatory field
        [array]$azureLocations = "eastasia","southeastasia","centralus","eastus","eastus2","westus","northcentralus","southcentralus","northeurope","westeurope","japanwest","japaneast","brazilsouth","australiaeast","australiasoutheast","southindia","centralindia","canadacentral","canadaeast","uksouth","ukwest","westcentralus","westus2","koreacentral","koreasouth"
        if($vm.PRODUCT -match "AZURE" -and $azureLocations -notcontains $vm.LOCATION){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine '"+$vm.VMNAME+"' has either invalid or blank Location"
        }


        # Make sure 'DATACENTER' both populated and a valid entry for ECICLOUD VMs
        [array]$eciDatacenters = "ECI-BOS","ECI-QTS","ECI-SAC","ECI-LHC","ECI-LD5","ECI-HK","ECI-SG"
        if($vm.PRODUCT -match "ECICLOUD" -and $eciDatacenters -notcontains $vm.LOCATION){
            do{
                $x = 1
                Write-Host "`r`n...DataCenter for VM "$vm.VMNAME" not defined.  Chose Number of preferred DataCenter below:"
                foreach($dc in $eciDatacenters){
                    Write-Host "$x - $dc"
                    $x++
                }
                $answer = Read-Host "...Enter choice"
            }until($answer -gt 0 -and $answer -le $eciDatacenters.count)
            $answer2 = $answer - 1
            $dc = $eciDatacenters[$answer2]
            $vm.LOCATION = $dc
            write-host "choice $answer -> "$vm.LOCATION
        }
        

        # IF AN AZURE VM, make sure Azure VM Size definition is available in the Azure Location specified
        ##if($vm.PRODUCT -match "AZURE" -and $vm.LOCATION){
        ##    $vmSizes = Get-AzureRmVMSize -Location $vm.LOCATION | select Name
        ##    $exists = "No"
        ##    foreach($size in $vmSizes){
        ##        if($size.Name -eq $vm.AZ_VMSIZE){
        ##            $exists = "Yes"
        ##        }
        ##    }
        ##    if($exists -match "No"){
        ##        $csvErrorsFoundBool = "Yes"
        ##        $csvErrorCount++
        ##        $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine "+$vm.VMNAME+" is set for a TYPE not available in its given LOCATION"
        ##   }
        ##}
        ##elseif($vm.PRODUCT -match "AZURE" -and !$vm.LOCATION){
        ##    $csvErrorsFoundBool = "Yes"
        ##    $csvErrorCount++
        ##    $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine "+$vm.VMNAME+" MUST have a LOCATION (MS Datacenter) chosen"
        ##}
               


        # Make sure JOINDOM (join domain boolean) is either TRUE or FALSE.  Error on anything else
        if($vm.JOINDOM -ne "TRUE" -and $vm.JOINDOM -ne "FALSE"){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine "+$vm.VMNAME+" JOINDOM field (join domain) must be set to TRUE or FALSE"
        }


        # Make sure SRVROLE field is populated and is valid
        [array]$vmRoles = "DC-Pri","DC-Sec","CTX","APP","SQL"
        if($vmRoles -notcontains $vm.SRVROLE -or !$vm.SRVROLE){
            $csvErrorsFoundBool = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - Virtual Machine "+$vm.VMNAME+" has invalid ROLE or ROLE is blank"
        }
        
        
        # WARN if IP Address field is not NULL for AZURE VMs.  VMs built in AZURE will use DHCP with reservation only.
        if($vm.PRODUCT -match "AZURE" -and $vm.IPAddress){
            $csvWarningsFound = "Yes"
            $csvErrorCount++
            $csvErrors += "  $csvErrorCount - ERROR - WARNING - Virtual Machine "+$vm.VMNAME+" will not use specified IP address, IP will be assigned via Azure DHCP"
        }
        
        
        # If an AZURE VM, and 'AZ_RESOURCEGP' not supplied by CSV, get existing objects and prompt user to chose or create a new Resource Group in given location
        # Create ResourceGroup if necessary but do not create Subnets or VNets as they should already exist at the time this script runs.
        ##if($vm.PRODUCT -eq "AZURE" -and $vm.LOCATION -and !$vm.AZ_RESOURCEGRP){
        ##    [array]$allResourceGroups = Get-AzureRmResourceGroup | select ResourceGroupName,Location | Where-Object {$_.Location -match $vm.LOCATION}
        ##   if($allResourceGroups.count -gt 0){
        ##        do{
        ##            $x = 1
        ##            Write-Host "`r`n...Azure Resource Group for VM "$vm.VMNAME" not defined.  Chose Number of preferred Resource Group below:"
        ##            foreach($rg in $allResourceGroups){
        ##                Write-Host "$x -"$rg.ResourceGroupName
        ##                $x++
        ##            }
        ##            $answer = Read-Host "...Enter choice"
        ##       }until($answer -gt 0 -and $answer -le $allResourceGroups.count)
        ##       $answer2 = $answer - 1
        ##        $rg = $allResourceGroups[$answer2]
        ##        $vm.AZ_RESOURCEGRP = $rg.ResourceGroupName
        ##       write-host "choice $answer -> "$vm.AZ_RESOURCEGRP
        ##    }
        ##    else{
        ##        $rgName = $vm.GPID + "_" + $vm.LOCATION
        ##        Write-Host "`r`n...Azure Resource Group for VM "$vm.VMNAME" undefined and none exist.  Defining Group '$rgName' ..."
        ##        $vm.AZ_RESOURCEGRP = $rgName
         ##   }
        ##}


  ##      # If an AZURE VM and 'AZ_VNET' not supplied by CSV, get existing vNets and prompt user to chose
  ##      # OR if 'AZ_VNET' is supplied, make sure it exists in portal and is valid.
  ##      if($vm.PRODUCT -eq "AZURE" -and $vm.LOCATION -and !$vm.AZ_VNET){
  ##          [array]$allVnets = Get-AzureRmVirtualNetwork | select Name,Location | Where-Object {$_.Location -match $vm.LOCATION}
  ##          if($allVnets.count -gt 0){
  ##              do{
  ##                  $x = 1
  ##                  Write-Host "`r`n...Azure VNET for VM "$vm.VMNAME"not defined.  Chose Number of preferred Resource Group below:"
  ##                  foreach($vNet in $allVnets){
  ##                      Write-Host "$x -"$vNet.Name
  ##                      $x++
  ##                  }
  ##                  $answer = Read-Host "...Enter choice"
  ##              }until($answer -gt 0 -and $answer -le $allVnets.count)
  ##              $answer2 = $answer - 1
  ##              $vNet = $allVnets[$answer2]
  ##              $vm.AZ_VNET = $vNet.Name
  ##             write-host "choice $answer -> "$vm.AZ_VNET
  ##          }
  ##          else{
  ##              $csvErrorsFoundBool = "Yes"
  ##              $csvErrorCount++
  ##              $csvErrors += "  $csvErrorCount - ERROR - No Azure Virtual Networks found in location "+$vm.LOCATION+". Azure networking must be setup before deploying Azure VMs here"
  ##          }
  ##      }
  ##      elseif($vm.PRODUCT -eq "AZURE" -and $vm.LOCATION -and $vm.AZ_VNET){
  ##          [array]$allVnets = Get-AzureRmVirtualNetwork | select Name,Location | Where-Object {$_.Location -match $vm.LOCATION}
  ##          if($allVnets.count -gt 0){
  ##              $x = 0
  ##              $vnetFound = "false"
  ##              while($x -lt $allVnets.count){
  ##                  if($allVnets[$x].Name -eq $vm.AZ_VNET){
  ##                      $vnetFound = "true"
  ##                  }
  ##                  $X++
  ##              }
  ##             if($vnetFound -eq "false"){
  ##                  do{
  ##                      $x = 1
  ##                      Write-Host "`r`n...For VM "$vm.VMNAME", vNET "$vm.AZ_VNET" was not found.  Chose Number of preferred VNET below:"
  ##                      foreach($vNet in $allVnets){
  ##                          Write-Host "$x -"$vNet.Name
  ##                          $x++
  ##                      }
  ##                      $answer = Read-Host "...Enter choice"
  ##                  }until($answer -gt 0 -and $answer -le $allVnets.count)
  ##                  $answer2 = $answer - 1
  ##                  $vNet = $allVnets[$answer2]
  ##                  $vm.AZ_VNET = $vNet.Name
  ##                  write-host "choice $answer -> "$vm.AZ_VNET
  ##              }
  ##          }
  ##          else{
  ##              $csvErrorsFoundBool = "Yes"
  ##              $csvErrorCount++
  ##              $csvErrors += "  $csvErrorCount - ERROR - No Azure Virtual Networks found in location "+$vm.LOCATION+". Azure networking must be setup before deploying Azure VMs here"
  ##          }
  ##      }


        # If an Azure VM, and 'AZ_SUBNET' not supplied by CSV, get existing objects and prompt user to chose which to use in given location
        # OR if an Azure VM and 'AZ_SUBNET' is specified, make sure it exists in portal and is valid.
  ##      if($vm.PRODUCT -eq "AZURE" -and $vm.LOCATION -and $vm.AZ_VNET -and !$vm.AZ_SUBNET){
  ##          $allSubnets = Get-AzureRmVirtualNetwork | Where-Object {$_.Name -eq $vm.AZ_VNET} | Get-AzureRmVirtualNetworkSubnetConfig | select Name,AddressPrefix
  ##          if($allSubnets.count -gt 0){
  ##              do{
  ##                  $x = 1
  ##                  Write-Host "`r`n...Azure SUBNET for VM "$vm.VMNAME" not defined.  Chose Number of preferred Resource Group below:"
  ##                  foreach($snet in $allSubnets){
  ##                      Write-Host "$x -"$snet.Name : $snet.AddressPrefix
  ##                      $x++
  ##                  }
  ##                  $answer = Read-Host "...Enter choice"
  ##              }until($answer -gt 0 -and $answer -le $allSubnets.count)
  ##              $answer2 = $answer - 1
  ##              $snet = $allSubnets[$answer2]
  ##              $vm.AZ_SUBNET = $snet.Name
  ##              write-host "choice $answer -> "$vm.AZ_SUBNET
  ##          }
  ##         else{
  ##              $csvErrorsFoundBool = "Yes"
  ##              $csvErrorCount++
  ##              $csvErrors += "  $csvErrorCount - ERROR - No Azure Virtual Networks found in location "+$vm.LOCATION+". Azure networking must be setup before deploying Azure VMs here"
  ##          }
  ##      }
  ##      elseif($vm.PRODUCT -eq "AZURE" -and $vm.LOCATION -and $vm.AZ_VNET -and $vm.AZ_SUBNET){
  ##          $allSubnets = Get-AzureRmVirtualNetwork | Where-Object {$_.Name -eq $vm.AZ_VNET} | Get-AzureRmVirtualNetworkSubnetConfig | select Name,AddressPrefix
  ##          if($allSubnets.count -gt 0){
  ##              $x = 0
  ##              $subnetFound = "false"
  ##              while($x -lt $allSubnets.count){
  ##                  if($allSubnets[$x].Name -eq $vm.AZ_SUBNET){
  ##                      $subnetFound = "true"
  ##                  }
  ##                  $X++
  ##              }
  ##              if($subnetFound -eq "false"){
  ##                  do{
  ##                      $x = 1
  ##                      Write-Host "`r`n...For VM "$vm.VMNAME", SUBNET "$vm.AZ_SUBNET" was not found.  Chose Number of preferred SUBNET below:"
  ##                      foreach($sNet in $allSubnets){
  ##                          Write-Host "$x -"$sNet.Name : $sNet.AddressPrefix
  ##                          $x++
  ##                      }
  ##                      $answer = Read-Host "...Enter choice"
  ##                  }until($answer -gt 0 -and $answer -le $allSubnets.count)
  ##                  $answer2 = $answer - 1
  ##                  $sNet = $allSubnets[$answer2]
  ##                  $vm.AZ_SUBNET = $sNet.Name
  ##                  write-host "choice $answer -> "$vm.AZ_SUBNET
  ##              }
  ##          }
  ##          else{
  ##              $csvErrorsFoundBool = "Yes"
  ##              $csvErrorCount++
  ##              $csvErrors += "  $csvErrorCount - ERROR - No Azure Subnets found within VNET "+$vm.AZ_VNET+". Azure networking must be setup before deploying Azure VMs"
  ##          }
  ##      }
        
        
        $i++  # Increment iteration variable and repeat While loop until breakout condition is reached
    } # END OF WHILE LOOP
	



    #  Error checking complete.  If errors were found script will terminate.  If No errors but warnings were found, give user the option to 
    #    continue or not.  If no errors or warnings were found, inform the user and proceed with build.
    Write-Host "`r`n=========================================================================="
    Write-Host "`r`nError checking complete...."
    if($csvErrorsFoundBool -eq "Yes"){
        Write-Host "`r`n**  Too many errors were found in input csv.  Script will terminate and no VMs will be built."
        Write-Host "**  Please fix entries below and rerun script later."
        Write-Host "`r`nERRORS:"
        foreach($issue in $csvErrors){write-host $issue}
        write-host ""
        pause
        exit
    }
    elseif($csvErrorsFoundBool -eq "No" -and $csvWarningsFound -eq "Yes"){
        Write-Host "`r`n**  Warnings were found in input CSV.  Script CAN proceed with the builds if you like."
        foreach($issue in $csvErrors){write-host $issue}
        do{
            $answer = read-host "`r`n  Enter 'Y' to continue with the provided build, or 'N' to terminate script"
            if($answer -match "N"){
                Write-Host "`r`nYou have entered $answer so script will terminate and no VMs will be built.  Please try again later."
                exit
            }
            elseif($answer -match "Y"){
                Write-Host "`r`nYou have entered $answer, opting to proceed to building VMs as input.  Proceeding..."
            }
        }while($answer -notmatch "y" -and $answer -notmatch "n")
    }
    elseif($csvErrorsFoundBool -eq "No" -and $csvWarningsFound -eq "No"){
        Write-Host "`r`n** No errors or warnings were found in the input CSV!"
        Write-Host "`r`n** Press 'Enter' to continue and build VMs per CSV input, or Press 'Ctrl-C' to terminate..."
        pause
    }
    else{
        write-host "`r`nSCRIPT ERROR @ END OF ERROR CHECKING.  THIS CONDITION SHOULD NOT HAVE BEEN MET.  SCRIPT WILL TERMINATE"
        write-host "CSV Errors: $csvErrorsFoundBool; CSV Warnings: $csvWarningsFound"
        pause
        exit
    }


    $vmList | Export-Csv .\ArrayCorrectedEndOfErrorFunc.csv

    ##return $vmList  # Pass corrected version of the array back to the global script


} # END OF 'errorCheck' FUNCTION DEFINITION
# END OF 'errorCheck' FUNCTION DEFINITION


# Import CSV file into array, VM names, IP settings, domain name and server roles, etc
[array]$csvArray = Import-Csv -Path $csvFilePath



	# Configure DC1 first if it exists AND if it is to be configured in ECICLOUD
	# Create $configArray array which can be referenced in the configuration phase.
	[array]$configArray = @()
	[array]$finishedAzureVMs = @()

	
	# Create arrays for DC-pri and DC-sec if they exist 
	[array]$vmDC1s = $csvArray | Where-Object {$_.SRVROLE -eq "DC-Pri"}
    [array]$vmDC2s = $csvArray | Where-Object {$_.SRVROLE -eq "DC-Sec"}
	
	if($vmDC1s.PRODUCT -eq "ECICLOUD")
	{
	$finishedAzureVMs += $vmDC1s.VMNAME
	
	# Add rows with headers to $configArray.
	$mrow = "" | Select "VMname", "Location", "IPaddress", "SubnetMAsk", "Gateway", "DNSIP", "SRVROLE", "PRODUCT", "PRODTYPE", "VMTYPE", "JOINDOM"
	$mrow."vmname" = $vmDC1s.vmname
	$mrow."location" = $vmDC1s.location
	$mrow."ipaddress" = $vmDC1s.ipaddress
	$mrow."SubnetMask" = $vmDC1s.SubnetMask
	$mrow."Gateway" = $vmDC1s.Gateway
	$mrow."DNSIP" = $vmDC1s.DNSIP
	$mrow."SRVROLE" = $vmDC1s.SRVROLE
	$mrow."PRODUCT" = $vmDC1s.PRODUCT
	$mrow."VMTYPE" = $vmDC1s.VMTYPE
	$mrow."JOINDOM" = $vmDC1s.JOINDOM
	$configArray += $mrow
        
     }
     
	 
     # Begin 'While loop' through each VM.  If its PRODUCT is ECICLOUD and its name doesn't appear in the sortedArray
     # variable configure it as CSV specifies:  join to AD domain, set standard options, install Citrix, etc
     $i = 0
     while($i -lt $csvArray.count){
        $vm = $csvArray[$i]
        if($vm.PRODUCT -eq "ECICLOUD" -and $finishedAzureVMs -notcontains $vm.VMNAME){
		
		$finishedAzureVMs += $vm.VMNAME

        # Add rows with headers to $configArray array which can be referenced in the config phase.
		$mrow = "" | Select "VMname", "Location", "IPaddress", "SubnetMAsk", "Gateway", "DNSIP", "SRVROLE", "PRODUCT", "PRODTYPE", "VMTYPE", "JOINDOM"
		$mrow."vmname" = $vm.vmname
		$mrow."location" = $vm.location
		$mrow."ipaddress" = $vm.ipaddress
		$mrow."SubnetMask" = $vm.SubnetMask
		$mrow."Gateway" = $vm.Gateway
		$mrow."DNSIP" = $vm.DNSIP
		$mrow."SRVROLE" = $vm.SRVROLE
		$mrow."PRODUCT" = $vm.PRODUCT
		$mrow."PRODTYPE" = $vm.PRODTYPE
		$mrow."VMTYPE" = $vm.VMTYPE
		$mrow."JOINDOM" = $vm.JOINDOM
		$configArray += $mrow           
        }
        $i++
     }
	# End sort with DC1 first 

	
# Call function to error check CSV file.  See Function Definition section above for details
errorCheck($csvArray)


# Create empty arrays for datacenters, RAM and CPU.
$locArray = @()
$ramArray = @()
$cpuArray = @()
$dcrArray = @()
$BNRPool = @()


#########################################################################################
#   FUNCTION DEFINITION - This function sets the VClocation for Powershell to connect   #
#########################################################################################
function vCenterFnctn
	{
		if ($VClocation -eq "ECI-BOS") {$vCenterChoice = "bosvc.eci.cloud"
	return $vCenterChoice}
	
	if ($VClocation -eq "ECI-QTS") {$vCenterChoice = "cloud-qtsvc.eci.corp"
	return $vCenterChoice}

	if ($VClocation -eq "ECI-SAC") {$vCenterChoice = "sacvc.eci.cloud"
	return $vCenterChoice}

	if ($VClocation -eq "ECI-LHC") {$vCenterChoice = "lhcvc.eci.cloud"
	return $vCenterChoice}

	if ($VClocation -eq "ECI-LD5") {$vCenterChoice = "ld5vc.eci.cloud"
	return $vCenterChoice}

	if ($VClocation -eq "ECI-HK") {$vCenterChoice = "hkvc.eci.cloud"
	return $vCenterChoice}

	if ($VClocation -eq "ECI-SG") {$vCenterChoice = "sgvc.eci.cloud"
	return $vCenterChoice}

}
# End function to set VClocation

# Get GPID, PRODTYPE and domain name from CSV depending on whether there is one one of more entries 
	if ($csvArray.count -eq 1){
		$GPID = $csvArray.gpid
		$PRODTYPE = $csvArray.prodtype
		$DomainName = $csvArray.CustADName
	}
	else {
	$GPID = $csvArray.gpid[0]
	$PRODTYPE = $csvArray.prodtype[0]
	$DomainName = $csvArray.CustADName[0]
	}
	
	

#NetBios Domain Name
#with a domain name like corp.company.com, Netbios name will be 'company' 
$DomainNetBIOSName =  ($DomainName -split "\.")[1]

# Search csvArray for server rolls that are not DC/CTX - such servers would be considered EMI and have APP as role
$SrvRoleList = $configArray.srvrole | select-string -notmatch "DC|CTX" | Select-Object -Unique |  ForEach { $_ -Replace(" ","") }

# Search csvArray for server rolls that are DC
$DCRoleList = $configArray.srvrole | select-string -allmatches "DC*" | Select-Object -Unique |  ForEach { $_ -Replace(" ","") }

# Get list of ECI datacenter locations  in the CSV
$locationList = $configArray.location  | select-string -allmatches "ECI-" | Select-Object -Unique |  ForEach { $_ -Replace(" ","") }
	
#################################     RESOURCE POOL     #################################
# All VMs will go into a resource pool, production - $emiRESPOOL				  		#
# 														           					    #
#########################################################################################


# Resource pool name depending on PRODTYPE, EMS or EHC
	if ($PRODTYPE -eq "EMS") {
	$basePOOL = "ems2_" + $GPID

}
	if ($PRODTYPE -eq "EHC") {
	$basePOOL = "hybrid2_" + $GPID

}

# If there is a DC-pri and it's in the ECICLOUD then create a emiRESPOOL pool 
# and verify there isn't an existing pool.
# Else if no DC-Pri - check that emiRESPOOL exists - exit if not

if ($vmDC1s -ne "" -and $vmDC1s.PRODUCT -eq "ECICLOUD") {

	# Loop through All VMs to get resource pool CPU and RAM limits

	# Start Instance Based Calculator to get CPU and RAM for the resource pool.
	# Set RAM and CPU counts to zero
	$RAMTot = 0
	$CPUTot = 0

		# Loop through the VMs in csvArray and assign RAM and CPU values.
		foreach ($line in $configArray)	{
			$VMInst = $line.VMType
			$ComputerName = $line.VMName
			$DataCenter = $line.location
			$Product = $line.Product
			$SrvRole = $line.SrvRole
			$dcr = "$DataCenter,$SrvRole,$ComputerName,$Product"
			
 
			# Exclude Azure rows
			# Only include the VMs in the production data center
			
			# Start Instance Based Calculator
			if ($DataCenter -eq $vmDC1s.location)	{

				if     ($VMInst -eq "IN01002"){$RAM = 2; $CPU = 0.6}
				elseif ($VMInst -eq "IN01004"){$RAM = 4; $CPU = 0.6}
				elseif ($VMInst -eq "IN02004"){$RAM = 4; $CPU = 1.5}
				elseif ($VMInst -eq "IN02008"){$RAM = 8; $CPU = 1.5}
				elseif ($VMInst -eq "IN04008"){$RAM = 8; $CPU = 4}
				elseif ($VMInst -eq "IN04016"){$RAM = 16; $CPU = 4}
				elseif ($VMInst -eq "IN04032"){$RAM = 32; $CPU = 4}
				elseif ($VMInst -eq "IN06016"){$RAM = 16; $CPU = 6}
				elseif ($VMInst -eq "IN06048"){$RAM = 48; $CPU = 6}
				elseif ($VMInst -eq "IN08032"){$RAM = 32; $CPU = 8}
				elseif ($VMInst -eq "IN08064"){$RAM = 64; $CPU = 8}
 
				else {
				$RAM = 0
				$CPU = 0
					}

			# Add RAM and CPU to the counts to keep running totals
			$RAMTot = ($RAMTot + $RAM)
			$CPUTot = ($CPUTot + $CPU)
			
			#Write-Host "$ComputerName $VMInst"
				
			# Build dcrArray - will use this to align VM roles and data centers					}
			$dcrArray += $dcr
										}
		# Get Pool RAM in MB
		$MemLimitMB =($RAMTot * 1024)

		# Apply CEILING function to CPU to get a multiple of 2000
		$CPUTotC = (($CPUTot * 2700) / 2000)

		# Get Pool CPU im mhz
		$CpuLimitMhz = ([Math]::Ceiling($CPUTotC) * 2000)

		$locArray += $location
		$ramArray += $RAMTot
		$cpuArray += $CPUTot

		# End Instance Based Calculator
		
		}
}
		#
else {
	if ($csvArray.count -eq 1){
		$location = $csvArray.location
	}
	else {
	$location = $csvArray.location[0]
	}
	
	$VClocation = $location
	$vCenterInstance = vCenterFnctn
	
Write-Host ""
    Write-Host -foreground "White" " Connecting to VCenter to verify Resource Pool " -nonewline; Write-Host -foreground "Green" $vCenterInstance
	
	## -Connect-VIServer $vCenterInstance -WarningAction SilentlyContinue
	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
	Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
	
	$exRpool = Get-ResourcePool -name $basePOOL -ErrorAction SilentlyContinue
	#If $exRpool is not empty, then it exits already
			if (!$exRpool) {
			Write-Host ""
			Write-Host -foreground "White" " The resource pool " -nonewline; Write-Host -foreground "Green" $basePOOL -nonewline; Write-Host -foreground "White" " does not exist "		
			Write-Host -foreground "White" " exiting ... "
			exit
			}

	}

	# This section insures that the PowerCLI PowerShell Modules are currently active. The pipe to Out-Null can be removed if you desire additional Console output.
	Get-Module -ListAvailable VMware* | Import-Module | Out-Null
	
	# Assuming that EMI production VMs only get deployed in one data center.
	# Search $dcrArray, which was created on the fly above, 
	# which only contains instance codes for EMI servers, therefore the production datacenter 
	# Will return only one datacenter value, such as ECI-QTS or ECI-SAC etc.
	
	# Log into data centers and check for the existence of resource pools
	
	#$VCloc = $dcrArray  | select-string -allmatches "DC-Pri" | Select-Object -Unique 

	#$VClocation = ($VCloc -split "\,")[0]
	
	$y = 0
	foreach ($location in $locationList) {
	
	#Set the vCenterInstance by running the vCenterFnctn function against the VClocation
	$VClocation = $location
	$vCenterInstance = vCenterFnctn

	# Log in to the  datacenter

	Write-Host ""
    Write-Host -foreground "White" " Connecting to VCenter to verify Resource Pool " -nonewline; Write-Host -foreground "Green" $vCenterInstance
	
	## -Connect-VIServer $vCenterInstance -WarningAction SilentlyContinue
	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
	Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
	Start-Sleep -Seconds 5

	if ($DCRoleList[$y] -eq "DC-Sec") {
	$emiRESPOOL = "dr_" + $basePOOL
			}
	else	{
	$emiRESPOOL = $basePOOL
		}
 
	# Verify that EMI pool either exists or needs to be created based on Yes/No answers.
	# Start Verify resource pool $emiRESPOOL
	$currentRAM = 0
	$currentCPU = 0
	$exRpool = Get-ResourcePool -name $emiRESPOOL -ErrorAction SilentlyContinue

	$ansCkR = 1
		do {

			#If $exRpool is not empty, then it exits already
			if ($exRpool) {
				$currentRAM = $exRpool.MemLimitMB
				$currentCPU = $exRpool.CpuLimitMhz
			Write-Host ""
			Write-Host -foreground "White" " The resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL -nonewline; Write-Host -foreground "White" " already exists "

			$anspChk = 1
			
			do {
				Write-Host ""
				Write-Host -foreground "White" " Do you want to use this resource pool? : " -nonewline; Write-Host -foreground "green" $emiRESPOOL
				$promptP = Read-Host " Yes or No - default: [Yes] "

				if ($promptP -eq ""){
					$answerP = "Yes"
						} 
					else 				{
					$answerP = $promptP
				}
 
				if ($answerP -eq "Yes" -or $answerP -eq "No" -or $answerP -eq "Y" -or $answerP -eq "N")	{
					Write-Host ""
					# Write-Host -foreground "DarkGreen" " You chose " $answerP
					$anspChk = 2
				} 
				
				else		{
				Write-Host -foreground "Magenta" " Invalid answer. YES/NO "
				Write-Host ""
				$anspChk = 1
				}

			} until ($anspChk -eq 2)
			}
												
							
		if ($answerP -eq "Yes" -or $answerP -eq "Y") {
			# NO to Build a new resource pool, add current RAM/CPU to new, break loop and use existing pool
			$BNR = "NO"
			$MemLimitMB = ($MemLimitMB + $currentRAM)
			$CpuLimitMhz = ($CpuLimitMhz + $currentCPU)
			
			Write-Host ""
			Write-Host -foreground "White" " VMs will be deployed into existing " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
			Write-Host -foreground "White" " RAM and CPU will be set to " $MemLimitMB " MB and " $CpuLimitMhz " Mhz on resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
		
			#Stop at this point to confirm user input
			Write-Host ""
			Write-Host -foreground "White" " Press enter to execute the script or CTRL-C to exit ..."
			$sconn = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
			
			$ansCkR = 2			

		}
		else {
	
		Write-Host " Enter the name of the new resource pool."
		$promptR = Read-Host " Press enter to accept default: [$($emiRESPOOL)] "
	
		if ($promptR -eq "") {} else {
			$emiRESPOOL = $promptR
		}
		
		$exRpool = Get-ResourcePool $emiRESPOOL -ErrorAction SilentlyContinue
		if ($exRpool) {
	
			$ansCkR = 1
		}
		
			else	{
			
			# YES to Build a new resource pool, there is no existing pool, break loop.
			$BNR = "YES"
			$ansCkR = 2
					
			Write-Host ""
			Write-Host -foreground "White" " VMs will be deployed into new resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
			Write-Host -foreground "White" " RAM and CPU will be set to " $MemLimitMB "MB and " $CpuLimitMhz "Mhz on resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
		
			#Stop at this point to confirm user input 
			Write-Host ""
			Write-Host -foreground "White" " Resource Pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL -nonewline; Write-Host -foreground "White" " will be created in the execution phase."
			Write-Host -foreground "White" " Press enter to continue error checking or CTRL-C to exit ..."
			$sconn = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
		
					}
						} 
						
	} until ($ansCkR -eq 2)
	
Start-Sleep -Seconds 5
$BNRPool += $BNR
$y = ($y + 1)
# Disconnect from VCenter
Disconnect-VIServer -Server * -Force -confirm:$false

}
# End Verify EMI resource pool $emiRESPOOL


#########################################################################################
#         Start datastore and resource pool discovery and verification                  #
#########################################################################################


###++++++++++++++++++++++++++ VLAN ID

# Get the VLAN ID from the EMSVRFID
	if ($csvArray.count -eq 1) {
		$VLANID = $csvArray.emsvrfid |   ForEach { $_ -Replace("EMS","") }
		}
	else {
		$VLANID = $csvArray.emsvrfid[0] |   ForEach { $_ -Replace("EMS","") }
	}

###++++++++++++++++++++++++++ VLAN ID

# Set the name of the multi_newclientXXXX portgroup
$newClientPG = "multi_newclient" + $VLANID 

# Set the name of the multi_gpid port group.
$multipgrp = "multi_" + $GPID

# Create an array to hold all the pool and datastore info for each datacenter
$dspArray = @()

# Loop through the location list, created above, to verify objects exist.
foreach ($location in $locationList) {
	$VClocation = $location
	$vCenterInstance = vCenterFnctn

	Write-Host ""
	Write-Host -foreground "White" " Connecting to VCenter " -nonewline; Write-Host -foreground "Green" $vCenterInstance
	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
	Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
	Start-Sleep -Seconds 5
	
	#vcCode - for example QTS
	$vcCode = ($location -split "-")[1]

	#dvSwitch - for example qts-pod2051-10g
	$dvSwitch = get-VDPortgroup -name $newClientPG | get-vdswitch -ErrorAction SilentlyContinue
	if ($dvSwitch) {
		$dvSwitchName = $dvSwitch.name
	}
	else {
		write-host -foreground "red" "Expected to find port group	: " $newClientPG
		write-host -foreground "red" "Please ensure the port group already exists in VSphere"
		write-host -foreground "red" "The script will now exit"
		#exit
	}

	#POD Suffix - for example POD2051
	$podSuffix = ($dvSwitch.name -split "\-")[1]

	#POD Number - for example 2051
	$podNum = $podSuffix |   ForEach { $_ -Replace("POD","") }

	#POD name or Cluster name - for example Cloud-qts-pod2051
	$podName = "Cloud-" + $vcCode + "-" + $podSuffix
	$podNameV = get-Cluster -name $podName -ErrorAction SilentlyContinue
	if ($podNameV) {
		Write-Host -foreground "White" "POD Name " -nonewline; Write-Host -foreground "Green" $podName "Ok!"}
	else {
		write-host -foreground "red" "Expected to find POD	: " $podName
		write-host -foreground "red" "Please ensure the POD is named correctly"
		write-host -foreground "red" "The script will now exit"
		#exit
	} 

	#EMI OS datastore cluster
	$emiOSds = $vcCode + "_EMI_os_" + $podNum
	
	#EMI Swap datastore cluster
	$emiSWds = $vcCode + "_EMI_swap_" + $podNum
	
	#EMI Data datastore cluster
	$emiDTds = $vcCode + "_EMI_data_" + $podNum
	
	#EMS DC OS datastore cluster
	$emsDCOSds = $vcCode + "_EMS_Client_DC_OS_" + $podNum
	
	#EMS DC Swap datastore cluster
	$emsDCSWds = $vcCode + "_EMS_Client_DC_SWAP_" + $podNum
	
	#EMS DC Files datastore cluster
	$emsFILESds = $vcCode + "_EMS_Client_Files_" + $podNum
	
	#EMS CTX OS datastore cluster
	$emsCtxOSds = $vcCode + "_EMS_Client_Citrix_OS_" + $podNum
	
	#EMS CTX Swap datastore cluster
	$emsCtxSWds = $vcCode + "_EMS_Client_Citrix_SWAP_" + $podNum
	
	#Loop through each datastore cluster to see if it exists
	foreach ($ds in $emiOSds, $emiSWds, $emiDTds, $emsDCOSds, $emsDCSWds, $emsFILESds, $emsCtxOSds, $emsCtxSWds)
	{
		$dsV = get-datastoreCluster -name $ds -ErrorAction SilentlyContinue
		if ($dsV) {
		Write-Host -foreground "White" "Datastore " -nonewline; Write-Host -foreground "Green" $ds "Ok!"}
	else {
		write-host -foreground "red" "Expected to find datastore cluster 	: " $ds
		write-host -foreground "red" "Please ensure the datastore exists or is named correctly"
		write-host -foreground "red" "The script will now exit"
		Disconnect-VIServer -Server * -Force -confirm:$false
		exit
	} 
	}
	
	## #DC Root Pool
	## $dcRootPool = "multi_ems_clientdcs_" + $vcCode + "_" + $podNum
	## $dcRootPoolV = Get-ResourcePool $dcRootPool -ErrorAction SilentlyContinue
	## if ($dcRootPoolV) {
	## 	Write-Host -foreground "White" "DC Root Pool " -nonewline; Write-Host -foreground "Green" $dcRootPool "Ok!"}
	## else {
	## 	write-host -foreground "red" "Expected to find DC root Resource Pool	: " $dcRootPool
	## 	write-host -foreground "red" "Please ensure the DC root pool exists in VSphere"
	## 	write-host -foreground "red" "The script will now exit"
	## 	Disconnect-VIServer -Server * -Force -confirm:$false
	## 	exit
	## } 
	
	## #DC Sub Pool
	## $dcSUBPool = "multi_" + $GPID + "_" +$vcCode + "_" + $podNum
	## $dcSUBPoolV = Get-ResourcePool $dcSUBPool -ErrorAction SilentlyContinue
	## if ($dcRESPoolV) {
	## 	Write-Host -foreground "White" "DC Resource Pool " -nonewline; Write-Host -foreground "Green" $dcSUBPool "Ok!"}
	## else {
	## 	write-host -foreground "White" "Will create DC sub Resource Resource Pool	: " -nonewline; Write-Host -foreground "Green" $dcSUBPool
	## 	$dcSUBPoolB = "YES"
	## } 

	## #CTX Root Pool
	## $ctxRootPool = "multi_ems_citrix_"  +$vcCode + "_" + $podNum
	## $ctxRootPoolV = Get-ResourcePool $ctxRootPool -ErrorAction SilentlyContinue
	## if ($ctxRootPoolV) {
	## 	Write-Host -foreground "White" "CTX Root Pool " -nonewline; Write-Host -foreground "Green" $dcRootPool "Ok!"}
	## else {
	## 	write-host -foreground "red" "Expected to find CTX root Resource Pool	: " $ctxRootPool
	## 	write-host -foreground "red" "Please ensure the CTX root pool exists in VSphere"
	## 	write-host -foreground "red" "The script will now exit"
	## 	Disconnect-VIServer -Server * -Force -confirm:$false
	## 	exit
	## } 
	
	## #CTX Sub Pool
	## $ctxSUBPool = "multi_" + $GPID + "_" +$vcCode + "_" + $podNum + "_ctx"
	## $ctxSUBPoolV = Get-ResourcePool $ctxSUBPool -ErrorAction SilentlyContinue
	## if ($ctxSUBPoolV) {
	## 	Write-Host -foreground "White" "CTX Resource Pool " -nonewline; Write-Host -foreground "Green" $ctxSUBPool "Ok!"}
	## else {
	## 	write-host -foreground "White" "Will create CTX sub Resource Resource Pool	: " -nonewline; Write-Host -foreground "Green" $ctxSUBPool
	## 	$ctxSUBPoolB = "YES"
	## }
	
	#Template
	$VMTempTest = Get-Template -Name $VMTemplate -ErrorAction SilentlyContinue
	if ($VMTempTest) {
		Write-Host -foreground "White" "Template " -nonewline; Write-Host -foreground "Green" $VMTemplate "Ok!"}
	else {
		write-host -foreground "red" "Expected to find Template	: $VMTemplate"
		write-host -foreground "red" "Please ensure the Template exists in VSphere"
		write-host -foreground "red" "The script will now exit"
		Disconnect-VIServer -Server * -Force -confirm:$false
		exit
	} 
	
	#Customization spec
	$VMCustSpecTest = Get-OSCustomizationSpec -Name $VMCustomSpec -ErrorAction SilentlyContinue
	if ($VMCustSpecTest) {
		Write-Host -foreground "White" "Customization Spec " -nonewline; Write-Host -foreground "Green" $VMCustomSpec "Ok!"}
	else {
		write-host -foreground "red" "Expected to find Customization spec	: $VMCustomSpec"
		write-host -foreground "red" "Please ensure the Customization spec exists in VSphere"
		write-host -foreground "red" "The script will now exit"
		#exit
	}

	# Add rows with headers to $dspArray array which can be referenced in the deployment phase.
	$row = "" | Select "location", "podName", "emiOSds", "emiSWds", "emiDTds", "emsDCOSds", "emsDCSWds", "emsFILESds", "emsCtxOSds", "emsCtxSWds", "dcRootPool", "dcSUBPool", "dcSUBPoolB", "ctxRootPool", "ctxSUBPool", "ctxSUBPoolB", "VMTemplate", "VMCustomSpec" 
	$row."location" = $location
	$row."podName" = $podName
	$row."emiOSds" = $emiOSds
	$row."emiSWds" = $emiSWds
	$row."emiDTds" = $emiDTds
	$row."emsDCOSds" = $emsDCOSds
	$row."emsDCSWds" = $emsDCSWds
	$row."emsFILESds" = $emsFILESds
	$row."emsCtxOSds" = $emsCtxOSds
	$row."emsCtxSWds" = $emsCtxSWds
	$row."dcRootPool" = $dcRootPool
	$row."dcSUBPool" = $dcSUBPool
	$row."dcSUBPoolB" = $dcSUBPoolB
	$row."ctxRootPool" = $ctxRootPool
	$row."ctxSUBPool" = $ctxSUBPool
	$row."ctxSUBPoolB" = $ctxSUBPoolB
	$row."VMTemplate" = $VMTemplate
	$row."VMCustomSpec" = $VMCustomSpec
	$dspArray += $row
	
# Disconnect from VCenter
Disconnect-VIServer -Server * -Force -confirm:$false

}
# End datastore and resource pool discovery and verification


#########################################################################################
#                               Start User Input                                        #
#########################################################################################

# Start Local username - offer administrator as default
Write-Host ""
$VMLocalUser = 'administrator'
    [array]$vmDC1s = $csvArray | Where-Object {$_.SRVROLE -eq "DC-Pri"}
    if ($vmDC1s.count -eq 1){
	
Write-Host " Enter the local username."
Write-Host " This should be the same as the local username in the template."
}
 elseif ($vmDC1s.Count -eq 0){
 Write-Host " Enter the domain username."
 }
 

$prompt = Read-Host " Press enter to accept default:[$($VMLocalUser)] "
	if ($prompt -eq "") {} else {
		$VMLocalUser = $prompt
		}
# End Local username	
	
	########### ADD IF SERVER ROLE INCLUDEs DC-Pri ############
# Start Local user password
$lpChk = 1
do {
  
Write-Host ""
Write-Host " Please enter the  password ... "
Write-Host ""
$locpw1 = Read-Host " Password" -AsSecureString
$locpw2 = Read-Host " Re-enter Password" -AsSecureString
$locpw1_text = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($locpw1))
$locpw2_text = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($locpw2))
 
	if ($locpw1_text -ceq $locpw2_text) {
	Write-Host ""
	Write-Host -foreground "DarkYellow" " Passwords matched "
	$lpChk = 2
	} else {
	Write-Host
	Write-Host -foreground "DarkRed" " Passwords do not match, please try again "
	Write-Host ""
	$lpChk = 1
	}

} until ($lpChk -eq 2)
# Ed Local user password

# Start DRSM password
# If server role is DC-Pri or DC-Sec using $vmDC1s and $vmDC2s defined above


    if ($vmDC1s.count -eq 1 -or $vmDC2s.count -eq 1){
	


$dpChk = 1
do {
 
Write-Host "" 
Write-Host " Please create a DSRM password ... "
Write-Host ""
$dsrmpw1 = Read-Host " Password" -AsSecureString
$dsrmpw2 = Read-Host " Re-enter Password" -AsSecureString
$dsrmpw1_text = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($dsrmpw1))
$dsrmpw2_text = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($dsrmpw2))
 
	if ($dsrmpw1_text -ceq $dsrmpw2_text) {
	Write-Host ""
	Write-Host -foreground "DarkYellow" " Passwords matched "
	$dpChk = 2
	} else {
	Write-Host
	Write-Host -foreground "DarkRed" " Passwords do not match, please try again "
	Write-Host ""
	$dpChk = 1
	}

} until ($dpChk -eq 2)
}
# End DRSM password

# Print input values back to the user
Write-Host ""
Write-Host -foreground "DarkGray" "Please confirm the following parameters"
Write-Host ""
###Z Write-Host -foreground "Cyan" " Virtual Center     :"	$vCenterInstance
Write-Host -foreground "Cyan" " GPID               :"	$GPID
Write-Host -foreground "Cyan" " Resource Pool(s)   :"	$emiRESPOOL
Write-Host -foreground "Cyan" " CPU Limit          :"	$CpuLimitMhz "Mhz"
Write-Host -foreground "Cyan" " Memory Limit       :"	$MemLimitMB "MB ($MemLimitGB GB)"
Write-Host -foreground "Cyan" " POD                :"	$dspArray.podName[1]
Write-Host ""
Write-Host -foreground "Cyan" " Local user account :"	$VMLocalUser
Write-Host ""
Write-Host -foreground "DarkGray" "VMs to be deployed"
foreach ($line in $configArray) {write-host -foreground "Cyan" "" $line.VMName, $line.VMType, $line.IPAddress, $line.CustADName, $line.location}
Write-Host ""

# Stop at this point to confirm user input 
Write-Host ""
Write-Host -foreground "DarkCyan" "If these are correct, press enter to continue or CTRL-C to exit ..."
$usrchk = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# End User Input

# Get execute start time.
$XDATE = Get-date

#########################################################################################
#    Start creating pools and deploying Instance Based VMs, Power Up, per data center   #
#########################################################################################
		
# Set x to 0 and use this variable to extract corresponding info from $dspArray as it increments up.		
$x = 0
foreach ($location in $locationList) {

	#Set the VC with the vCenterFnctn function
	$VClocation = $location
	$vCenterInstance = vCenterFnctn

	# Connect to vcenter
	Write-Host ""
	Write-Host -foreground "White" " Connecting to VCenter " -nonewline; Write-Host -foreground "Green" $vCenterInstance
	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
	Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
	Start-Sleep -Seconds 5

		if ($DCRoleList[$x] -eq "DC-Sec") {
	$emiRESPOOL = "dr_" + $basePOOL
			}
	else	{
	$emiRESPOOL = $basePOOL
		}
		
	#Create EMI resource pool if needed $VCloc, is defined on line 379 as production datacenter
	if ($location -eq $VClocation -and $BNRPool[$x] -eq "YES")
	{
		Write-Host ""
		Write-Host -foreground "Yellow" " Creating EMI resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
		pause
		New-ResourcePool -Location $dspArray.podName[$x] -Name $emiRESPOOL -CpuLimitMhz $CpuLimitMhz -MemLimitMB $MemLimitMB
		#New-vipermission -role DRTechAdmin -principal "ezebos\dr.tech" -entity $emiRESPOOL
		#New-vipermission -role ResourceAdmin -principal "ezebos\cloud_resource_admin_nyc" -entity $emiRESPOOL
	}
	
	elseif ($location -eq $VCloc -and $BNRPool[$x] -eq "NO"){
		Set-ResourcePool -Name $emiRESPOOL -CpuLimitMhz $CpuLimitMhz -MemLimitMB $MemLimitMB
	}
	
	## #Create DC Sub resource pool if needed
	## if ($dspArray.dcSUBPoolB[$x] -eq "YES")
	## {
	## 	Write-Host ""
	## 	Write-Host -foreground "Yellow" " Creating DC sub resource pool " -nonewline; Write-Host -foreground "Green" $dspArray.dcSUBPool[$x]
	## 	New-ResourcePool -Location $dspArray.dcRootPool[$x] -Name $dspArray.dcSUBPool[$x]
	## 	#New-vipermission -role DRTechAdmin -principal "ezebos\dr.tech" -entity $dspArray.dcSUBPool[$x]
	## 	#New-vipermission -role ResourceAdmin -principal "ezebos\cloud_resource_admin_nyc" -entity $dspArray.dcSUBPool[$x]
	## }
	
	## #Create CTX Sub resource pool if needed
	## if ($dspArray.ctxSUBPoolB[$x] -eq "YES")
	## {
	## 	Write-Host ""
	## 	Write-Host -foreground "Yellow" " Creating CTX sub resource pool " -nonewline; Write-Host -foreground "Green" $dspArray.ctxSUBPool[$x]
	## 	New-ResourcePool -Location $dspArray.ctxRootPool[$x] -Name $dspArray.ctxSUBPool[$x]
	## 	#New-vipermission -role DRTechAdmin -principal "ezebos\dr.tech" -entity $dspArray.ctxSUBPool[$x]
	## 	#New-vipermission -role ResourceAdmin -principal "ezebos\cloud_resource_admin_nyc" -entity $dspArray.ctxSUBPool[$x]
	## }


	# Rename multi_newclientXXX portgroup to multi_gpid, per data center
	
	#~~~# get-VDPortgroup -name $newClientPG | set-VDPortgroup -name $multipgrp
			
	#Get list of VMs per data center, including DC and CTX
	#$rdclist = $rdcArray  | select-string -allmatches $loc  | Select-Object -Unique
	#$myvmslist = $rdclist | Foreach {($_ -split "\,")[2]}

	# Loop through the VMs looking for their ECI Instance Codes, assign RAM and CPU, then deploy

		foreach ($line in $csvArray) 	{
			$VMInst = $line.VMType
			$ComputerName = $line.VMName
			$DataCenter = $line.location
			$SrvRole = $line.SrvRole
	
			if ($DataCenter -eq $dspArray.location[$x]){
 
			# Exclude Azure rows
			#if ($DataCenter -notlike "*azure*")	{

				if     ($VMInst -eq "IN01002"){$RAM = 2; $nCPU = 1}
				elseif ($VMInst -eq "IN01004"){$RAM = 4; $nCPU = 1}
				elseif ($VMInst -eq "IN02004"){$RAM = 4; $nCPU = 2}
				elseif ($VMInst -eq "IN02008"){$RAM = 8; $nCPU = 2}
				elseif ($VMInst -eq "IN04008"){$RAM = 8; $nCPU = 4}
				elseif ($VMInst -eq "IN04016"){$RAM = 16; $nCPU = 4}
				elseif ($VMInst -eq "IN04032"){$RAM = 32; $nCPU = 4}
				elseif ($VMInst -eq "IN06016"){$RAM = 16; $nCPU = 6}
				elseif ($VMInst -eq "IN06048"){$RAM = 48; $nCPU = 6}
				elseif ($VMInst -eq "IN08032"){$RAM = 32; $nCPU = 8}
				elseif ($VMInst -eq "IN08064"){$RAM = 64; $nCPU = 8}
 
				else {
				$RAM = 0
				$CPU = 0
				}
				
			# Calculate number of cores per socket, set to 1 of less than 2.
			$CPS = ($nCPU / 2)
				if ($CPS -lt 2) {
				$CPS = 1
							}
			#Set RESPOOL to emiRepool so that all servers get deployed into the same pool	
			$RESPOOL = $emiRESPOOL			
							
			# Select datastores depending on server role.				
				if ($SrvRole -like "DC*") {
				#$RESPOOL = $dspArray.dcSUBPool[$x]
				$TargetDataStore = $dspArray.emsDCOSds[$x]
				$SwapDataStore = $dspArray.emsDCSWds[$x]
				$FilesDataStore = $dspArray.emsFILESds[$x]
				}
								
				if ($SrvRole -eq "CTX") {
				#$RESPOOL = $dspArray.ctxSUBPool[$x]
				$TargetDataStore = $dspArray.emsCtxOSds[$x]
				$SwapDataStore = $dspArray.emsCtxSWds[$x]
				}
				
				if ($SrvRole -notmatch "DC*|CTX") {
				#$RESPOOL = $emiRESPOOL
				$TargetDataStore = $dspArray.emiOSds[$x]
				$SwapDataStore = $dspArray.emiSWds[$x]
				}
				 
			####################################################################
			##          DEPLOY VMs AND SET CPU,RAM AND NIC PORTGROUP          ##
			####################################################################
			Write-Verbose -Message "Deploying Virtual Machine with Name: [$ComputerName] using Template: [$VMTemplate] and Customization Specification: [$VMCustomSpec] in Resource Pool: [$RESPOOL] on Cluster: [$TargetCluster] and waiting for completion" -Verbose

			#~~~# New-VM -Name $ComputerName -Template $VMTemplate -OSCustomizationSpec $VMCustomSpec -ResourcePool $RESPOOL -DiskStorageFormat Thin -Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)  
			
			Write-Verbose -Message "Migrating Swap VMDK." -Verbose
			#~~~# $SwapDisk = Get-VM -Name $ComputerName | Get-HardDisk | where {$_.CapacityGB -like "10*"}
			#~~~# Move-hardDisk -HardDisk $SwapDisk -Datastore (Get-DatastoreCluster -Name $SwapDataStore | Get-Datastore | Get-Random) -StorageFormat 'Thin' -Confirm:$false
		
			Write-Host ""
			Write-Verbose -Message "Setting CPU and RAM on $ComputerName Deployed" -Verbose
			Start-Sleep -Seconds 2
			#~~~# Set-VM $ComputerName -MemoryGB $RAM -NumCPU $nCPU -Confirm:$False
			
			# Create the VirtualMachineConfigSpec with which to reconfig the VM and set cores per socket
			Start-Sleep -Seconds 2
			#~~~# $spec = New-Object -Type VMware.Vim.VirtualMachineConfigSpec -Property @{"NumCoresPerSocket" = $CPS}

			# Apply this spec to the VM
			# This will give 2 sockets with 2 CPU per socket
			Start-Sleep -Seconds 2
			#~~~# (Get-VM $ComputerName).ExtensionData.ReconfigVM_Task($spec)

			# Set the port group in the VM to the $multipgrp
			Write-Verbose -Message "Setting the port group on $ComputerName " -Verbose
			Start-Sleep -Seconds 2
			#~~~# get-vm -name $ComputerName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $multipgrp -Confirm:$false
			
			Write-Host ""
			Write-Verbose -Message "Virtual Machine $ComputerName Deployed. Powering On" -Verbose
			Start-Sleep -Seconds 2
			#~~~# Start-VM -VM $line.VMName
			Write-Host ""
			
			#Add new VMDK for Files to Domain Controllers and move to $emsFILESds 
				if ($SrvRole -like "DC*"){
					Write-Verbose -Message "Adding new VMDK for Files to $ComputerName " -Verbose
					$vm = get-vm $ComputerName
			#~~~# 		$vm | New-HardDisk -CapacityGB 100 -Datastore (Get-DatastoreCluster -Name $FilesDataStore | Get-Datastore | Get-Random) -StorageFormat 'Thin' -Confirm:$false
				}
			#}

											}
									}
		$x = ($x + 1)	
		
	# Disconnect from VCenter
	Disconnect-VIServer -Server * -Force -confirm:$false
}
# End Deploying Instance Based VMs and Power Up

 pause 
# ------This Section Sets the Credentials to be used to connect to Guest VMs that are NOT part of a Domain------
 
# NOTE - Make sure you input the local credentials for your domain controller virtual machines below. This is used for logins prior to them being promoted to DCs.
# This should be the same local credentials as defined within the template that you are using for the domain controller VM. 

#$VMLocalUser is equal to the user input above, usually "administrator"
$VMLocalPWord = ConvertTo-SecureString -String $locpw2_text -AsPlainText -Force
$VMLocalCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $VMLocalUser, $VMLocalPWord

# The below credentials are used by operations below once the domain controller virtual machines and the new domain are in place. These credentials should match the credentials
# used during the provisioning of the new domain. 
$DomainUser = $DomainNetBIOSName + "\" + $VMLocalUser
#$DomainUser =  $VMLocalUser

$DomainPWord = ConvertTo-SecureString -String $locpw2_text -AsPlainText -Force
$DomainCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $DomainUser, $DomainPWord 

# ------This Section Contains the Scripts to be executed against new VMs depending on their Role
 
# This Scriptblock is used to add new VMs to the newly created domain by first defining the domain creds on the machine and then using Add-Computer
# - Sample        '$DomainUser = "TESTDOMAIN\Administrator";'$DomainUser = "' + $DomainUser + '";
$JoinNewDomain = '$DomainUser = "' + $DomainUser + '";
                  $DomainPWord = ConvertTo-SecureString -String ' + $locpw2_text + ' -AsPlainText -Force;
                  $DomainCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $DomainUser, $DomainPWord;
                  Add-Computer -DomainName ' + $DomainName + ' -Credential $DomainCredential;
                  Start-Sleep -Seconds 20;
                  Shutdown /r /t 20'
 
 
# These commands will install the AD Role and AD DS Tool on the target virtual machine. 
# They will only get called if VM is tagged as a Domain Controller in the csv file.
$InstallADRole = 'Add-WindowsFeature -Name "AD-Domain-Services" -Restart'
$InstallADDSTools = 'Add-WindowsFeature -Name "RSAT-ADDS-Tools"'


 
# This Scriptblock will define settings for a new AD Forest and then provision it with said settings. 
# It will only get called if VM's server role is DC-Pri in the csv file.
# NOTE - Make sure to define the DSRM Password below in the line below that defines the $DSRMPWord Variable!!!!
$ConfigureNewDomain = 'Write-Verbose -Message "Configuring Active Directory" -Verbose;
					   $DomainMode = "' + $DomainMode + '";
					   $ForestMode = "' + $ForestMode + '";
                       $DomainName = "' + $DomainName + '";
					   $DomainNetBIOSName = "' + $DomainNetBIOSName + '";
                       $DSRMPWord = ConvertTo-SecureString -String ' + $dsrmpw2_text + ' -AsPlainText -Force;
                       Install-ADDSForest -ForestMode $ForestMode -DomainMode $DomainMode -DomainName $DomainName -DomainNetBIOSName $DomainNetBIOSName -InstallDns:$true -SafeModeAdministratorPassword $DSRMPWord -Force'
 
# Configure an additional domain controller, if server role is DC-sec
$ConfigureADC = 	  'Write-Verbose -Message "Configuring Active Directory" -Verbose;
                       $DomainMode = "Win2012R2";
                       $ForestMode = "Win2012R2";
                       $DomainName = "' + $DomainName + '";
                       $DSRMPWord = ConvertTo-SecureString -String ' + $dsrmpw2_text + ' -AsPlainText -Force;
					   Install-ADDSDomainController -CreateDnsDelegation:$false -DatabasePath "C:\Windows\NTDS" -DomainName $DomainName -InstallDns:$true -LogPath "C:\Windows\NTDS" -NoGlobalCatalog:$false -SiteName "Default-First-Site-Name" -SysvolPath "C:\Windows\SYSVOL" -NoRebootOnCompletion:$false -Force:$true -SafeModeAdministratorPassword $DSRMPWord'


# This scriptblock creates a new administrative user account inside of the new domain
# ***Not doing this at the moment, but will leave the block here.***
# NOTE - Be Sure to set the password using the $AdminUserPWord Below!
$NewAdminUser = '$AdminUserPWord = ConvertTo-SecureString -String "pAsSw0rD" -AsPlainText -Force;
                 New-ADUser -Name "TestAdmin" -AccountPassword $AdminUserPWord;
                 Add-ADGroupMember -Identity "Domain Admins" -Members "TestAdmin";
                 Enable-ADAccount -Identity "TestAdmin"'

 
# ------This Section Contains the Scripts to be executed against file server VMs------
# ***Not doing this at the moment, but will leave the block here.***
$InstallFSRole = 'Add-WindowsFeature -Name "FS-FileServer"'
 
 
# The below block of code first creates a new folder and then creates a new SMB Share with rights given to the defined user or group.
# ***Not doing this at the moment, but will leave the block here.***
$NewFileShare = '$ShareLocation = "C:\ShareTest";
                 $FolderName = "Public";
                 New-Item -Path $ShareLocation -Name $FolderName -ItemType "Directory";
                 New-SmbShare -Name "Public" -Path "$ShareLocation\$FolderName" -FullAccess "TestDomain\TestAdmin"'
 
 
$y = 0
$clocationList = $configArray.location  | select-string -allmatches "ECI-" | Select-Object -Unique |  ForEach { $_ -Replace(" ","") }
foreach ($location in $clocationList) {

	#Set the VC with the vCenterFnctn function
	$VClocation = $location
	$vCenterInstance = vCenterFnctn

	# Connect to vcenter
	Write-Host ""
	Write-Host -foreground "White" " Connecting to VCenter " -nonewline; Write-Host -foreground "Green" $vCenterInstance
	$crdfile = ("W:\Automation\VMWareScripts\" + $vCenterInstance + ".xml")
	$creds = Get-VICredentialStoreItem -file $crdfile
	Connect-VIServer -Server $creds.Host -user $creds.User -password $creds.Password -WarningAction SilentlyContinue | Out-Null
	Start-Sleep -Seconds 5

	# Loop through the configArray and configure the VMs 
	foreach ($line in $configArray) {

		$DataCenter = $line.location
		$ComputerName = $line.VMName
		$IPAddress = $line.IPAddress
		$SubnetMask = $line.SubnetMask
		$Gateway = $line.Gateway
		$DNSIP = $line.DNSIP
		$SRVROLE = $line.SRVROLE
 
		if ($DataCenter -eq $dspArray.location[$y]){
 
# ------This section contains the commands for defining the IP and networking settings for the new virtual machines------
# NOTE: The Interface Name needs to be the name of the Interface in the template. 
 
# VM IPs Below
# NOTE: Insert IP info in IP SubnetMask Gateway Order
#$VMNetworkSettings = 'netsh interface ip set address "Ethernet" static ' + $_.IPAddress $_.SubnetMask $_.Gtway'
$VMNetworkSettings = 'netsh interface ip set address "Ethernet0" static ' + $IPAddress + ' ' + $SubnetMask + ' ' + $Gateway + ' '

# NOTE: DNS Server IP below should be the same IP as given to the domain controller in the $DCNetworkSettings Variable
# $DCDNSSettings = 'netsh interface ip set dnsservers name="Ethernet" static 10.10.0.1 primary'
$VMDNSSettings = 'netsh interface ip set dnsservers name="Ethernet0" static ' + ' ' + $DNSIP + ' primary'
 
#########################################################################################################################################################################################

# We first verify that the guest customization has finished on on the new DC VM by using the below loops to look for the relevant events within vCenter. 
# Start VM Customization

Write-Verbose -Message "Customization of VM $ComputerName Completed Successfully!" -Verbose
# End VM Customization


# NOTE - The below Sleep command is to help prevent situations where the post customization reboot is delayed slightly causing
# the Wait-Tools command to think everything is fine and carrying on with the script before all services are ready.
# Value can be adjusted for your environment. 

Write-Verbose -Message "Sleeping 30 seconds while VM $ComputerName reboots" -Verbose
Start-Sleep -Seconds 30

Write-Verbose -Message "Waiting for VM $ComputerName to complete post-customization reboot." -Verbose 
Wait-Tools -VM $ComputerName -TimeoutSeconds 300
 
# NOTE - Another short sleep here to make sure that other services have time to come up after VMware Tools are ready. 
Write-Verbose -Message "Sleeping 30 seconds waiting for $ComputerName VMwaretools" -Verbose
Start-Sleep -Seconds 30


# Network settings: Set the IP of the VM to the value given in the csv file
Write-Verbose -Message "Getting ready to change IP Settings on VM $ComputerName " -Verbose
Invoke-VMScript -ScriptText $VMNetworkSettings -VM $ComputerName -GuestCredential $VMLocalCredential

Write-Verbose -Message "Sleeping 10 seconds before adding $ComputerName DNS IP setting." -Verbose
Start-Sleep 10
# DNS Setings
Invoke-VMScript -ScriptText $VMDNSSettings -VM $ComputerName -GuestCredential $VMLocalCredential

# NOTE - The Below Sleep Command is due to it taking a few seconds for VMware Tools to read the IP Change so that we can return the below output. 
# This is strictly informational and can be commented out if needed, but it's helpful when you want to verify that the settings defined above have been 
# applied successfully within the VM. We use the Get-VM command to return the reported IP information from Tools at the Hypervisor Layer. 

Write-Verbose -Message "Sleeping 10 seconds to display IP of $ComputerName " -Verbose
Start-Sleep 10

# Display the VM's IP address
$DCEffectiveAddress = (Get-VM $ComputerName).guest.ipaddress[0]
Write-Verbose -Message "Assigned IP for VM [$ComputerName] is [$DCEffectiveAddress]" -Verbose
 

 # Start Domain Controller Configuration      

########################################
### DC-Pri
########################################		
 # The csv file tags the VMs for Domain Controller status, YES or NO.
 # If the VM is a DC then install AD roles.
		If ($SRVROLE -eq 'DC-Pri') {
 
		Write-Verbose -Message "$ComputerName will be configured as a Domain Controller" -Verbose
		
		# Then we Actually install the AD Role and configure the new domain
		Write-Verbose -Message "Sleeping 10 seconds before adding the AD roles" -Verbose
		Start-Sleep 10

		Write-Verbose -Message "Getting Ready to Install Active Directory Services on $ComputerName" -Verbose

		Write-Verbose -Message "Adding Servermanager Powershell Module to DC" -Verbose
		Invoke-VMScript -ScriptText "import-module servermanager -passthru" -VM $ComputerName -GuestCredential $VMLocalCredential

		Write-Verbose -Message "Adding AD Role DC" -Verbose
		Invoke-VMScript -ScriptText $InstallADRole -VM $ComputerName -GuestCredential $VMLocalCredential

		#Reboot and then configure Forest 
		#Invoke-VMScript -ScriptText "Shutdown /r /t 0" -VM $ComputerName -GuestCredential $VMLocalCredential

		Write-Verbose -Message "Sleeping 60 seconds while rebooting DC $ComputerName " -Verbose
		Start-Sleep 60


		Write-Verbose -Message "Configuring New AD Forest on $ComputerName" -Verbose 
		Invoke-VMScript -ScriptText $ConfigureNewDomain -VM $ComputerName -GuestCredential $VMLocalCredential
 
		# Script Block for configuration of AD automatically reboots the machine after provisioning
		Write-Verbose -Message "Rebooting $ComputerName to Complete Forest Provisioning" -Verbose
 
		# Below sleep command is in place as the reboot needed from the above command doesn't always happen before the wait-tools command is run
		Write-Verbose -Message "Sleeping 540 seconds for DC $ComputerName to reboot" -Verbose
		Start-Sleep -Seconds 540
 
		Wait-Tools -VM $ComputerName -TimeoutSeconds 300
 
		Write-Verbose -Message "Installing AD DS Tools on $ComputerName Complete" -Verbose
		Invoke-VMScript -ScriptText $InstallADDSTools -VM $ComputerName -GuestCredential $DomainCredential
		
		Write-Verbose -Message "Sleeping 10 seconds before adding $ComputerName DNS IP setting .. again." -Verbose
		Start-Sleep 3
		# DNS Setings - dcpromo sets DNS to 127.0.0.1  -s we reset the DNS here 
		Invoke-VMScript -ScriptText $VMDNSSettings -VM $ComputerName -GuestCredential $DomainCredential

		
		Write-Verbose -Message "Installation of Domain Services and Forest Provisioning on $ComputerName Complete" -Verbose

	}
# End Domain Controller Configuration


#######################################################################
# Configure an additional domain controller, if server role is DC-sec #
#######################################################################

########################################
### DC-Sec
########################################

If ($SRVROLE -eq 'DC-Sec') {

		
		# Add VM to the domain. 
		Write-Verbose -Message "Adding VM $ComputerName to the domain" -Verbose 
		Invoke-VMScript -ScriptText $JoinNewDomain -VM $ComputerName -GuestCredential $VMLocalCredential
 
		# Below sleep command is in place as the reboot needed from the above command doesn't always happen before the wait-tools command is run
		Write-Verbose -Message "Sleeping 60 seconds waiting for $ComputerName to reboot" -Verbose
		Start-Sleep -Seconds 60
 
		Wait-Tools -VM $ComputerName -TimeoutSeconds 300
 
		Write-Verbose -Message "VM $ComputerName Added to Domain and Successfully Rebooted." -Verbose
		Write-host ""
		
		Write-Verbose -Message "$ComputerName will be configured as an additional Domain Controller" -Verbose
		
		# Install the AD Role
		Write-Verbose -Message "Sleeping 10 seconds before adding the AD roles" -Verbose
		Start-Sleep 10

		Write-Verbose -Message "Getting Ready to Install Active Directory Services on $ComputerName" -Verbose

		Write-Verbose -Message "Adding Servermanager Powershell Module to $ComputerName" -Verbose
		Invoke-VMScript -ScriptText "import-module servermanager -passthru" -VM $ComputerName -GuestCredential $DomainCredential

		Write-Verbose -Message "Adding AD Role to $ComputerName" -Verbose
		Invoke-VMScript -ScriptText $InstallADRole -VM $ComputerName -GuestCredential $DomainCredential

		#Reboot and then configure 
		Invoke-VMScript -ScriptText "Shutdown /r /t 0" -VM $ComputerName -GuestCredential $DomainCredential

		Write-Verbose -Message "Sleeping 60 seconds while rebooting $ComputerName " -Verbose
		Start-Sleep 60
		

		Write-Verbose -Message "Configuring AD on $ComputerName" -Verbose 
		Invoke-VMScript -ScriptText $ConfigureADC -VM $ComputerName -GuestCredential $DomainCredential

		Write-Verbose -Message "Installing AD DS Tools on $ComputerName Complete" -Verbose
		Invoke-VMScript -ScriptText $InstallADDSTools -VM $ComputerName -GuestCredential $DomainCredential
		$VMDNSSettings = 'netsh interface ip set dnsservers name="Ethernet0" static ' + ' ' + $DNSIP + ' primary'

}



########################################
### CTX
########################################

# Start joining VMs to Domain.
 #If the VM is not a domain controller, add it to the domain.
 
		# If server role is CTX
		If ($SRVROLE -eq 'CTX') {
		
		Write-Verbose -Message "Sleeping 15 seconds before adding $ComputerName to the domain" -Verbose
		Start-Sleep 15
		
		# The Below Cmdlets actually add the VM to the newly deployed domain. 
		Write-Verbose -Message "Adding VM $ComputerName to the domain" -Verbose 
		Invoke-VMScript -ScriptText $JoinNewDomain -VM $ComputerName -GuestCredential $VMLocalCredential
 
		# Below sleep command is in place as the reboot needed from the above command doesn't always happen before the wait-tools command is run
		Write-Verbose -Message "Sleeping 60 seconds waiting for $ComputerName to reboot" -Verbose
		Start-Sleep -Seconds 60
 
		Wait-Tools -VM $ComputerName -TimeoutSeconds 300
 
		Write-Verbose -Message "VM $ComputerName Added to Domain and Successfully Rebooted." -Verbose
		
		####!@#$%^&**!@#$%^&**!@#$%^&**!@#$%^&**!@#$%^&**!@#$%^&**!@#$%^&** ##### CALL SHAUNs CTX script
 }
 
		# If not DC or CTX
		If ($SRVROLE -notmatch "DC|CTX") {
		
		Write-Verbose -Message "Sleeping 15 seconds before adding $ComputerName to the domain" -Verbose
		Start-Sleep 15
		
		# The Below Cmdlets actually add the VM to the newly deployed domain. 
		Write-Verbose -Message "Adding VM $ComputerName to the domain" -Verbose 
		Invoke-VMScript -ScriptText $JoinNewDomain -VM $ComputerName -GuestCredential $VMLocalCredential
 
		# Below sleep command is in place as the reboot needed from the above command doesn't always happen before the wait-tools command is run
		Write-Verbose -Message "Sleeping 60 seconds waiting for $ComputerName to reboot" -Verbose
		Start-Sleep -Seconds 60
 
		Wait-Tools -VM $ComputerName -TimeoutSeconds 300
 
		Write-Verbose -Message "VM $ComputerName Added to Domain and Successfully Rebooted." -Verbose
 }
 
#Write-Verbose -Message "Installing File Server Role and Creating File Share on $FSVMName." -Verbose
 
# The below commands actually execute the script blocks defined above to install the file server role and then configure the new file share. 
#Invoke-VMScript -ScriptText "import-module servermanager -passthru" -VM $FSVMName -GuestCredential $DomainCredential
#Invoke-VMScript -ScriptText $InstallFSRole -VM $FSVMName -GuestCredential $DomainCredential
 
#Invoke-VMScript -ScriptText $NewFileShare -VM $FSVMName -GuestCredential $DomainCredential
 
 }
# End joining VMs to Domain.

}
	$y = ($y + 1)

# Disconnect from VCenter
	Disconnect-VIServer -Server * -Force -confirm:$false
}


# Setup Complete.
 Write-Verbose -Message "Environment Setup Complete" -Verbose
 $EDATE = Get-date

 # Display the Start, execute and end times
 Write-Host -foreground "Cyan" " Start time               :"	$SDATE
 Write-Host -foreground "Cyan" " Execute time             :"	$XDATE
 Write-Host -foreground "Cyan" " End time                 :"	$EDATE
 
 # Calculate and display isplay how long to execute
 $tdiff = ($EDATE - $XDATE)
 Write-Host ""
 Write-Host -foreground "Cyan" " Total execution time     :"	$tdiff minutes
# End of Script