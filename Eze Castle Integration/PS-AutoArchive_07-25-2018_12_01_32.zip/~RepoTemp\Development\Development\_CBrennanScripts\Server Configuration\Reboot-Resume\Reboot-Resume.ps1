﻿    param(
    
        [Parameter(Mandatory = $True, Position = 0)] [string]$Step
    )

function Do-Something1
{
    write-host "Do-Something1"
    "Do-Something1" | Out-File -FilePath "C:\Scripts\Do-Somehting1.txt"
}

function Do-Something2
{
    write-host "Do-Something2"
    "Do-Something2" | Out-File -FilePath "C:\Scripts\Do-Somehting2.txt"
}

function Do-Something3
{
    write-host "Do-Something3"
    "Do-Something3" | Out-File -FilePath "C:\Scripts\Do-Somehting3.txt"
}

function Reboot
{
    write-host "Reboot"
    #Restart-Computer -ComputerName .
}

function Do-Something4
{
    write-host "Do-Something4"
    "Do-Something4" | Out-File -FilePath "C:\Scripts\Do-Somehting4.txt"
}


function Set-RegKey
{
    $RegRunKey     = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
    $RegRunOnceKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    $ResumePSCommand = "C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -noexit -command '\\tsclient\Z\CBrennanScripts\Reboot-Resume\Reboot-Resume.ps1 -Step C'"
    
    Set-ItemProperty -Path $RegRunOnceKey -Name "ResumePS" -Value $ResumePSCommand 
}

function Execute-Script 
{
    BEGIN
    {
        cls
        Remove-Item "C:\Scripts\*.txt"
    }
    PROCESS
    {
        write-host "Step: " $Step
        
        if ($Step -eq "A")
        {
            Do-Something1
            Set-RegKey
        }

        if ($Step -eq "B")
        {
            Do-Something2
            Reboot
            Do-Something3
        }

        if ( $Step -eq "C")
        {
            Do-Something4
        }
    }

    END
    {
    }
}

Execute-Script

