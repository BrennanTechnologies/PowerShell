﻿function vCenterFnctn
{
    if ($VClocation -eq "ECI-BOS") 
    {
        $vCenterChoice = "bosvc.eci.cloud"
        return $vCenterChoice
    }
	
    if ($VClocation -eq "ECI-QTS") 
    {
        $vCenterChoice = "cloud-qtsvc.eci.corp"
        return $vCenterChoice
    }

    if ($VClocation -eq "ECI-SAC") 
    {
        $vCenterChoice = "sacvc.eci.cloud"
        return $vCenterChoice
    }

    if ($VClocation -eq "ECI-LHC") 
    {
        $vCenterChoice = "lhcvc.eci.cloud"
        return $vCenterChoice
    }

    if ($VClocation -eq "ECI-LD5") 
    {
        $vCenterChoice = "ld5vc.eci.cloud"
        return $vCenterChoice
    }

    if ($VClocation -eq "ECI-HK") 
    {
        $vCenterChoice = "hkvc.eci.cloud"
        return $vCenterChoice
    }

    if ($VClocation -eq "ECI-SG") 
    {
        $vCenterChoice = "sgvc.eci.cloud"
        return $vCenterChoice
    }

}

# All VMs will go into a resource pool, production - $emiRESPOOL
# Resource pool name depending on PRODTYPE, EMS or EHC
if ($PRODTYPE -eq "EMS") 
{
	$basePOOL = "ems2_" + $GPID

}
if ($PRODTYPE -eq "EHC") 
{
	$basePOOL = "hybrid2_" + $GPID

}

$exRpool = Get-ResourcePool -name $basePOOL -ErrorAction SilentlyContinue

				$currentRAM = $exRpool.MemLimitMB
				$currentCPU = $exRpool.CpuLimitMhz

			$MemLimitMB = ($MemLimitMB + $currentRAM)
			$CpuLimitMhz = ($CpuLimitMhz + $currentCPU)


# Get the VLAN ID from the EMSVRFID
	if ($csvArray.count -eq 1) {
		$VLANID = $csvArray.emsvrfid |   ForEach { $_ -Replace("EMS","") }
		}
	else {
		$VLANID = $csvArray.emsvrfid[0] |   ForEach { $_ -Replace("EMS","") }
	}


$dvSwitch = get-VDPortgroup -name $newClientPG | get-vdswitch -ErrorAction SilentlyContinue

	#POD Suffix - for example POD2051
	$podSuffix = ($dvSwitch.name -split "\-")[1]

	#POD Number - for example 2051
	$podNum = $podSuffix |   ForEach { $_ -Replace("POD","") }

	#POD name or Cluster name - for example Cloud-qts-pod2051
	$podName = "Cloud-" + $vcCode + "-" + $podSuffix
	$podNameV = get-Cluster -name $podName -ErrorAction SilentlyContinue



	$VMTempTest = Get-Template -Name $VMTemplate -ErrorAction SilentlyContinue

	$VMCustSpecTest = Get-OSCustomizationSpec -Name $VMCustomSpec -ErrorAction SilentlyContinue


	#Create EMI resource pool if needed $VCloc, is defined on line 379 as production datacenter
	if ($location -eq $VClocation -and $BNRPool[$x] -eq "YES")
	{
		Write-Host ""
		Write-Host -foreground "Yellow" " Creating EMI resource pool " -nonewline; Write-Host -foreground "Green" $emiRESPOOL
		pause
		New-ResourcePool -Location $dspArray.podName[$x] -Name $emiRESPOOL -CpuLimitMhz $CpuLimitMhz -MemLimitMB $MemLimitMB
	}
	
	elseif ($location -eq $VCloc -and $BNRPool[$x] -eq "NO"){
		Set-ResourcePool -Name $emiRESPOOL -CpuLimitMhz $CpuLimitMhz -MemLimitMB $MemLimitMB




			####################################################################
			##          DEPLOY VMs AND SET CPU,RAM AND NIC PORTGROUP          ##
			####################################################################
			Write-Verbose -Message "Deploying Virtual Machine with Name: [$ComputerName] using Template: [$VMTemplate] and Customization Specification: [$VMCustomSpec] in Resource Pool: [$RESPOOL] on Cluster: [$TargetCluster] and waiting for completion" -Verbose

			#~~~# New-VM -Name $ComputerName -Template $VMTemplate -OSCustomizationSpec $VMCustomSpec -ResourcePool $RESPOOL -DiskStorageFormat Thin -Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)  
			
			Write-Verbose -Message "Migrating Swap VMDK." -Verbose
			#~~~# $SwapDisk = Get-VM -Name $ComputerName | Get-HardDisk | where {$_.CapacityGB -like "10*"}
			#~~~# Move-hardDisk -HardDisk $SwapDisk -Datastore (Get-DatastoreCluster -Name $SwapDataStore | Get-Datastore | Get-Random) -StorageFormat 'Thin' -Confirm:$false
		
			Write-Host ""
			Write-Verbose -Message "Setting CPU and RAM on $ComputerName Deployed" -Verbose
			Start-Sleep -Seconds 2
			#~~~# Set-VM $ComputerName -MemoryGB $RAM -NumCPU $nCPU -Confirm:$False
			
			# Create the VirtualMachineConfigSpec with which to reconfig the VM and set cores per socket
			Start-Sleep -Seconds 2
			#~~~# $spec = New-Object -Type VMware.Vim.VirtualMachineConfigSpec -Property @{"NumCoresPerSocket" = $CPS}

			# Apply this spec to the VM
			# This will give 2 sockets with 2 CPU per socket
			Start-Sleep -Seconds 2
			#~~~# (Get-VM $ComputerName).ExtensionData.ReconfigVM_Task($spec)

			# Set the port group in the VM to the $multipgrp
			Write-Verbose -Message "Setting the port group on $ComputerName " -Verbose
			Start-Sleep -Seconds 2
			#~~~# get-vm -name $ComputerName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $multipgrp -Confirm:$false
			
			Write-Host ""
			Write-Verbose -Message "Virtual Machine $ComputerName Deployed. Powering On" -Verbose
			Start-Sleep -Seconds 2
			#~~~# Start-VM -VM $line.VMName
			Write-Host ""
			
			#Add new VMDK for Files to Domain Controllers and move to $emsFILESds 
				if ($SrvRole -like "DC*"){
					Write-Verbose -Message "Adding new VMDK for Files to $ComputerName " -Verbose
					$vm = get-vm $ComputerName
			#~~~# 		$vm | New-HardDisk -CapacityGB 100 -Datastore (Get-DatastoreCluster -Name $FilesDataStore | Get-Datastore | Get-Random) -StorageFormat 'Thin' -Confirm:$false
				}
			#}


New-VM `
-Name $ComputerName `
-Template $VMTemplate `
-OSCustomizationSpec $VMCustomSpec `
-ResourcePool $RESPOOL `
-DiskStorageFormat Thin `
-Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)  









