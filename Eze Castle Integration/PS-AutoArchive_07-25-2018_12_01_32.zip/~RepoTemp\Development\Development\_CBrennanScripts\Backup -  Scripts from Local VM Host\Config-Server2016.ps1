﻿<# TODO
----------------------------------------------------------------------------------------------------

- Install all Windows Updates available
4. Set Network Information 
    - CHECK “Internet Protocol Version 6 (TCP/IPv6)”
    - Enter the IP address, Subnet mask, Default gateway, and DNS server information. 

- Set up NIC teaming on network infrastructures that can support fault-tolerant LAN switching. This can only be done with the server has two NICs and software that can support It. 

- FOR VIRTUAL SERVERS: Create additional disk partitions based on the server function (refer to the appropriate standard for that function) 

6. Install all Windows Updates available
    - ‘Update & Security’
    - Verify that the Windows Updates Settings says DownloadOnly 
    - After the updates are installed the server will reboot.

7. FOR VIRTUAL SERVERS: Create additional disk partitions based on the server function (refer to the appropriate standard for that function) 

8. Configure Disks 
- Right-click the CD-ROM drive and choose “Change Drive Letter and Paths”  Click “Change” and choose “R” from the drop-down list. Click OK twice 

- Create a primary disk partition (D:) for the Swap & Kits drive from Disk Management 
    - Label the Swap drive “Swap” or “Swap and Kits”.
    Copy the contents of the Server 2016 DVD to the D:\Kits folder 
    - Disable Files/Folder Compression
    - In the Registry Editor, locate the following key:HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem If the NtfsDisableCompression DWORD Does Not Exist, create it, if it does then skip the following bullet points: 

9. Configure Paging (Swap) File

10. Create a folder called “Scripts” in the root of the C: drive to store all non-logon scripts 
    - Create a folder called “Kits” in the root of the D: drive to store all installation files

11. Configure Remote Desktop
    - Choose “Allow Remote connections to this computer” Make sure that the “Allow Connections only from Computers running Desktop with Network Level Authentication (Recommended)” is not checked. 

12. Disable “Restrict each user to a single session”
     - Type “GPEDIT.MSC” and on the Local Group Policy Editor navigate to “Computer Configuration\ Administrative Templates\ Windows Components\ Remote Desktop Services\ Remote Desktop Session Host\ Connections” 
        Double click “Restrict Remote Desktop user to a single Remote Desktop session” 
        Check “Not configured” or “Disable” and click “OK” 
        FOR VIRTUAL CITRIX SERVERS: Check the “Restrict each user to a single session” and click “OK”. Check with your CTM 

13. Disable Automatic Reboot 



14. Disable IE IE Enhance Security Configuration

15. Rename Administrator to ECIAdmin
    - Open the “eciadmin” user properties and make sure the password is set to never expire 

16. Rename Server and Join to Domain 

17?  - Install-WindowsFeature RSAT 
     - Install-WindowsFeature Telnet-Client



----------------------------------------------------------------------------------------------------
#>

function Import-CommonFunctions 
{
    ### Reload Module at RunTime
    if(Get-Module -Name "CommonFunctions"){Remove-Module -Name "CommonFunctions"}

    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")   {$Module = "\\tsclient\P\CBrennanScripts\Modules\CommonFunctions\CommonFunctions.psm1"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM") {$Module = "\\tsclient\P\CBrennanScripts\Modules\CommonFunctions\CommonFunctions.psm1"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")     {$Module = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\CommonFunctions\CommonFunctions.psm1"}
    if($env:COMPUTERNAME  -eq "W2K16V2")      {$Module = "\\tsclient\Z\CBrennanScripts\Modules\CommonFunctions\CommonFunctions.psm1"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")      {$Module = "\\tsclient\Z\CBrennanScripts\Modules\CommonFunctions\CommonFunctions.psm1"}
    
    $Module = "C:\Users\Administrator\Documents\CommonFunctions.psm1"

    ### Import the Module
    Import-Module -Name $Module -DisableNameChecking #-Verbose
    
    ### Test the Module - Exit Script on Failure
    if( (Get-Module -Name "CommonFunctions")){Write-Host "Loading Custom Module: CommonFunctions" -ForegroundColor Green}
    if(!(Get-Module -Name "CommonFunctions")){Write-Host "The Custom Module CommonFunctions WAS NOT Loaded! `nFunctions Wont Work! `nExiting Script!" -ForegroundColor Red;exit}
}

function Import-Parameters
{
    $ScriptBlock = 
    {
        ### Hard Code the Parameter File
        $ParameterFile = "Parameters.csv"

        ### Set Parameter File Path 
        $ParametersFilePath =  $ScriptPath + "\" + $ParameterFile

        ### Check if Parameter File Exits
        write-log "Checking for Parameter File: $ParameterFile"

        if(-not (Test-Path $ParametersFilePath))
        {
            write-log "Parameter File Missing: $ParameterFile" -Foregroundcolor Red
            write-log "Exiting Script!" -Foregroundcolor Red
            Exit
        }
        else
        {
            write-log "Parameter File Exists. Importing: $ParameterFile" -Foregroundcolor Green
        }

        ###########################
        ### Initialize Parameters
        ###########################

        ### Import from CSV file
        $script:Parameters = Import-CSV -path $ParametersFilePath 

        foreach ($Parameter in $Parameters)
        {
            # Set Variable Scope to "Script" for Functions
            Set-Variable -Name $Parameter.NewParameter -Value $Parameter.NewValue -scope global
                
            # Verify Variables
            $Verify = Get-Variable -Name $Parameter.NewParameter
            #$Parameter.NewParameter
            #$Parameter.NewValue
        }            
    }

    Try-Catch $ScriptBlock
}

function Write-Config
{
    Param(
    [Parameter(Mandatory = $True, Position = 0)] [string]$Msg,
    [Parameter(Mandatory = $False, Position = 1)] [string]$String,
    [Parameter(Mandatory = $False, Position = 2)] [string]$String2,
    [Parameter(Mandatory = $False, Position = 3)] [string]$String3,
    [Parameter(Mandatory = $False, Position = 4)] [string]$String4
    )

`    ### Write the Message to the Config Report.
    $Msg = $Msg + $String + $String2 + $String3 + $String4
    Write-Host $Msg -ForegroundColor White
    
    ### Export Config File
    $script:ConfigReportFile = $ReportPath + "\ConfigReport_" + $ScriptName + "_" + $TimeStamp + ".log"
    $Msg | Out-File -filepath $ConfigReportFile -append   # Write the Log File Emtry
}

function Start-ConfigReport
{
    $script:ConfigReportFile = $ReportPath + "\ConfigReport_" + $ScriptName + "_" + $TimeStamp + ".log"

    ### Write Config Report Header
    Write-Config "Server Configuration Report:"
    Write-Config  ('-' * 50) 
    $ConfigReport = @()
    $ReportHeader = @{
        New_Computer_Name = $NewComputerName
        Build_Date        = (Get-Date)
        New_Domain        = $NewDomain
        Target_Server     = $env:COMPUTERNAME
        Target_Domain     = $env:USERDNSDOMAIN
    }

    $PSObject      = New-Object PSObject -Property $ReportHeader
    $ConfigReport += $PSObject 
    $ConfigReport | Format-List
    $ConfigReport | Format-List | Out-File  -filepath $ConfigReportFile -append 
    
    ### Write Input Parameters
    Write-Config "Input Parameters:"
    Write-Config  ('-' * 50) 

    $Params = @()
    foreach ($Parameter in $Parameters)
    {
        $NewParams = [ordered]@{
        NewParameter = $Parameter.NewParameter
        NewValue     = $Parameter.NewValue
        }

        ### Build Parameter Report Header
        $PSObject      = New-Object PSObject -Property $NewParams
        $Params       += $PSObject 
    }  
    $Params | Format-Table -AutoSize
    $Params | Format-Table -AutoSize | Out-File  -filepath $ConfigReportFile -append 
}

workflow Reboot-Computer
{
    ### Rename Computer
    #write-host "Renaming Local Computer"
    #Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru
            
    ### Reboot Computer
    Restart-Computer -Wait -PSComputerName $CurrentComputerName

        ### Verify the New Computer Name
        $NewComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name
        #Write-Host "New Computer Name: $NewComputerName" 
        $NewComputerName | Out-File -FilePath -Path "$ReportPath \Test.txt"
}

function Rename-LocalComputer
{

    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[2].Command) `n('-' * 50)

        #$CurrentComputerName = $env:COMPUTERNAME
        $CurrentComputerName = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Name

        ### CheckCurrent Computer Name1
        if($CurrentComputerName -ne $NewComputerName)
        {
            ### Rename Computer
            write-host "Renaming Local Computer"
            Rename-Computer –ComputerName  $CurrentComputerName –NewName $NewComputerName # -LocalCredential $AdministratorAccount -PassThru
            
            ### Reboot Computer
            #Restart-Computer -Wait -PSComputerName CurrentComputerName

            ### Verify Computer Name
            write-Host "The computer is now named: $CurrentComputerName"
        }

        elseif(CurrentComputerName -eq $NewComputerName)
        {
            ### Names are the Same
            write-host "Computer Names are the same"
        }

    }

    Try-Catch $ScriptBlock
}
function Rename-Interface
{
        Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

        $ScriptBlock = 
        {
            ### Get NIC that is currently in use.
            $ExistingInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name

            #### Check if Interface Name Exists before Renaming
            if ($ExistingInterfaceName -ne $NewInterfacename )
             {
                Rename-NetAdapter (Get-NetAdapter -Name $ExistingInterfaceName).Name -NewName $NewInterfaceName
                                    
                ### Verify
                $VerifyInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
                if($VerifyInterfaceName -eq $NewInterfacename)
                {
                    Write-Config "VERIFIED: Interface $ExistingInterfaceName renamed to $VerifyInterfaceName"
                }
            }

            elseif($ExistingInterfaceName -eq $NewInterfacename)
            {
                Write-Config "Not Renaming interface. Adapter is already named $ExistingInterfaceName"
            }
            elseif($ExistingInterfaceName -ne $NewInterfacename)
            {
                Write-Config "Interface Not Renamed -  ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
            }
        }

    Try-Catch $ScriptBlock
}

function Set-IPv4
{
        $ScriptBlock = 
        {
            ### Cast the variables as IP address.
            [IPAddress]$NewIPv4Address     = $NewIPv4Address.Trim()
            [IPAddress]$NewDefaultGateway  = $NewDefaultGateway.Trim()

            ### Get the Current NIC
            $CurrentInterface  = Get-NetAdapter –Physical | where Status -eq 'Up'
            $CurrentInterfaceName = $CurrentInterface.Name

            ### Determine if IPv4 Address is Static of if DHCP is enabled.
            $DhcpStatus = (Get-NetIPInterface -AddressFamily IPv4 -InterfaceAlias $CurrentInterfaceName).DHCP
            write-host "DHCP Status:"  $DhcpStatus

            ### If DHCP is Enabled, Create New IPv4 Address, Else Set IPv4 Address.
            if ($DhcpStatus -eq "Enabled")
            {
                ### Set the IPv4 Settings
                write-config "Adding New IPv4 Address: -InterfaceAlias $CurrentInterfaceName -IPAddress $NewIPv4Address -AddressFamily: IPV4 –PrefixLength: $NewPrefixLength -DefaultGateway: $NewDefaultGateway"
                New-NetIPAddress –InterfaceAlias $CurrentInterfaceName -IPAddress $NewIPv4Address -AddressFamily IPV4 –PrefixLength $NewPrefixLength -DefaultGateway $NewDefaultGateway #| Out-Null
            }
            ### If IPv4 is currently Static, use Set commands
            elseif ($DhcpStatus -eq "Disabled")
            {
                ### Get the Stiatic IPs
                $CurrentIPs = (Get-NetIPAddress –InterfaceAlias $CurrentInterfaceName).IPAddress

                if( -NOT ($CurrentIPs.Contains([string]$NewIPv4Address)))
                {
                    write-config "Configuring Existing IPv4 Address: -InterfaceAlias $CurrentInterfaceName -IPAddress $NewIPv4Address -AddressFamily: IPV4 –PrefixLength: $NewPrefixLength -DefaultGateway: $NewDefaultGateway"
                    New-NetIPAddress –InterfaceAlias $CurrentInterfaceName -IPAddress $NewIPv4Address -AddressFamily IPV4 –PrefixLength $NewPrefixLength #-DefaultGateway $NewDefaultGateway #| Out-Null
                }
                                
                elseif ($CurrentIPs.Contains([string]$NewIPv4Address))
                {
                    write-host "IPv4 Address is already configured: $NewIPv4Address"
                }
            }
        }

        Try-Catch $ScriptBlock
}

function Set-IPv6
{
    # Get Name of current network adapter
    write-host "Finding Current Network Interface"
    $CurrentInterface     = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name

    # Check IPv6 Status 
    $IPv6Status = (Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)").Enabled
    Write-Host "IPv6 Status: $IPv6Status"            

    if($IPv6Status)
    {
        Write-Host "IPv6 Status:"  $IPv6Status
    }



    # Use to Disable IPv6
    #Write-Host "Disabling IPv6 on Interface $CurrentInterfaceName"
    #Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID ms_tcpip6


}

function Set-CDRom
{
    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[2].Command) `n('-' * 50)
        
        ### Drive Letter Must End with Colon ":"
        $LastChar = $NewCDLetter.substring($NewCDLetter.length-1) 
        if ($LastChar -ne ":"){$NewCDLetter = $NewCDLetter + ":"}

        ### Get the Current CD-ROM Letter & Volume
        $CurrentCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive

        if ($CurrentCDLetter -ne $NewCDLetter)
        {
            ### Get the CD Volume Object
            $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $env:computername -Filter "DriveLetter='$CurrentCDLetter'" -ErrorAction Stop            
 
            ### Change the CD-ROM Letter of the CD Volume Object
            Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter=$NewCDLetter} | Out-Null

            ### Verify New CD-ROM Letter
            $VerifiedCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:computername).Drive
            if ($CurrentCDLetter -eq $NewCDLetter)
            {
                Write-Config "VERIFIED:`t CD-ROM CurrentCDLetter: $CurrentCDLetter renamed to VerifiedCDLetter: $VerifiedCDLetter"
            }
            elseif($CurrentCDLetter -ne $NewCDLetter)
            {
                Write-Config "Mismatch - CurrentCDLetter: $CurrentCDLetter doesnr match NewCDLetter: $NewCDLetter"
            }
        }
        else
        {
            Write-Config "Not Renaming CD-Rom. Drive Letters are the same: CurrentCDLetter: $CurrentCDLetter"
        }
    }

    Try-Catch $ScriptBlock
}

function Set-SwapFile
{
    $ScriptBlock = 
    {
        function Set-SwapFile-Physical
        {
            $NewSwapFileLocation = "D:"
            $PageFileInitialSize = "1024"
            $PageFileMaximumSize = "1024"

            ### Turn Off Automatic PageFile Management
            $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges
            if ($ComputerSystem.AutomaticManagedPagefile)
            {
                $ComputerSystem.AutomaticManagedPagefile = $false
                $ComputerSystem.Put()
            }

            ### Delete the Current PageFile
            $CurrentPageFile = Get-WmiObject -Query "select * from Win32_PageFileSetting where name = $CurrentPageFileLocation"
            $CurrentPageFile.delete()

            ### Create New Page File
            $NewPageFileLocation = $NewSwapFileLocation + "\pagefile.sys" 
            Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$NewPageFileLocation; InitialSize = $PageFileInitialSize; MaximumSize = $PageFileMaximumSize}
        }

        function Set-SwapFile-HyperV
        {
            ### This code is not complete

            $ComputerName = "2012_R2_Base"
            $SmartPagingFilePath = "D:\SmartPaging"

            if((Get-Module Hyper-v) -ne $Null)
            {
                Get-VM | where-object {$_.Name -like $ComputerName  } 
                Set-VM -ComputerName $ComputerName -SmartPagingFilePath $SmartPagingFilePath
            }
            elseif((Get-Module Hyper-v) -eq $Null)
            {
            write-host "This host is a Hyper-V VM."
            write-host "These commands require the Hyper-V Module & Services to be loaded"
            Pause-Script "This host is a Hyper-V VM. `n`n These commands require the Hyper-V Module & Services to be loaded. `n`n Hit any key to Continue."
            }
        }

        function Set-SwapFile-VMWare
        {
            write-host "This host is a VMWare VM."
            write-host "These commands require the PowerCLI Module & Services to be loaded"
            Pause-Script "This host is a Hyper-V VM. `n`n These commands require the PowerCLI V Module & Services to be loaded. `n`n Hit any key to Continue."

            ### This code is not complete
            <#
            Get-VM  | %{
            $ds = $_.ExtensionData.Layout.Swapfile.Split(']')[0].TrimStart('[')
            $_ | Select Name,@{N="Swap DS";E={$ds}},@{N="Free GB";E={[math]::Round($dsTab[$ds],1)}}
            #>
        }

        function Get-MachineType
        {
            $Computer = $env:COMPUTERNAME
            $ComputerSystemInfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $env:COMPUTERNAME #-ErrorAction Stop -Credential $Credential 

            switch ($ComputerSystemInfo.Model) 
            { 
                # Check for Hyper-V Machine Type 
                "Virtual Machine" 
                { 
                    $MachineType="Hyper-V" 
                    $Machine = "VM"
                } 
 
                # Check for VMware Machine Type 
                "VMware Virtual Platform"
                { 
                    $MachineType="VMware"
                    $Machine = "VM" 
                } 
 
                # Check for Oracle VM Machine Type 
                "VirtualBox" 
                { 
                    $MachineType="VirtualBox" 
                    $Machine = "VM"
                }
                default 
                { 
                    $MachineType="Physical"
                    $Machine = "Physical" 
                } 
                }          
  
            $script:Machine              = $Machine
            $script:MachineType          = $MachineType 
            $script:MachineModel         = $ComputerSystemInfo.Model 
            $script:MachineManufacturer  = $ComputerSystemInfo.Manufacturer 

            write-host "This host is a VM. Thee are the properties:"
            write-host "Machine: "             $Machine
            write-host "MachineType: "         $MachineType
            write-host "MachineModel: "        $MachineModel
            write-host "MachineManufacturer: " $MachineManufacturer
        }

        ### Detect Machine Type ###

        # Call the Function
        Get-MachineType

        if($MachineType -eq "Physical")
        {
            write-host "Machine is Physical"
            # Call the Function
            Set-SwapFile-Physical
        }
        elseif($MachineType -eq "Hyper-V")
        {
            write-host "Hyper-V"
            Set-SwapFile-HyperV
        }
        elseif($MachineType -eq "VNWare")
        {
            write-host "Hyper-V PowerCLI"
            Set-SwapFile-VMWare
        }
    }

    Try-Catch $ScriptBlock

}
function Add-WindowsFeatures
{
    $ScriptBlock = 
    {
        $FeatureNames  = @()
        $FeatureNames += "NET-Framework-Features"
        $FeatureNames += "NET-Framework-Core"
        $FeatureNames += "GPMC"
        $FeatureNames += "RSAT"
        $FeatureNames += "Telnet-Client"

        ### List Features to Install
        write-log "The following Features will be installed" cyan
        foreach ($FeatureName in $FeatureNames)
        {
            write-log $FeatureName white
        }

        foreach ($FeatureName in $FeatureNames)
        {
            ### Install Feature
            function Ask-Install
            {
                $Msg = "Do you want to Install `n $FeatureName ?"
                $ReadHost = Read-Host "$Msg [Y/N]"
                $ReadHost = $ReadHost.ToUpper()

                if ($ReadHost -eq "Y" )
                {
                    write-log "Installing $FeatureName"
                    Install-WindowsFeature -name $FeatureName
                }
                elseif($ReadHost -eq "N")
                {
                    write-host "Continueing"
                    continue
                }
                elseif (($ReadHost -ne "Y") -or ($ReadHost -ne "N"))
                {
                    write-host "You did not enter Y or N!" -foregroundcolor cyan
                    Ask-Install
                }
            }
            ### Use this to call the function
            Ask-Install

            ### Verify Feature
            Write-log "Verifying Installaton of $FeatureName"
            $Feature = Get-WindowsFeature -name $FeatureName 
            if($Feature.Installed -eq "True")
            {
                Write-log "Feature is Installed" Green
                write-host "Name: " $Feature.Name "Installed: " $Feature.Installed -ForegroundColor Green
            }
            if($Feature.Installed -ne "True")
            {
                Write-log "Feature not Installed" Red
                write-host "Name:" $Feature.Name "Installed:" $Feature.Installed -ForegroundColor Red
            }
        } 
    }
    
    Try-Catch $ScriptBlock
}

function Update-Windows
{
    $ScriptBlock = 
    {
        ## Set the Path too the Modules
        #$script:ScriptPath  = split-path -parent $MyInvocation.MyCommand.Definition # Required method for PS 2.0
        $script:PSWindowsUpdateScriptPath = $ScriptPath + "\PSWindowsUpdate\"

        function Install-Updates
        {
            ### Install Updates
            Get-WUInstall  -IgnoreReboot 
        }

        function Ask-YesNo($Prompt, $YesMsg, $NoMsg)
        {
            ### Advanced Function using cmdletbinding Methods
            [cmdletbinding()]

            [Parameter(Mandatory=$True, Position=0)]
            [String]$Prompt,

            [Parameter(Mandatory=$True, Position=1)]
            [String]$YesMsg

            [Parameter(Mandatory=$True, Position=1)]
            [String]$NoMsg

            $ReadHost = Read-Host "$Prompt [Y/N]"
            $ReadHost = $ReadHost.ToUpper()

            if ($ReadHost -eq "Y" )
            {
                write-host $YesMsg
                Install-Updates
            }
            elseif($ReadHost -eq "N")
            {
                write-host $NoMsg
            }
            elseif (($ReadHost -ne "Y") -or ($ReadHost -ne "N"))
            {
                write-host "You did not enter Y or N!" -foregroundcolor white
                Ask-YesNo
            }
        }

        function Install-PSWindowsUpdateModule
        {
            # This function uses the Windows Update Module for PowerShell
  
            ### Check for Module
            if( -not (Test-Path $PSWindowsUpdateScriptPath))
            {
                write-log "The PSWindowsUpdate module is not avalable in $PSWindowsUpdateScriptPath."
            }
            elseif( -not (Test-Path $PSWindowsUpdateScriptPath))
            {
                write-log "Module exists. Importing." 
            }

            ### Unbloack the Files
            Unblock-File -Path "$PSWindowsUpdateScriptPath\*"

            ### Import the Module
            Import-Module $PSWindowsUpdateScriptPath\PSWindowsUpdate

            ### Show PSWindowsUpdate Commandlets
            #Get-Command –module PSWindowsUpdate
        }

        function List-AvailableUpdates
        {
            ### List Avaialable Updatesi
            Write-Host "Getting List of Udates: This requires Internet Access"
            Write-Host "Getting List of the Updates Avalable for this Computer. `n This may take a minute . . ." -ForegroundColor Cyan
            Get-WUInstall -ListOnly | FT Title, KB #, ComputerName, Size   
        }

        function Run-Updates
        {
            Install-PSWindowsUpdateModule
            List-AvailableUpdates
            Ask-YesNo "Do You want to install these updates?" "Installing Updates" "Canceling Update Installs"
        }

        function Check-InternetConnection
        {

            $TargetURL = "google-public-dns-a.google.com"
            $TargetIP  = "8.8.8.8"
                 
            write-host "Testing Internet Connection."
            $TestInternetConnection = [Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet 
            $PingInternet = Test-Connection $TargetIP -count 1 -quiet


            If ($PingInternet -eq "True")
            {
                write-host "Internet Connection is Good."
                Run-Updates
            }
            elseif($PingInternet -eq "False")
            {
                write-host "Internet Connection is not Available."
            }
        }
    
    Write-Host "Windows Updates requires a connection to the Internet. `n Testing internet connection."
    Check-InternetConnection

        
    }
    Try-Catch $ScriptBlock

}

function Set-FirewallRules
{
    $ScriptBlock = 
    {
        $Parameters = @{
            DisplayName = "Allow RDP from 10.0.0.0/24"
            LocalPort = 3390
            Direction="Inbound"
            Protocol ="TCP" 
            Action = "Allow"
                
            # Get the Remote Address from the $ParamaterFile
            RemoteAddress = $AllowRDPSubnet
        }

        ## Checking if the Rule Exists
        write-host "Checking if rule exists: " $Parameters.DisplayName
        $Rules = Get-NetFirewallRule -DisplayName *
            
        if (-not $Rules.DisplayName.Contains($Parameters.DisplayName)) 
        {
            ### Create New Firewall Rule
            Write-Log "This rule Does not exist. Creating New Firewall Rule"
            New-NetFirewallRule -DisplayName $Parameters.DisplayName -Action $Parameters.Action -Direction $Parameters.Direction `
            –LocalPort $Parameters.LocalPort -Protocol $Parameters.Protocol -RemoteAddress $Parameters.RemoteAddress| Out-Null
        }
        else
        {
            write-host "This rule already exists. Not Creating"
        }

        ### Show the Firewall Settings
        write-log "Checking the Firewall Settings"
        $FirewallRule = Get-NetFirewallRule -DisplayName $Parameters.DisplayName
        write-host "DisplayName: " $FirewallRule.DisplayName "Action: " $FirewallRule.Action "Enabled: " $FirewallRule.Enabled
    }
    Try-Catch $ScriptBlock
}

function Rename-LocalAdministrator
{

    $ScriptBlock = 
    {

        function Get-CurrentAdmin
        {
            ### Find the Current Local Administrator Account
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
            $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
            $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
            $Searcher.QueryFilter = $UserPrincipal

            ### The Administrator account is the only account that has a SID that ends with “-500”
            $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
            $script:CurrentAdminName = $Account.Name
            Write-Log "The current Local Administrator Account is: $CurrentAdminName"
        }

        function Rename-Admin
        {
            ### Get the Current Local Admin Account
            $User= Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | Where {$_.Name -eq $CurrentAdminName}

            ### Rename the Current Local Admin Account
            write-host "Renaming $CurrentAdminName to $NewAdminName "
            $user.Rename($NewAdminName) | Out-Null
        }

        function Check-CurrentAdmin
        {
            ### Check if Local Admin is already renamed

            if($CurrentAdminName -eq $NewAdminName)
            {
                write-host "CurrentAdminName is the same as NewAdminName"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
            }
            elseif($CurrentAdminName -ne $NewAdminName)
            {
                write-host "Renaming Local Admin Account"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
                Rename-Admin
            }
        }

        function Verify-NewAdmin
        {
            write-host "Verifying new Admin Account Name"
            Get-CurrentAdmin
        }

        Get-CurrentAdmin
        Check-CurrentAdmin
        Verify-NewAdmin

    }

    Try-Catch $ScriptBlock
}

function Join-ComputerToDomain
{
    $ScriptBlock = 
    {
        Param([String]$User = "Administrator")

        function Join-Domain
        {
            write-host "Addding computer to domain $ADDomain"
            $Password = Read-Host -Prompt "Enter password for $ADDomain\$User" -AsSecureString 
            $UserName = "$ADDomain\$user" 
            $credential = New-Object System.Management.Automation.PSCredential($UserName,$Password) 

            try
            {
                Add-Computer -DomainName $ADDomain -Credential $Credential #-restart –force
            }

            catch
            {
                write-log "Unable to join Domain $ADDomain"
                $error[0]
            }
        }

        ### Check if Domain is reachable
        if (Test-Connection $ADDomain)
        {
            write-host "Adding computer to Domain $ADDomain"
            Join-Domain
        }
        elseif(-not (Test-Connection $ADDomain))
        {
            write-host-"The Domain $ADDomain is not reachable"
        }
    }

    Try-Catch $ScriptBlock
}

function Execute-Script 
{

   
    BEGIN 
    {
        # Initialize Script
        #--------------------------
        Clear-Host
        Write-Host "`nRunning: BEGIN Block" -ForegroundColor Blue
        Import-CommonFunctions 
        Set-ScriptVariables
        #Start-Transcribing 
        Start-LogFiles
    }

    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue
        # Run Functions
        #--------------------------
        Import-Parameters
        Start-ConfigReport
        #Rename-LocalComputer
        #Rename-Interface
        #Set-TimeZone
        Set-IPv4
        #Set-IPv6
        #Set-CDRom
        #Set-SwapFile
        #Add-WindowsFeatures
        #Update-Windows
        #Set-WindowsFirewall
        #Add-WindowsFeatures
        #Rename-LocalAdministrator
        #Join-ComputerToDomain

        <#
        Configure-RemoteDesktop
        Create-ScriptsFolder
        Create-KitssFolder
        Disable-AutomaticReboot
        Diable-IE-ESC

        #>
    }

    END 
    {
        # Close Script
        #--------------------------
        Write-Log "`nRunning: END Block"  -ForegroundColor Blue
        #Close-LogFile -Quiet
        #Measure-Script
        #Stop-Transcribing
    }
}
Execute-Script