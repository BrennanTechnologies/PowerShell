﻿function Set-VMExecutionPolicy
{
    ### Set Execution Policy on Guest VM
    ### ----------------------------------------------------------------------
    try
    {
        Set-ExecutionPolicy Bypass
    }
    catch
    {
        Write-Host "Error: $Error[0]" 
    }
}

function Invoke-BootStrapModuleLoader
{
    ### Connect a Non-Persistent Drive - then Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $global:RootPath = "\\eciscripts.file.core.windows.net\clientimplementation"
    New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.ModuleLoader.ps1"
    #. "X:\Root\ECI.ModuleLoader.ps1"
}

function Import-ParametersToGuestVM
{


    ### Import API Parameters


    ### imorpt Script Parameters

}

function Import-APIParameters
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    Write-Host "Importing Parameters from API (or .CSV):" -ForegroundColor Magenta
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Varibles = @()
    foreach ($Parameter in (Import-CSV -path $ParameterFile))
    {
        # Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -scope global
                
        # Verify Variables
        $Varibles += Get-Variable -Name $Parameter.Name
    }  
    
    $Varibles | ft
}

function Stage-ConfigFiles
{

    $Src = ""
    $Dest = ""

    Copy-Item -Path $src -Destination $Dest

}

#######################################
### Import Parameters from API
#######################################
function Import-APIParameters
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    Write-Host "Importing Parameters from API (or .CSV):" -ForegroundColor Magenta
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Varibles = @()
    foreach ($Parameter in (Import-CSV -path $ParameterFile))
    {
        # Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -scope global
                
        # Verify Variables
        $Varibles += Get-Variable -Name $Parameter.Name
    }  
    
    $Varibles | ft
}

&{

    BEGIN
    {
        $Step = "1"
        Start-Transcript
        Write-Host "BEGIN-STEP: $Step"
        Set-VMExecutionPolicy
        Invoke-BootStrapModuleLoader
        #Import-ParametersToGuestVM
        #Import-APIParameters

    }
    PROCESS
    {
        Write-Host "BEGIN-STEP: $Step"

    }
    END
    {
        Write-Host "BEGIN-STEP: $Step"
        Stop-Transcript
    }

}


function InvokeVMScript-Step1
{
    ##########################################################################################
    $global:FunctionName = $MyInvocation.MyCommand.Name
    ##########################################################################################

    Write-Host "Running Function: " $FunctionName -ForegroundColor Yellow
    
    #$ScriptText = $Null

    $ScriptText = 
    {
        ### Set Execution Policy on Guest VM
        ### ----------------------------------------------------------------------
        Set-ExecutionPolicy Bypass
        
        ### Import BootStrap Module Loader
        ### -------------------------------------------
        #BootStrapModuleLoader#

        ### Import Parameters To VMGuest from API/VMHost
        ### -------------------------------------------
        #ImportParametersToVMGuest#

        function Import-ParametersToVMGuest
        {
            ### Pass in Paramters from API/VMHost
            ### ----------------------------------------------------------------------
            
            ### API PArameters (#<ParameterName># Gets -Replace w/ Values)
            $ComputerName = "#ComputerName#"
            $DomainName = "#DomainName#"
            $IPv4Address = "#IPv4Addres#"
            $SubnetPrefix = "#SubnetPrefix#"
            $DefaultGateway = "#DefaultGateway#"
            $DNS1 = "#DNS1#"
            $DNS2 = "#DNS2#"
            
            ### Script Parameters
            $VM  = "#VM#"

            Write-Host "`nImporting API Parameters:`n"('-' * 50)
            Write-Host "ComputerName   : " $ComputerName
            Write-Host "DomainName     : " $DomainName
            Write-Host "IPv4Address    : " $IPv4Address
            Write-Host "SubnetPrefix   : " $SubnetPrefix
            Write-Host "DefaultGateway : " $DefaultGateway
            Write-Host "DNS1           : " $DNS1
            Write-Host "DNS2           : " $DNS2
            
            Write-Host "`nImporting Script Parameters:`n"('-' * 50)
            Write-Host "VM             : " $VM
            Write-Host ('-' * 50)
        }
        
        &{
            BEGIN
            {
                Write-Host "BEGIN-INVOKE:"
                Import-ParametersToVMGuest 
                Start-Transcript
                #Start-VMLogs
              
            }
            PROCESS
            {
                Write-Host "PROCESS-INVOKE:"
                #Get-VMGuestData

            }
            END
            {
                Write-Host "BEGIN-INVOKE:"
                Stop-Transcript
            }
        }
    }

    #function Import-ParametersToGuestVM
    #    {
        ### Replace Variables with Literal Values for the Invoke-VMScript 
        ### ----------------------------------------------------------------
        $Params = @{
        
            ### API Parameters
            $ComputerName    = "#ComputerName#"
            $DomainName      = "#DomainName#"
            $IPv4Address     = "#IPv4Addres#"
            $SubnetPrefix    = "#SubnetPrefix#"
            $DefaultGateway  = "#DefaultGateway#"
            $DNS1            = "#DNS1#"
            $DNS2            = "#DNS2#"
        
            ### Script Parameters
            $VM              = "#VM#"
        }

        ### Inject Variables into ScriptText Block
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Value,$Param.Key
        }
    #}    
    
    #Import-ParametersToGuestVM
    
    ### Inject BootStrap Module Loader into VM Host
    $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader
    
    ### Debugging: Write ScriptText Block to Screen
    write-host "ScriptText:"
    $ScriptText
    
    Write-Host "Invoking ScriptText: $ScriptTextName" -ForegroundColor Cyan
    $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword Tolkien4374 -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

    Write-Host $Invoke.ScriptOutput

    if (($Invoke.ExitCode) -eq 0)
    {
        Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
    }
    elseif (($Invoke.ExitCode) -ne 0)
    {
        Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
    }



    ##########################################################################################
}
