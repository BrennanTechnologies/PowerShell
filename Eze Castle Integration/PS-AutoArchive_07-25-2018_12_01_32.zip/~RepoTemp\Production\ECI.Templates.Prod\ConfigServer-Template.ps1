﻿function Import-CBModules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")     {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM")   {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")       {$ModulePath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    #if($env:USERDNSDOMAIN -eq "ECI.CORP")       {$ModulePath = "P:\CBrennanScripts\Modules"}
    if($env:COMPUTERNAME  -eq "W2K16V2")        {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "C:\Scripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}

    ### Add Custom Modules to Path
    if(-NOT($env:PSModulePath.Contains($ModulePath))) {$env:PSModulePath = $ModulePath + ";" + $env:PSModulePath}
        
    ## Modules to Load
    $Modules = @()
    $Modules += "CommonFunctions"
    $Modules += "ConfigServer"
  

    foreach ($Module in $Modules)
    {
        write-host "Importing Module: Path: $ModulePath Module: $Module" -ForegroundColor Magenta
       
        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module -ErrorAction SilentlyContinue | out-null}

        ### Import the Module
        ### DO NOT Specify Module Literal Path: Must load through $env:PSModulePath 
        ###--------------------------------------------------------------------------
        Import-Module -Name $Module -DisableNameChecking #-Verbose

        ### Get Module Meta Data
        Get-ModuleMetaData $Module
    }
}

function Set-BuildParameters
{
    <#
    USAGE:

    ### Choose a Server Build Template
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:ServerTemplate     = "2016_DC"
    $global:ServerTemplate     = "2016_File"
    $global:ServerTemplate     = "2016_Citrix"
    $global:ServerTemplate     = "2012R2_Std_Base"
    $global:ServerTemplate     = "2012R2_DC"
    $global:ServerTemplate     = "2012R2_File"
    $global:ServerTemplate     = "2012R2_Citrix"
    #>

    ### Server Specific "Soft" Parameters
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:NewComputerName    = "BLU-SRVTEST01"
    $global:NewIPv4Address     = "10.61.1.111"
    $global:NewPrefixLength    = "24"
    $global:NewDefaultGateway  = "10.61.1.250"
    $global:NewPrimaryDNS      = "10.61.1.1"
    $global:NewSecondaryDNS    = "10.61.1.2"
    $global:NewDomain          = "ECILAB"

    ### Log Parameter Settings
    ###------------------------------------------------
    Write-Config ('-' * 50) "`nINPUT PARAMETERS: `n" ('-' * 50)  -foregroundcolor Gray
    Write-Config "ServerTemplate:`t`t " $ServerTemplate -foregroundcolor Gray
    Write-Config "NewComputerName:`t " $NewComputerName -foregroundcolor Gray
    Write-Config "NewIPv4Address:`t`t " $NewIPv4Address -foregroundcolor Gray
    Write-Config "NewPrefixLength:`t " $NewPrefixLength -foregroundcolor Gray
    Write-Config "NewDefaultGateway:`t " $NewDefaultGateway -foregroundcolor Gray
    Write-Config "NewPrimaryDNS:`t`t " $NewPrimaryDNS -foregroundcolor Gray
    Write-Config "NewSecondaryDNS:`t " $NewSecondaryDNS -foregroundcolor Gray
    Write-Config "NewDomain:`t`t`t " $NewDomain -foregroundcolor Gray
    Write-Config  ('-' * 50)  -foregroundcolor Gray
}

function Get-TargetInfo
{
    ### Get Target VM Information
    ###------------------------------------------------
   
    $TargetName = (Get-CIMInstance CIM_ComputerSystem).Name
    $VM         = "Get-VM"
    $VMHost     = "Get-VMHost"
    $GuestOS    = "Get-VMHost"
    Write-Config "TARGET INFO: `n" ('-' * 50) -foregroundcolor Gray
    Write-Config "TargetName:`t`t" $TargetName -foregroundcolor Gray
    Write-Config "VMHost:`t`t`t"  $VMHost -foregroundcolor Gray
    Write-Config "GuestOS:`t`t"  $GuestOS -foregroundcolor Gray
    Write-Config  ('-' * 50)  -foregroundcolor Gray


}

function Execute-Script 
{
    BEGIN 
    {
        # Initialize Script
        #--------------------------
        Clear-Host
        Write-Host "`nRunning: BEGIN Block" -ForegroundColor Blue
        Import-CBModules 
        #Start-Transcribing 

    }

    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue
        # Run Functions
        #--------------------------
        #Set-BuildParameters
        #Get-TargetInfo
        #Build-Server -ServerTemplate $ServerTemplate  -Step 1 # Requires $ServerTemplate is set in the "Set-BuildParameters" function above.
        Test-IsAdministrator

    }

    END 
    {
        # Close Script
        #--------------------------
        Write-Log "`nRunning: END Block"  -ForegroundColor Blue
        #Close-LogFile -Quiet
        Measure-Script
        #Stop-Transcribing
    }
}
Execute-Script