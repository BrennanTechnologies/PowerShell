﻿cls


$AUObj = @()

$AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings

$AUSettings.NotificationLevel
$AUSettings.ReadOnly
$AUSettings.Required
$AUSettings.ScheduledInstallationDay
$AUSettings.ScheduledInstallationTime
$AUSettings.IncludeRecommendedUpdates
$AUSettings.NonAdministratorsElevated
$AUSettings.FeaturedUpdatesEnabled

Function Get-WindowsUpdateConfig
{
    $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings

    $AUObj = New-Object -TypeName System.Object
    Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "NotificationLevel" -Value $AutoUpdateNotificationLevels[$AUSettings.NotificationLevel]
    Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateDays" -Value $AutoUpdateDays[$AUSettings.ScheduledInstallationDay]
    Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateHour" -Value $AUSettings.ScheduledInstallationTime
    Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "Recommended updates" -Value $(IF ($AUSettings.IncludeRecommendedUpdates) {"Included."}  else {"Excluded."})

    $AuObj
} 

Function Set-WindowsUpdateConfig
{
    Param ($NotificationLevel , $Day, $hour, $IncludeRecommended)
    $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
    if ($NotificationLevel)  {$AUSettings.NotificationLevel         = $NotificationLevel}
    if ($Day)                {$AUSettings.ScheduledInstallationDay  = $Day}
    if ($hour)               {$AUSettings.ScheduledInstallationTime = $hour}
    if ($IncludeRecommended) {$AUSettings.IncludeRecommendedUpdates = $IncludeRecommended}
    $AUSettings.Save
} 