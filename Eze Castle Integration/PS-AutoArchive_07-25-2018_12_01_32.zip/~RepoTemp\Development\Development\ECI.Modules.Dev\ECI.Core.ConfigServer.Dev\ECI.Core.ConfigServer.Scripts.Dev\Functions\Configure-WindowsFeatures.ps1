﻿function Configure-WindowsFeatures
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False


    foreach ($Feature in $WindowsFeatures)
    {
        $DesiredState = $Feature

        ##########################################
        ### GET CURRENT CONFIGURATION STATE: 
        ##########################################
        [scriptblock]$script:GetCurrentState =
        {
            $script:CurrentState = Get-WindowsFeature -name $Feature
        }

        ##########################################
        ### SET DESIRED-STATE:
        ##########################################
        [scriptblock]$script:SetDesiredState =
        {
            Install-WindowsFeature -name $Feature
        }
    }



    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}
