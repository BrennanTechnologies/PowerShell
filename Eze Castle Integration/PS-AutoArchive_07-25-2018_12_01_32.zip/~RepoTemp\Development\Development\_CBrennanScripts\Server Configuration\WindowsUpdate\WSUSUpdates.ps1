﻿cls
#https://blogs.technet.microsoft.com/heyscriptingguy/2012/01/19/use-powershell-to-find-missing-updates-on-wsus-client-computers/
#https://blogs.technet.microsoft.com/heyscriptingguy/2012/01/18/approve-or-decline-wsus-updates-by-using-powershell/

[void][reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration")

#$UpdateServer = "BLU-MGMT01.ecilab.net "
#$UpdateServer = 10.70.0.8

### Connect to the WSUS Server and create the wsus object
$WSUS = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer('10.70.0.8',$False,8530)
#$wsus | Get-Member

#$Server = "BLU-SRVTEST01.ecilab.net"
$Server = "BLU-DC01.ecilab.net"
$WSUS.GetComputerTargetByName($Server)

exit


### Create a computer scope object
$ComputerScope = New-Object Microsoft.UpdateServices.Administration.ComputerTargetScope

$ComputerScope

exit
#Find all clients using the computer target scope
#$wsus.GetComputerTargets($computerscope)


#Get all updates
$updates = $WSUS.GetUpdates()
#$wsus.SearchUpdates(‘SQL’)

$WSUS.GetUpdates() | where {$_.IsApproved -eq "False"}

#Iterate every update and output some basic info about it
ForEach ($update in $updates) 
{
    $update
    exit
    New-Object PSObject -Property @{
        Id = $update.Id.UpdateId.ToString()
        Title = $update.Title
        Source = $update.UpdateSource.ToString()
    }
}

