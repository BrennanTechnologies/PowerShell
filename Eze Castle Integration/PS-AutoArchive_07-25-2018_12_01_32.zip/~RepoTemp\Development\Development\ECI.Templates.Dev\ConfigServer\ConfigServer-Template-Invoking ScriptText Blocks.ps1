﻿cls
### Dev Server
$DevHost = "ECILAB-BOSAPP1.ecilab.corp"

### VI Servere
$VIServer = "ecilab-bosvcsa01.ecilab.corp"
$VICreds  = "" # -User cbrennan_admin@ecilab.corp -Password W3lcome123!

### Host VM
$HOSTVM = ""
$HostCreds = # -HostUser ezebos\cbrennan -HostPassword Tolkien4374
     
### Guest VM

$global:VM = "RGEE-SRV1" # <-- Param from API???

$GuestCreds = "" # -GuestUser administrator -GuestPassword Tolkien4374


### Import VMWare Modules
function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: $VMModules"
    }
    <#
    PS C:\Users\cbrennan_admin> Get-Module vm*

    ModuleType Version    Name                                ExportedCommands                                                                                                                   
    ---------- -------    ----                                ----------------                                                                                                                   
    Script     10.0.0.... VMware.VimAutomation.Cis.Core       {Connect-CisServer, Disconnect-CisServer, Get-CisService}                                                                          
    Script     10.0.0.... VMware.VimAutomation.Common                                                                                                                                            
    Script     10.0.0.... VMware.VimAutomation.Core           {Add-PassthroughDevice, Add-VirtualSwitchPhysicalNetworkAdapter, Add-VMHost, Add-VMHostNtpServer...}                               
    Script     10.0.0.... VMware.VimAutomation.Sdk            {Get-InstallPath, Get-PSVersion}  
    #>
}

#######################################
### Function: Connect to ECI VI Server
#######################################
function Connect-ECIVIServer
{

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false #| Out-Null

    <#
    Connecting New Session to VI Server:  ecilab-bosvcsa01.ecilab.corp
    WARNING: There were one or more problems with the server certificate for the server ecilab-bosvcsa01.ecilab.corp:443:

    * The X509 chain could not be built up to the root certificate.

    Certificate: [Subject]
      C=US, CN=ecilab-bosvcsa01.ecilab.corp

    [Issuer]
      O=ecilab-bosvcsa01.ecilab.corp, C=US, DC=local, DC=vsphere, CN=CA

    [Serial Number]
      00E95976D6B9344236

    [Not Before]
      6/22/2015 3:34:28 PM

    [Not After]
      6/16/2025 3:34:27 PM

    [Thumbprint]
      38A7F51B30A4CFAC6A136D0585D77322106CC69E



The server certificate is not valid.
    
WARNING: THE DEFAULT BEHAVIOR UPON INVALID SERVER CERTIFICATE WILL CHANGE IN A FUTURE RELEASE. To ensure scripts are not affected by the change, use Set-PowerCLIConfigura
tion to set a value for the InvalidCertificateAction option.
#>

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Yellow
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Yellow
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    $VISession = Connect-VIServer -Server  $VIServer  -User ezebos\cbrennan -Password Tolkien4374
    }


    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

#######################################
### Import Parameters from API
#######################################
function Import-APIParameters
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    Write-Host "Importing Parameters from API (or .CSV):" -ForegroundColor Magenta
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Varibles = @()
    foreach ($Parameter in (Import-CSV -path $ParameterFile))
    {
        # Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -scope global
                
        # Verify Variables
        $Varibles += Get-Variable -Name $Parameter.Name
    }  
    
    $Varibles | ft
}



#######################################
### Function: Get Guest VM
#######################################
function Get-GuestVM
{
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}

#######################################
### Function: Restart Guest VM
#######################################
function Restart-GuestOS
{
    #######################################
    ### Restart Guest VM Computer
    #######################################
    Write-Host "Rebooting Server: $VM" -ForegroundColor Yellow
    Restart-VMGuest -VM $VM -Server $VIServer | Wait-Tools | Out-Null
}

#######################################
### Function: Resume Guest VM
#######################################
function Resume-GuestOS
{
    #######################################
    ### Resume after Restart
    #######################################
    Write-Host "Waiting for Server to Resume: $VM" -ForegroundColor Yellow

    ### Pasuse Script
    ### ---------------------------
    ### Pause to let the Reboot command Start, otherwise the Wait-Tools will respond immediately
    $t = 15 ### Timer for Dev
    #$t = 60 ### Timer for Prod
    Write-Host "Sleeping Script for $t secs ..." -ForegroundColor Gray
    Start-Sleep -Seconds $t

    ### Wait for VM Tools
    ### ---------------------------
    $t = 60 ### Timer for Dev
    #$t = 240 ### Timer for Prod
    Write-Host "Waiting for VMTools to Respond for $t secs ..." -ForegroundColor Gray
    Wait-Tools -VM $VM -TimeoutSeconds $t -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null

    ### Resume Script
    ### ---------------------------
    Write-Host "Resuming after Restart: $VM" -ForegroundColor Yellow

    ### Test VMGuest Connectivity
    ### ---------------------------
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}

#######################################
### Import Bootstap Module
#######################################
$BootStrapModuleLoader = {

        ### Connect a Non-Persistent Drive - then Import the ECI.ModuleLoader
        ### ----------------------------------------------------------------------
        $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
        $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
        $global:RootPath = "\\eciscripts.file.core.windows.net\clientimplementation"
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

        ### Import the Module Loader - Dot Source
        ### ----------------------------------------------------------------------
        . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.ModuleLoader.ps1"
        #. "X:\Root\ECI.ModuleLoader.ps1"

} # END BootStrapModuleLoader


function InvokeVMScript-Step0
{
    ##########################################################################################
    $global:FunctionName = $MyInvocation.MyCommand.Name
    ##########################################################################################

    Write-Host "Running Function: " $FunctionName -ForegroundColor Yellow
    
    $ScriptText = 
    {
        ### Set Execution Policy on Guest VM
        ### ----------------------------------------------------------------------
        Set-ExecutionPolicy Bypass
        
        ### Import BootStrap Module Loader
        ### -------------------------------------------
        #BootStrapModuleLoader#

        ### Import Parameters To VMGuest from API/VMHost
        ### -------------------------------------------
        #ImportParametersToVMGuest#

        function Import-ParametersToVMGuest
        {
            ### Pass in Paramters from API/VMHost
            ### ----------------------------------------------------------------------
            
            $ComputerName = "#ComputerName#"
            $DomainName = "#DomainName#"
            $IPv4Address = "#IPv4Addres#"
            $SubnetPrefix = "#SubnetPrefix#"
            $DefaultGateway = "#DefaultGateway#"
            $DNS1 = "#DNS1#"
            $DNS2 = "#DNS2#"

            Write-Host "`nImporting Parameters:`n"('-' * 50)
            Write-Host "ComputerName   : " $ComputerName
            Write-Host "DomainName     : " $DomainName
            Write-Host "IPv4Address    : " $IPv4Address
            Write-Host "SubnetPrefix   : " $SubnetPrefix
            Write-Host "DefaultGateway : " $DefaultGateway
            Write-Host "DNS1           : " $DNS1
            Write-Host "DNS2           : " $DNS2
            Write-Host ('-' * 50)
        }
       

       & { ### Execution Block
            
            
            BEGIN
            {
                Write-Host "INVOKE-BEGIN:"
                Import-ParametersToVMGuest 
                Start-Transcript
            }
    
            PROCESS
            {
                Write-Host "INVOKE-PROCESS:" 
                Write-host "Test"
            }

            END
            {
                Write-Host "INVOKE-END: " 
                Stop-Transcript

            }
            
        }
    }
    
    #function Import-ParametersToGuestVM
    #    {
        ### Replace Variables with Literal Values for the Invoke-VMScript 
        ### ----------------------------------------------------------------
        $Params = @{
        $ComputerName    = "#ComputerName#"
        $DomainName      = "#DomainName#"
        $IPv4Address     = "#IPv4Addres#"
        $SubnetPrefix    = "#SubnetPrefix#"
        $DefaultGateway  = "#DefaultGateway#"
        $DNS1            = "#DNS1#"
        $DNS2            = "#DNS2#"
        }

        ### Inject Variables into ScriptText Block
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Value,$Param.Key
        }
    #}    
    
    #Import-ParametersToGuestVM

    
    ### Inject BootStrap Module Loader into VM Host
    $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader
    
    #write-host "ScriptText:"
    #$ScriptText
    
    Write-Host "Invoking ScriptText: $ScriptTextName" -ForegroundColor Cyan
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword Tolkien4374 -Verbose #-Debug

    ##########################################################################################
}

function InvokeVMScript-Step1
{
    ##########################################################################################
    $global:FunctionName = $MyInvocation.MyCommand.Name
    ##########################################################################################

    Write-Host "Running Function: " $FunctionName -ForegroundColor Yellow
    
    #$ScriptText = $Null

    $ScriptText = 
    {
        ### Set Execution Policy on Guest VM
        ### ----------------------------------------------------------------------
        Set-ExecutionPolicy Bypass
        
        ### Import BootStrap Module Loader
        ### -------------------------------------------
        #BootStrapModuleLoader#

        ### Import Parameters To VMGuest from API/VMHost
        ### -------------------------------------------
        #ImportParametersToVMGuest#

        function Import-ParametersToVMGuest
        {
            ### Pass in Paramters from API/VMHost
            ### ----------------------------------------------------------------------
            
            ### API PArameters (#<ParameterName># Gets -Replace w/ Values)
            $ComputerName = "#ComputerName#"
            $DomainName = "#DomainName#"
            $IPv4Address = "#IPv4Addres#"
            $SubnetPrefix = "#SubnetPrefix#"
            $DefaultGateway = "#DefaultGateway#"
            $DNS1 = "#DNS1#"
            $DNS2 = "#DNS2#"
            
            ### Script Parameters
            $VM  = "#VM#"

            Write-Host "`nImporting API Parameters:`n"('-' * 50)
            Write-Host "ComputerName   : " $ComputerName
            Write-Host "DomainName     : " $DomainName
            Write-Host "IPv4Address    : " $IPv4Address
            Write-Host "SubnetPrefix   : " $SubnetPrefix
            Write-Host "DefaultGateway : " $DefaultGateway
            Write-Host "DNS1           : " $DNS1
            Write-Host "DNS2           : " $DNS2
            
            Write-Host "`nImporting Script Parameters:`n"('-' * 50)
            Write-Host "VM             : " $VM
            Write-Host ('-' * 50)
        }
        
        &{
            BEGIN
            {
                Write-Host "BEGIN-INVOKE:"
                Import-ParametersToVMGuest 
                Start-Transcript
                #Start-VMLogs
              
            }
            PROCESS
            {
                Write-Host "PROCESS-INVOKE:"
                #Get-VMGuestData

            }
            END
            {
                Write-Host "BEGIN-INVOKE:"
                Stop-Transcript
            }
        }
    }

    #function Import-ParametersToGuestVM
    #    {
        ### Replace Variables with Literal Values for the Invoke-VMScript 
        ### ----------------------------------------------------------------
        $Params = @{
        
            ### API Parameters
            $ComputerName    = "#ComputerName#"
            $DomainName      = "#DomainName#"
            $IPv4Address     = "#IPv4Addres#"
            $SubnetPrefix    = "#SubnetPrefix#"
            $DefaultGateway  = "#DefaultGateway#"
            $DNS1            = "#DNS1#"
            $DNS2            = "#DNS2#"
        
            ### Script Parameters
            $VM              = "#VM#"
        }

        ### Inject Variables into ScriptText Block
        foreach ($Param in $Params.GetEnumerator())
        {
            $ScriptText =  $ScriptText -replace $Param.Value,$Param.Key
        }
    #}    
    
    #Import-ParametersToGuestVM
    
    ### Inject BootStrap Module Loader into VM Host
    $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader
    
    ### Debugging: Write ScriptText Block to Screen
    write-host "ScriptText:"
    $ScriptText
    
    Write-Host "Invoking ScriptText: $ScriptTextName" -ForegroundColor Cyan
    $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword Tolkien4374 -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

    Write-Host $Invoke.ScriptOutput

    if (($Invoke.ExitCode) -eq 0)
    {
        Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
    }
    elseif (($Invoke.ExitCode) -ne 0)
    {
        Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
    }



    ##########################################################################################
}



#######################################
### Execute the Script
#######################################
&{ 

    BEGIN
    {
        Write-Host "BEGIN: ConfigServer-Template" -ForegroundColor Yellow
        ### Setup Script Environment
        ### -------------------------------------

        ### Hide VMWare Module Progress Bar
        $ProgressPreference = "SilentlyContinue"


    }

    PROCESS
    {
        Write-Host "PROCESS: ConfigServer-Template" -ForegroundColor Yellow
        Import-VMWareModules
        Connect-ECIVIServer
        Get-GuestVM
        #Import-APIParameters
        InvokeVMScript-Step1
        #Restart-GuestOS
        #Resume-GuestOS
        #InvokeVMScript-Step1

    }

    END
    {
        Write-Host "END: ConfigServer-Template" -ForegroundColor Yellow

    }

}

### Wait-Tools
<#

Wait-Tools

Version                 : v11
Notes                   : 
Guest                   : RGEE-SRV1:Microsoft Windows Server 2016 (64-bit)
NumCpu                  : 2
CoresPerSocket          : 1
MemoryMB                : 4096
MemoryGB                : 4
VMHostId                : HostSystem-host-28320
VMHost                  : ecilab-bosesx6.ecilab.corp
VApp                    : 
FolderId                : Folder-group-v199
Folder                  : geemoneymgmt
ResourcePoolId          : ResourcePool-resgroup-3573
ResourcePool            : ClientDCs
PersistentId            : 501a05e0-e684-2a98-cb2a-c6d72fd12582
UsedSpaceGB             : 26.94964139163494110107421875
ProvisionedSpaceGB      : 60.00109402835369110107421875
DatastoreIdList         : {Datastore-datastore-28214}
HARestartPriority       : ClusterRestartPriority
HAIsolationResponse     : AsSpecifiedByCluster
DrsAutomationLevel      : AsSpecifiedByCluster
VMSwapfilePolicy        : Inherit
VMResourceConfiguration : CpuShares:Normal/2000 MemShares:Normal/40960
GuestId                 : windows9Server64Guest
Name                    : RGEE-SRV1
CustomFields            : {[Backup status, ], [com.emc.avamar.vmware.snapshot, ], [com.vmware.vdp2.is-protected, ], [com.vmware.vdp2.protected-by, ]}
ExtensionData           : VMware.Vim.VirtualMachine
Id                      : VirtualMachine-vm-31164
Uid                     : /VIServer=ezebos\cbrennan@ecilab-bosvcsa01.ecilab.corp:443/VirtualMachine=VirtualMachine-vm-31164/

#>
