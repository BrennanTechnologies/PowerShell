﻿cls

function Import-CBModules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")     {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM")   {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")       {$ModulePath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    #if($env:USERDNSDOMAIN -eq "ECI.CORP")       {$ModulePath = "P:\CBrennanScripts\Modules"}
    if($env:COMPUTERNAME  -eq "W2K16V2")        {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "C:\Scripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")  {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}

    ### Add Custom Modules to Path
    if(-NOT($env:PSModulePath.Contains($ModulePath))) {$env:PSModulePath = $ModulePath + ";" + $env:PSModulePath}
        
    ## Modules to Load
    $Modules = @()
    $Modules += "CommonFunctions"
    #$Modules += "ConfigServer"
  

    foreach ($Module in $Modules)
    {
        write-host "Importing Module: Path: $ModulePath Module: $Module" -ForegroundColor Magenta
       
        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module -ErrorAction SilentlyContinue | out-null}

        ### Import the Module
        ### DO NOT Specify Module Literal Path: Must load through $env:PSModulePath 
        ###--------------------------------------------------------------------------
        Import-Module -Name $Module -DisableNameChecking #-Verbose

        ### Get Module Meta Data
        Get-ModuleMetaData $Module
    }
}


function UPNinProxy
{
    ##############################
    ### Get ScriptBlock
    ##############################

    $script:GetScriptBlock =
    {

#SQL Server = Domains .... C:\monitorscripts\o365_billingreport\o365_billingreportHK.ps1
###    Get-ADUser -Server corp.desimonemgmt.com -Properties * -filter * | ?{$_.mail -ne $null}

        ### ECI Cloud
        #$Domain = "ecicloud.com"
        #$SearchBase = "OU=Clients,DC=ecicloud,DC=com"
        #$SearchBase = "OU=Users,OU=SchoenerMgmt,OU=Clients,DC=ecicloud,DC=com"
        
        ### Lab
        $Domain = "ecilab.net"        
        $SearchBase = "OU=MacdonaldVentures,OU=Clients,DC=ecilab,DC=net"
        #$SearchBase = "OU=Clients,DC=ecilab,DC=net"
        #$User = "CN=Ham Burglar,OU=Users,OU=MacdonaldVentures,OU=Clients,DC=ecilab,DC=net"

        ### Do-Something
        ###-----------------------------------------
        Write-Log "Running GetScriptBlock"-foregroundcolor DarkGreen
        $script:Users = Get-ADUser -Server $Domain -SearchBase $SearchBase -Filter * -Properties * | where {(($_.ProxyAddresses).count -ne "0") -AND ($_.UserPrincipalName -ne $Null)}
        #$script:Users = Get-ADUser -Identity $User -Properties * | where {(($_.ProxyAddresses).count -ne "0") -AND ($_.UserPrincipalName -ne $Null)}
    }

    ##############################
    ### Commit ScriptBlock
    ##############################

    $global:CommitScriptBlock = 
    {    
        Set-ADUser -Identity $Target -Add @{ProxyAddresses="smtp:$CommitValue"}
    } 

    ##############################
    ### Undo ScriptBlock
    ##############################
    
    $global:UndoScriptBlock = 
    {    
        Set-ADUser -Identity $Target -Remove @{ProxyAddresses="smtp:$UndoValue"}
    }

    ##############################
    ### Execute Commands
    ##############################
    
    $UPNinProxyCounter = 0
    Invoke-Command $GetScriptBlock

    foreach ($User in $Users)
    {
        ############################
        ### Set Target and Values
        ############################

        ### Set Target
        ###------------------------------------------
        $global:TargetProperty = '$User.DistinguishedName'
        $global:Target         = $User.UserPrincipalName
        
        ### Set Commit Value
        ###------------------------------------------
        $global:CommitProperty = '$User.UserPrincipalName'
        $global:CommitValue    = $User.UserPrincipalName
        
        ### Set Undo Value
        ###------------------------------------------
        $global:UndoValue = $CommitValue
        
        ### Find Users with UPN in ProxyAddresses
        $UPNinProxy = ($User.ProxyAddresses -replace "smtp:","").Contains($User.UserPrincipalName)

        if($UPNinProxy -ne $True)
        {
            $UPNinProxyCounter ++

            write-host "UPNinProxy: "  $UPNinProxy -ForegroundColor Gray
            #Write-host "Name: " $User.Name
            #Write-host "Target: $Target `nValue: $CommitValue `nUndoValue: $UndoValue" -ForegroundColor Cyan
            Write-host "ProxyAddresses: " ($User.ProxyAddresses -replace "smtp:","") -ForegroundColor Cyan
            Write-host "UserPrincipalName: " $User.UserPrincipalName -ForegroundColor Cyan
            #write-host "UPNinProxy: " ($User.ProxyAddresses).Contains($User.UserPrincipalName)

            ############################
            ### Invoke-Whatif
            ############################
 
            <######################################################################
                USAGE:  - Must use either -Whatif or -Commit.
                        - Can ONLY use EITHER -Whatif or -Commit. Not Both!
                        - Force is optional when -Commit is used.

                        - Whatif : This switch ONLY runs a whatif and show the result. NO SETS or COMMITS are made.
                        - Commit : This switch will Commit the Set command actionss. By default the -Confirm switch is set to on. (You will be prompted to Confirm Actions)
                        - Force  : This switch will overide the -Confirm switch and force all commit actions. (You WILL NOT be prompted to Confirm Actions)
                        - RollBack  : Rolls back all chanches made by the commit command.

                USAGE:  - Must use either -Whatif or -Commit -Force
            
                EXAMPLES:
                            Invoke-Whatif -Whatif 
                            Invoke-Whatif -Commit
                            Invoke-Whatif -Commit -Force
                            Invoke-Whatif -Commit -Rollback
            <######################################################################>
        
            Invoke-Whatif -Whatif
            #Invoke-Whatif -Commit
            #Invoke-Whatif -Commit -Force
            #Invoke-Whatif -RollBack
        }
        
        if ($UPNinProxyCounter -eq "0")
        {
            write-host "No Objects met the criteries:" 
            write-host "UPNinProxyCounter: "  $UPNinProxyCounter
        }
        
        write-host "UPNinProxyCounter: "  $UPNinProxyCounter
    }
}


UPNinProxy

