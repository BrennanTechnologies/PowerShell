﻿cls

function Import-Modules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")   {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM") {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")     {$ModulePath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "W2K16V2")      {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}
    #if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")      {$ModulePath = "C:\Scripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")      {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}

    $Modules = @()
    $Modules += "CommonFunctions"
    $Modules += "ConfigServer"

    foreach ($Module in $Modules)
    {
        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module -ErrorAction SilentlyContinue | out-null}

        ### Import the Module
        $ModuleFilePath = $ModulePath + $Module + "\" + $Module + ".psm1"
        Import-Module -Name $ModuleFilePath -DisableNameChecking #-Verbose

        ### Test the Module - Exit Script on Failure
        if( (Get-Module -Name $Module)){Write-Host "Loaded Custom Module: $Module" -ForegroundColor Green}
        if(!(Get-Module -Name $Module)){Write-Host "The Custom Module $Module WAS NOT Loaded! `nFunctions Wont Work! `nExiting Script!" -ForegroundColor Red;exit}
    }
}
Import-Modules 

function Configure-PageFile
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

Configure-PageFile