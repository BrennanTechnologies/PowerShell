﻿function Import-SoftParametersFromAPI
{

    Write-Host "`nImporting *SOFT* Parameters from API:`n" ("-" * 50) -ForegroundColor White
    
    ### Import *SOFT* Paramters from API
    ### -------------------------------
    $Parameters = [ordered]@{

    Step               = $Step
    VM                 = $VM
    ServerBuildType    = $ServerBuildType
    GuestComputerName  = $GuestComputerName
    DomainName         = $DomainName
    IPv4Address        = $IPv4Address
    SubnetPrefixLength = $SubnetPrefixLength
    DefaultGateway     = $DefaultGateway
    DNS1               = $DNS1
    DNS2               = $DNS2

    }

    Write-Host "`nParameters Imported to $env:COMPUTERNAME `n" ('-' * 50)
    Write-Host "Step                  : " $Step
    Write-Host "VM                    : " $VM
    Write-Host "ServerBuildType       : " $ServerBuildType
    Write-Host "GuestComputerName     : " $GuestComputerName
    Write-Host "DomainName            : " $DomainName
    Write-Host "IPv4Address           : " $IPv4Address
    Write-Host "SubnetPrefixLength    : " $SubnetPrefixLength
    Write-Host "DefaultGateway        : " $DefaultGateway
    Write-Host "DNS1                  : " $DNS1
    Write-Host "DNS2                  : " $DNS2
    Write-Host ('-' * 50)


    $global:SoftParameters = @()
    Write-Host "`nImporting *SOFT* Parameters from API:`n" ("-" * 50)
    foreach($Parameter in $Parameters.GetEnumerator())
    {
        Write-Host "$($Parameter.Name): $($Parameter.Value)"

        # Create Variables and Set Variable Scope to "Global"
        Set-Variable -Name $($Parameter.Name) -Value $($Parameter.Value) -Scope Global
        $global:SOFTParameters += Get-Variable -Name $($Parameter.Name)
    }
            
    Write-Host "`nVERIFY: Server Template *SOFT* Parameters:"`n("-" * 50)
    $SoftParameters | FT

}

function New-VM
{
$VMTest = "VMTest"
$VMTemplate = "W2K16v2"
$VMCustomSpec	= "Server-2016R2-ProductKey-SID"
#$RESPOOL = "ecilab"
$RESPOOL = "ClientDCs"
$TargetDataStore = "nfs_emsadmin_sas1"
#$TargetDataStore = "nfs_emsadmin_sas2"
$VMHost = "ecilab-bosesx2.ecilab.corp"

New-VM -Name VMTest -ResourcePool ClientDCs -Datastore nfs_emsadmin_sas1 -Template W2K16v2
New-VM -Name VMTest -VMHost ecilab-bosesx2.ecilab.corp
New-VM -Name $VMTest -Template $VMTemplate -ResourcePool $RESPOOL -DiskStorageFormat Thin -Datastore $TargetDataStore


<#
    New-VM `
    -Name $VM `
    -Template $VMTemplate `
    -OSCustomizationSpec $VMCustomSpec `
    -ResourcePool $RESPOOL `
    -DiskStorageFormat Thin `
    -Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)  
#>

}

function Send-Alert
{
    ### Manually Overide Email Parameters
    ### ---------------------------------
    $SMTPServer = "owablu.ecilab.net"
    $To         = "cbrennan@eci.com"
    $From       = "cbrennan@eci.com"
    $Subject    = ""
    $Message    = ""

    ### Email Parameters
    $EmailParams = 
    @{
        From       = $From
        To         = $To 
        #CC        = $CC
        SMTPServer = $SMTPServer
     }
    #Send-MailMessage -SmtpServer owablu.ecilab.net -To sdesimone@eci.com -From wwilson@geemoneymgmt.com -Subject "hi"
    Send-MailMessage @EmailParams -Body ($Message | Out-String) -BodyAsHtml -Subject $Subject

}

function Start-ConfigLogs
{
    ### Create Timestamp
    $global:TimeStamp  = Get-Date -format "MM-dd-yyyy_hh_mm_ss"

    ### Create Log Folder
    $ConfigLogPath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $VM + "\"
    if(-NOT(Test-Path -Path $ConfigLogPath)) {(New-Item -ItemType directory -Path $ConfigLogPath -Force | Out-Null);Write-Host "Creating ConfigLogPath: " $ConfigLogPath }

    ### Create Log File
    $global:ConfigLogFile = $ConfigLogPath + "ConfigReport_" + $VM + "_" + $TimeStamp + ".log"
}

function Write-ServerBuildTag
{
    Write-Host "Writing ServerBuildTag:"`n("-" * 50)

    ### Create Server Build Tag
    $ServerBuildTagPath = "C:\Scripts\VMAutomation\ServerBuildTag_" + $VM + "_" + $(get-date -f MM-dd-yyyy_HH_mm_ss) + ".txt"
   
    $ServerBuildTag     = [ordered]@{
        VMGuestName     = (Get-WmiObject Win32_ComputerSystem).Name
        VMGuestOS       = [environment]::OSVersion.Version
        VMGuestDomain   = (Get-WmiObject Win32_ComputerSystem).Domain
        BuildDate       = $(get-date)
        Engineer        = "CBrennan - (cbrennan@eci.com)"

    }
    $ServerBuildTag | Out-File -FilePath $ServerBuildTagPath -Force

    ### Get Module Meta Data
    $Modules = Get-Module | Where-Object {($_.Name -like "ECI.Core.*")}
    foreach($Module in $Modules)
    {
        $ModuleData = [ordered]@{
            Module        = $Module
            ModuleVersion = $Module.Version
        }
        $ModuleData | Out-File -FilePath $ServerBuildTagPath -Append
    
        Write-Host "Module: " $Module
        Write-Host "ModuleVersion: " $Module.Version   
    }

    ### Get Parameters
    Write-Host "Soft Parameters:" 
    $SoftParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $SoftParameters | FT
    
    Write-Host "Hard Parameters:" 
    $HardParameters | Out-File -FilePath $ServerBuildTagPath -Append
    $HardParameters | FT
    
    Write-Host "Windows Features Installed:" 
    ("Windows Features:") | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | Out-File -FilePath $ServerBuildTagPath -Append
    $WindowsFeatures | FT
}

function Write-Cookie
{
    Param(
    [Parameter(Mandatory = $False, Position = 0)] [string]$VM,
    [Parameter(Mandatory = $False, Position = 1)] [string]$Function,
    [Parameter(Mandatory = $False, Position = 2)] [string]$Verified,
    [Parameter(Mandatory = $False, Position = 3)] [string]$Abort,
    [Parameter(Mandatory = $False)] [switch]$Remove
    )

    ### Store Cookie in Repo
    $CookiePath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $VM + "\Cookie.$VM.txt" # <-- Store Cookie in Repo
    
    ### Store Cookie Locally
    #$CookiePath = "C:\Scripts\VMAutomation\Cookie." + $VM + ".txt" # <-- Store Cookie Locally
   
    if($Remove)
    {
        if(Test-Path -Path $CookiePath){Remove-Item -Path $CookiePath -Force}
    }
    elseif(!$Remove)
    {
        if(-NOT(Test-Path -Path $CookiePath)) {(New-Item -ItemType File -Path $CookiePath -Force | Out-Null)}
        $Cookie = "VM=$VM,Step=$Step,Function=$Function,Verified=$Verified,Abort=$Abort,Timestamp=$(get-date -f MM-dd-yyyy_HH_mm_ss)"
        Add-Content -Path $CookiePath -Value $Cookie -Force
    }



    ### Clear the Cookie File of any current Function Records
    #Write-Host "Cookie Function: " $Function
    #Get-Content $CookiePath | Where-Object {$_ -notmatch $Function} | Set-Content $CookiePath

<#  Use Hash
    $Cookie = [ordered]@{

        VM         = $VM
        Step       = $Step
        Function   = $Function
        Verified   = $Verified
        AbortValue = $Abort
    }
    $Cookie
    $Cookie | Out-File -FilePath $CookiePath -Force -Append
#>


    <#
    if(Test-Path -Path $CookiePath)
    {
        #Remove-Item -Path $CookiePath
        Set-Content -Path $CookiePath -Value $Cookie -Force
    }
    elseif(!(Test-Path -Path $CookiePath))
    {
        Add-Content -Path $CookiePath -Value $Cookie -Force
    }
    #>

}

function Write-Config
{
    Param(
    [Parameter(Mandatory = $True, Position = 0)] [string]$Message,
    [Parameter(Mandatory = $False, Position = 1)] [string]$String,
    [Parameter(Mandatory = $False, Position = 2)] [string]$String2,
    [Parameter(Mandatory = $False, Position = 3)] [string]$String3,
    [Parameter(Mandatory = $False, Position = 4)] [string]$String4,
    [Parameter(Mandatory = $False, Position = 5)] [string]$String5,
    [Parameter(Mandatory = $False, Position = 6)] [string]$String6
    )

    if (((Get-Variable 'ConfigLogFile' -Scope Global -ErrorAction 'Ignore')) -eq $Null)    #if (-NOT($LogFile))
    {
        #Write-Host "No Logfile exists. Starting Log Files:"
        Start-ConfigLogs
    }     

    ### Write the Message to the Config Report.
    $Message = $Message + $String + $String2 + $String3 + $String4 + $String5 + $String6
    #Write-Host "ConfigLogFile: " $ConfigLogFile
    Write-Host $Message
    $Message | Out-File -filepath $ConfigLogFile -append   # Write the Log File Emtry
}

function Verify-Config
{
    param ($ParameterValue)
    
    ### Verify Command
    ### -------------------------------------------
    $VerifyCommand = Invoke-Command {}
    $VerifyValue = $VerifyCommand.Value
    
    ### Verify Check
    ### -------------------------------------------
    if     ($VerifiedValue -eq $ParameterValue) {Write-Config "VERIFY SUCCEDED: - VerifyValue: $VerifyValue      ParameterValue: $ParameterValue"}
    elseif ($VerifiedValue -ne $ParameterValue) {Write-Config "VERIFY FAILED:   - VerifyValue: $VerifiedCDLetter ParameterValue: $ParameterValue"}

}

function Get-VMGuestConfiguration
{
    Write-Config "Getting Guest Data:"
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Host ("-" * 50)
    Write-Host "VM GUEST DATA:"
    Write-Host "GuestComputerName : " $env:COMPUTERNAME
    Write-Host "GuestOSVer        : " $GuestOSVer 
    Write-Host "GuestIPv4Addr     : " $GuestIPv4Addr
    Write-Host ("-" * 50)
}

function Configure-NetworkInterface
{
    Param(
    [Parameter(Mandatory = $False)] [string]$DesiredState,
    [Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report",
    [Parameter(Mandatory = $False)] [string]$AbortTrigger = "$False"
    )
    
    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)


    ### Manually Overide Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False


    ### Manually Overide Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False
    $script:DesiredState = $NewInterfacename

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:ExistingInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                Rename-NetAdapter (Get-NetAdapter -Name $ExistingInterfaceName).Name -NewName $NewInterfaceName
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
                
            }
        }
        
        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
            if($ExistingInterfaceName -eq $NewInterfacename)
            {
                Write-Config "COMPARE: TRUE - The Current-Configuration is the same as the Desired-Configuration - ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
                Write-Config "Not Running Configuration!"
            }
            elseif ($ExistingInterfaceName -ne $NewInterfacename )
            {
                Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - ExistingInterfaceName: $ExistingInterfaceName NewInterfacename: $NewInterfacename"
                Invoke-Command -ScriptBlock $ConfigureScriptBlock
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyInterfaceName = (Get-NetAdapter –Physical | Where-Object Status -eq 'Up').Name
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Compare Configuration
        ### -----------------------------------------------------------------------
        if($VerifyInterfaceName -eq $NewInterfacename)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyInterfaceName: $VerifyInterfaceName NewInterfacename: $NewInterfacename"
            Write-Cookie $VM $Function $Verified $Abort
        }
        elseif($VerifyInterfaceName -ne $NewInterfacename)
        {
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                Write-Cookie $VM $Function $Verified $Abort
                #Send-Alert
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY FAILURE! - Verified: $Verified Abort: $Abort VerifyInterfaceName: $VerifyInterfaceName NewInterfacename: $NewInterfacename"
                Write-Cookie $VM $Function $Verified $Abort
            }
        }
        ###################################
        ### REPORT:
        ###################################

    }
    Try-Catch $ScriptBlock
}

function Configure-IPv6
{
    Param([Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report")

    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    ### Modify Parameters
    ### --------------------------------------
    if     ($Ipv6Preference -eq "Enable") {$script:Ipv6Preference = $True}
    elseif ($Ipv6Preference -eq "Disable"){$script:Ipv6Preference = $False}
    else   {$script:Ipv6Preference  = $Null}

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            ### Get Current Interface
            $CurrentInterface     = Get-NetAdapter –Physical | Where-Object Status -eq 'Up'
            $script:CurrentInterfaceName = $CurrentInterface.Name
    
            ### Get IPv6 State
            $IPv6State   = Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)"
            $script:IPv6Enabled = $IPv6State.Enabled
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                if ($Ipv6Preference -eq $True)
                {
                    ### Enable IPv6
                    Enable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
                }
                elseif ($Ipv6Preference -eq $False)
                {
                    ### Disable IPv6
                    Disable-NetAdapterBinding -InterfaceAlias $CurrentInterfaceName -ComponentID MS_TCPIP6
                }
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
         }

        ###################################
        ### COMPARE:
        ###################################
        if ($IPv6Enabled -eq $Ipv6Preference)
        {
            Write-Config "COMPARE: TRUE  - The Current-Configuration is the same as the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
            Write-Config "Not Running Configuration!"
        }
        elseif ($IPv6Enabled -ne $Ipv6Preference)
        {
            Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
            Write-Config "Running Configuration!"
            Invoke-Command -ScriptBlock $ConfigureScriptBlock
        }
     
        ##########################
        ### VERIFY:
        ##########################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyIPv6Enabled = (Get-NetAdapterBinding -Name $CurrentInterfaceName -DisplayName "Internet Protocol Version 6 (TCP/IPv6)").Enabled
        }
        Invoke-Command $VerifyScriptBlock

        if ($VerifyIPv6Enabled -eq $Ipv6Preference)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified -VerifyIPv6Enabled: $VerifyIPv6Enabled -IPv6Preference: $Ipv6Preference"
            Write-Cookie $VM $Function $Verified $Abort
        }
        elseif ($VerifyIPv6Enabled -ne $Ipv6Preference)
        {
            ### Verify Failure
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified Abort: $Abort Function: $Function `nExiting Script!"
                Write-Cookie $VM $Function $Verified $Abort
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY ERROR! - VERIFIED: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                Write-Cookie $VM $Function $Verified $Abort
            }
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-IPv4
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Cast the Parameters as IPAddress
        [IPAddress]$IPv4Address     = $IPv4Address.Trim()
        [IPAddress]$DefaultGateway  = $DefaultGateway.Trim()

        ### Get the Current NIC
        $CurrentInterface  = (Get-NetAdapter –Physical | where Status -eq 'Up').Name
        #write-host "CurrentInterface:" $CurrentInterface

        ### Determine if DHCP is Enabled or if IPv4 Address is Static
        $DhcpStatus = (Get-NetIPInterface -AddressFamily IPv4 -InterfaceAlias $CurrentInterface).DHCP
        #write-host "DhcpStatus:" $DhcpStatus            

        ### If DHCP is Enabled, Create New IPv4 Address, Else Set IPv4 Addres
        if ($DhcpStatus -eq "Enabled")
        {
            ### Set the IPv4 Settings
            Write-Config "`n`nSetting New IP Address and Default Gateway"
            #New-NetIPAddress $IPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $PrefixLength -DefaultGateway $DefaultGateway | Out-Null
        }
        elseif ($DhcpStatus -eq "Disabled")
        {
            Write-Config "`n`nAdding IP Address and Default Gateway"
            #Set-NetIPAddress
        }

<#
        ### Get the Current IP Address
        $CurrentIPAddress = (Get-NetIPAddress -InterfaceAlias $CurrentInterface -AddressFamily IPv4).IPv4Address

        ### Checking if the current IP Address is already the same if the New IP Address
        if($CurrentIPAddress -ne $NewIPv4Address) 
        {
            write-log "The New IP Address is Different - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow

            #$ISDHCPEnabled = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration  -Filter "IPEnabled=TRUE").DHCPEnabled

            # Remove the static ip
            #Remove-NetIPAddress -InterfaceAlias $CurrentInterface

            # Remove the default gateway
            #Remove-NetRoute -InterfaceAlias $CurrentInterface

            ### Change the IPv4 Settings
            write-log "`n`nSetting Adapter IP Address and Default Gateway"  -ForegroundColor Yellow
            New-NetIPAddress $NewIPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $NewPrefixLength -DefaultGateway $NewDefaultGateway | Out-Null

            ### Verify Settings
            $VerifyIP = (Get-NetIPAddress -InterfaceAlias $NewInterfaceName -AddressFamily IPv4).IPv4Address

            if($VerifyIP -eq $NewIPv4Address){Write-Log "IP Address set to this new value: " $VerifyIP}
            else {Write-Log "Mismatch - VerifyIP: $VerifyIP NewIPv4Address: $NewIPv4Address"}
        }
        elseif($CurrentIPAddress -eq $NewIPv4Address) 
        {
            ### Do nothing if the New iP Address is the same as the Existing IP Address 
            write-log "The IP Address is the Same - CurrentIP: $CurrentIPAddress NewIP: $NewIPv4Address" -ForegroundColor Yellow
        }
#>
    }

    Try-Catch $ScriptBlock
}

function Verify-IPv4
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
}

function Configure-WindowsFirewallProfile
{
    Param([Parameter(Mandatory = $False)] [string]$ConfigurationMode = "Report")

    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    ### Modify Parameters
    ### --------------------------------------
    if($WindowesFireWallProfile -eq "Disable") {$WindowesFireWallProfileValue = "False"}
    elseif($WindowesFireWallProfile -eq "Enable") {$WindowesFireWallProfileValue = "True"}

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:NetFirewallProfiles = Get-NetFirewallProfile -Name *
        }
        Invoke-Command $CurrentConfiguration

        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                Set-NetFirewallProfile -Profile $NetFirewallProfileName -Enabled $WindowesFireWallProfileValue
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
        }
        
        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
            foreach($NetFirewallProfile in $NetFirewallProfiles)
            {
                $script:NetFirewallProfileName  = $NetFirewallProfile.name
                $NetFirewallProfileValue = $NetFirewallProfile.Enabled                                

                if ($NetFirewallProfileValue -eq $WindowesFireWallProfileValue)
                {
                   Write-Config "COMPARE: TRUE  - The Current-Configuration is the same as the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
                   Write-Config "Not Running Configuration!"
                }
                if ($NetFirewallProfileValue -ne $WindowesFireWallProfileValue)
                {
                    Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - IPv6Enabled: $IPv6Enabled Ipv6Preference: $Ipv6Preference"
                    Write-Config "Running Configuration!"
                    Invoke-Command -ScriptBlock $ConfigureScriptBlock
                }
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyNetFirewallProfiles = Get-NetFirewallProfile -Name *
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Configuration
        ### -----------------------------------------------------------------------
        foreach ($VerifyNetFirewallProfile in $VerifyNetFirewallProfiles)
        {
            $VerifyNetFirewallProfile = $VerifyNetFirewallProfile.Enabled
            
            if($VerifyNetFirewallProfile -eq $WindowesFireWallProfileValue)
            {
                ### Verify Success
                $global:Verified = $True
                $global:Abort    = $False
                Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyNetFirewallProfile: $VerifyNetFirewallProfile WindowesFireWallProfileValue: $WindowesFireWallProfileValue"
                Write-Cookie $VM $Function $Verified $Abort
            }
            elseif($VerifyNetFirewallProfile -ne $WindowesFireWallProfileValue)
            {
                ### Verify Failure
                $global:Verified = $False
                if ($AbortTrigger -eq $True)
                {
                    ### Abort Failure
                    $global:Abort -eq $True
                    Write-Config "ABORT ERROR! - Verified: $Verified Abort: $Abort Function: $Function `nExiting Script!"
                    Write-Cookie $VM $Function $Verified $Abort
                    Exit
                }
                else
                {
                    ### Verify Error
                    $global:Abort -eq $False
                    Write-Config "VERIFY ERROR! - VERIFIED: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                    Write-Cookie $VM $Function $Verified $Abort
                }
            }
  
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-WindowsFirewallRules
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
}

function Configure-CDROM
{
    $Function = $((Get-PSCallStack)[0].Command)

    Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ### Set Abort Trigger
    ### --------------------------------------
    $AbortTrigger = $False

    ### Modify Parameters
    ### --------------------------------------
    ### Drive Letter Must End with Colon ":"
    $LastChar = $NewCDLetter.substring($NewCDLetter.length-1) 
    if ($LastChar -ne ":"){$NewCDLetter = $NewCDLetter + ":"}

    $ScriptBlock = 
    {
        ###################################
        ### CURRENT CONFIGURATION STATE: 
        ###################################
        [ScriptBlock]$CurrentConfiguration =
        {
            $script:CurrentCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive
        }
        Invoke-Command $CurrentConfiguration


        ###################################
        ### CONFIGURE:
        ###################################
        [ScriptBlock]$ConfigureScriptBlock = 
        {
            if($ConfigurationMode -eq "Configure")
            {
                Write-Config "Running in Configure Mode. Changing Configuration!"
                $CDVolume = Get-WmiObject -Class Win32_Volume -ComputerName $env:computername -Filter "DriveLetter='$CurrentCDLetter'" -ErrorAction Stop 
                Set-WmiInstance -InputObject $CDVolume -Arguments @{DriveLetter=$NewCDLetter} | Out-Null
            }
            elseif($ConfigurationMode -eq "Report")
            {
                Write-Config "Running in Report Mode. Logging Data Only!"
            }
        }

        ###################################
        ### COMPARE:
        ###################################
        [ScriptBlock]$CompareScriptBlock = 
        {
        write-host "CurrentCDLetter: " $CurrentCDLetter
        write-host "NewCDLetter: " $NewCDLetter

            if($CurrentCDLetter -eq $NewCDLetter)
            {
                Write-Config "COMPARE: TRUE - The Current-Configuration is the same as the Desired-Configuration - CurrentCDLetter: $CurrentCDLetter NewCDLetter: $NewCDLetter"
                Write-Config "Not Running Configuration!"
            }
            elseif ($ExistingInterfaceName -ne $NewInterfacename )
            {
                Write-Config "COMPARE: FALSE - The Current-Configuration does not match the Desired-Configuration - CurrentCDLetter: $CurrentCDLetter NewCDLetter: $NewCDLetter"
                Write-Config "Running Configuration!"
                Invoke-Command -ScriptBlock $ConfigureScriptBlock
            }
        }
        Invoke-Command $CompareScriptBlock

        ###################################
        ### VERIFY:
        ###################################
        [ScriptBlock]$VerifyScriptBlock = 
        {
            $script:VerifyCDLetter = (Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:ComputerName).Drive
        }
        Invoke-Command $VerifyScriptBlock

        ### Verify Compare Configuration
        ### -----------------------------------------------------------------------
        if($VerifyCDLetter -eq $NewCDLetter)
        {
            ### Verify Success
            $global:Verified = $True
            $global:Abort    = $False
            Write-Config "VERIFY SUCCEDED! - Verified: $Verified VerifyCDLetter: $VerifyCDLetter NewCDLetter: $NewCDLetter"
            Write-Cookie $VM $Function $Verified $Abort
        }
        elseif($VerifyCDLetter -ne $NewCDLetter)
        {
            $global:Verified = $False
            if ($AbortTrigger -eq $True)
            {
                ### Abort Failure
                $global:Abort -eq $True
                Write-Config "ABORT ERROR! - Verified: $Verified ABORT: $Abort FUNCTION: $Function `nExiting Script!"
                Write-Cookie $VM $Function $Verified $Abort
                #Send-Alert
                Exit
            }
            else
            {
                ### Verify Error
                $global:Abort -eq $False
                Write-Config "VERIFY FAILURE! - Verified: $Verified Abort: $Abort VerifyCDLetter: $VerifyCDLetter NewCDLetter: $NewCDLetter"
                Write-Cookie $VM $Function $Verified $Abort
            }
        }

    }
    Try-Catch $ScriptBlock
}

###############################################
#^ New Functions
#|
#|
#v Old Functions
###############################################

function Configure-ECIFolders
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    
    $ScriptBlock = 
    {
        ### Create ECI Folders
        ###--------------------------------        
        $ECIFolders = @()
        $ECIFolders += "C:\Scripts"
        $ECIFolders += "D:\Kits"

        foreach ($Folder in $ECIFolders)
        {
            if(-NOT(Test-Path -Path $Folder)) {(New-Item -ItemType Directory -Path $Folder -Force | Out-Null);Write-Host "Creating Folder: " $Folder }
        }
        ### Verify

        foreach ($Folder in $ECIFolders)
        {
            if(Test-Path $Folder){Write-Config "VERIFY SUCCEDED: $Folder"}
            elseif(-NOT(Test-Path $Folder)){Write-Config "VERIFY FAILED: $Folder"}
        }        
    }
    Try-Catch $ScriptBlock

    ### Copy Media

}

function Configure-PageFile
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Configure-RemoteDesktop
{
    ### Configure Remote Desktop Preference: RDP
    ### ------------------------------------------------------------ 

    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    
    if($RemoteDesktopPreference -eq "Disable")
    {
        $RemoteDesktopPreferenceValue = "1"
    }
    elseif($RemoteDesktopPreference -eq "Enable")
    {
        $RemoteDesktopPreferenceValue = "0"
    }

    $ScriptBlock = 
    {
        ### Enable Remote Desktop
        Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections" -Value $RemoteDesktopPreferenceValue
        Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    $VerifyValue = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections").fDenyTSConnections
    if($VerifyValue -eq $RemoteDesktopPreferenceValue){Write-Config "VERIFY SUCCESS: VerifyValue: $VerifyValue RemoteDesktopPreference: $RemoteDesktopPreference"}
    elseif($VerifyValue -ne $RemoteDesktopPreferenceValue){Write-Config "VERIFY FAILURE: VerifyValue: $VerifyValue RemoteDesktopPreference: $RemoteDesktopPreference"}

    ### Configure “Restrict each user to a single session”
    #
    #This policy setting appears in both Computer Configuration and User Configuration. 
    #If both policy settings are configured, the Computer Configuration policy setting takes precedence.
    #
    #


}

function Configure-InternetExplorerESC 
{
    ### Configure Internet Explorer Enhanced Security Configuration
    ### -------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    if($InternetExplorerESC -eq "Disable")
    {
        $InternetExplorerESCValue = "0"
    }
    elseif($InternetExplorerESC -eq "Enable")
    {
        $InternetExplorerESCValue = "1"
    }
    
    $ScriptBlock = {                
        $script:AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $script:UserKey  = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
        Set-ItemProperty -Path $UserKey  -Name "IsInstalled" -Value $InternetExplorerESCValue -Force
        
        # Needed???
        #Stop-Process -Name Explorer
    }

    Try-Catch $ScriptBlock
    
    ### Verify Configuration
    $VerifyAdminKey = (Get-ItemProperty -Path $AdminKey -Name "IsInstalled").IsInstalled
    $VerifyUserKey  = (Get-ItemProperty -Path $UserKey  -Name "IsInstalled").IsInstalled
    
    if (($VerifyAdminKey -eq $InternetExplorerESCValue) -AND ($VerifyUserKey -eq $InternetExplorerESCValue))
    {Write-Config "VERIFY SUCCEDED: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

    elseif (($VerifyAdminKey -ne $InternetExplorerESCValue) -OR ($VerifyUserKey -ne $InternetExplorerESCValue))
    {Write-Config "VERIFY FAILURE: IE Enhanced Security Configuration (ESC) has been Configured - Prefered Value: $InternetExplorerESC VerifyAdminKey: $VerifyAdminKey VerifyUserKey: $VerifyUserKey"}

}

function Configure-PageFile
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    # Disables Automatically Managed Page File Setting
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges

    if ($ComputerSystem.AutomaticManagedPagefile) 
    {
        Write-Config "Disabling AutomaticManagedPagefile: " $ComputerSystem.AutomaticManagedPagefile
        $ComputerSystem.AutomaticManagedPagefile = $false
        $ComputerSystem.Put() | Out-Null
    }

    ### Get Current PageFile Settings
    ### ---------------------------------
    $CurrentPageFile = Get-WmiObject Win32_Pagefile | Select-Object Name, InitialSize, MaximumSize, FileSize
    $CurrentPageFile = Get-WmiObject Win32_PagefileSetting | Where-Object {$_.name -eq $CurrentPageFile.Name}

    ### Delete Existing PageFile
    ### ---------------------------------
    if($CurrentPageFile)
    {
        Write-Config "Deleting Existing Page File: " $CurrentPageFile.Name
        $CurrentPageFile.Delete()
    }

    ### Calculate New Page File Size
    $Memory = (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
    $NewPageFileSize = [Math]::Round(($Memory * 1.2)) # Memory Size Plus 20% - Round Up
    
    if ($Memory -lt "4") {$NewPageFileSize = "4"}
    $NewPageFileSize = ($NewPageFileSize * 1000)


    ### Create New Page File
    ### ---------------------------------
    $PageFileLocation = "D:\"
    $PageFilePath = $PageFileLocation + "pagefile.sys"
    
    Write-Config "Creating New Page File: PageFilePath: $PageFilePath NewPageFileSize: $NewPageFileSize" 
    Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name=$PageFilePath; InitialSize = $NewPageFileSize; MaximumSize = $NewPageFileSize} | Out-Null

    ### Verify


}

function Configure-WindowsFeatures
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### List Features to Install
        Write-Config "The following Features will be installed:"
        foreach ($Feature in $WindowsFeatures)
        {
            Write-Config $Feature
        }

        ### Instal Features
        foreach ($Feature in $WindowsFeatures)
        {
            Install-WindowsFeature -name $Feature
        } 
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    foreach ($Feature in $WindowsFeatures)
    {
        $Feature = Get-WindowsFeature -name $Feature 
        if($Feature.Installed -eq "True") {Write-Config "VERIFY SUCCEDED: " $Feature.Name "`tInstalled: " $Feature.Installed}
        if($Feature.Installed -ne "True") {Write-Config "VERIFY FAILED: " $Feature.Name "`tInstalled: " $Feature.Installed}
    }
}

function Resume-Configure-WindowsFeatures
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        foreach ($Feature in $WindowsFeatures)
        {
            $Feature = Get-WindowsFeature -ComputerName $VM -Name $Feature
            
            If($Feature.Installed -eq "Installed") {Write-Config "VERIFY SUCCEDED: " $Feature.Name "`tInstalled: " $Feature.Installed}
            Else {Write-Config "VERIFY FAILED: " $Feature.Name "`tInstalled: " $Feature.Installed}
        }
    }
    Try-Catch $ScriptBlock
}

function Configure-WindowsUpdates
{
    function Get-AUSettings
    {
        $AUObj = @()
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
        $AUSettings.NotificationLevel
        $AUSettings.ReadOnly
        $AUSettings.Required
        $AUSettings.ScheduledInstallationDay
        $AUSettings.ScheduledInstallationTime
        $AUSettings.IncludeRecommendedUpdates
        $AUSettings.NonAdministratorsElevated
        $AUSettings.FeaturedUpdatesEnabled
    }

    function Get-WindowsUpdateConfig
    {
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings

        $AUObj = New-Object -TypeName System.Object
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "NotificationLevel" -Value $AutoUpdateNotificationLevels[$AUSettings.NotificationLevel]
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateDays" -Value $AutoUpdateDays[$AUSettings.ScheduledInstallationDay]
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "UpdateHour" -Value $AUSettings.ScheduledInstallationTime
        Add-Member -inputObject $AuObj -MemberType NoteProperty -Name "Recommended updates" -Value $(IF ($AUSettings.IncludeRecommendedUpdates) {"Included."}  else {"Excluded."})

        $AuObj
    } 

    function Set-WindowsUpdateConfig
    {
        Param ($NotificationLevel , $Day, $hour, $IncludeRecommended)
        $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
        if ($NotificationLevel)  {$AUSettings.NotificationLevel         = $NotificationLevel}
        if ($Day)                {$AUSettings.ScheduledInstallationDay  = $Day}
        if ($hour)               {$AUSettings.ScheduledInstallationTime = $hour}
        if ($IncludeRecommended) {$AUSettings.IncludeRecommendedUpdates = $IncludeRecommended}
        $AUSettings.Save
    } 
}

function Install-WindowsUpdates
{
    $ScriptBlock = {
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }

        Get-WUInstall  -IgnoreReboot 
        Get-WUInstall -ListOnly | FT Title, KB #, ComputerName, Size  
    }
    Try-Catch $ScriptBlock

}

function Rename-LocalAdministrator
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal

        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name

        ### Check if Local Admin is already renamed
        if($CurrentAdminName -eq $NewLocalAdminName)
        {
            Write-Config "Local Admin Names are the same -  CurrentAdminName: $CurrentAdminName NewAdminName: $NewLocalAdminName"
            $RebootRequired = $False
        }
        elseif($CurrentAdminName -ne $NewLocalAdminName)
        {
            $RebootRequired = $True
            Write-Config "Renaming Local Admin Account: Current Admin: $CurrentAdminName New Admin: $NewLocalAdminName"
            #Rename-LocalUser -Name $CurrentAdminName -NewName $NewLocalAdminName -ErrorAction SilentlyContinue | Out-Null
        }
    }
    Try-Catch $ScriptBlock
}

function Resume-Rename-LocalAdministrator
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = 
    {
        ### Use .NET to Find the Current Local Administrator Account
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        $ComputerName = [System.Net.Dns]::GetHostName()
        $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $ComputerName)
        $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
        $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
        $Searcher.QueryFilter = $UserPrincipal
        
        ### The Administrator account is the only account that has a SID that ends with “-500”
        $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
        $script:CurrentAdminName = $Account.Name
        wRITE-hOST "CurrentAdminName:" $CurrentAdminName
    }
    Try-Catch $ScriptBlock

    ### Verify Configuration
    ### --------------------------------------------------
    if($CurrentAdminName -eq $NewLocalAdminName) 
    {
        Write-Config "VERIFY SUCCEDED - CurrentAdminName: $CurrentAdminName NewLocalAdminName: $NewLocalAdminName"
        $VerifyFailure  = $False
        $RebootRequired = $False
    }
    elseif($CurrentAdminName -ne $NewLocalAdminName)
    {
        Write-Config "VERIFY FAILED - CurrentAdminName: $CurrentAdminName NewLocalAdminName: $NewLocalAdminName"
        $VerifyFailure = $True
    }
}

function Rename-GuestComputer
{
    ### Rename the Computer
    ### ----------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $CurrentComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
    Write-Host "CurrentComputerName: " $CurrentComputerName
    Write-Host "VMGuestComputerName: " $GuestComputerName

    ### Import Credentials
    ### ----------------------------------------
    #$PSCrdentials = (Import-AESEncryptionKey)
    #Import-AESEncryptionKey

    $SecPasswd = ConvertTo-SecureString "cH3r0k33" -AsPlainText -Force
    $PSCredentials =  New-Object System.Management.Automation.PSCredential ("Administrator", $SecPasswd)

    $ScriptBlock =
    {
        if($CurrentComputerName -ne $GuestComputerName)
        {
            ### Rename Computer
            write-log "Renaming Local Computer - NewName: $GuestComputerName"
            Rename-Computer –ComputerName  $CurrentComputerName –NewName $GuestComputerName -Force -LocalCredential $PSCredentials  #-PassThru
        }
        elseif($CurrentComputerName -eq $GuestComputerName)
        {
            ### Names are the Same
            write-log "Computer Names are the same - CurrentComputerName: $CurrentComputerName GuestComputerName: $GuestComputerName `nNot Renaming."
        }
    }
    Try-Catch $ScriptBlock
}

function Resume-Rename-GuestComputer
{
    ### Resume Rename-Computer After Reboot
    ### ----------------------------------------------------------------------------
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
        
    ### Verify Configuration
    $VerifyComputerName = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
    if ($VerifyComputerName -eq $GuestComputerName) {Write-Config "VERIFY SUCCEDED: VerifyComputerName: $VerifyComputerName GuestComputerName: $GuestComputerName"}
    elseif($VerifyComputerName -ne $GuestComputerName) { Write-Config "VERIFY FAILED: VerifyComputerName: $VerifyComputerName NewComputerName: $GuestComputerName"}

}

function Join-Domain
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)
    <#
    ### Generate Credentials
    ### ---------------------------------
    $UserName = "ecilab-bosdev01\cbrennan_admin"
    $PasswordFile = "c:\Scripts\password.txt"
    $Password ="01000000d08c9ddf0115d1118c7a00c04fc297eb010000000ada8d4ffc858d479f28124bff339f9a000000000200000000001066000000010000200000003c54ad13b08dfcd81ce6685c230c87208f97b585dec28dfb206c6c24d9b9e41d000000000e80000000020000200000004cd87e40bd5a96af906430a54909ec1b6468d1213f2ff08fd4d439dbbd0e7be120000000154f0ce9aef1faea4984397fc9f6066a6e955aeab72b58f6971230b46b539bdf400000001230e9f850ecc30c33204a8ec5fd98c6587a9e9e575662b0eb8da8d11cee6d21b05ddfcc16b6f67805e6a48ca2e60d190992bf62d4c073a3981450167905d703"

    ### Run this Command Manually to Create Password File
    ##############################################################
    ### Read-Host "Enter Password To Be Encrypted" -AsSecureString | ConvertFrom-SecureString | Out-File $PasswordFile
    ### You have to create the password string on the same computer and with the same login that you will use to run it.
    ##############################################################

    $PSCredentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, ($Password | ConvertTo-SecureString)
    #>


    ### Import Credentials
    ### ----------------------------------------
    #$PSCrdentials = (Import-AESEncryptionKey)
    #Import-AESEncryptionKey


    $ScriptBlock = 
    {
        $UserName = "GEEMONEYMGMT\ECIADMIN"
        $SecPasswd = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($UserName, $SecPasswd)

        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain

        If (-NOT(($CurrentDomain.Split(".")) -Contains $DomainName))
        {
            Write-Config "Joining Computer $VM to Domain - DomainName: $DomainName "
            Add-Computer -ComputerName $VM -DomainName $DomainName -Credential $PSCredentials -Force -Passthru -Verbose
        }

        Elseif (($CurrentDomain.Split(".")) -Contains $DomainName)
        {
            Write-Config "Computer $VM is already a Domain Member - DomainName: $DomainName "
        }
    }

    Try-Catch $ScriptBlock
    
    $RebootPending = $False
    if (!$?){$RebootPending = $True}

}

function Resume-Join-Domain
{
    Write-Config "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50)

    $ScriptBlock = {
        
        $CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
        
        If (($CurrentDomain.Split(".")) -Contains $DomainName) {Write-Config "VERIFY SUCCESS - DomainName $DomainName CurrentDomain: $CurrentDomain"}
        Else {Write-Config "VERIFY FAILURE - DomainName $DomainName CurrentDomain: $CurrentDomain"}
    }
    
    Try-Catch $ScriptBlock
}

function Get-ServerBuildType #Get-ServerConfigurationDefinition
{

    Param(
    [Parameter(Mandatory = $True)] [string]$ServerBuildType
    #[Parameter(Mandatory = $True)] [string]$Step
    )
    Write-Host `n("=" * 50)"`nSERVER BUILD TEMPLATE: `nBUILDTYPE:" $ServerBuildType`n("=" * 50)
    #Write-Host "SERVER BUILD TEMPLATE: `nBUILDTYPE:" $ServerBuildType
    #Write-Host ("=" * 75)

    ### Set Parameters for ALL Server Build Types
    $global:BuildDate = Get-Date -Format g

    ### Set Parameters for Server Build Types

    Switch ($ServerBuildType)
    {
         ### Windows Server 2016 Builds
         ###-----------------------------------

         2016_Std_Base 
         {


<#
            ### Server Template "Hard" Parameters
            ### -----------------------------------------
            $vCPU = "2"
            $Memory = "4"
            $OSVolume = "50"
            $PageFileVolume = "10"
            $DataVolume = $Null
            $LogSettingsEvent = $Null 
            $Sys = $Null


$arr=@{}
$arr["Template"] = @{}
$arr["Template"]["TSHIRTS"] = @{}    
$arr["Template"]["TSHIRTS"]["SIZE"] ="M"
$arr.Template.tshirts.size
#>

            ### Server Template "Hard" Parameters
            ### -----------------------------------------
            $Parameters = [ordered]@{
                NewInterfacename            = "Ethernet1"
                NewLocalAdminName           = "ECIAdmin"
                NewCDLetter                 = "R:"
                Ipv6Preference              = "Enable"
                WindowesFireWallProfile     = "Disable"
                AutomaticReboot             = "Disable"
                RemoteDesktopPreference     = "Enable"
                RDPResitrctSessions         = "Disable"
                PageFileLabel               = "SWAP\KITS"
                PageFileSize                = "1.2"
                PageFileLocation            = "D:\"
                InternetExplorerESC         = "Disable"
            }

            $global:HardParameters = @()
            Write-Host "`nImporting *HARD* Parameters from Server Build Template:`n" ("-" * 50)
            foreach($Parameter in $Parameters.GetEnumerator())
            {
                Write-Host "$($Parameter.Name): $($Parameter.Value)"

                # Create Variables and Set Variable Scope to "Global"
                Set-Variable -Name $($Parameter.Name) -Value $($Parameter.Value) -Scope Global
                $global:HardParameters += Get-Variable -Name $($Parameter.Name)
            }
            
            Write-Host "`nVERIFY: *Hard* Parameters from Server Build Template :"`n("-" * 50)
            $HardParameters | FT
            <#
            Write-Host "NewInterfacename            : " $NewInterfacename
            Write-Host "NewLocalAdminName           : " $NewLocalAdminName
            Write-Host "NewCDLetter                 : " $NewCDLetter
            Write-Host "Ipv6Preference              : " $Ipv6Preference
            Write-Host "WindowesFireWallProfile     : " $WindowesFireWallProfile
            Write-Host "AutomaticReboot             : " $AutomaticReboot
            Write-Host "RemoteDesktopPreference     : " $RemoteDesktopPreference
            Write-Host "RDPResitrctSessions         : " $RDPResitrctSessions
            Write-Host "PageFileLabel               : " $PageFileLabel
            Write-Host "PageFileLocation            : " $PageFileLocation
            #>

            ### Windows Features
            ### -----------------------------------------
            $WindowsFeatures  = @()
            $WindowsFeatures += "NET-Framework-Features"
            $WindowsFeatures += "NET-Framework-Core"
            $WindowsFeatures += "GPMC"
            $WindowsFeatures += "Telnet-Client"
            #$WindowsFeatures += "RSAT"
            $global:WindowsFeatures = $WindowsFeatures
         
            # Server Build Functions
            #--------------------------
            
            if ($Step -eq "xyz")
            {
                #Do-Something1
                #Rename-Computer
                #Set-RegKey
                #Pause-Script
                #Reboot-Resume
                #Update-Windows
            }

            if ($Step -eq "xyz")
            {
                #Do-Something2
                Invoke-Test
                
                #Pause-Script
                #Verify-ComputerRename
                #Rename-Interface
                #Set-IPv4
                #Set-IPv6
                #Set-SwapFile
                #Add-WindowsFeatures
                #Update-Windows
                #Set-WindowsFirewall
                #Add-WindowsFeatures
                #Rename-LocalAdministrator
                #Join-Domain

                #Disable-AutomaticReboot
                #Create-KitsFolder
                #Create-ScriptsFolder
                #Enable-RemoteDesktop
                #Disable-InternetExplorerESC 

                ### Optional
                #Screen Resolution to 1024 x 768    
                #Set-TimeZone

            }
           
            if ($Step -eq "xyz")
            {
                #Set-RegKey
                #Reboot-Resume
                #Continue
            }
               
        }

         2016_DC{}

         2016_File{}
            
         2016_Citrix{}

         ### Windows Server 2012 R2 Builds
         ###-----------------------------------
         2012R2_Std_Base {}

         2012R2_File{}

         2012R2_DC{}

         2012R2_Citrix{}

    }
}

function Function-Template
{
    $Function = $((Get-PSCallStack)[0].Command)
    Write-Config "Executing Function: $Function `n " ('-' * 50)

    $ParameterValue = $ParameterValue
    $AbortTrigger = 0

    #############################################
    ### Set Configuration
    #############################################
    function Set-Configuration
    {
        $ScriptBlock = 
        {
            Set-Something -Name $Name -Value $Value
        }

        Try-Catch $ScriptBlock
    }
    
    #############################################
    ### Get Current Configuration
    #############################################
    $CurrentValue = Set-Something -Name $Name -Value $Value

    if ($CurrentValue -ne $ParameterValue)
    {
        Write-Config "Values are the Different. Configuring: CurrentValue: $CurrentValue ParameterValue: $ParameterValue"
        Set-Configuration
    }
    elseif ($CurrentValue -eq $ParameterValue)
    {
        Write-Config "Values are the Same. Not Configuring: CurrentValue: $CurrentValue ParameterValue: $ParameterValue"
    }
    else
    {
        Write-Config "Values cant be identified. Aborting!"
        $Abort = $True
    }

    #############################################
    ### Verify Configuration
    #############################################
    $VerifyValue = Get-Something -Name $Name -Value $Value

    if ($VerifyValue -eq $ParameterValue)
    {
        $Verified = $True
        $Abortvalue = $False

        Write-Config "VERIFED: $Verifed $VerifyValue ParameterValue: $ParameterValue"
        Write-Cookie $VM $Function $Verified $AbortValue
    }
    else 
    {
        $Verified = $False
        if($AbortTrigger = 1){$Abortvalue = $True}
        
        Write-Config "VERIFED: $Verifed $VerifyValue ParameterValue: $ParameterValue"
        Write-Cookie $VM $Function $Verified $AbortValue
    }
}

function Configure-GuestVMDebuging
{
    Param([Parameter(Mandatory = $True,  Position = 0)] [string]$Mode = "Enable")

    $global:VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools\Tools.conf"

    function Create-VMToolsConfigFile    {        ### Create Log Folder        $DebugLogPath = "C:\Temp\VMTools"        if(-NOT(Test-Path -Path $DebugLogPath)) {New-Item -ItemType directory -Path $DebugLogPath | out-null}        ### Create VM Tools Guest Config File        $TextBlock = {
        [logging]        log = true        vmtoolsd.level = debug        vmtoolsd.handler = file
        vmtoolsd.data = c:/temp/vmtoolsd.log        }        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}

        #$TextBlock | 
        #$TextBlock | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII #UTF8 #ASCII #String #Unicode
        #Set-Content -Value $TextBlock -Path $VMGuestConfigFile #-Force


        # Hard Code & Copy Conf File - Until above gets fixed!
        $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\Tools.conf"
        $VMGuestConfigFile = "C:\ProgramData\VMware\VMware Tools"

        #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
        Copy-Item -Path $Src -Destination $VMGuestConfigFile -Force

    }

    if($Mode -eq "Enable")    {        Write-Host "Enabling Debug Logging a Guest VM"        Create-VMToolsConfigFile    }    elseif($Mode -eq "Disable")    {        Write-Host "Disbling Debug Logging a Guest VM"        if(Test-Path -Path $VMGuestConfigFile){Remove-Item -Path $VMGuestConfigFile -ErrorAction SilentlyContinue | out-null}            }}

##################################################################################################################
##################################################################################################################
##################################################################################################################
# Junk?

function Dev-Update-Windows
{
    $ScriptBlock = 
    {
        Write-Config "Executing Function: " $((Get-PSCallStack)[-1].Command) `n('-' * 50)
### Windows Server 2016 Update settings
<#
– 2 = Notify before download.
– 3 = Automatically download and notify of installation.
– 4 = Automatically download and schedule installation. Only valid if values exist for ScheduledInstallDay and ScheduledInstallTime.
– 5 = Automatic Updates is required and users can configure it.
#>
#HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

$WindowsUpdateAU = HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU

Set-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU -Name AUOptions -Value 3

        
        write-host "PSVersion: " $PSVersionTable.PSVersion
        <#
        if ($PSVersionTable.PSVersion -gt "5")
        {
            write-host "PSVersion: " $PSVersionTable.PSVersion
        }
        #>
        
        $PSWindowsUpdateModuleisLoaded = Get-Module PSWindowsUpdate

        if (!$PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate NOT Loaded. Loading!" -ForegroundColor Red
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
                
        if ($PSWindowsUpdateModuleisLoaded)
        {
            Write-Host "PSWindowsUpdate is already loaded." -ForegroundColor Green

        }

        write-host "PSWindowsUpdateModuleisLoaded: " $PSWindowsUpdateModuleisLoaded

        <#
        ### Get Microsoft Updates
        ### -----------------------------------
        $UpdateSession = new-object -com "Microsoft.Update.Session"
        $Criteria="IsInstalled=0 and IsHidden=0"
        $Updates=$UpdateSession.CreateupdateSearcher().Search($Criteria).Updates
        $Updates | Format-Table -property Title
        #>

        <#
        ### Get WSUSUpdates
        ### -----------------------------------
        $UpdateServer = "BLU-MGMT01.ecilab.net"
        
        Get-WSUSServer -Name "10.70.0.8" -Port 8530 
        Get-WSUSServer -Name "BLU-MGMT01.ecilab.net" -Port 8530

        Get-WsusUpdate -UpdateServer "BLU-MGMT01.ecilab.net"
         Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        #Get-WsusUpdate -Classification All -Approval Unapproved -Status FailedOrNeeded
        
        #https://blogs.technet.microsoft.com/heyscriptingguy/2012/01/19/use-powershell-to-find-missing-updates-on-wsus-client-computers/
        #>


        <#
        $WindowsUpdateModuleisAvailable = (Get-Module -ListAvailable WindowsUpdate)
        if ($WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module is available" -ForegroundColor Green
            #Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
            #Install-Module -Name PSWindowsUpdate -Force -AllowClobber
        }
        if (!$WindowsUpdateModuleisAvailable)
        {
            write-host "PSWindowsUpdate Module not available" -ForegroundColor Red
        }
        #>

    }
    
    Try-Catch $ScriptBlock
}

function Set-FirewallRules
{
    $ScriptBlock = 
    {
        $Parameters = @{
            DisplayName = "Allow RDP from 10.0.0.0/24"
            LocalPort = 3390
            Direction="Inbound"
            Protocol ="TCP" 
            Action = "Allow"
                
            # Get the Remote Address from the $ParamaterFile
            RemoteAddress = $AllowRDPSubnet
        }

        ## Checking if the Rule Exists
        write-host "Checking if rule exists: " $Parameters.DisplayName
        $Rules = Get-NetFirewallRule -DisplayName *
            
        if (-not $Rules.DisplayName.Contains($Parameters.DisplayName)) 
        {
            ### Create New Firewall Rule
            Write-Log "This rule Does not exist. Creating New Firewall Rule"
            New-NetFirewallRule -DisplayName $Parameters.DisplayName -Action $Parameters.Action -Direction $Parameters.Direction `
            –LocalPort $Parameters.LocalPort -Protocol $Parameters.Protocol -RemoteAddress $Parameters.RemoteAddress| Out-Null
        }
        else
        {
            write-host "This rule already exists. Not Creating"
        }

        ### Show the Firewall Settings
        write-log "Checking the Firewall Settings"
        $FirewallRule = Get-NetFirewallRule -DisplayName $Parameters.DisplayName
        write-host "DisplayName: " $FirewallRule.DisplayName "Action: " $FirewallRule.Action "Enabled: " $FirewallRule.Enabled
    }
    Try-Catch $ScriptBlock
}

function OldRename-LocalAdministrator
{

    $ScriptBlock = 
    {

        function Get-CurrentAdmin
        {
            ### Find the Current Local Administrator Account
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            $PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:ComputerName)
            $UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
            $Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
            $Searcher.QueryFilter = $UserPrincipal

            ### The Administrator account is the only account that has a SID that ends with “-500”
            $Account = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"}
            $script:CurrentAdminName = $Account.Name
            Write-Log "The current Local Administrator Account is: $CurrentAdminName"
        }

        function Rename-Admin
        {
            ### Get the Current Local Admin Account
            $User= Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | Where {$_.Name -eq $CurrentAdminName}

            ### Rename the Current Local Admin Account
            write-host "Renaming $CurrentAdminName to $NewAdminName "
            $user.Rename($NewAdminName) | Out-Null
        }

        function Check-CurrentAdmin
        {
            ### Check if Local Admin is already renamed

            if($CurrentAdminName -eq $NewAdminName)
            {
                write-host "CurrentAdminName is the same as NewAdminName"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
            }
            elseif($CurrentAdminName -ne $NewAdminName)
            {
                write-host "Renaming Local Admin Account"
                write-host "Current Admin: $CurrentAdminName New Admin: $NewAdminName"
                Rename-Admin
            }
        }

        function Verify-NewAdmin
        {
            write-host "Verifying new Admin Account Name"
            Get-CurrentAdmin
        }

        Get-CurrentAdmin
        Check-CurrentAdmin
        Verify-NewAdmin

    }

    Try-Catch $ScriptBlock
}

function Test-VMGuestConnection
{
    Write-Host "Getting Guest Data:" -ForegroundColor Cyan
    $global:GuestOSVer        = (Get-CimInstance Win32_OperatingSystem).version 
    $global:GuestComputerName = $env:COMPUTERNAME
    $global:GuestIPv4Addr     = [string]((Get-NetAdapter –Physical | where Status -eq 'Up') | Get-NetIPAddress -AddressFamily IPv4).IPv4Address

    Write-Log "GuestComputerName : " $env:COMPUTERNAME
    Write-Log "GuestOSVer        : " $GuestOSVer 
    Write-Log "GuestIPv4Addr     : " $GuestIPv4Addr
}

function CopyFile-ToGuestVM
{
    # Hard Code & Copy Conf File - Until above gets fixed!
    $Src = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\tools.conf"
    $Dest = "C:\ProgramData\VMware\VMware Tools"

    #Get-Content -Path $Src | Out-File -FilePath $VMGuestConfigFile -Append -NoClobber -Force -Encoding ASCII
    Write-Host "Copying File: SRC: $Src DEST: $Dest"
    Copy-Item -Path $Src -Destination $Dest -Force

}

function Get-VMToolsStatus
{

    Restart-VM -VM $dbvm2 -Confirm :$false
    Sleep 10
    while (((get-vm $dbvm2 ).ExtensionData.Guest.ToolsRunningStatus ) -ne "guestToolsRunning" ) {
    Write-Host "....." -ForegroundColor Yellow
    Sleep 5
    }
 
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    while ( $? -eq $false ) {
    Get-Date -Format HH :mm :ss
    sleep 2
    Invoke-VMScript -ScriptText $bb -vm $dbvm2 -HostCredential $hostcreds -GuestCredential $guestcreds
    }
}

function Restart-VMGuestService
{
    write-host "VMTools Status: " (Get-Service -Name VMTools).Status

    ### Restart the VMTools Service
    if((Get-Service -Name VMTools).Status -eq "Running")
    {
        Write-Host "Re-Starting VMTools:"
        Get-Service -Name VMTools | Restart-Service -Force
        Wait-Tools -VM $VM -TimeoutSeconds 60
    }
    else
    {
        Write-Host "Starting VMTools:"
        #Get-Service -Name VMTools | Start-Service -Name VMTools
    }
}

function Restart-GuestVMTools
{


}

function Start-ConfigReport
{
    $script:ConfigReportFile = $ReportPath + "\ConfigReport_" + $ScriptName + "_" + $TimeStamp + ".log"

    ### Write Config Report Header
    Write-Config "Server Configuration Report:"
    Write-Config  ('-' * 50) 
    $ConfigReport = @()
    $ReportHeader = @{
        New_Server_Name = $NewServerName
        Build_Date = (Get-Date)
        New_Domain = $NewDomain
        Target_Server = $env:COMPUTERNAME
        Target_Domain = $env:USERDNSDOMAIN
    }

    $PSObject      = New-Object PSObject -Property $ReportHeader
    $ConfigReport += $PSObject 
    $ConfigReport | Format-List
    $ConfigReport | Format-List | Out-File  -filepath $ConfigReportFile -append 
    
    ### Write Input Parameters
    Write-Config "Input Parameters:"
    Write-Config  ('-' * 50) 

    $Params = @()
    foreach ($Parameter in $Parameters)
    {
        $NewParams = [ordered]@{
        NewParameter = $Parameter.NewParameter
        NewValue     = $Parameter.NewValue
        }

        ### Build Parameter Report Header
        $PSObject      = New-Object PSObject -Property $NewParams
        $Params       += $PSObject 
    }  
    $Params | Format-Table -AutoSize
    $Params | Format-Table -AutoSize | Out-File  -filepath $ConfigReportFile -append 
}

function Set-RegKey
{
    Write-Host "Setting RunOnce Reg Key"
    #$ScriptPath  = $MyInvocation.PSCommandPath
    $ScriptPath  = $((Get-PSCallStack)[-1].Command)
    Write-Host "ScriptPath: " $ScriptPath
   
    
    $RegRunKey     = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
    $RegRunOnceKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    #$ResumePSCommand = "C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -noexit -file C:\Scripts\Reboot-Resume\Reboot-Resume.ps1 -Step 3"
    $ResumePSCommand = "C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -noexit -file C:\Scripts\Modules\ConfigServer\ConfigServer-Template.ps1 -Step 2"
    Set-ItemProperty -Path $RegRunOnceKey -Name "ResumePS" -Value $ResumePSCommand 
}

function Import-Parameters
{
    $ScriptBlock = 
    {
        ### Hard Code the Parameter File
        $ParameterFile = "Parameters.csv"

        ### Set Parameter File Path 
        $ParametersFilePath =  $ScriptPath + "\" + $ParameterFile

        ### Check if Parameter File Exits
        write-log "Checking for Parameter File: $ParameterFile"

        if(-not (Test-Path $ParametersFilePath))
        {
            write-log "Parameter File Missing: $ParameterFile" -Foregroundcolor Red
            write-log "Exiting Script!" -Foregroundcolor Red
            Exit
        }
        else
        {
            write-log "Parameter File Exists. Importing: $ParameterFile" -Foregroundcolor Green
        }

        ###########################
        ### Initialize Parameters
        ###########################

        ### Import from CSV file
        $script:Parameters = Import-CSV -path $ParametersFilePath 

        foreach ($Parameter in $Parameters)
        {
            # Set Variable Scope to "Script" for Functions
            Set-Variable -Name $Parameter.NewParameter -Value $Parameter.NewValue -scope global
                
            # Verify Variables
            $Verify = Get-Variable -Name $Parameter.NewParameter
            #$Parameter.NewParameter
            #$Parameter.NewValue
        }            
    }

    Try-Catch $ScriptBlock
}

####################################