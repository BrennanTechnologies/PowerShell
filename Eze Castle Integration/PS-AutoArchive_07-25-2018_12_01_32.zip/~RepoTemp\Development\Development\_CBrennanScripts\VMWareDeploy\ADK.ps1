﻿### From <http://thecrazyconsultant.com/windows-server-2016-unattended-installation-plus-vmware-tools/> 

#Find your build
(Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name ReleaseId).ReleaseId


#https://packages.vmware.com/tools/esx/6.5/windows/VMware-tools-windows-10.1.0-4449150.iso