﻿cls

Start-Transcript

function Stop-Transcribing
{
    try
    {

        Stop-Transcript | Out-Null

    }
    catch
    {
        write-host "No Transcript Running"
    }
}
Stop-Transcribing