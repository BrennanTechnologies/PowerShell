﻿cls

### Parameter File
$ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"

### Dev Server
$DevHost = "ECILAB-BOSAPP1.ecilab.corp"

### VI Servere
$VIServer = "ecilab-bosvcsa01.ecilab.corp"
$VICreds  = "" # -User cbrennan_admin@ecilab.corp -Password W3lcome123!

### Host VM
$HOSTVM = ""
$HostCreds = # -HostUser ezebos\cbrennan -HostPassword Tolkien4374
     
### Guest VM

$global:VM = "RGEE-SRV1" # <-- Param from API???

$GuestCreds = "" # -GuestUser administrator -GuestPassword Tolkien4374



### Import VMWare Modules
function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: $VMModules"
    }
    <#
    PS C:\Users\cbrennan_admin> Get-Module vm*

    ModuleType Version    Name                                ExportedCommands                                                                                                                   
    ---------- -------    ----                                ----------------                                                                                                                   
    Script     10.0.0.... VMware.VimAutomation.Cis.Core       {Connect-CisServer, Disconnect-CisServer, Get-CisService}                                                                          
    Script     10.0.0.... VMware.VimAutomation.Common                                                                                                                                            
    Script     10.0.0.... VMware.VimAutomation.Core           {Add-PassthroughDevice, Add-VirtualSwitchPhysicalNetworkAdapter, Add-VMHost, Add-VMHostNtpServer...}                               
    Script     10.0.0.... VMware.VimAutomation.Sdk            {Get-InstallPath, Get-PSVersion}  
    #>
}

#######################################
### Function: Connect to ECI VI Server
#######################################
function Connect-ECIVIServer
{

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false #| Out-Null

    <#
    Connecting New Session to VI Server:  ecilab-bosvcsa01.ecilab.corp
    WARNING: There were one or more problems with the server certificate for the server ecilab-bosvcsa01.ecilab.corp:443:

    * The X509 chain could not be built up to the root certificate.

    Certificate: [Subject]
      C=US, CN=ecilab-bosvcsa01.ecilab.corp

    [Issuer]
      O=ecilab-bosvcsa01.ecilab.corp, C=US, DC=local, DC=vsphere, CN=CA

    [Serial Number]
      00E95976D6B9344236

    [Not Before]
      6/22/2015 3:34:28 PM

    [Not After]
      6/16/2025 3:34:27 PM

    [Thumbprint]
      38A7F51B30A4CFAC6A136D0585D77322106CC69E



The server certificate is not valid.
    
WARNING: THE DEFAULT BEHAVIOR UPON INVALID SERVER CERTIFICATE WILL CHANGE IN A FUTURE RELEASE. To ensure scripts are not affected by the change, use Set-PowerCLIConfigura
tion to set a value for the InvalidCertificateAction option.
#>

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Yellow
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Yellow
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    $VISession = Connect-VIServer -Server  $VIServer  -User ezebos\cbrennan -Password Tolkien4374
    }


    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

#######################################
### Import Parameters from API
#######################################
function Import-APIParameters
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    Write-Host "Importing Parameters from API (or .CSV):" -ForegroundColor Magenta
    $ParameterFile = "C:\Users\cbrennan_admin\Documents\Parameters.csv"
    $Varibles = @()
    foreach ($Parameter in (Import-CSV -path $ParameterFile))
    {
        # Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -scope global
                
        # Verify Variables
        $Varibles += Get-Variable -Name $Parameter.Name
    }  
    
    $Varibles | ft
}


#######################################
### Function: Get Guest VM
#######################################
function Get-GuestVM
{
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}

#######################################
### Function: Restart Guest VM
#######################################
function Restart-GuestOS
{
    #######################################
    ### Restart Guest VM Computer
    #######################################
    Write-Host "Rebooting Server: $VM" -ForegroundColor Yellow
    Restart-VMGuest -VM $VM -Server $VIServer | Wait-Tools | Out-Null
}

#######################################
### Function: Resume Guest VM
#######################################
function Resume-GuestOS
{
    #######################################
    ### Resume after Restart
    #######################################
    Write-Host "Waiting for Server to Resume: $VM" -ForegroundColor Yellow

    ### Pasuse Script
    ### ---------------------------
    ### Pause to let the Reboot command Start, otherwise the Wait-Tools will respond immediately
    $t = 15 ### Timer for Dev
    #$t = 60 ### Timer for Prod
    Write-Host "Sleeping Script for $t secs ..." -ForegroundColor Gray
    Start-Sleep -Seconds $t

    ### Wait for VM Tools
    ### ---------------------------
    $t = 60 ### Timer for Dev
    #$t = 240 ### Timer for Prod
    Write-Host "Waiting for VMTools to Respond for $t secs ..." -ForegroundColor Gray
    Wait-Tools -VM $VM -TimeoutSeconds $t -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null

    ### Resume Script
    ### ---------------------------
    Write-Host "Resuming after Restart: $VM" -ForegroundColor Yellow

    ### Test VMGuest Connectivity
    ### ---------------------------
    $global:VM = Get-VM $VM
    Write-Host "Contacting VM Guest OS:" -ForegroundColor Magenta
    Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta
}


function InvokeVMScript-Step1
{

    BEGIN
    {
        Write-Host "BEGIN: InvokeVMScript-Step: $Step" -ForegroundColor Magenta

    }

    PROCESS
    {
        Write-Host "PROCESS: InvokeVMScript-Step: $Step" -ForegroundColor Magenta
    
    
    }
    
    END
    {
        Write-Host "END: InvokeVMScript-Step: $Step" -ForegroundColor Magenta
    
    }
}


#######################################
### Execute the Script
#######################################
&{ 

    BEGIN
    {
        Write-Host "BEGIN: ConfigServer-Template" -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue" ### Hide VMWare Module Progress Bar
        Import-VMWareModules
        Connect-ECIVIServer
    }

    PROCESS
    {
        Write-Host "PROCESS: ConfigServer-Template" -ForegroundColor Yellow
        Get-GuestVM
        #Import-APIParameters
        InvokeVMScript-Step1
        #Restart-GuestOS
        #Resume-GuestOS
        #InvokeVMScript-Step2

    }

    END
    {
        Write-Host "END: ConfigServer-Template" -ForegroundColor Yellow
        #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
    }

}
