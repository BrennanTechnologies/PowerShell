﻿cls
function Write-Log
{
    param (
        [Parameter(Mandatory=$true,  Position=0)] [string] $Msg,
        [Parameter(Mandatory=$false, Position=1)] [string] $Value,
        [Parameter(Mandatory=$false, Position=2)] [string] $ForegroundColor
    )

    ### Write the Messages to the Console & the Log File.
    $LogLine = $Msg + "`t" + $Value
    if ($Foregroundcolor -eq $null) {$Foregroundcolor = White}
    write-host $LogLine -Foregroundcolor $Foregroundcolor
    "`n`n"   | out-file -filepath $LogFile -append
    $LogLine | out-file -filepath $LogFile -append
}


Write-Log "My Msg:" $(Get-Date) -ForegroundColor cyan
