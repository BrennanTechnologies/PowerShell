﻿
Get-Module -ListAvailable

#Get-VMGuest -VM VM

Get-VMHost

#Restart-VMGuest