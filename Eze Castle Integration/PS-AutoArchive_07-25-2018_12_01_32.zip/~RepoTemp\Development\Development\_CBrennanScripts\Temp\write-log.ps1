﻿cls

function Write-Log
{
    Param(
    [Parameter(Mandatory = $true,Position = 0)] [string]$Message,
    [Parameter(Mandatory = $false,Position = 1)] [string]$Value,
    [Parameter(Mandatory = $false)] [string]$ForegroundColor,
    [Parameter(Mandatory = $false)] [switch]$Quiet
    )
    
    write-host "Message:" $Message
    write-host "Value:"   $Value
    write-host "Color:"   $Foregroundcolor
    write-host "Quiet:"   $Quiet

    ### Write the Messages to the Console.
    if (!$Quiet)
    {
        if($Value){$Message = $Message + $Value}
        if (!$Foregroundcolor) {$Foregroundcolor = Cyan}
        $String = $Message + " -Foregroundcolor " + $Foregroundcolor
        write-host $Message -Foregroundcolor $Foregroundcolor
    }

    ### Write the Message to the Log File.
    "`n`n*****"   | out-file -filepath $LogFile -append
    $Message      | out-file -filepath $LogFile -append
}
write-log "Test" "Text" -Foregroundcolor Yellow -Verbose
