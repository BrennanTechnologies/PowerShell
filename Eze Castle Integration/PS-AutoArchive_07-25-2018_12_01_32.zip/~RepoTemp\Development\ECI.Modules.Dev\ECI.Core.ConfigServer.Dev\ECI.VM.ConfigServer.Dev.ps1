﻿cls

<#
1. New VM
    - CPU
    - Mem
    - SCSI Controller
    - HD
    - ISO

2. Mount-Tools
    - Install VMTOols

3. SysPrep


#>

function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
}

function Connect-ECIVIServer
{
    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Write-Host "Setting PowerCLIConfiguration: -InvalidCertificateAction Ignore" -ForegroundColor Gray
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false <#-ParticipateInCEIP:$false#> | Out-Null

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Gray
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    #$VISession = Connect-VIServer -Server $VIServer  -User ezebos\cbrennan -Password Tolkien43741
    $VISession = Connect-VIServer -Server $VIServer  -User sdesimone_admin@ecilab.corp -Password cH3r0k33!B

    }

    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}





#Get-ResourcePool

#Get-Datastore




### VM Host Parameters
$ProgressPreference = "SilentlyContinue" #<-- Hide VMWare Module Progress Bar
#$WarningPreference 

### VM Parameters
$VM = "RGEE-SRVx2"
$AlternateGuestName = $VM
$GuestId = "Windows Server 2003, Enterprise Edition"
$VMTemplate = "W2K16v2"
$ResourcePool = "ClientDCs"
$TargetDataStore = "nfs_emsadmin_sas1"
$NetworkName = ""
$DiskStorageFormat = "Thin" ### Thin/Thick

### VM Parameters
$vCPUCount = "2"
$vMemorySize = "4000"
$OSVolumeSize = "50"
$SwapVolumeSize = "10"
$DataVolumeSize = $Null
$LogVolumeSize = $Null
$SysVolumeSize = $Null


function New-ECIVM
{
    ### New-VM --- https://www.vmware.com/support/developer/windowstoolkit/wintk40u1/html/New-VM.html

    Write-Host "Creating VM: " $VM "ResourcePool: " $ResourcePool -ForegroundColor Yellow
    
    #New-VM -Name $VM -Template $VMTemplate -ResourcePool $ResourcePool -DiskStorageFormat Thin -Datastore $TargetDataStore
    New-VM -Name $VM -Datastore $TargetDataStore -ResourcePool $ResourcePool -NumCpu $vCPUCount -MemoryMB $vMemorySize # -CD #-DiskGB $OSVolumeSize -DiskStorageFormat $DiskStorageFormat #-InformationAction SilentlyContinue #-CD $CD #-DiskStorageFormat Thin -Datastore $TargetDataStore
        #-Template $VMTemplate
        #-AlternateGuestName $AlternateGuestName
        #-Datastore (Get-DatastoreCluster -Name $TargetDataStore | Get-Datastore | Get-Random)
        #-OSCustomizationSpec $VMCustomSpec `
    #>  
}

function Get-ESXHost
{
    Get-View -ViewType HostSystem -Property Name,Config.Product | Format-Table Name, @{L='Host Version & Build Version';E={$_.Config.Product.FullName}}
}

function Start-ECIVM
{
    Write-Host "Starting VM: $VM" -ForegroundColor Yellow
    Start-VM $VM
}

function Set-ECIOSCustomizationSpec
{
    ### Set-OSCustomizationSpec
}

function Stop-ECIVM
{
    Write-Host "Stopping VM: $VM" -ForegroundColor Yellow
    Stop-VM $VM -Confirm:$false
}

function Install-VMTools
{
    Mount-Tools -VM $VM
    Dismount-Tools -VM $VM
    Update-Tools -VM $VM
  
  
    #$vm.ExtensionData.Guest | Select Hostname,Tools*

<#
Copy the VMware Tools Installer to a local or shared folder
Note: There are 2 different installers: Setup.exe and Setup64.exe Choose according to the corresponding OS
Open Command Prompt
Browse to the folder that includes the setup file
type .\setup64.exe /s /v “/qn reboot=r”
The /qn means it will be a silent (quiet) installation, there will be no GUI.

reboot=r will keep your VM from restarting after the installation completes

s – silent execution

v – sends all parameters directly to the msi file.
#>

}

function New-ECIScsiController
{
    Write-Host "Creating ScsiController: " -ForegroundColor Yellow

    $ScsiControllerType = "VirtualLsiLogicSAS"
    $Disk = Get-HardDisk -VM $VM | Select -First 1
    
    New-ScsiController -HardDisk $Disk -Type $ScsiControllerType -Confirm:$false

}

function Remove-ECIHardDisk
{
    Write-Host "Removing Hard Disk: " -ForegroundColor Yellow
    
    Get-HardDisk -VM $VM | Remove-HardDisk -DeletePermanently -Confirm:$false
}

function New-ECIHardDisk
{
    Write-Host "Creating Hard Disk: " -ForegroundColor Yellow

    $Persistence = "Persistent"
    $StorageFormat = "Thin"
    $Controller = Get-ScsiController -VM $VM | Select -First 1

    ### Add OS Volume
    Get-VM $VM | New-HardDisk -CapacityGB $OSVolumeSize -Persistence $Persistence -StorageFormat $StorageFormat -Controller $Controller

    ### Add PageFile Volume
    Get-VM $VM | New-HardDisk -CapacityGB $SwapVolumeSize -Persistence $Persistence -StorageFormat $StorageFormat -Controller $Controller

}



function Set-ECIHardDisk 
{
    Write-Host "Setting Hard Disk: " -ForegroundColor Yellow

    $Disk = Get-HardDisk -VM $VM | Select -First 1
    Set-HardDisk -HardDisk $Disk -CapacityGB $OSVolumeSize -Confirm:$False
}

function Remove-ECIVM
{
    Write-Host "Removing VM: " -ForegroundColor Yellow
    #Stop-VM -VM $VM -Kill -Confirm:$False
    #Shutdown-VMGuest -VM $VM -Confirm:$False
    Remove-VM -VM $VM -DeletePermanently -Confirm:$False
}

function New-ECICDDrive
{
    Write-Host "Creating CD Drive: " -ForegroundColor Yellow

    $ISOFolder = Get-ChildItem vmstore:\Boston\nfs_iso\Microsoft\Windows\
    $ISOFile = Get-ChildItem vmstore:\Boston\nfs_iso\Microsoft\Windows\SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_English_-3_MLF_X21-30350.ISO
    $ISOPath = Join-Path $ISOFolder.DatastoreFullPath[0] $ISOFile.Name
    $ISOPath = Join-Path (Split-Path $ISOFolder.DatastoreFullPath[0] -Parent) $ISOFile.Name
    (Split-Path $ISOFolder.DatastoreFullPath[0] -Parent)
    New-CDDrive -VM $VM -IsoPath $ISOPath -StartConnected -Confirm:$false
}


function Set-ECICDDrive
{
    Write-Host "Setting CDROM: " -ForegroundColor Yellow
    Get-CDDrive -VM $VM
    Set-CDDrive
}

&{

    BEGIN
    {
        Import-VMWareModules
        Connect-ECIVIServer
    }

    PROCESS 
    {
        #New-ECIVM
        #New-ECIScsiController
        #Remove-ECIHardDisk
        #New-ECIHardDisk
        #Set-ECIHardDisk
        #New-ECICDDrive
        #Start-ECIVM
        #Install-VMTools
        #Remove-ECIVM
    }

    END{}


}