﻿






exit
$SearchBase = "OU=Clients,DC=ecicloud,DC=com"
$OUs = Get-ADOrganizationalUnit -Filter * -SearchBase $SearchBase -SearchScope 2 | Where-Object {$_.Name -match "Disabled Users"}

foreach ($OU in $OUs)
{
    
    #write-host $OU.DistinguishedName
    #$(get-aduser -filter *).name
}


 Get-Mailbox -OrganizationalUnit $OU -ResultSize unlimited 

exit



$ou="OU=OU,DC=domain,DC=com"

$worksfolder="$env:userprofile\desktop\work"
if ( !(test-path "$worksfolder")) {
    Write-Verbose "Folder [$($worksfolder)] does not exist, creating"
    new-item $worksFolder -type directory -Force 
}

#define days days the period which users did not logged and you want to disable
$days=30

#you can change the path where users will be exported.
$exportedpath= "$worksfolder\inactiveusers.csv"

Import-Module activedirectory

get-aduser -filter 'enabled -eq $true' -SearchBase $ou -Properties samaccountname,lastlogondate | Where-object {$_.lastlogondate -lt (get-date).AddDays(-$days)} |select samaccountname,lastlogondate  | export-csv $exportedpath -nti

import-csv $exportedpath| Foreach-Object {Get-ADUser  $_.samaccountname  | Set-ADUser -Enabled $false -Verbose
}

$body="GC $exportedpath"
Send-MailMessage -to to@to.com -From from@from.com -SmtpServer mail.mail.com -Body $body -Subject "sunbject" 
