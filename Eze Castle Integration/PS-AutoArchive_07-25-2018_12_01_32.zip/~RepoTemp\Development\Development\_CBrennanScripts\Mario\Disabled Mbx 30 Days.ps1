﻿cls

### Function to Connect to Exchange Session
### ----------------------------------------------------------------
function Import-ExchangeSession
{
    ### Check for Existing Session
    $ExchangeSession = Get-PSSession | where { $_.ConfigurationName -eq "Microsoft.Exchange"  -and $_.State -eq 'Opened' }

    ### Create a new session If there is no existing Session
    if (-not $ExchangeSession) 
    {
        write-host "Creating New Session"    
        ### Create Session to Import Exchange Tools
        $ExchangeCAS = (HostName).split("-")[0] + "-htcas01.ecicloud.com"
        #$ExchangeCAS = (HostName).split("-")[0] + "-htcas02.ecilab.net"
        #$ExchangeCAS = (HostName).split("-")[0] + "-exch01.ecilab.net"
        $ExchangeSession = New-PSSession -Name ExchangeSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://$ExchangeCAS/PowerShell/ -Authentication Kerberos
        Import-PSSession $ExchangeSession -AllowClobber #-ea "silentlycontinue"  

    }
    else
    {
        ### If current session exist, use it
        write-host "Using Current Session: " $ExchangeSession 
    }
}
Import-ExchangeSession

### Get "Disabled Users" OU's for allclients
### ----------------------------------------------------------------
#$SearchBase = "OU=northwoodsecurities,OU=Clients,DC=ecicloud,DC=com"
$SearchBase = "OU=Clients,DC=ecicloud,DC=com"
$OUs = Get-ADOrganizationalUnit -Filter * -SearchBase $SearchBase  | Where-Object {$_.Name -match "Disabled Users"}
#$OUs = Get-ADOrganizationalUnit -Filter * -SearchBase $SearchBase -SearchScope OneLevel | Where-Object {$_.Name -match "Users"}
foreach ($OU in $OUs)
{
    write-host "Getting OU: $OU" -ForegroundColor Cyan
    $When = ((Get-Date).AddDays(-30)).Date
    ### Get AD Users where "Last Modified" is older than 30 days from today
    $Users = Get-ADUser -SearchBase $OU -Filter {Modified -le $When} -Properties *

    ### Create new array to add users without mailboxes
    $MAILBOXFOUND = @()

    foreach ($User in $Users)
    {
        #write-host "Getting AD Users: " -ForegroundColor Yellow
        $Mailbox = Get-Mailbox -Identity $User.name -ErrorAction silentlycontinue
        
        if($Mailbox)
        {
            $MAILBOXFOUND += $Mailbox
            write-host "MAILBOX FOUND! USER: $User  MBX: $Mailbox" -ForegroundColor Red
        }
        elseif(!$Mailbox)
        {
            write-host "MAILBOX NOT FOUND! USER: " $User.SamAccountName $User.Name $User.Modified -ForegroundColor Green
        }
    }
}

$MAILBOXFOUND | Select-Object Name,SamAccountName,UserPrincipalName | export-csv -Path C:\temp\test4.csv -NoTypeInformation

############################
### HTML Header
############################
$Header  = "<style>"
$Header += "BODY{font-family: Verdana, Arial, Helvetica, sans-serif;font-size:9;font-color: #000000;text-align:left;}"
$Header += "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$Header += "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color: #D2B48C}"
$Header += "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color: #FFEFD5}"
$Header += "</style>"
    
############################
### Format Report Data
############################
$ReportName = "DisabledUsers_w_ExchMbx_" + $(get-date -format "MM-dd-yyyy_hh_mm_ss")
$Report = $MAILBOXFOUND | ConvertTo-Html -Head $Header 

############################
### Email HTML Report
############################

### Email Parameters Hash Table
$EmailParams = @{
            From       = "cbrennan@eci.com"
            To         = "cbrennan@eci.com" 
            #CC         = "cbrennan@eci.com"
            SMTPServer = "qts-outlook.ecicloud.com"
            }

Send-MailMessage @EmailParams -Body ($Report | Out-String) -BodyAsHtml -Subject $ReportName
