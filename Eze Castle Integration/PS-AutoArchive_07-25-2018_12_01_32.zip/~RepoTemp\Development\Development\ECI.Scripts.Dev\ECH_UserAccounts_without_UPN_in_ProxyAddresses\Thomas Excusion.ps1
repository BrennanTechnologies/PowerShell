﻿$sqldatabase = "ECI_SB"
$sqlserver = "connectdb"
$sqlusername = "Cloud_integration"
$sqlpassword = "############"
$connectionstring = "Data Source=$sqlserver;User ID = $sqlusername; Password = $sqlpassword;Initial Catalog=$sqldatabase;"
 
 
$sqlquery2 = "SELECT * FROM [ECI_SB].[dbo].[Client_Office365]"
 
$SqlAdapter2 = New-Object System.Data.SqlClient.SqlDataAdapter ($sqlquery2, $connectionstring)
$table2 = new-object “System.Data.DataSet”
$SqlAdapter2.Fill($table2) | Out-Null
$Table2 = $Table2.tables | Select -Expand Rows 
 
    #convert to PSObject Array
    $ConvertToPSObjectsArray2 = @()
    for ($i=0; $i -lt $table2.Length; $i++)
    {
    $ClientObjects2 = New-Object psobject
    Add-Member -InputObject $ClientObjects2 -MemberType NoteProperty -Name Connectwise_id -Value $Table2[$i].Connectwise_id
    Add-Member -InputObject $ClientObjects2 -MemberType NoteProperty -Name office365_guid -Value $Table2[$i].office365_guid
    Add-Member -InputObject $ClientObjects2 -MemberType NoteProperty -Name office365_domain -Value $Table2[$i].office365_domain
    Add-Member -InputObject $ClientObjects2 -MemberType NoteProperty -Name InternalDomain -Value $Table2[$i].InternalDomain
    $ConvertToPSObjectsArray2 += $ClientObjects2
    }
 
$sqlquery3="SELECT Distinct VM_Recid, VMName, GPID, EMSGPID 
FROM [ECI_SB].[dbo].[CLOUD_VM]
Where VMName LIKE '%-dc%' AND VMName != VMNameShort AND EMSGPID != '' AND GPID LIKE 'EHC%' AND Date >= GETDATE()-5 AND Date <= GETDATE()
Order By VMName"
 
$SqlAdapter3 = New-Object System.Data.SqlClient.SqlDataAdapter ($sqlquery3, $connectionstring)
$SqlAdapter3.SelectCommand.CommandTimeout = 0
$table3 = new-object “System.Data.DataSet”
$SqlAdapter3.Fill($table3) | Out-Null
 
$Table3 = $Table3.tables | Select -Expand Rows | Sort EMSGPID -Unique
 
#convert to PSObject Array
$ConvertToPSObjectArray3 = @()
for ($i=0; $i -lt $table3.Length; $i++)
{
$VMNameSplit = $Table3[$i].VMName.split(".")
    if($VMNameSplit.count -gt 3)
    {
    $VMDomain = $VMNameSplit[1] + "." + $VMNameSplit[2] + "." + $VMNameSplit[3]
    }
    else
    {
    $VMDomain = $VMNameSplit[1] + "." + $VMNameSplit[2]
    }
$ClientObjects3 = New-Object psobject
Add-Member -InputObject $ClientObjects3 -MemberType NoteProperty -Name VM_Recid -Value $Table3[$i].VM_Recid
Add-Member -InputObject $ClientObjects3 -MemberType NoteProperty -Name VMName -Value $Table3[$i].VMName
Add-Member -InputObject $ClientObjects3 -MemberType NoteProperty -Name VMDomain -Value $VMDomain
Add-Member -InputObject $ClientObjects3 -MemberType NoteProperty -Name GPID -Value $Table3[$i].GPID
Add-Member -InputObject $ClientObjects3 -MemberType NoteProperty -Name EMSGPID -Value $Table3[$i].EMSGPID
$ConvertToPSObjectArray3 += $ClientObjects3
}
 
#Exclude client from checking their licenses
$ConvertToPSObjectsArray2 = $ConvertToPSObjectsArray2 | ?{$ConvertToPSObjectArray3.VMDomain -contains $_.InternalDomain}
