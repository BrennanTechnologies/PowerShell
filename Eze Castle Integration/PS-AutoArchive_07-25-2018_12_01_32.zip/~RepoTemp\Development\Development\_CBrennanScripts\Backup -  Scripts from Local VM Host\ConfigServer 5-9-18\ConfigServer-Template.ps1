﻿function Import-Modules 
{
    ### Set the Module Location
    if($env:USERDNSDOMAIN -eq "ECILAB.NET")   {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECICLOUD.COM") {$ModulePath = "\\tsclient\P\CBrennanScripts\Modules\"}
    if($env:USERDNSDOMAIN -eq "ECI.CORP")     {$ModulePath = "\\eci.corp\dfs\nyusers\cbrennan\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "W2K16V2")      {$ModulePath = "\\tsclient\Z\CBrennanScripts\Modules\"}
    if($env:COMPUTERNAME  -eq "BLU-SRVTEST01")      {$ModulePath = "C:\Scripts\Modules\"}

    $Modules = @()
    $Modules += "CommonFunctions"
    $Modules += "ConfigServer"

    foreach ($Module in $Modules)
    {
        ### Reload Module at RunTime
        if(Get-Module -Name $Module){Remove-Module -Name $Module}

        ### Import the Module
        $ModuleFilePath = $ModulePath + $Module + "\" + $Module + ".psm1"
        Import-Module -Name $ModuleFilePath -DisableNameChecking #-Verbose

        ### Test the Module - Exit Script on Failure
        if( (Get-Module -Name $Module)){Write-Host "Loaded Custom Module: $Module" -ForegroundColor Green}
        if(!(Get-Module -Name $Module)){Write-Host "The Custom Module $Module WAS NOT Loaded! `nFunctions Wont Work! `nExiting Script!" -ForegroundColor Red;exit}
    }
}

function Set-BuildParameters
{
    <#
    USAGE:

    ### Choose a Server Build Template
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:ServerTemplate     = "2016_DC"
    $global:ServerTemplate     = "2016_File"
    $global:ServerTemplate     = "2016_Citrix"
    $global:ServerTemplate     = "2012R2_Std_Base"
    $global:ServerTemplate     = "2012R2_DC"
    $global:ServerTemplate     = "2012R2_File"
    $global:ServerTemplate     = "2012R2_Citrix"
    #>

    ### Server Specific "Soft" Parameters
    ###------------------------------------------------
    $global:ServerTemplate     = "2016_Std_Base"
    $global:NewComputerName    = "BLU-SRVTEST01"
    $global:NewIPv4Address     = "10.61.1.111"
    $global:NewPrefixLength    = "24"
    $global:NewDefaultGateway  = "10.61.1.250"
    $global:NewPrimaryDNS      = "10.61.1.1"
    $global:NewSecondaryDNS    = "10.61.1.2"
    $global:NewDomain          = "ECILAB"

    ### Log Parameter Settings
    ###------------------------------------------------
    Write-Config "ServerTemplate: " $ServerTemplate
    Write-Config "NewComputerName: " $NewComputerName
    Write-Config "NewIPv4Address: " $NewIPv4Address
    Write-Config "NewPrefixLength: " $NewPrefixLength
    Write-Config "NewDefaultGateway: " $NewDefaultGateway
    Write-Config "NewPrimaryDNS: " $NewPrimaryDNS
    Write-Config "NewSecondaryDNS: " $NewSecondaryDNS
    Write-Config "NewDomain: " $NewDomain

}

function Get-TargetInfo
{
    ### Get Target VM Information
    ###------------------------------------------------
    $TargetName = (Get-CIMInstance CIM_ComputerSystem).Name
    $VMHost = ""
    $GuestOS = ""

    Write-Config "TargetName:" $TargetName
    Write-Config "VMHost: " $VMHost
    Write-Config "GuestOS: " $GuestOS


}

function Execute-Script 
{
    BEGIN 
    {
        # Initialize Script
        #--------------------------
        Clear-Host
        Write-Host "`nRunning: BEGIN Block" -ForegroundColor Blue
        Import-Modules 
        #Start-Transcribing 
        Start-LogFiles
    }

    PROCESS 
    {
        Write-Log "`nRunning: PROCESS Block" -ForegroundColor Blue
        # Run Functions
        #--------------------------
        Set-BuildParameters
        Get-TargetInfo
        Build-Server $ServerTemplate  # Requires $ServerTemplate is set in the "Set-BuildParameters" function above.

    }

    END 
    {
        # Close Script
        #--------------------------
        Write-Log "`nRunning: END Block"  -ForegroundColor Blue
        #Close-LogFile -Quiet
        Measure-Script
        #Stop-Transcribing
    }
}
Execute-Script