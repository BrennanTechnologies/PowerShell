﻿### Microsoft Compress-Archive:
### C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules\Microsoft.PowerShell.Archive\Microsoft.PowerShell.Archive.psm1:807 char:38

Start-Transcript

cls

& {

    ######################################
    ### Bootstrap Module Loader
    ######################################

    ### Set Execution Policy to ByPass
    Write-Host "Setting Execution Policy: ByPass"
    #Set-ExecutionPolicy Bypass

    ### Connect to the Repository & Import the ECI.ModuleLoader
    ### ----------------------------------------------------------------------
    $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials     = $Null
    $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath        = "\\eciscripts.file.core.windows.net\clientimplementation"
            
    ((Get-PSDrive | Where {((Get-PSDrive).DisplayRoot) -like "\\eciscripts"}) | Remove-PSDrive -Force ) | Out-Null

    #if(-NOT((Get-PSDrive -PSProvider FileSystem).Name) -eq "X")
    #{
        ####New-PSDrive -Name $RootDrive -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope global
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global -ErrorAction SilentlyContinue
    #}

    #$PSDrive = New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

    ### Import the Module Loader - Dot Source
    ### ----------------------------------------------------------------------
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
}

### Variables
$TimeStamp  = Get-Date -format "MM-dd-yyyy_hh_mm_ss"
$TempFolder = "\\eciscripts.file.core.windows.net\clientimplementation\_Repository\ArchiveFiles\~RepoTemp\"
$ZipFile = "\\eciscripts.file.core.windows.net\clientimplementation\_Repository\ArchiveFiles\PS-AutoArchive\PS-AutoArchive_$TimeStamp.zip"
$DFSVolume = "\\ecicloud.com\dfs\kits\ECI.Repository"

### Folders to Archive
$Folders = @()
$Folders += "\\eciscripts.file.core.windows.net\clientimplementation\Root"
$Folders += "\\eciscripts.file.core.windows.net\clientimplementation\Development"
$Folders += "\\eciscripts.file.core.windows.net\clientimplementation\Production"

foreach ($Folder in $Folders)
{
    ### Copy each Folder to Temp
    $TempFiles = $TempFolder + $Folder.Split("\")[-1]
    Write-Host "Copying... Folder: $Folder  Temp-Dest: $TempFiles" -ForegroundColor Yellow
    Copy-Item -Path $Folder -Destination $TempFiles -Recurse -Container -Force 
}

Write-Host "Creating Zip File: $ZipFile" -ForegroundColor Cyan
Compress-Archive -Path $TempFolder -DestinationPath $ZipFile 

Write-Host "Copying... Zip File: $ZipFile  DFS-Dest: $DFSVolume" -ForegroundColor Yellow
Copy-Item -Path $ZipFile -Destination $DFSVolume -Force

### Email Report Files
$SMTP = "qts-outlook.ecicloud.com"
#$SMTP = "alertmx.eci.com"
Write-Host "Sending Email" -ForegroundColor Gray
Copy-Item -Path $ZipFile -Destination C:\Scripts\ECI.Repository -Force
$Attachment = "C:\Scripts\ECI.Repository\" + (Split-Path $ZipFile -leaf)
Rename-Item -Path $Attachment -NewName ($Attachment +".zi_")

Send-MailMessage -SmtpServer $SMTP -From cbrennan@eci.com -To cbrennan@eci.com -Subject PSArchives -Body "PowerShell Archive Files" -Attachments $Attachment

$t = 360
Write-Host "Starting Sleep for $t seconds" -ForegroundColor Green
Start-Sleep -s $t
Stop-Transcript