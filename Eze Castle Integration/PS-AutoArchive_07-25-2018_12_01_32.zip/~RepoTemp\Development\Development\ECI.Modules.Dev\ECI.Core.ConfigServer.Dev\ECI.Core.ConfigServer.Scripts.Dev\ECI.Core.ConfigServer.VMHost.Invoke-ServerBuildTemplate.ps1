﻿#######################################
### Function: Import VMWare Modules
#######################################
function Set-TranscriptPath
{
    $global:TranscriptPath = "C:\Scripts\VMAutomation\Transcripts"
    if(-NOT(Test-Path -Path $TranscriptPath)) {(New-Item -ItemType directory -Path $TranscriptPath | Out-Null);Write-Host "Creating TranscriptPath: " $TranscriptPath }
    Return $TranscriptPath
}

#######################################
### Function: Import VMWare Modules
#######################################
function Import-VMWareModules
{
    $VMModules = "VMware.VimAutomation.C*"
    if((Get-Module -ListAvailable $VMModules) -ne $Null)
    {
        Write-Host "Importing VNWare Modules: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Gray
        Get-Module -ListAvailable $VMModules | Import-Module
    }
    else
    {
         Write-Host "Modules not available: " (Get-Module -ListAvailable $VMModules) -ForegroundColor Red
    }
    <#
        PS C:\Users\cbrennan_admin> Get-Module vm*

        ModuleType Version    Name                                ExportedCommands                                                                                                                   
        ---------- -------    ----                                ----------------                                                                                                                   
        Script     10.0.0.... VMware.VimAutomation.Cis.Core       {Connect-CisServer, Disconnect-CisServer, Get-CisService}                                                                          
        Script     10.0.0.... VMware.VimAutomation.Common                                                                                                                                            
        Script     10.0.0.... VMware.VimAutomation.Core           {Add-PassthroughDevice, Add-VirtualSwitchPhysicalNetworkAdapter, Add-VMHost, Add-VMHostNtpServer...}                               
        Script     10.0.0.... VMware.VimAutomation.Sdk            {Get-InstallPath, Get-PSVersion}  
    #>
}

#######################################
### Function: Connect to ECI VI Server
#######################################
function Connect-ECIVIServer
{

    ### Check if Running Elevated Privledges
    #IS-Admin
    <#
    if($IsAdmin)
    {
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore 
    }
    if(!$IsAdmin)
    {
    }
    #>

    Write-Host "Setting PowerCLIConfiguration: -InvalidCertificateAction Ignore" -ForegroundColor Gray
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false <#-ParticipateInCEIP:$false#> | Out-Null

    <#
        Connecting New Session to VI Server:  ecilab-bosvcsa01.ecilab.corp
        WARNING: There were one or more problems with the server certificate for the server ecilab-bosvcsa01.ecilab.corp:443:

        * The X509 chain could not be built up to the root certificate.

        Certificate: [Subject]
          C=US, CN=ecilab-bosvcsa01.ecilab.corp

        [Issuer]
          O=ecilab-bosvcsa01.ecilab.corp, C=US, DC=local, DC=vsphere, CN=CA

        [Serial Number]
          00E95976D6B9344236

        [Not Before]
          6/22/2015 3:34:28 PM

        [Not After]
          6/16/2025 3:34:27 PM

        [Thumbprint]
          38A7F51B30A4CFAC6A136D0585D77322106CC69E

        The server certificate is not valid.
    
        WARNING: THE DEFAULT BEHAVIOR UPON INVALID SERVER CERTIFICATE WILL CHANGE IN A FUTURE RELEASE. To ensure scripts are not affected by the change, use Set-PowerCLIConfigura
        tion to set a value for the InvalidCertificateAction option.
    #>

    if($global:DefaultVIServers.Count -gt 0)
        {
    Write-Host "Using Current VI Server Session: " $global:DefaultVIServers -ForegroundColor Gray
    }
    else 
                    {
    $VIServer = "ecilab-bosvcsa01.ecilab.corp"
    Write-Host "Connecting New Session to VI Server: "  $VIServer -ForegroundColor Gray
    $HostCreds = # -User cbrennan_admin@ecilab.corp -Password W3lcome123!
    $VISession = Connect-VIServer -Server  $VIServer  -User ezebos\cbrennan -Password Tolkien43741
    }

    #Disconnect-VIServer -Server "ecilab-bosvcsa01.ecilab.corp"
}

####################################### 
### Function: Import Parameters from API
#######################################
function Import-ParametersFromAPI
{
    ### Import Parameters from the API
    ### ---------------------------------------------
    #$ParameterFile = "C:\Scripts\VMAutomation\Parameters.csv"
    $ParameterFile = "\\tsclient\X\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\Bin\Parameters.csv"

    try
    {
        $Parameters = Import-CSV -path $ParameterFile
    }
    catch
    {
        Write-Host "ABORT ERROR:`n$Error[0] `nExiting Script!" -ForegroundColor Red
        $Abort = $True
        #Send-Alert
        Exit
    }
    
    $SoftParameters = @()
    foreach ($Parameter in  $Parameters)
    {
        # Create Variables and Set Variable Scope to "Global"
        Set-Variable -Name $Parameter.Name -Value $Parameter.Value -Scope global
        $SoftParameters += Get-Variable -Name $Parameter.Name
    }  
    ### Write Variables to Console
    Write-Host "`nImporting *SOFT* Parameters from API:`n" ("-" * 50) -ForegroundColor White
    $SoftParameters | ft
}

#######################################
### Function: Measure Script Runtime
#######################################
function Measure-Script
{
    Param(
    [Parameter(Mandatory = $True,  Position = 0)] [string]$Clock
    )

    if($Clock -eq "Start")
    {
        ### Get Start Time for Measure-Script function
        $script:StartTime = Get-Date
    }
    if($Clock -eq "Stop")
    {
        ### Calculates Script Execution Time
        $StopTime = Get-Date
        $ElapsedTime = ($StopTime-$StartTime)
        Write-host `n`n
        write-Host "Script Ended At: $StopTime" -ForegroundColor Gray
        Write-Host "Execution Time : $ElapsedTime"-ForegroundColor Gray
    }
}

#######################################
### Function: Get Cookie from VM Guest
#######################################
function Get-Cookie
{
    ### Import Cookie Parameters
    ### ---------------------------------------------
    #$CookiePath = "\\eciscripts.file.core.windows.net\clientimplementation\_VMAutomation\VMBuilds\" + $VM + "\Cookie.$VM.txt"
    $CookiePath = "X:\_VMAutomation\VMBuilds\" + $VM + "\Cookie.$VM.txt"
    try
    {
        $Cookies = Get-Content -Path $CookiePath 
        $CookieCounter = 0
        $VerifyFailures = @()

        foreach ($Cookie in $Cookies)
        {
            $CookieCounter++
            $CookieVaribles = @()
            ### Split Each Line in the Cookie into Parameters
            $CookieParameters = $Cookie.Split(",")
            foreach ($CookieParameter in $CookieParameters)
            {
                ### Split Each Parameter into Key/Value Pairs
                $CookieKey = "Cookie_" + $CookieParameter.Split("=")[0]
                $CookieValue = $CookieParameter.Split("=")[1]
                ### Set the Variables
                Set-Variable -Name $CookieKey -Value $CookieValue -Scope Global
                $CookieVaribles += Get-Variable -Name $CookieKey
            }
            ### Write Variables to Console
            $CookieVaribles | ft
            
            Write-Host "CookieCounter: " $CookieCounter
            Write-Host "Cookie_Verified: " $Cookie_Verified -ForegroundColor Magenta
            if ($Cookie_Verified -ne "True")
            {
                $VerifyFailures += $Cookie_Function
                Write-Host "Verified Function: " $Cookie_Function -ForegroundColor Magenta
            }
         }

         ####################################################
         ### VERIFY FAILURES:
         ####################################################
         if($VerifyFailures.Count -ne "0")
         {
            Write-Host "VerifyFailures: " $VerifyFailures.Count -ForegroundColor Red  
            #Send-Alert
         }
         elseif ($VerifyFailures.Count -eq "0")
         {
            Write-Host "VerifyFailures: " $VerifyFailures.Count -ForegroundColor Green  
         }

         <#
         ####################################################
         ### SET/VERIFY RETRY:
         ####################################################
         $RetryCount = 0
         foreach ($VerifyFailure in $VerifyFailures)
         {
            DO
            {
                $RetryCount++
                Invoke-VMScript -VM $VM -ScriptText $VerifyFailures -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose
            }
            WHILE ($RetryCount -lt 2)
         }
         #>

    }
    catch
    {
        Write-Host "ABORT ERROR:`n$Error[0] `nExiting Script!" -ForegroundColor Red
        $Abort = $True
        #Send-Alert
        Exit
    }
}

#######################################
### Function: Configure VM Guest IPv4
#######################################
function Configure-VMGuestIPv4
{
    Write-Host "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50) -ForegroundColor Magenta
    
    $ScriptText =
    { 
        Write-Host "`nConfiguring IPV4 on VM Guest" -foregroundcolor Magenta
        
        ### Pass in Paramters from API/VMHost
        ### ----------------------------------------------------------------------
        $global:IPv4Address          = "#IPv4Addres#"
        $global:SubnetPrefixLength   = "#SubnetPrefixLength#"
        $global:DefaultGateway       = "#DefaultGateway#"
        $global:DNS1                 = "#DNS1#"
        $global:DNS2                 = "#DNS2#"

        Write-Host "`nParameters Imported From API:`n"('-' * 50)
        Write-Host "IPv4Address         : " $IPv4Address
        Write-Host "SubnetPrefixLength  : " $SubnetPrefixLength
        Write-Host "DefaultGateway      : " $DefaultGateway
        Write-Host "DNS1                : " $DNS1
        Write-Host "DNS2                : " $DNS2
        Write-Host ('-' * 50)
                
        ### Cast the Parameters as IPAddress
        [IPAddress]$IPv4Address     = $IPv4Address.Trim()
        [IPAddress]$DefaultGateway  = $DefaultGateway.Trim()

        ### Get the Current NIC
        $CurrentInterface  = (Get-NetAdapter –Physical | where Status -eq 'Up').Name

        ### Determine if DHCP is Enabled or if IPv4 Address is Static
        $DhcpStatus = (Get-NetIPInterface -AddressFamily IPv4 -InterfaceAlias $CurrentInterface).DHCP

        ### If DHCP is Enabled, Create New IPv4 Address, Else Set IPv4 Address
        if ($DhcpStatus -eq "Enabled")
        {
            ### Set the IPv4 Settings
            #Write-Host "`nSetting New IP Address and Default Gateway on VM Guest" -foregroundcolor Magenta
            try
            {
                New-NetIPAddress $IPv4Address –InterfaceAlias $CurrentInterface -AddressFamily IPV4 –PrefixLength $SubnetPrefixLength -DefaultGateway $DefaultGateway | Out-Null
                Set-DnsClientServerAddress $CurrentInterface -ServerAddresses ($DNS1,$DNS2)
            }
            catch
            {
                Write-Host "ERROR: " $Error[0]
                $Abort = $True
            }
        }
        elseif ($DhcpStatus -eq "Disabled")
        {
            Write-Host "`nIPv4 is Currently Configured"
            #Set-NetIPAddress
        }
    }

    ### Replace Variables with #LiteralValues#
    ### ---------------------------------------
    $Params = @{
    "#IPv4Addres#"          = $IPv4Address
    "#SubnetPrefixLength#"  = $SubnetPrefixLength
    "#DefaultGateway#"      = $DefaultGateway
    "#DNS1#"                = $DNS1
    "#DNS2#"                = $DNS2
    }

    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
    }

    ### Debugging: Write ScriptText Block to Screen
    ### ---------------------------------------
    #Write-Host "ScriptText:`n" $ScriptText -ForegroundColor Gray

    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VM" -ForegroundColor Yellow
    $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose <#-Debug#> #| Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

    if($Invoke.ExitCode -ne 0)
    {
        $Abort = $True
        Write-Host "ABORT ERROR: Aborting Script Execution" -ForegroundColor Red
        #Send-Alert
        Exit
    }
}

#######################################
### Function: Verify IPv4 on VM Guest
#######################################
function Verify-VMGuestIPv4
{
    ### Test connectivity before proceeding
    Write-Host "Verifying IPv4 Connectivity on VM Guest" -ForegroundColor Magenta
}

#######################################
### Function: Verify VM Guest
#######################################
function Verify-VMGuestConnectivity
{
    Write-Host "Verifying VMHost Connectivity to VM Guest" -ForegroundColor Magenta
    $VMTools = Wait-Tools -VM $VM -TimeoutSeconds 30 -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null
    Write-Host "VMTools:" $VMTools
    $VMGuest = Get-VMGuest -VM $VM
    Write-Host "VMGuest: " $VMGuest
}

#######################################
### Import Bootstap Module
#######################################
[ScriptBlock]$BootStrapModuleLoader = 
{
    ### BEGIN: Import BootStrap Module Loader
    Set-ExecutionPolicy ByPass -Scope CurrentUser
    $AcctKey=ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
    $Credentials=$Null
    $Credentials=New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
    $RootPath="\\eciscripts.file.core.windows.net\clientimplementation"
    ((Get-PSDrive|Where {((Get-PSDrive).DisplayRoot) -like "\\eci*"})|Remove-PSDrive -Force )|Out-Null
    $PSDrive=$Null
    $PSDrive=New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global
    Write-Host `n
    . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1" -Env dev
    ### END: Import BootStrap Module Loader
} 

#######################################
### Import Bootstap Module
#######################################
function Verify-VMGuestRepositoryConnectivity
{
    Write-Host "Verifying Repository Connectivity on VM Guest" -ForegroundColor Magenta
}

#######################################
### Function: Invoke Module Loader on Guest
#######################################
function Invoke-ModuleLoaderOnGuest
{
    #Write-Host "Executing Function: " $((Get-PSCallStack)[0].Command) `n('-' * 50) -ForegroundColor Magenta
    
    $ScriptText =
    {
        &{
        
        #########################################
        ### Attach to Repository
        #########################################   
        ### Set VM Execution Policy to ByPass
        Write-Host "Setting Execution Policy: ByPass"
        Set-ExecutionPolicy Bypass

        ### Connect a Non-Persistent Drive - then Import the ECI.ModuleLoader
        ### ----------------------------------------------------------------------
        $AcctKey         = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
        $Credentials     = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey
        $RootPath = "\\eciscripts.file.core.windows.net\clientimplementation\"
        New-PSDrive -Name X -PSProvider FileSystem -Root $RootPath -Credential $Credentials -Persist -Scope Global

        #########################################
        ### Copy BootStrap Module Loader
        #########################################        
        $Path = "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\Invoke-ECI.Root.ModuleLoader.ps1"
        $Destination = "C:\Scripts\VMAutomation"
        if(-NOT(Test-Path -Path $Destination)) {New-Item -ItemType directory -Path $Destination | Out-Null}
        Copy-Item -Path $Path -Destination $Destination -Force

        }

    }        
    Write-Host "INVOKING: $((Get-PSCallStack)[0].Command) on $VM" -ForegroundColor Yellow
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose <#-Debug#> | Select -ExpandProperty ScriptOutput #ExitCode #ScriptOutput 

}

#######################################
### Function: Reboot-Resume Guest OS
#######################################
function Reboot-Resume
{
    ###################################
    ### Reboot Guest OS
    ###################################
    Write-Host "Rebooting Server: $VM" -ForegroundColor Yellow
    Restart-VMGuest -VM $VM -Server $VIServer | Wait-Tools | Out-Null

    ###################################
    ### Resume Guest OS After Restart
    ###################################
    Write-Host "Waiting for Server to Resume: $VM" -ForegroundColor Yellow

    ### Pause Script
    ### ---------------------------
    ### Pause to let the Reboot command Start, otherwise the Wait-Tools will respond immediately
    $t = 15 ### Timer for Dev
    #$t = 60 ### Timer for Prod
    Write-Host "Sleeping Script for $t secs ..." -ForegroundColor Gray
    Start-Sleep -Seconds $t

    ### Wait for VM Tools
    ### ---------------------------
    $t = 60 ### Timer for Dev
    #$t = 240 ### Timer for Prod
    Write-Host "Waiting for VMTools to Respond for $t secs ..." -ForegroundColor Gray
    Wait-Tools -VM $VM -TimeoutSeconds $t -HostUser cbrennan_admin@ecilab.corp -HostPassword W3lcome123! | Out-Null

    ### Resume Script
    ### ---------------------------
    Write-Host "Resuming after Restart: $VM" -ForegroundColor Yellow
    
    ### Test VMGuest Connectivity
    ### ---------------------------
    Write-Host "Verifying Invoke Connectivity to VM Guest OS:" -ForegroundColor Magenta
    $ScriptText = 
    {
        Write-Host "Computer Name: " (Get-CimInstance -ClassName Win32_LogicalDisk)
    }
    
    $Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose | Select -ExpandProperty ScriptOutput
    
    
    #Test-Connection -Cn $VM.Name -BufferSize 16 -Count 1 -ea 0 -quiet

    #Do {$Service = "LanmanServer";$Service = Get-Service -computername $VM -Name $Service}
    #While ($Service.Status -ne 'Running')

    #$global:VM = Get-VM $VM
    #Write-Host "Testing Connectivity to VM Guest OS:" -ForegroundColor Magenta
    #Write-Host "`tVM.Name   : " $VM.Name -ForegroundColor Magenta
    #Write-Host "`tVM.VMHost : " $VM.VMHost -ForegroundColor Magenta
    #Write-Host "`tVM.Guest  : " $VM.Guest -ForegroundColor Magenta

}

#######################################
### Function: Execute Invoke Process
#######################################
function Invoke-ScriptText
{
    ### Replace Parameters with #LiteralValues#
    ### ---------------------------------------
    $Params = @{
    "#Step#"                = $Step
    "#VM#"                  = $VM
    "#ServerBuildType#"     = $ServerBuildType
    "#GuestComputerName#"   = $GuestComputerName
    "#DomainName#"          = $DomainName
    "#IPv4Addres#"          = $IPv4Address
    "#SubnetPrefixLength#"  = $SubnetPrefixLength
    "#DefaultGateway#"      = $DefaultGateway
    "#DNS1#"                = $DNS1
    "#DNS2#"                = $DNS2
    }

    ### Inject Variables into ScriptText Block
    ### ---------------------------------------
    foreach ($Param in $Params.GetEnumerator())
    {
        $ScriptText =  $ScriptText -replace $Param.Key,$Param.Value
    }

    ### Inject BootStrap Module Loader into VM Host
    ### ---------------------------------------
    $ScriptText =  $ScriptText -replace '#BootStrapModuleLoader#',$BootStrapModuleLoader

    ### Debugging: Write ScriptText Block to Screen
    ### ---------------------------------------
    #Write-Host "ScriptText:`n" $ScriptText -ForegroundColor Gray

    ###############################
    ### Inovke VMScript
    ###############################
        ###---------------------------------------------------------
        ### Invoke-VMScript
        ### -Verbose 
        ### -Debug
        ### | Select -ExpandProperty ScriptOutput
        ### | Select -ExpandProperty ExitCode
        ###---------------------------------------------------------

    Write-Host "Executing Invoke-VMScript Function: $((Get-PSCallStack)[0].Command) Step: $Step" -ForegroundColor Magenta
    
    ### Development: Run Invoke without Variable
    ### -------------------------------------------
    Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose #| Select -ExpandProperty ScriptOutput #ExitCode
    
    ### Procuction: Run Invoke as Variable
    ### -------------------------------------------
    #$Invoke = Invoke-VMScript -VM $VM -ScriptText $ScriptText -ScriptType Powershell -GuestUser administrator -GuestPassword cH3r0k33 -Verbose
    
    if($Invoke)
    {
        ### Check Exit Code for any Errors
        ### ---------------------------------------
        Write-Host $Invoke.ScriptOutput

        if (($Invoke.ExitCode) -eq 0) {
            Write-Host "Invoke-VMScript Commands Executed Successfully " -ForegroundColor Green
        }
        elseif (($Invoke.ExitCode) -ne 0) {
            Write-Host "Error in Invoke-VMScript Commands! " -ForegroundColor Red
        }
    }
}

##############################################################################
### Function: Invoke VM Script
##############################################################################
function Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host "BEGIN INVOKE Function: " $((Get-PSCallStack)[0].Command) "-Step:" $Step `n('-' * 50) -ForegroundColor Yellow

    [ScriptBlock]$ScriptText = 
    {
        
    ### Import BootStrap Module Loader
    ### -------------------------------
    #BootStrapModuleLoader#
        
    ### Import *SOFT* Paramters from API
    ### -------------------------------
    $global:Step                    = "#Step#"    
    $global:VM                      = "#VM#"    
    $global:ServerBuildType         = "#ServerBuildType#"  
    $global:GuestComputerName       = "#GuestComputerName#"
    $global:DomainName              = "#DomainName#"
    $global:IPv4Address             = "#IPv4Addres#"
    $global:SubnetPrefixLength      = "#SubnetPrefixLength#"
    $global:DefaultGateway          = "#DefaultGateway#"
    $global:DNS1                    = "#DNS1#"
    $global:DNS2                    = "#DNS2#"


    Write-Host "`,Imported *SOFT* Parameters Passed from API:" `n("-" * 50)
    Write-Host "Step                : " $Step
    Write-Host "VM                  : " $VM
    Write-Host "ServerBuildType     : " $ServerBuildType
    Write-Host "GuestComputerName   : " $GuestComputerName
    Write-Host "DomainName          : " $DomainName
    Write-Host "IPv4Address         : " $IPv4Address
    Write-Host "SubnetPrefixLength  : " $SubnetPrefixLength
    Write-Host "DefaultGateway      : " $DefaultGateway
    Write-Host "DNS1                : " $DNS1
    Write-Host "DNS2                : " $DNS2
    Write-Host ("-" * 50)
    Write-Host `n('-' * 100)
    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    . "Y:\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate.ps1"
    } # END ScriptText

    $ScriptTextLength = ($ScriptText | Measure-Object -Character).Characters
    if($ScriptTextLength -le 1505)
    {
        Write-Host "ScriptTextLength: $ScriptTextLength" -ForegroundColor Gray
    }    
    if($ScriptTextLength -gt 1505)
    {
        Write-Host "ScriptTextLength Is Too Long: $ScriptTextLength" -ForegroundColor DarkMagenta
    }
    ### Execute ServerBuildTemplate.ps1
    ### ----------------------------------
    ### Invoke-MVScript Breaks if -GT 1505
    #Invoke-Expression "dir"      
   
    ##### Testing 6-17-18 3:34
        ### Invoke VMGuest.ServerBuildTemplate.ps1
        ### ----------------------------------   
        #. "Y:\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate.ps1"    
 
    Invoke-ScriptText
}

function Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate-ORIGINAL
{
    Param([Parameter(Mandatory = $True)] [string]$Step)
    Write-Host "BEGIN FUNCTION: " $((Get-PSCallStack)[0].Command) "-Step:" $Step `n('-' * 50) -ForegroundColor Yellow

    $ScriptText = {
        
        ### BEGIN: Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step: #Step#
        ### -------------------------------------------------------------------------------

        ######################################
        ### Import BootStrap Module Loader
        ######################################
        #BootStrapModuleLoader#

        ### TESTING: Import Module Loader Locally
        ###-----------------------------------
        # . "\\eciscripts.file.core.windows.net\clientimplementation\Root\ECI.Root.ModuleLoader.ps1"
        # . "C:\Scripts\VMAutomation\Invoke-ECI.Root.ModuleLoader.ps1"

        ######################################
        ### ImportParameters from API
        ######################################        
        
        ### Import Paramters from API
        ### -------------------------------------------------------------------------------
        $global:Step               = "#Step#"    
        $global:VM                 = "#VM#"    
        $global:ServerBuildType    = "#ServerBuildType#"  
        $global:GuestComputerName  = "#GuestComputerName#"
        $global:DomainName         = "#DomainName#"
        $global:IPv4Address        = "#IPv4Addres#"
        $global:SubnetPrefixLengt  = "#SubnetPrefixLength#"
        $global:DefaultGateway     = "#DefaultGateway#"
        $global:DNS1               = "#DNS1#"
        $global:DNS2               = "#DNS2#"

        Write-Host "`n*SOFT* Parameters Imported From API:`n"('-' * 50)
        Write-Host "Step              : " $Step
        Write-Host "VM                : " $VM
        Write-Host "ServerBuildType   : " $ServerBuildType
        Write-Host "GuestComputerName : " $GuestComputerName
        Write-Host "DomainName        : " $DomainName
        Write-Host "IPv4Address       : " $IPv4Address
        Write-Host "SubnetPrefixLength: " $SubnetPrefixLength
        Write-Host "DefaultGateway    : " $DefaultGateway
        Write-Host "DNS1              : " $DNS1
        Write-Host "DNS2              : " $DNS2
        Write-Host ('-' * 50)
        ### -------------------------------------------------------------------------------

        
        ##############################################################################
        ### Execute ECI.Core.ConfigServer.ServerBuildTemplate.ps1
        ##############################################################################

        ### Testing - Windowed
        ### ----------------------------------
        #powershell.exe -NoProfile -NonInteractive -NoExit -file "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.ServerBuildTemplate.ps1"
        #powershell.exe -WindowStyle Normal "& ""\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.ServerBuildTemplate.ps1"""

        ### Execute PS Commands
        ### ----------------------------------
        #powershell.exe -Command "& {Get-EventLog -LogName security}"
       
        ### Execute ServerBuildTemplate.ps1
        ### ----------------------------------
        #. "\\eciscripts.file.core.windows.net\clientimplementation\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate.ps1"
    }

    ##################################
    ### Execute Invoke Function
    ##################################
    Invoke-ScriptText
}

##############################################################################
### Execute the Script
##############################################################################
&{ 

    BEGIN
    {
        Clear-Host
        Measure-Script Start
        Start-Transcript -IncludeInvocationHeader -OutputDirectory (Set-TranscriptPath) #-Path
        Write-Host "SCRIPT BEGIN BLOCK: " (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue" #<-- Hide VMWare Module Progress Bar
        Import-VMWareModules
        Connect-ECIVIServer
        Import-ParametersFromAPI
        Configure-VMGuestIPv4
        Verify-VMGuestConnectivity
        #Invoke-ModuleLoaderOnGuest #<-- Use ModuleLoader Scriptblock instead
    }

    PROCESS
    {
        Write-Host "SCRIPT PROCESS BLOCK: " (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 1 # Base Configuration Functions - No Reboot Needed
        Get-Cookie


        <#
        if($Cookie_Verified -eq "True")
        {
            Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step $Cookie_Step
        }
        #>

        <#
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 2 # Configure-WindowsFeatures
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 3 # Resume-Configure-WindowsFeatures
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 4 # Rename-LocalAdministrator
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 5 # Resume-Rename-LocalAdministrator
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 6 # Rename-GuestComputer
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 7 # Resume-Rename-GuestComputer
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 8 # Join-Domain
        Reboot-Resume
        Invoke-ECI.Core.ConfigServer.VMGuest.ServerBuildTemplate -Step 9 # Resume-Join-Domain
        #>
    }

    END
    {
        Write-Host "SCRIPT END BLOCK:" (Split-Path ($((Get-PSCallStack)[0].ScriptName)) -Leaf) `n('- -' * 25) -ForegroundColor Yellow
        Measure-Script Stop
        Stop-Transcript
        #Disconnect-VIServer -Server $VIServer  #"ecilab-bosvcsa01.ecilab.corp"
    }

}


###################
###Delete
###################
#######################################
### Test: Script Variables
#######################################
<#
    ### Dev Server
    #$DevHost = "ECILAB-BOSAPP1.ecilab.corp"

    ### VI Servere
    #$VIServer = "ecilab-bosvcsa01.ecilab.corp"
    #$VICreds  = "" # -User cbrennan_admin@ecilab.corp -Password W3lcome123!

    ### Host VM
    #$HOSTVM = ""
    #$HostCreds = # -HostUser ezebos\cbrennan -HostPassword Tolkien4374
     
    ### Guest VM
    #$global:VM = "RGEE-SRV1" # <-- Param from API???
    #$GuestCreds = "" # -GuestUser administrator -GuestPassword cH3r0k33
#>
