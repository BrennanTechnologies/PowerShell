﻿
cls


$DatabaseName = "X:\Development\ECI.Modules.Dev\ECI.Core.ConfigServer.Dev\ECI.Core.ConfigServer.Scripts.Dev\Bin\ServerConfig.accdb"
$Query = "SELECT * FROM ServerTemplates"
$ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source=$DatabaseName"
$Connection = New-Object System.Data.OleDb.OleDbConnection $ConnectionString
$Command  = New-Object System.Data.OleDb.OleDbCommand $Query, $Connection
$Connection.Open()
$Adapter = New-Object System.Data.OleDb.OleDbDataAdapter $Command
$Dataset = New-Object System.Data.DataSet
[void] $Adapter.Fill($DataSet)
$Connection.Close()
$x = Dataset.Tables

$x

<#
foreach ($u in $x) {
    New-ADUser -Name $u.name ...
}
#>