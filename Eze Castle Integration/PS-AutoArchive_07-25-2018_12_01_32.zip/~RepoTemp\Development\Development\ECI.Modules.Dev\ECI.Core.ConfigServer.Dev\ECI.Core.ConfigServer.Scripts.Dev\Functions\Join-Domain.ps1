﻿function Join-Domain
{
    $script:Function = $((Get-PSCallStack)[0].Command);Write-Config `n('-' * 50)`n "Executing Function: " $Function `n('-' * 50)

    ##########################################
    ### DESIRED STATE PARAMETERS
    ##########################################
    $DesiredState      = $DomainName
    $ConfigurationMode = "Configure" ### Report - Configure
    $AbortTrigger      = $False  ### $True - $False

    ##########################################
    ### GET CURRENT CONFIGURATION STATE: 
    ##########################################
    [scriptblock]$script:GetCurrentState =
    {
        $script:CurrentState = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
    }

    ##########################################
    ### SET DESIRED-STATE:
    ##########################################
    [scriptblock]$script:SetDesiredState =
    {
        ### Import Credentials
        ### ----------------------------------------
        #$PSCrdentials = (Import-AESEncryptionKey)
        #Import-AESEncryptionKey

        $UserName = "GEEMONEYMGMT\ECIADMIN"
        $SecPasswd = ConvertTo-SecureString "g3n3r0s!ty" -AsPlainText -Force
        $PSCredentials =  New-Object System.Management.Automation.PSCredential ($UserName, $SecPasswd)

        Add-Computer -ComputerName $VM -DomainName $DomainName -Credential $PSCredentials -Force -Passthru -Verbose
    }

    Configure-DesiredState -GetCurrentState $GetCurrentState -SetDesiredState $SetDesiredState -ConfigurationMode $ConfigurationMode -AbortTrigger $AbortTrigger
}
