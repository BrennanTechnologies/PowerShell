﻿function Set-PSCredentials
{
    #$UserName = "cbrennan@eciadmin.onmicrosoft.com"
    $UserName = "Administrator"

    $ScriptPath  = split-path $MyInvocation.PSCommandPath -Parent
    
    $PasswordFile = $ScriptPath + "\Password.txt"
    write-host "Password File: $PasswordFile" -ForegroundColor Cyan

    if(-not (Test-Path $PasswordFile))
    {
        Read-Host "Enter Password for Azure To Bed Encrypted" -AsSecureString |  ConvertFrom-SecureString | Out-File $PasswordFile
        write-host "Created Encrypted Password File: " $PasswordFile -ForegroundColor Green
    }
    elseif(Test-Path $PasswordFile)
    {
        write-host "Using Existing Password File: " $PasswordFile -ForegroundColor Green
    }

    $PSCredentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName, (Get-Content $PasswordFile | ConvertTo-SecureString)
    #PSCredentials

}

Set-PSCredentials
PSCredentials
#Connect-MsolService -Credential $PSCredentials