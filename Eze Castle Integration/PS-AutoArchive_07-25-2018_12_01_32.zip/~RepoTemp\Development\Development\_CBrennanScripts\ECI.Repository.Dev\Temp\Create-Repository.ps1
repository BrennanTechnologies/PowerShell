﻿ # https://bentaylor.work/2016/08/private-powershell-repository-using-an-azure-file-share/
 # https://kevinmarquette.github.io/2017-05-30-Powershell-your-first-PSScript-repository/
       
$RepositoryPath = "\\eciscripts.file.core.windows.net\clientimplementation"

$AcctKey     = ConvertTo-SecureString -String "VSRMGJZNI4vn0nf47J4bqVd5peNiYQ/8+ozlgzbuA1FUnn9hAoGRM9Ib4HrkxOyRJkd4PHE8j36+pfnCUw3o8Q==" -AsPlainText -Force
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList "Azure\eciscripts", $AcctKey

### Add the ECI Script Repository to the PS Module Path
if(-NOT($env:PSModulePath.Contains($RepositoryPath))) {$env:PSModulePath = $RepositoryPath + "\Eze.Modules\;" + $env:PSModulePath}
Write-Host "PSModulePath: $env:PSModulePath"



#Get-PSRepository
#Unregister-PSRepository EZERepository

#Import-Module PowerShellGet
#Get-Command PowerShellGet


<#
#Register a default repository
Register-PSRepository –Name DemoRepo –SourceLocation “https://www.myget.org/F/powershellgetdemo/api/v2” –PublishLocation “<https://www.myget.org/F/powershellgetdemo/api/v2>/package” –InstallationPolicy –Trusted

\#Get all of the registered repositories
Get-PSRepository
Name SourceLocation
---- --------------
PSGallery https://msconfiggallery.cloudapp...
DemoRepo https://www.myget.org/F/powershe...

\#Search only the new repository for modules
Find-Module -Repository DemoRepo
Repository Version Name
---------- ------- ----
DemoRepo 1.0.1 xActiveDirectory
DemoRepo 1.1.1 SomeModule

\#By default, PowerShellGet operates against all registered repositories when none is specified. In this example, the “SomeModule” module is installed from the DemoRepo.
Install-Module SomeModule

\#Removing a repository
Unregister-PSRepository DemoRepo
#>

$RepoArgs = @{
    Name = 'EZERepository'
    SourceLocation = $RepositoryPath
    PublishLocation = $RepositoryPath
    InstallationPolicy = 'Trusted'
}

Register-PSRepository @RepoArgs

Get-PSRepository

$env:PSModulePath

#Install-Module Eze.CommonFunctions
#Import-Module CommonFunctions