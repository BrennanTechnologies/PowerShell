﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ServerRequest
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=ASTDEPLOY\SQLEXPRESS;Initial Catalog=ServerDeploy;Integrated Security=True");
            {
                con.Open();
                // SqlCommand cmd = new SqlCommand("Insert into ServerRequest values (@ServerName,@Description)",con);
                SqlCommand cmd = new SqlCommand("Insert into ServerRequest values (@ServerName,@Description,@Domain,@OUPath,@vCenter,@VMHost,@VMTemplate,@Datastore,@VLAN,@OS,@IPAddress,@SubnetMask,@DefaultGateway,@DNS,@NumCPU,@MemoryGB,@DiskGB,@Owner,@Team,@Environment1,@BackupType1,@ADAdminID,@ADAdminPassword,@GuestAdminID,@GuestAdminPassword)", con);

                cmd.Parameters.AddWithValue("ServerName", ServerName.Text);
                cmd.Parameters.AddWithValue("Description", Description.Text);
                cmd.Parameters.AddWithValue("Domain", Domain.SelectedValue);
                cmd.Parameters.AddWithValue("OUPath", OUPath.Text);
                cmd.Parameters.AddWithValue("vCenter", vCenter.SelectedValue);
                cmd.Parameters.AddWithValue("VMHost", VMHost.Text);
                cmd.Parameters.AddWithValue("VMTemplate", VMTemplate.Text);
                cmd.Parameters.AddWithValue("Datastore", Datastore.Text);
                cmd.Parameters.AddWithValue("VLAN", VLAN.Text);
                cmd.Parameters.AddWithValue("OS", OS.Text);
                cmd.Parameters.AddWithValue("IPAddress", IPAddress.Text);
                cmd.Parameters.AddWithValue("SubnetMask", SubnetMask.Text);
                cmd.Parameters.AddWithValue("DefaultGateway", DefaultGateway.Text);
                cmd.Parameters.AddWithValue("DNS", DNS.Text);
                cmd.Parameters.AddWithValue("NumCPU", NumCPU.SelectedValue);
                cmd.Parameters.AddWithValue("MemoryGB", MemoryGB.SelectedValue);
                cmd.Parameters.AddWithValue("DiskGB", DiskGB.Text);
                cmd.Parameters.AddWithValue("Owner", Owner.Text);
                cmd.Parameters.AddWithValue("Team", Team.Text);
                cmd.Parameters.AddWithValue("Environment1", Environment1.SelectedValue);
                cmd.Parameters.AddWithValue("BackupType1", BackupType1.SelectedValue);
                cmd.Parameters.AddWithValue("ADAdminID", ADAdminID.Text);
                cmd.Parameters.AddWithValue("ADAdminPassword", ADAdminPassword.Text);
                cmd.Parameters.AddWithValue("GuestAdminID", GuestAdminID.Text);
                cmd.Parameters.AddWithValue("GuestAdminPassword", GuestAdminPassword.Text);
                

                cmd.ExecuteNonQuery();
                ServerName.Text = "";
                Description.Text = "";
                Domain.SelectedValue = "";
                OUPath.Text = "";
                vCenter.SelectedValue = "";
                VMHost.Text = "";
                VMTemplate.Text = "";
                Datastore.Text = "";
                VLAN.Text = "";
                OS.Text = "";
                IPAddress.Text = "";
                SubnetMask.Text = "";
                DefaultGateway.Text = "";
                DNS.Text = "";
                NumCPU.SelectedValue = "";
                MemoryGB.SelectedValue = "";
                DiskGB.Text = "";
                Owner.Text = "";
                Team.Text = "";
                Environment1.SelectedValue = "";
                BackupType1.SelectedValue = "";
                ADAdminID.Text = "";
                ADAdminPassword.Text = "";
                GuestAdminID.Text = "";
                GuestAdminPassword.Text = "";

            }
        }

       // Response.Redirect("Confirm.aspx");
    }


}